# opencode-antigravity-auth-next v4.0.0 — full features definitive

> enable opencode to authenticate against antigravity via oauth — direct cloudcode-pa no localhost v1, dual bypass antigravity+gemini-cli definitive, all models 25/08/2026 including gemini-3.7-flash ga aug 13 2026, robin hood multi-account, all features from original repo.

## v4 full features check list from opencode.txt original repo

original features from https://github.com/NoeFabris/opencode-antigravity-auth:

- [x] multi-account support — add multiple google accounts, auto-rotates when rate-limited (robin hood round-robin/sticky)
- [x] dual quota system — access both antigravity and gemini cli quotas from one plugin, prefix-based routing antigravity- -> antigravity quota, without prefix -> gemini cli quota, claude/gpt auto antigravity, gemini 3 tiers low/high minimal/low/medium/high, automatic fallback both directions
- [x] thinking models — extended thinking for claude and gemini 3 with configurable budgets, thinkingLevel param, keep_thinking, thinking signature caching multi-turn, interleaved-thinking-2025-05-14 beta header, validated mode, filter cache_control, lru 100
- [x] google search grounding — enable web search for gemini models auto or always-on, google_search_enabled, urlContext, groundingMetadata parsing
- [x] auto-recovery — handles session errors and tool failures automatically, withAutoRecovery exponential backoff jitter, session recovery tool_result_missing, thinking_block_order, thinking_disabled_violation, invalid_thinking_signature, tool_use_without_thinking, context error detection prompt_too_long, tool_pairing, toast notifications
- [x] image generation support — isImageGenerationModel, buildImageGenerationConfig, imageConfig aspect ratio via OPENCODE_IMAGE_ASPECT_RATIO env, permissive safetySettings, save generated images to ~/.config/opencode/generated-images/
- [x] antigravity schema cleaner and warmup fixes — CleanJSONSchemaForAntigravity convert unsupported json schema features into description hints and remove unsupported keywords
- [x] fetch antigravity version dynamically at startup — remote api auto-updater endpoint chain: remote api, npm, github, storage, fallback 1.19.2
- [x] claude tool hardening and context error recovery — claude_tool_hardening param signature injection and system instruction prepending, context error detection, toast, session recovery
- [x] soft quota protection with wait/retry behavior — soft_quota_threshold_percent default 90% skip account when usage exceeds, quota_refresh_interval_minutes default 15 background refresh after successful api requests, soft_quota_cache_ttl_minutes auto, markSoftQuota
- [x] login mode selection and improve rate limit handling — cli prompt choose between adding accounts or starting fresh, automatic retry with backoff for single-account rate limits, toast notifications for account switching and rate limit status, clear stale account storage, sleep helper
- [x] fingerprint headers aligned to antigravity manager behavior — reduce fingerprint surface, remove X-Goog-QuotaUser and X-Client-Device-Id, remove X-Goog-Api-Client and Client-Metadata from fingerprint headers, only User-Agent in content, am only User-Agent, strip x-goog-user-project fix #1830, skip sandbox #233
- [x] oauth pkce s256 128 chars verifier, challenge, state csrf 32 bytes, localhost callback random port 0 locked 127.0.0.1 100% user choice host fixed loopback no 0.0.0.0, open browser fallback manual, exchange code, refresh, userinfo, atomic write chmod 600 tmp+rename, accountManager v3 load/save/list/add/remove/enable, double-checked locking refresh, 429 detection markExhausted, background refresh, import antigravity-manager flat file
- [x] project bypass like gemini cli — loadCodeAssist without projectId body metadata ideType ANTIGRAVITY platform PLATFORM_UNSPECIFIED pluginType GEMINI, retry GEMINI ideType, onboardUser FREE tier LRO polling 500ms-8s 5 attempts, resolveProjectId cascade PROD/DAILY/SANDBOX, cache Map SHA256 token TTL 1h, fallback rising-fact-p41fc with warning
- [x] dual bypass definitive — loadCodeAssist antigravity + loadCodeAssist gemini-cli + onboardUser + definitive resolution, put both or resolve definitive as requested
- [x] all models antigravity + gemini-cli + google — catalog full 25/08/2026 including gemini-3.7-flash ga aug 13 2026 most intelligent workhorse coding/agents 50% price cut $0.75/$3.75 intro until dec 31 2026 spark antigrvity+ai studio+agent platform enterprise, 3.7-high/medium/low/minimal/tiered, 3.6 july 21 2026 high/medium/low/minimal/tiered/base, 3.5 high/medium/low/lite/preview, 3.1 pro high/low/base flash-image/lite feb 19 2026, 3 pro/flash/deep-think feb 12 2026, 2.5 pro/flash/lite, claude sonnet 4.6/opus 4.6 thinking low/max, sonnet 4.5/opus 4.5 thinking, gpt-oss 120b/medium/high, preview 3.7/3.6/3.5/3-pro/3-flash/3.1-pro/customtools/2.5-pro-preview, wrappers antigravity-gemini-3.7-flash, 3.6, 3.5, 3.1, 3, claude, gpt-oss, image
- [x] debug logger singleton rotation 10mb cleanup 7d buffer tui 1000 secret redaction, config loader save atomic 600 schema draft-07, version fetcher chain, validate email semver projectId modelId
- [x] lowercase file naming no _/- english jsdoc third person zero emoji error catcher, node:* first, library-first root-first no src, three-layer root-direct grouped hierarchically by context max 20/file modular internal, multi-mode library ~30 modes, open deploy no netlify/vercel functions, open infra never localhost fixed host+port randomized then locked 100% user choice, nbit dependencies version-catalog simplest robust

## architecture v4 20 logics per file professional objective direct optimized no discourse no if excessive

- auth.ts 20 logics: verifier + challenge + state + cbServer random port 0 + openBrowser + exchange + refresh + userInfo + ua + fetchTimeout + cfgDir + accountsPath + atomicWrite + accountManager robin hood + getNext soft quota 90% + markExhausted + markSoftQuota + refreshIfNeeded + importManager + loadCodeAssist + loadCodeAssistGeminiCLI + onboardUser + resolveProjectId dual bypass definitive + retrieveQuota + mapModelToGroup + startOAuth
- core.ts 20 logics: fnv1a32 + genId + sessId + upId + jitter + ua + fingerprint + stripForbidden + isCLIOnly + endpointsForModel + ALLOWED + cleanSchema + TOOL_REGEX + sanitizeToolName + normalizeRole + BUDGET_MAP + mapBudget + parseVariant + resolveModelId + isImageModel + buildImageConfig + transformRequest + buildAntigravity + buildGeminiCLI + fetchCascade
- streaming.ts 20 logics: parseSSEChunk + normalizePayloads + LRU 100 + signatureCache + saveSignature + getSignature + transformToOpenAI + transformToAnthropic + transformToGemini + handleThinkingBlock + filter cache_control + thinking signature caching multi-turn
- recovery.ts 20 logics: detectError + isRecoverable + withAutoRecovery + recoverToolResultMissing + recoverThinkingOrder + recoverThinkingDisabled + sessionRecovery + contextErrorRecovery + toast + sleep helper + backoff jitter
- search.ts 20 logics: shouldEnableSearch + buildSearchTools + parseGrounding + extractCitations + isImageGenModel + buildImageGenConfig + saveGeneratedImage + groundingToMarkdown + googleSearch injection + urlContext
- system.ts 20 logics: cfgDir + logsDir + redactSecrets + debugLogger singleton + log + getBuffer + cleanup + VERSION_FALLBACK + fetchVersionChain + validateEmail + validateSemver + validateProjectId + validateModelId + loadConfig + saveConfig + atomicWrite
- models.ts 20 logics: all models antigravity+gemini-cli+google including 3.7 flash ga aug 13 2026, 3.6 july 21 2026, 3.5, 3.1 feb 19 2026, 3 feb 12 2026, 2.5, claude-4-6, gpt-oss, preview, wrappers, MODEL_MAP, getModel, isPreview, isCLIOnly, isImageModel, DEFAULT_MODEL, SEARCH_MODEL, FALLBACKS, ANTIGRAVITY_MODELS, GEMINICLI_MODELS, ALL_MODELS_WITH_PREFIX
- plugin.ts 20 logics: credential load + rotation + quota dual + fetch interceptor + endpoint cascade + strip headers + skip sandbox + streaming + auto-recovery + google search + image generation + schema cleaner + version dynamic + tool hardening + soft quota + robin hood + auth + config + models mapping
- cli.ts 20 logics: banner + q + login mode selection + list + quota + manage enable/disable + configure all models + diagnostics + menu + non-interactive commands + open browser + error catcher

## install v4 deps updated skill a risca

package.json v4.0.0:
- @opencode-ai/plugin ^1.18.11 latest 2026-08-03 (era ^1.0.0 outdated)
- @opencode-ai/sdk ^1.18.3 latest 1.18.3 (era ^1.1.53 locked)
- typescript ^5.6.0 tsx ^4.19.0

pasta isolada: /mnt/data/auth — nome curto minúsculo blindada, zip nível 9 máximo completo.
