/**
 * @file index.ts v4 barrel esm library-first ~30 modes, all features, lowercase.
 */
export * as auth from "./auth.js";
export * from "./auth.js";
export * as core from "./core.js";
export * from "./core.js";
export * as streaming from "./streaming.js";
export * from "./streaming.js";
export * as recovery from "./recovery.js";
export * from "./recovery.js";
export * as search from "./search.js";
export * from "./search.js";
export * as system from "./system.js";
export * from "./system.js";
export * as models from "./models.js";
export * from "./models.js";
export * as pluginModule from "./plugin.js";
export * from "./plugin.js";
export * as cli from "./cli.js";
export * from "./cli.js";
import plugin from "./plugin.js";
export default plugin;
export { default as plugin } from "./plugin.js";
export const VERSION="4.0.0" as const;
export const PLUGIN_ID="opencode-antigravity-auth-next" as const;
export { getPlugin } from "./plugin.js";
