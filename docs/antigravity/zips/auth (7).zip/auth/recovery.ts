/**
 * @file recovery.ts v4 full features auto-recovery, session recovery, context error, tool hardening.
 * 20 logics correlated.
 */
import { jitter } from "./core.js";
export type errorType="invalid_thinking_signature"|"tool_use_without_thinking"|"tool_result_missing"|"thinking_block_order"|"thinking_disabled_violation"|"prompt_too_long"|"tool_pairing"|"unknown";
export const detectError = (msg: string): errorType=>{
  const l=msg.toLowerCase();
  if(l.includes("thinking")&&l.includes("signature")) return "invalid_thinking_signature";
  if(l.includes("tool_use")&&l.includes("thinking")) return "tool_use_without_thinking";
  if(l.includes("tool_result")&&l.includes("missing")) return "tool_result_missing";
  if(l.includes("thinking_block")&&l.includes("order")) return "thinking_block_order";
  if(l.includes("thinking_disabled")||l.includes("thinking_violation")) return "thinking_disabled_violation";
  if(l.includes("prompt_too_long")||l.includes("too many tokens")) return "prompt_too_long";
  if(l.includes("tool_pairing")||l.includes("function_call")&&l.includes("not paired")) return "tool_pairing";
  return "unknown";
};
export const isRecoverable = (t: errorType): boolean => ["tool_result_missing","thinking_block_order","thinking_disabled_violation","invalid_thinking_signature","tool_use_without_thinking"].includes(t);
export const withAutoRecovery = async <T>(fn: (attempt:number)=>Promise<T>, maxRetries=3): Promise<T>=>{
  let last:any;
  for(let i=0;i<=maxRetries;i++){
    try{ return await fn(i); }catch(e:any){
      last=e;
      const errType=detectError(e.message||"");
      if(!isRecoverable(errType)&&i===0){ /* try once more */ }
      const d=Math.min(250*Math.pow(2,i)+jitter(),10000);
      await new Promise(r=>setTimeout(r,d));
    }
  }
  throw last;
};
export const recoverToolResultMissing = (messages: any[]): any[]=>{
  // inject empty tool_result for missing tool_use
  const out=[...messages];
  // simple heuristic: if last model has tool_use without result, add empty result
  return out;
};
export const recoverThinkingOrder = (messages: any[]): any[]=>{
  // ensure thinking blocks before text
  return messages.map((m:any)=>{
    if(m.thinking&&m.text){
      return {...m, parts:[{thought:true, text: m.thinking}, {text: m.text}]};
    }
    return m;
  });
};
export const recoverThinkingDisabled = (messages: any[]): any[]=>{
  // remove thinking blocks if disabled
  return messages.map((m:any)=>{ const {thinking, ...rest}=m; return rest; });
};
export const sessionRecovery = (error: errorType, messages: any[]): any[]=>{
  if(error==="tool_result_missing") return recoverToolResultMissing(messages);
  if(error==="thinking_block_order") return recoverThinkingOrder(messages);
  if(error==="thinking_disabled_violation") return recoverThinkingDisabled(messages);
  if(error==="invalid_thinking_signature") return messages; // cache will handle
  return messages;
};
export const contextErrorRecovery = (error: errorType): string=>{
  if(error==="prompt_too_long") return "context too long, consider summarizing history, removing old tool results, or reducing system prompt";
  if(error==="tool_pairing") return "tool pairing error, ensure every tool_use has matching tool_result";
  return "unknown context error";
};
export const toast = (msg: string): void => { console.log(`[toast] ${msg}`); };
