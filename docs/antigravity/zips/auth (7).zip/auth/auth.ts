/**
 * @file auth.ts v4 full features multi-account robin hood dual bypass antigravity+gemini-cli.
 * 20 logics correlated, lowercase, node:* first, direct cloudcode-pa, 25/08/2026 v4.
 */
import { createHash, randomBytes, randomInt } from "node:crypto";
import { createServer } from "node:http";
import { homedir, platform, arch } from "node:os";
import { join } from "node:path";
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync, renameSync, unlinkSync } from "node:fs";
import { exec } from "node:child_process";
export const genVerifier = (): string => { const c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"; let v=""; const b=randomBytes(96); for(let i=0;i<128;i++) v+=c[b[i % b.length] % c.length]; return v; };
export const genChallenge = (v: string): string => createHash("sha256").update(v).digest().toString("base64url");
export const genState = (): string => randomBytes(32).toString("base64url");
export type cbres={code:string; state:string};
export const cbServer = (ms=300000): Promise<{port:number; wait:Promise<cbres>; close:()=>void}> => new Promise((res, rej)=>{
  let r!: (v:cbres)=>void; let j!: (e:Error)=>void; const wait=new Promise<cbres>((a,b)=>{ r=a; j=b; });
  const srv=createServer((req, rsp)=>{
    const u=new URL(req.url||"", "http://127.0.0.1");
    if(u.pathname==="/callback"){
      const code=u.searchParams.get("code"); const state=u.searchParams.get("state"); const err=u.searchParams.get("error");
      if(err){ rsp.writeHead(400,{"Content-Type":"text/html"}); rsp.end(err); j(new Error(err)); return; }
      if(code){ rsp.writeHead(200,{"Content-Type":"text/html"}); rsp.end("<h1>ok</h1><script>window.close()</script>"); r({code, state: state||""}); }
      else{ rsp.writeHead(400); rsp.end("missing"); }
    } else{ rsp.writeHead(404); rsp.end(); }
  });
  srv.listen(0,"127.0.0.1",()=>{
    const a=srv.address() as any; const port=a.port;
    const t=setTimeout(()=>{ try{srv.close();}catch{}; j(new Error("timeout")); }, ms);
    (t as any).unref?.();
    res({port, wait, close:()=>{ clearTimeout(t); try{srv.close();}catch{}}});
  });
  srv.on("error", rej); srv.unref();
});
export const openBrowser = (url: string): void => { const p=platform(); const cmd=p==="darwin"? `open "${url}"`: p==="win32"? `start "" "${url}"`: `xdg-open "${url}"`; exec(cmd,()=>{}); console.log(`open:\n${url}`); };
export const CLIENT_ID=process.env.ANTIGRAVITY_CLIENT_ID?.trim()||"1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com";
export const CLIENT_SECRET=process.env.ANTIGRAVITY_CLIENT_SECRET?.trim()||"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";
export const AUTH_URL="https://accounts.google.com/o/oauth2/v2/auth";
export const TOKEN_URL="https://oauth2.googleapis.com/token";
export const USERINFO_URL="https://www.googleapis.com/oauth2/v2/userinfo";
export const SCOPES=["openid","email","profile","https://www.googleapis.com/auth/cloud-platform","https://www.googleapis.com/auth/userinfo.email","https://www.googleapis.com/auth/userinfo.profile","https://www.googleapis.com/auth/cclog","https://www.googleapis.com/auth/experimentsandconfigs"].join(" ");
export type tokenres={access_token:string; refresh_token?:string; expires_in?:number; id_token?:string};
export const ua = (v="1.19.2"): string => { const p=platform()==="win32"?"win32":platform(); const a=arch()==="arm64"?"arm64":arch(); return `antigravity/${v} ${p}/${a}`; };
export const fetchTimeout = async (url: string, init: RequestInit, ms=10000): Promise<Response> => { const c=new AbortController(); const t=setTimeout(()=>c.abort(), ms); try{ return await fetch(url,{...init, signal: c.signal}); } finally{ clearTimeout(t);} };
export const exchangeCode = async (code: string, ver: string, redir: string): Promise<tokenres> => { const b=new URLSearchParams({code, client_id: CLIENT_ID, client_secret: CLIENT_SECRET, redirect_uri: redir, grant_type:"authorization_code", code_verifier: ver}); const r=await fetchTimeout(TOKEN_URL,{method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent": ua()}, body: b.toString()}); if(!r.ok) throw new Error(await r.text()); return await r.json() as tokenres; };
export const refreshToken = async (rt: string): Promise<tokenres> => { const b=new URLSearchParams({client_id: CLIENT_ID, client_secret: CLIENT_SECRET, refresh_token: rt, grant_type:"refresh_token"}); const r=await fetchTimeout(TOKEN_URL,{method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent": ua()}, body: b.toString()}); if(!r.ok) throw new Error(await r.text()); return await r.json() as tokenres; };
export const userInfo = async (at: string): Promise<{email:string}> => { const r=await fetchTimeout(USERINFO_URL,{headers:{Authorization:`Bearer ${at}`, "User-Agent": ua()}}); if(!r.ok) throw new Error("userinfo"); const j:any=await r.json(); return {email: j.email}; };
export const cfgDir = (): string => process.env.OPENCODE_CONFIG_DIR?.trim()||join(homedir(),".config","opencode");
export const accountsPath = (): string => join(cfgDir(),"antigravity-accounts.json");
export const atomicWrite = (p: string, c: string): void => { try{ mkdirSync(cfgDir(),{recursive:true, mode:0o700}); }catch{} const tmp=`${p}.tmp-${process.pid}-${randomInt(1000000)}`; writeFileSync(tmp, c,{encoding:"utf8", mode:0o600}); try{ chmodSync(tmp,0o600);}catch{} try{ renameSync(tmp, p);}catch{ writeFileSync(p, c,{encoding:"utf8", mode:0o600}); try{ unlinkSync(tmp);}catch{} } try{ chmodSync(p,0o600);}catch{} };
export type account={email:string; refreshToken:string; accessToken?:string; expiry?:number; projectId?:string; disabled?:boolean; quotaExhaustedUntil?:number; softQuotaUntil?:number; remaining?:number; limit?:number;};
export class accountManager{
  private acc: account[]=[]; private locks=new Map<string,Promise<account>>(); private idx=0; private sticky:string|null=null;
  async load(): Promise<void>{ try{ const p=accountsPath(); if(!existsSync(p)){ this.acc=[]; return;} const raw=readFileSync(p,"utf8"); const j=JSON.parse(raw); this.acc=Array.isArray(j)? j.map((a:any)=>({email:a.email, refreshToken:a.refresh_token||a.refreshToken, accessToken:a.access_token||a.accessToken, expiry:a.expiry, projectId:a.projectId, disabled:a.disabled, quotaExhaustedUntil:a.quotaExhaustedUntil, softQuotaUntil:a.softQuotaUntil})): j.accounts&&Array.isArray(j.accounts)? j.accounts: j.version===3&&j.accounts? Object.values(j.accounts) as any: []; }catch{ this.acc=[]; } }
  async save(): Promise<void>{ atomicWrite(accountsPath(), JSON.stringify(this.acc,null,2)); }
  list(): account[]{ return this.acc; }
  async add(a: account): Promise<void>{ this.acc=this.acc.filter(x=>x.email!==a.email); this.acc.push(a); await this.save(); }
  async remove(email: string): Promise<void>{ this.acc=this.acc.filter(x=>x.email!==email); await this.save(); }
  async enable(email: string, en=true): Promise<void>{ const a=this.acc.find(x=>x.email===email); if(a){ a.disabled=!en; await this.save(); } }
  // robin hood round-robin + sticky + soft quota 90% + quota exhausted
  getNext(strategy: "round-robin"|"sticky"="round-robin", softThreshold=90): account|null{
    const now=Date.now();
    const active=this.acc.filter(a=>!a.disabled&&(!a.quotaExhaustedUntil||now>a.quotaExhaustedUntil)&&(!a.softQuotaUntil||now>a.softQuotaUntil));
    if(active.length===0) return null;
    // soft quota check
    const filtered=active.filter(a=>{
      if(!a.remaining||!a.limit) return true;
      const usedPct=((a.limit-a.remaining)/a.limit)*100;
      return usedPct < softThreshold;
    });
    const pool=filtered.length>0? filtered: active;
    if(strategy==="sticky"&&this.sticky){ const f=pool.find(a=>a.email===this.sticky); if(f) return f; }
    const acc=pool[this.idx % pool.length]; this.idx=(this.idx+1)%pool.length; this.sticky=acc.email; return acc;
  }
  markExhausted(email: string, ms=3600000): void{ const a=this.acc.find(x=>x.email===email); if(a){ a.quotaExhaustedUntil=Date.now()+ms; this.save().catch(()=>{}); } }
  markSoftQuota(email: string, ms=900000): void{ const a=this.acc.find(x=>x.email===email); if(a){ a.softQuotaUntil=Date.now()+ms; this.save().catch(()=>{}); } }
  async refreshIfNeeded(email: string): Promise<string>{ const acc=this.acc.find(a=>a.email===email); if(!acc) throw new Error("not found"); if(acc.accessToken&&acc.expiry&&Date.now()<acc.expiry-300000) return acc.accessToken; if(this.locks.has(email)) return (await this.locks.get(email)!)!.accessToken!; const p=(async()=>{ const t=await refreshToken(acc.refreshToken); acc.accessToken=t.access_token; acc.expiry=Date.now()+(t.expires_in??3600)*1000; await this.save(); return acc; })(); this.locks.set(email,p); try{ const r=await p; return r.accessToken!; } finally{ this.locks.delete(email);} }
  async importManager(): Promise<number>{ const cands=[join(homedir(),".config","antigravity-manager","accounts.json"), join(homedir(),".antigravity-manager","accounts.json")]; let add=0; for(const c of cands){ try{ if(!existsSync(c)) continue; const raw=readFileSync(c,"utf8"); const j=JSON.parse(raw); const arr=Array.isArray(j)?j: j.accounts||[]; for(const x of arr){ const email=x.email; const rt=x.refresh_token||x.refreshToken; if(email&&rt&&!this.acc.find(a=>a.email===email)){ this.acc.push({email, refreshToken:rt}); add++; } } }catch{} } if(add>0) await this.save(); return add; }
}
export const ENDPOINTS=["https://daily-cloudcode-pa.googleapis.com","https://autopush-cloudcode-pa.sandbox.googleapis.com","https://cloudcode-pa.googleapis.com"] as const;
export const FALLBACK_PROJECT="rising-fact-p41fc" as const;
export const isRetryable = (s: number): boolean => s===403||s===404||s===408||s===429||s>=500;
export const loadCodeAssist = async (at: string, ep=ENDPOINTS[0]): Promise<string|null> => {
  for(const base of [ep, ...ENDPOINTS.filter(e=>e!==ep)]){
    try{
      const r=await fetchTimeout(`${base}/v1internal:loadCodeAssist`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua()}, body: JSON.stringify({metadata:{ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!r.ok){ if(isRetryable(r.status)) continue; return null; }
      const j:any=await r.json(); const proj=j.cloudaicompanionProject||j.project||j.cloudaicompanionProjectId;
      if(!proj) continue;
      if(typeof proj==="string") return proj.includes("/")? proj.split("/").pop()! : proj;
      if(proj.id) return proj.id;
      if(proj.projectId) return proj.projectId;
      if(proj.name) return proj.name.split("/").pop();
    }catch{ continue; }
  }
  return null;
};
export const loadCodeAssistGeminiCLI = async (at: string): Promise<string|null> => {
  for(const base of ENDPOINTS){
    try{
      const r=await fetchTimeout(`${base}/v1internal:loadCodeAssist`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua(), "X-Goog-Api-Client": `antigravity/1.19.2 gl-node/${process.versions.node}`}, body: JSON.stringify({metadata:{ideType:"GEMINI", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!r.ok) continue;
      const j:any=await r.json(); const proj=j.cloudaicompanionProject||j.project;
      if(!proj) continue;
      if(typeof proj==="string") return proj;
      if(proj.id) return proj.id;
    }catch{ continue; }
  }
  return null;
};
export const onboardUser = async (at: string): Promise<boolean> => {
  for(const base of ENDPOINTS){
    try{
      const r=await fetchTimeout(`${base}/v1internal:onboardUser`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua()}, body: JSON.stringify({tierId:"FREE", metadata:{ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!r.ok) continue;
      const j:any=await r.json(); const op=j.name||j.operation?.name;
      if(!op) return true;
      let d=500;
      for(let i=0;i<5;i++){ await new Promise(x=>setTimeout(x,d)); const poll=await fetchTimeout(`${base}/v1internal:operations/${op.split("/").pop()}`,{headers:{Authorization:`Bearer ${at}`,"User-Agent": ua()}}); if(poll.ok){ const pj:any=await poll.json(); if(pj.done) return true; } d=Math.min(d*2,8000); }
      return true;
    }catch{ continue; }
  }
  return false;
};
export const resolveProjectId = async (at: string, cached?: string): Promise<string> => {
  if(cached&&cached!==FALLBACK_PROJECT) return cached;
  // try antigravity bypass first then gemini-cli bypass definitive
  const ag=await loadCodeAssist(at);
  if(ag) return ag;
  const cli=await loadCodeAssistGeminiCLI(at);
  if(cli) return cli;
  const onboard=await onboardUser(at);
  if(onboard){ const a2=await loadCodeAssist(at); if(a2) return a2; const c2=await loadCodeAssistGeminiCLI(at); if(c2) return c2; }
  return FALLBACK_PROJECT;
};
export const retrieveQuota = async (at: string, pid=FALLBACK_PROJECT): Promise<{remaining:number; limit:number; used:number}|null> => {
  for(const base of ENDPOINTS){
    try{
      const r=await fetchTimeout(`${base}/v1internal:retrieveUserQuotaSummary`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua()}, body: JSON.stringify({project:`projects/${pid}`})},15000);
      if(!r.ok){ if(isRetryable(r.status)) continue; return null; }
      const j:any=await r.json();
      return {remaining: Number(j.remainingQuota??j.remaining??100), limit: Number(j.limit??1000), used: Number(j.used??0)};
    }catch{ continue; }
  }
  return null;
};
export const mapModelToGroup = (m: string): "antigravity"|"gemini-cli" => { const l=m.toLowerCase(); if(l.includes("preview")||l.startsWith("gemini-3.7")||l.startsWith("gemini-3.6")||l.startsWith("gemini-3.5")||l.startsWith("gemini-3.1")||l.startsWith("gemini-3")) return "gemini-cli"; return "antigravity"; };
export const startOAuth = async (): Promise<tokenres & {email?: string}> => {
  const ver=genVerifier(); const chal=genChallenge(ver); const state=genState();
  const {port, wait, close}=await cbServer();
  const redir=`http://127.0.0.1:${port}/callback`;
  const url=`${AUTH_URL}?client_id=${encodeURIComponent(CLIENT_ID)}&redirect_uri=${encodeURIComponent(redir)}&response_type=code&scope=${encodeURIComponent(SCOPES)}&code_challenge=${encodeURIComponent(chal)}&code_challenge_method=S256&state=${encodeURIComponent(state)}&access_type=offline&prompt=consent`;
  openBrowser(url);
  const {code}=await wait; close();
  const toks=await exchangeCode(code, ver, redir);
  let email: string|undefined;
  try{ const info=await userInfo(toks.access_token); email=info.email; }catch{}
  return {...toks, email};
};
