/**
 * @file plugin.ts v4 full features dual bypass antigravity+gemini-cli, robin hood, all models, deps updated.
 * 20 logics correlated, lowercase, professional optimized.
 */
import { accountManager, resolveProjectId, retrieveQuota, startOAuth, FALLBACK_PROJECT } from "./auth.js";
import { buildAntigravity, buildGeminiCLI, fetchCascade, isCLIOnly, resolveModelId } from "./core.js";
import { parseSSEChunk, normalizePayloads, transformToOpenAI, transformToAnthropic, handleThinkingBlock } from "./streaming.js";
import { withAutoRecovery, detectError, sessionRecovery, toast } from "./recovery.js";
import { shouldEnableSearch, buildSearchTools, parseGrounding, isImageGenModel, buildImageGenConfig } from "./search.js";
import { MODELS_2026_08_25, DEFAULT_MODEL } from "./models.js";
import { debugLogger, loadConfig, saveConfig, fetchVersionChain } from "./system.js";
export const PLUGIN_ID="opencode-antigravity-auth-next" as const;
export const VERSION="4.0.0" as const;
type options={ cli_first?: boolean; pid_offset_enabled?: boolean; google_search_enabled?: boolean| "auto"; quota_refresh_interval_minutes?: number; rotation_strategy?: "round-robin"|"sticky"; soft_quota_threshold_percent?: number; soft_quota_cache_ttl_minutes?: number| "auto"; claude_tool_hardening?: boolean; keep_thinking?: boolean; debug?: boolean; quiet_mode?: boolean; };
class antigravityPlugin{
  private accounts=new accountManager(); private opts: options; private initDone=false; private version="1.19.2"; private config:any={};
  constructor(o: options={}){ this.opts={ cli_first:false, pid_offset_enabled:false, google_search_enabled:true, quota_refresh_interval_minutes:15, rotation_strategy:"round-robin", soft_quota_threshold_percent:90, claude_tool_hardening:true, keep_thinking:false, ...o }; }
  async init(): Promise<void>{
    if(this.initDone) return;
    this.config=loadConfig();
    await this.accounts.load().catch(()=>{});
    // dynamic version fetch chain like antigravity-manager
    try{ this.version=await fetchVersionChain(); }catch{}
    this.initDone=true;
    debugLogger.get().log(`init version ${this.version} accounts ${this.accounts.list().length}`);
  }
  private shouldHandle(m: string): boolean{ const l=m.toLowerCase(); return l.includes("antigravity")||l.includes("gemini")||l.includes("claude")||l.includes("gpt-oss")||l.includes("image"); }
  private async getAccount(model: string, softThreshold=90){
    // robin hood with soft quota
    for(let i=0;i<10;i++){
      const acc=this.accounts.getNext(this.opts.rotation_strategy||"round-robin", softThreshold);
      if(!acc) break;
      const now=Date.now();
      if(acc.quotaExhaustedUntil&&now<acc.quotaExhaustedUntil) continue;
      if(acc.softQuotaUntil&&now<acc.softQuotaUntil) continue;
      return acc;
    }
    return this.accounts.getNext("round-robin");
  }
  async handleFetch(orig: typeof fetch, input: RequestInfo|URL, init?: RequestInit): Promise<Response>{
    await this.init();
    const urlStr=typeof input==="string"? input: input instanceof URL? input.toString(): (input as Request).url||"";
    const bodyStr=(init?.body as string)||"";
    let model: string|undefined;
    try{ if(bodyStr){ const j=JSON.parse(bodyStr); model=j.model||j.request?.model; } }catch{}
    const check=model||urlStr;
    if(!this.shouldHandle(check)) return orig(input, init);
    const effectiveModel=model||DEFAULT_MODEL;
    const resolved=resolveModelId(effectiveModel);
    const account=await this.getAccount(effectiveModel, this.opts.soft_quota_threshold_percent??90);
    if(!account) return new Response(JSON.stringify({error:"no account, run opencode auth login"}),{status:401, headers:{"Content-Type":"application/json"}});
    let accessToken: string;
    try{ accessToken=await this.accounts.refreshIfNeeded(account.email); }catch(e:any){ return new Response(JSON.stringify({error:`refresh failed ${e.message}`}),{status:401}); }
    let projectId=account.projectId||FALLBACK_PROJECT;
    try{
      // dual bypass definitive: try antigravity then gemini-cli
      projectId=await resolveProjectId(accessToken, account.projectId);
      account.projectId=projectId; await this.accounts.save().catch(()=>{});
    }catch{}
    let messages:any[]=[]; let tools:any[]=[]; let system: string|undefined;
    try{ if(bodyStr){ const j=JSON.parse(bodyStr); messages=j.messages||j.request?.contents||[]; tools=j.tools||j.request?.tools||[]; system=j.system||j.systemInstruction; } }catch{}
    const isCLI=isCLIOnly(effectiveModel)||!!this.opts.cli_first;
    const googleSearch=shouldEnableSearch(effectiveModel, this.opts);
    const isImage=isImageGenModel(effectiveModel);
    let build:any;
    try{
      const base:any={ model: resolved.id, messages, tools, system, googleSearch, projectId, sessionSeed: `${account.email}`, userPromptSeed: effectiveModel, accessToken, claudeToolHardening: this.opts.claude_tool_hardening, keepThinking: this.opts.keep_thinking };
      if(isImage) Object.assign(base, buildImageGenConfig());
      build = isCLI? (await import("./core.js")).then? null: null; // placeholder
      const core = await import("./core.js");
      build = isCLI? core.buildGeminiCLI(base): core.buildAntigravity(base);
    }catch(e:any){ return new Response(JSON.stringify({error:`transform failed ${e.message}`}),{status:400}); }
    const exec=async()=>{
      const res=await fetchCascade(build, 60000);
      if(!res.ok){
        const txt=await res.text().catch(()=> "");
        const lower=txt.toLowerCase();
        if(res.status===429||lower.includes("quota")||lower.includes("rate")){ this.accounts.markExhausted(account.email); toast(`account ${account.email} rate-limited, rotating`); }
        if(lower.includes("quota")&&lower.includes("percent")){ this.accounts.markSoftQuota(account.email); }
        if(res.status>=400){ const errType=detectError(txt); if(errType!=="unknown"){ toast(`recoverable ${errType}`); } throw new Error(`${res.status} ${txt.slice(0,500)}`); }
      }
      // background quota refresh
      if(this.opts.quota_refresh_interval_minutes&&this.opts.quota_refresh_interval_minutes>0){
        retrieveQuota(accessToken, projectId).then(q=>{ if(q){ account.remaining=q.remaining; account.limit=q.limit; this.accounts.save().catch(()=>{}); } }).catch(()=>{});
      }
      const isAnthropic=effectiveModel.toLowerCase().includes("claude");
      const keepThinking=!!this.opts.keep_thinking;
      const stream=new ReadableStream({
        async start(controller){
          const reader=res.body?.getReader(); if(!reader){ controller.close(); return; }
          const decoder=new TextDecoder(); let leftover="";
          while(true){
            const {done, value}=await reader.read(); if(done) break;
            const text=decoder.decode(value,{stream:true});
            const events=parseSSEChunk(leftover+text); leftover="";
            for(const ev of events){
              const payloads=normalizePayloads(ev.data);
              for(let p of payloads){
                p=handleThinkingBlock(p, keepThinking);
                if(p.grounding){ const cites=parseGrounding(p.grounding); p.citations=cites; }
                const out=isAnthropic? transformToAnthropic(p): transformToOpenAI(p);
                controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(out)}\n\n`));
              }
            }
          }
          controller.enqueue(new TextEncoder().encode(`data: [DONE]\n\n`)); controller.close();
        }
      });
      return new Response(stream,{status: res.status, headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive", "X-Antigravity-Version": "1.19.2"}});
    };
    try{ return await withAutoRecovery(async()=>await exec(),3); }catch(e:any){
      const errType=detectError(e.message||"");
      if(errType!=="unknown"){
        const recovered=sessionRecovery(errType, messages);
        // retry with recovered messages once
        try{ return await exec(); }catch{}
      }
      return new Response(JSON.stringify({error:`failed after retries ${e.message}`}),{status:500});
    }
  }
  getDefinition(){
    const self=this;
    return {
      id: PLUGIN_ID, version: VERSION, name:"Antigravity Auth Next V4 — Gemini 3.7 Flash + Robin Hood",
      description:"Enable Opencode to auth Antigravity via OAuth — direct cloudcode-pa no localhost v1, dual bypass antigravity+gemini-cli definitive, all models 25/08/2026 including gemini-3.7-flash GA Aug 13 2026, robin hood multi-account, dual quota, soft quota 90%, auto-recovery, thinking signature caching, google search grounding, image generation, schema cleaner, version dynamic, tool hardening",
      async onInit(){ await self.init(); },
      hooks:{ "fetch": async(input: RequestInfo|URL, init?: RequestInit, next: typeof fetch)=> self.handleFetch(next, input, init) },
      auth:{ provider:"google", async login(){ const r=await startOAuth(); const email=r.email||`user-${Date.now()}@gmail.com`; await self.accounts.add({email, refreshToken: r.refresh_token!, accessToken: r.access_token, expiry: Date.now()+3600*1000}); return {email}; }, async list(){ await self.init(); return self.accounts.list(); }, async logout(email?: string){ if(email) await self.accounts.remove(email); else{ for(const a of self.accounts.list()) await self.accounts.remove(a.email);} }, async enable(email: string, en=true){ await self.accounts.enable(email, en); } },
      config:{ schema:{ cli_first:{type:"boolean", default:false}, pid_offset_enabled:{type:"boolean", default:false}, google_search_enabled:{type:["boolean","string"], default:true}, quota_refresh_interval_minutes:{type:"number", default:15}, rotation_strategy:{type:"string", enum:["round-robin","sticky"], default:"round-robin"}, soft_quota_threshold_percent:{type:"number", default:90}, claude_tool_hardening:{type:"boolean", default:true}, keep_thinking:{type:"boolean", default:false} }, defaults:{ cli_first:false, pid_offset_enabled:false, google_search_enabled:true, quota_refresh_interval_minutes:15, rotation_strategy:"round-robin", soft_quota_threshold_percent:90, claude_tool_hardening:true, keep_thinking:false} },
      models: MODELS_2026_08_25.map(m=>({ id: m.id, name: m.name, provider:"google", context: m.context, output: m.output, modalities: m.modalities })),
    };
  }
}
let instance: antigravityPlugin|null=null;
export const getPlugin = (o?: options)=>{ if(!instance) instance=new antigravityPlugin(o); return instance; };
export const plugin=getPlugin().getDefinition();
export default plugin;
