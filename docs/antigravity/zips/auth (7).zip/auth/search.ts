/**
 * @file search.ts v4 full features google search grounding, urlContext, image generation, grounding metadata.
 * 20 logics correlated.
 */
export const shouldEnableSearch = (model: string, cfg: any): boolean => {
  if(cfg?.google_search_enabled===true) return true;
  if(cfg?.google_search_enabled==="auto"){ const l=model.toLowerCase(); return l.includes("gemini")&&!l.includes("image"); }
  return false;
};
export const buildSearchTools = (): any[] => [{ googleSearch:{} }, { urlContext:{} }];
export const parseGrounding = (meta: any): {uri: string; title?: string}[]=>{ const chunks=meta?.groundingChunks||meta?.grounding_chunks||[]; return chunks.map((c:any)=>c.web? {uri: c.web.uri, title: c.web.title}: null).filter(Boolean); };
export const extractCitations = (grounding: any[]): string => grounding.map(g=>`[${g.title||"source"}](${g.uri})`).join("\n");
export const isImageGenModel = (m: string): boolean => m.toLowerCase().includes("image")||m.includes("3.1-flash-image");
export const buildImageGenConfig = (aspect?: string): any => {
  const ar=aspect||process.env.OPENCODE_IMAGE_ASPECT_RATIO||"1:1";
  return {
    imageConfig:{ aspectRatio: ar },
    generationConfig:{ responseModalities:["TEXT","IMAGE"] },
    safetySettings:[{category:"HARM_CATEGORY_HARASSMENT", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_HATE_SPEECH", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_DANGEROUS_CONTENT", threshold:"BLOCK_NONE"}]
  };
};
export const saveGeneratedImage = async (b64: string, dir?: string): Promise<string> => {
  const { homedir } = await import("node:os");
  const { join } = await import("node:path");
  const { writeFileSync, mkdirSync } = await import("node:fs");
  const base=dir||join(homedir(),".config","opencode","generated-images");
  try{ mkdirSync(base,{recursive:true}); }catch{}
  const name=`img-${Date.now()}-${Math.random().toString(16).slice(2)}.png`;
  const path=join(base, name);
  const buf=Buffer.from(b64, "base64");
  writeFileSync(path, buf);
  return path;
};
export const groundingToMarkdown = (grounding: any[]): string => grounding.map(g=>`- [${g.title||g.uri}](${g.uri})`).join("\n");
