/**
 * @file streaming.ts v4 full features real-time sse, thinking signature caching, multi-turn, lru 100.
 * 20 logics correlated, lowercase.
 */
import { genId } from "./core.js";
export type sseEvent={ data: string };
export const parseSSEChunk = (chunk: string): sseEvent[]=>{ const ev:sseEvent[]=[]; const lines=chunk.split(/\r?\n/); let data:string[]=[]; for(const line of lines){ if(line.trim()===""){ if(data.length>0){ ev.push({data: data.join("\n")}); data=[]; } continue; } if(line.startsWith("data:")) data.push(line.slice(5).trimStart()); } if(data.length>0) ev.push({data: data.join("\n")}); return ev; };
export const normalizePayloads = (data: string): any[]=>{
  const out:any[]=[]; const t=data.trim(); if(!t) return out;
  try{
    const j=JSON.parse(t);
    const cand=j.candidates?.[0]||j;
    const parts=cand.content?.parts||[];
    let text=""; let thinking=""; let sig: string|undefined; const toolCalls:any[]=[];
    for(const p of parts){
      if(!p) continue;
      if(p.thought===true){ thinking+=p.text||""; sig=p.thoughtSignature||sig; }
      else if(p.text) text+=p.text;
      else if(p.functionCall) toolCalls.push({ id: genId(JSON.stringify(p.functionCall)), name: p.functionCall.name, args: p.functionCall.args });
    }
    out.push({ text: text||undefined, thinking: thinking? {text: thinking, signature: sig}: undefined, toolCalls: toolCalls.length>0? toolCalls: undefined, finishReason: cand.finishReason, raw:j, grounding: cand.groundingMetadata, safety: j.safetyRatings });
    return out;
  }catch{ return [{text: t, raw: t}]; }
};
export class LRU<K,V> extends Map<K,V>{ constructor(private max=100){ super(); } override set(k:K,v:V){ if(this.has(k)) this.delete(k); super.set(k,v); if(this.size>this.max){ const first=this.keys().next().value; if(first!==undefined) this.delete(first);} return this;} }
export const thinkingCache=new LRU<string,string>(100);
export const signatureCache=new Map<string,string>(); // session -> signature
export const saveSignature = (session: string, sig: string): void => { signatureCache.set(session, sig); thinkingCache.set(sig, sig); };
export const getSignature = (session: string): string|undefined => signatureCache.get(session);
export const transformToOpenAI = (p: any)=>{ const choice:any={index:0, delta:{}}; if(p.text) choice.delta.content=p.text; if(p.thinking) choice.delta.reasoning_content=p.thinking.text; if(p.toolCalls) choice.delta.tool_calls=p.toolCalls.map((tc:any)=>({id:tc.id, type:"function", function:{name:tc.name, arguments: JSON.stringify(tc.args)}})); if(p.finishReason) choice.finish_reason="stop"; return {id: genId(p.text||"openai"), object:"chat.completion.chunk", choices:[choice]}; };
export const transformToAnthropic = (p: any)=>{ if(p.thinking){ if(p.thinking.signature) saveSignature(p.thinking.signature, p.thinking.signature); return {type:"content_block_delta", delta:{type:"thinking_delta", thinking: p.thinking.text}}; } if(p.text) return {type:"content_block_delta", delta:{type:"text_delta", text: p.text}}; if(p.finishReason) return {type:"message_delta", delta:{stop_reason:"end_turn"}}; return {type:"message_delta", delta:{}}; };
export const transformToGemini = (p: any)=> p.raw||{candidates:[{content:{parts:[{text: p.text||""}]}}]};
export const handleThinkingBlock = (p: any, keepThinking=false): any => {
  if(!p.thinking) return p;
  // filter sdk-injected cache_control
  const cleaned={...p.thinking, text: p.thinking.text?.replace(/\[cache_control.*?\]/g, "")};
  if(keepThinking){ return {...p, thinking: cleaned}; }
  return {...p, thinking: cleaned};
};
