/**
 * @file cli.ts v4 full features login mode selection, multi-account robin hood, quotas, manage, configure all models.
 * 20 logics correlated, lowercase.
 */
import { createInterface } from "node:readline";
import { join } from "node:path";
import { existsSync, readFileSync, writeFileSync, chmodSync, mkdirSync } from "node:fs";
import { accountManager, retrieveQuota, startOAuth, cfgDir } from "./auth.js";
import { MODELS_2026_08_25 } from "./models.js";
import { debugLogger } from "./system.js";
const OPENCODE_JSON=join(cfgDir(),"opencode.json");
const banner = (): void=>{ console.log(`\n╔════════════════════════════════════════════════════╗\n║  opencode-antigravity-auth-next v4.0.0 — Gemini 3.7 Flash GA Aug 13 2026  ║\n║  Robin Hood multi-account + dual bypass antigravity+gemini-cli definitive  ║\n╚════════════════════════════════════════════════════╝\n`); };
const q = (rl:any, s:string): Promise<string>=> new Promise(res=>rl.question(s, (a:string)=>res(a)));
const login = async (): Promise<void>=>{
  console.log("[login] oauth pkce mode selection: 1 add accounts 2 start fresh");
  const rl=createInterface({input: process.stdin, output: process.stdout});
  const mode=await q(rl,"mode 1/2 [1]: "); rl.close();
  const r=await startOAuth();
  if(!r.refresh_token) throw new Error("no refresh_token");
  const email=r.email||`user-${Date.now()}@gmail.com`;
  const mgr=new accountManager(); await mgr.load().catch(()=>{});
  if(mode.trim()==="2"){ for(const a of mgr.list()) await mgr.remove(a.email); }
  await mgr.add({email, refreshToken: r.refresh_token, accessToken: r.access_token, expiry: Date.now()+3600*1000});
  console.log(`✅ logged in ${email}`);
  debugLogger.get().log(`login ${email}`);
};
const listAcc = async (): Promise<void>=>{
  const mgr=new accountManager(); await mgr.load().catch(()=>{});
  const list=mgr.list();
  if(list.length===0) console.log("no accounts"); else list.forEach((a,i)=>console.log(` ${i+1}. ${a.email} ${a.disabled?"(disabled)":""} ${a.quotaExhaustedUntil?"(quota)":""} ${a.softQuotaUntil?"(soft-quota)":""} ${a.remaining? `${a.remaining}/${a.limit}`:""}`));
};
const quota = async (): Promise<void>=>{
  const mgr=new accountManager(); await mgr.load().catch(()=>{});
  for(const acc of mgr.list()){
    if(acc.disabled) continue;
    try{
      if(!acc.accessToken){ console.log(` ${acc.email}: no token`); continue; }
      const qq=await retrieveQuota(acc.accessToken, acc.projectId);
      if(qq){ acc.remaining=qq.remaining; acc.limit=qq.limit; await mgr.save(); }
      console.log(` ${acc.email}: ${qq? `${qq.remaining}/${qq.limit} used ${qq.used}`: "failed"}`);
    }catch(e:any){ console.log(` ${acc.email}: ${e.message}`); }
  }
};
const manage = async (): Promise<void>=>{
  const mgr=new accountManager(); await mgr.load();
  const rl=createInterface({input: process.stdin, output: process.stdout});
  await listAcc();
  const email=await q(rl,"email to toggle enable/disable: ");
  const enStr=await q(rl,"enable true/false [true]: ");
  const en=enStr.trim().toLowerCase()!=="false";
  await mgr.enable(email.trim(), en);
  console.log(`${en?"enabled":"disabled"} ${email.trim()}`);
  rl.close();
};
const configure = async (): Promise<void>=>{
  try{ mkdirSync(cfgDir(),{recursive:true, mode:0o700}); }catch{}
  const modelsConfig: any={};
  for(const m of MODELS_2026_08_25){
    const variants: any={};
    for(const v of m.thinking) variants[v]={thinkingLevel: v};
    // claude variants with thinkingConfig budget
    if(m.id.includes("claude-opus")){
      variants.low={thinkingConfig:{thinkingBudget:8192}};
      variants.max={thinkingConfig:{thinkingBudget:32768}};
    }
    if(m.id.includes("claude-sonnet")&&m.thinking.length>0){
      variants.low={thinkingLevel:"low"};
      variants.high={thinkingLevel:"high"};
    }
    modelsConfig[m.id]={ name: m.name, limit:{context: m.context, output: m.output}, modalities: m.modalities, variants, release: m.release };
  }
  let existing:any={};
  if(existsSync(OPENCODE_JSON)) try{ existing=JSON.parse(readFileSync(OPENCODE_JSON,"utf8")); }catch{}
  existing["$schema"]=existing["$schema"]||"https://opencode.ai/config.json";
  existing.plugin=existing.plugin||[];
  if(!existing.plugin.includes("opencode-antigravity-auth-next@latest")) existing.plugin.push("opencode-antigravity-auth-next@latest");
  existing.provider=existing.provider||{}; existing.provider.google=existing.provider.google||{}; existing.provider.google.models={...(existing.provider.google.models||{}), ...modelsConfig};
  const tmp=`${OPENCODE_JSON}.tmp-${process.pid}`;
  writeFileSync(tmp, JSON.stringify(existing,null,2), {encoding:"utf8", mode:0o600}); try{ chmodSync(tmp,0o600);}catch{}
  writeFileSync(OPENCODE_JSON, JSON.stringify(existing,null,2), {encoding:"utf8", mode:0o600}); try{ chmodSync(OPENCODE_JSON,0o600);}catch{}
  console.log(`✅ configured ${Object.keys(modelsConfig).length} models including gemini-3.7-flash, 3.6, 3.5, 3.1, 3, 2.5, claude-4-6, gpt-oss, image, preview, wrappers`);
};
const diagnostics = async (): Promise<void>=>{
  console.log("=== diagnostics ===");
  console.log(`cfgDir ${cfgDir()}`);
  console.log(`opencode.json exists ${existsSync(OPENCODE_JSON)}`);
  console.log(`accounts ${existsSync(join(cfgDir(),"antigravity-accounts.json"))}`);
  console.log(`logs dir ${existsSync(join(cfgDir(),"antigravity-logs"))}`);
  console.log(`models ${MODELS_2026_08_25.length}`);
  console.log(`default model ${MODELS_2026_08_25.find(m=>m.id==="antigravity-gemini-3.7-flash")?.name}`);
};
const menu = async (): Promise<void>=>{
  banner();
  const rl=createInterface({input: process.stdin, output: process.stdout});
  while(true){
    console.log("\nmenu:\n 1. login (add accounts)\n 2. list\n 3. quotas\n 4. manage enable/disable\n 5. configure models all (antigravity+gemini-cli+google)\n 6. diagnostics\n 7. exit\n");
    const ans=await q(rl,"→ ");
    try{
      if(ans.trim()==="1") await login();
      else if(ans.trim()==="2") await listAcc();
      else if(ans.trim()==="3") await quota();
      else if(ans.trim()==="4") await manage();
      else if(ans.trim()==="5") await configure();
      else if(ans.trim()==="6") await diagnostics();
      else if(ans.trim()==="7"){ rl.close(); console.log("bye"); return; }
    }catch(e:any){ console.error(`error ${e.message}`); }
  }
};
const main = async (): Promise<void>=>{
  const cmd=process.argv[2]?.toLowerCase();
  if(!cmd) return menu();
  if(cmd==="login") await login();
  else if(cmd==="list") await listAcc();
  else if(cmd==="quota"||cmd==="quotas") await quota();
  else if(cmd==="manage") await manage();
  else if(cmd.includes("config")) await configure();
  else if(cmd==="diagnostics") await diagnostics();
  else if(cmd==="menu") await menu();
  else console.log("usage: antigravity-auth [login|list|quota|manage|configure|diagnostics|menu]");
};
if(new URL(import.meta.url).pathname===process.argv[1]||process.argv[1]?.endsWith("cli.ts")) main().catch(e=>{ console.error(e); process.exit(1); });
export { login, listAcc, quota, manage, configure, diagnostics, menu };
export default { main, menu };
