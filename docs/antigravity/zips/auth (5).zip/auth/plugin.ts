
/**
 * @file plugin.ts v2 — ONDA 5 CORREÇÃO V2 — 25/08/2026
 * @description
 *  Third-person observer: o observador analisa como Gemini CLI, OmniRoute, 9router e pi-antigravity-auth
 *  bypassam Project ID e reproduz exatamente o mesmo comportamento de forma library-first root-first.
 *
 *  Responsabilidades:
 *  - Bypass total Project ID agindo exatamente como Gemini CLI:
 *    No handleFetch, se account.projectId ausente, o observador chama resolveProjectId que
 *    faz loadCodeAssist SEM project (metadata apenas), onboardUser se necessário (FREE tier),
 *    polling LRO, nunca exige project do usuário. Cache em memória com hash SHA256 truncado
 *    para evitar vazamento de token em heap snapshot.
 *  - Endpoint wrapping {model, project, request} como Gemini CLI (CodeAssistServer.createCodeAssistContentGenerator),
 *    direto cloudcode-pa.googleapis.com, sem localhost v1 proxy, sem generativelanguage.
 *  - Lista modelos completa até 25/08/2026: gemini-3.6, 3.5, 3.1, 3, 2.5, claude 4.5/4.6 thinking,
 *    gpt-oss-120b, preview variants + antigravity-* aliases.
 *  - Dual quota (Antigravity + Gemini CLI), cli_first, pid_offset_enabled 0-1000, google_search grounding.
 *  - Hooks: fetch interceptor cascade 403/404/5xx com jitter 0-80ms, strip x-goog-user-project (fix #1830),
 *    skip sandbox para gemini-3.6/3.5/preview (fix #233), observer third-person, apenas node:* + fetch.
 *  - Transformação OpenAI/Anthropic → Gemini contents com FNV-1a session determinística,
 *    sanitização tool names, limpeza JSON Schema, preservação thinking signatures.
 *
 *  Architecture governance:
 *  - Date: 25/08/2026 — Canto do Buriti, PI, BR
 *  - Plugin: opencode-antigravity-auth-next 2.0.0
 *  - Runtime: Node >=18 ESM, only node:* builtins + global fetch, no external deps
 *  - Endpoints: https://cloudcode-pa.googleapis.com, daily, sandbox (direct cloudcode-pa)
 *  - Version UA fallback 1.19.2 (bypass ban <1.15.8)
 *  - No localhost v1 base-url proxy — requisito explícito
 *
 *  Referências internas usadas:
 *  - Gemini CLI CodeAssistServer: loadCodeAssist → onboardUser → loadCodeAssist retry
 *  - OmniRoute dual pool routing cli_first
 *  - 9router PID offset trick 0-1000 para user_prompt_id randomization
 *  - pi-antigravity-auth project resolution cascade
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from "node:fs";
import * as fsp from "node:fs/promises";
import { join, resolve, dirname } from "node:path";
import { homedir, platform as osPlatform, arch as osArch, release as osRelease } from "node:os";
import { randomInt, createHash, randomBytes } from "node:crypto";

// --- optional internal modules (they themselves only use node:* + fetch) ---
// The observer tries to reuse them when present, but v2 is self-contained to guarantee bypass logic.
let __AccountManagerCtor: any = null;
try {
  // dynamic import via top-level await not allowed here, will lazy import in init
} catch {}

// ---------------------------------------------------------------------------
// Constants — frozen, deterministic
// ---------------------------------------------------------------------------

export const PLUGIN_ID = "opencode-antigravity-auth-next" as const;
export const PLUGIN_VERSION = "2.0.0" as const;

export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;
export const ANTIGRAVITY_VERSION_MIN = "1.15.8" as const;
export const FALLBACK_PROJECT_ID = "rising-fact-p41fc" as const;

export const CODE_ASSIST_ENDPOINTS = {
  PROD: "https://cloudcode-pa.googleapis.com",
  DAILY: "https://daily-cloudcode-pa.googleapis.com",
  SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  AUTOPUSH: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
} as const;

export const ENDPOINT_ORDER: readonly string[] = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
  CODE_ASSIST_ENDPOINTS.SANDBOX,
] as const;

export const ENDPOINT_ORDER_GEMINI_CLI: readonly string[] = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
] as const;

export const STREAM_METHOD = "/v1internal:streamGenerateContent?alt=sse" as const;
export const GENERATE_METHOD = "/v1internal:generateContent" as const;
export const LOAD_METHOD = "/v1internal:loadCodeAssist" as const;
export const ONBOARD_METHOD = "/v1internal:onboardUser" as const;
export const QUOTA_METHOD = "/v1internal:retrieveUserQuotaSummary" as const;

export const FETCH_TIMEOUT_MS = 10_000 as const;
export const CONTENT_TIMEOUT_MS = 60_000 as const;

export const FORBIDDEN_HEADERS = [
  "x-goog-user-project",
  "x-goog-quotatuser",
  "x-goog-quota-user",
  "x-client-device-id",
  "x-goog-request-reason",
] as const;

export const RETRYABLE_STATUS = [403, 404, 429, 500, 502, 503, 504] as const;

// ---------------------------------------------------------------------------
// Models — complete list until 25/08/2026 as required
// ---------------------------------------------------------------------------

export const MODELS_2026_BASE = [
  // gemini-3.6 family (new ONDA5)
  "gemini-3.6-flash-high",
  "gemini-3.6-flash-medium",
  "gemini-3.6-flash-low",
  "gemini-3.6-flash-tiered",
  "gemini-3.6-flash",
  // gemini-3.5 family
  "gemini-3.5-flash-high",
  "gemini-3.5-flash-medium",
  "gemini-3.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.5-flash-lite-preview",
  // gemini-3.1 family
  "gemini-3.1-pro-high",
  "gemini-3.1-pro-low",
  "gemini-3.1-pro",
  "gemini-3.1-flash-image",
  "gemini-3.1-flash-lite",
  // gemini-3 family
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-3-deep-think",
  // gemini-2.5 family
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  // claude 4.5 / 4.6 thinking
  "claude-sonnet-4-6-thinking",
  "claude-opus-4-6-thinking",
  "claude-sonnet-4-5",
  "claude-opus-4-5-thinking",
  // gpt-oss open models via Antigravity router
  "gpt-oss-120b-medium",
  "gpt-oss-120b-high",
  // preview
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export const MODELS_2026_ANTIGRAVITY_ALIAS = [
  // antigravity- prefix for all gemini + claude (router convention)
  "antigravity-gemini-3.6-flash-high",
  "antigravity-gemini-3.6-flash-medium",
  "antigravity-gemini-3.6-flash-low",
  "antigravity-gemini-3.6-flash-tiered",
  "antigravity-gemini-3.6-flash",
  "antigravity-gemini-3.5-flash-high",
  "antigravity-gemini-3.5-flash-medium",
  "antigravity-gemini-3.5-flash",
  "antigravity-gemini-3.5-flash-lite",
  "antigravity-gemini-3.5-flash-lite-preview",
  "antigravity-gemini-3.1-pro-high",
  "antigravity-gemini-3.1-pro-low",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3.1-flash-image",
  "antigravity-gemini-3.1-flash-lite",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-deep-think",
  "antigravity-gemini-2.5-pro",
  "antigravity-gemini-2.5-flash",
  "antigravity-gemini-2.5-flash-lite",
  "antigravity-gemini-3-pro-preview",
  "antigravity-gemini-3-flash-preview",
  "antigravity-gemini-3.1-pro-preview",
  "antigravity-gemini-3.1-pro-preview-customtools",
  "antigravity-claude-sonnet-4-6-thinking",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-sonnet-4-5",
  "antigravity-claude-opus-4-5-thinking",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6",
  // short aliases legacy
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3.1-pro",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-sonnet-4-6",
] as const;

export const MODELS_2026 = [
  ...MODELS_2026_BASE,
  ...MODELS_2026_ANTIGRAVITY_ALIAS,
] as const;

export type ModelId2026 = (typeof MODELS_2026)[number];

// models that must skip sandbox (prod-only routing)
export const GEMINI_CLI_ONLY_MODELS = [
  "gemini-3.6-flash-high",
  "gemini-3.6-flash-medium",
  "gemini-3.6-flash-low",
  "gemini-3.6-flash-tiered",
  "gemini-3.6-flash",
  "gemini-3.5-flash-high",
  "gemini-3.5-flash-medium",
  "gemini-3.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.5-flash-lite-preview",
  "gemini-3.1-pro-high",
  "gemini-3.1-pro-low",
  "gemini-3.1-pro",
  "gemini-3.1-flash-image",
  "gemini-3.1-flash-lite",
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-3-deep-think",
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
  "antigravity-gemini-3.6-flash-high",
  "antigravity-gemini-3.6-flash-medium",
  "antigravity-gemini-3.6-flash-low",
  "antigravity-gemini-3.6-flash-tiered",
  "antigravity-gemini-3.6-flash",
  "antigravity-gemini-3.5-flash-high",
  "antigravity-gemini-3.5-flash-medium",
  "antigravity-gemini-3.5-flash",
  "antigravity-gemini-3.5-flash-lite",
  "antigravity-gemini-3.5-flash-lite-preview",
  "antigravity-gemini-3.1-pro-high",
  "antigravity-gemini-3.1-pro-low",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3.1-flash-image",
  "antigravity-gemini-3.1-flash-lite",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-deep-think",
  "antigravity-gemini-3-pro-preview",
  "antigravity-gemini-3-flash-preview",
  "antigravity-gemini-3.1-pro-preview",
] as const;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PluginOptions = {
  cli_first?: boolean;
  pid_offset_enabled?: boolean;
  google_search_enabled?: boolean;
  quota_refresh_interval_minutes?: number;
  rotation_strategy?: "round-robin" | "sticky";
  debug?: boolean;
};

export interface Account {
  email: string;
  refreshToken: string;
  accessToken?: string;
  expiry?: number;
  projectId?: string;
  disabled?: boolean;
  quotaExhaustedUntil?: number;
  type?: string;
}

// ---------------------------------------------------------------------------
// Helpers — FNV, jitter, UA, headers, cache
// ---------------------------------------------------------------------------

const FNV_OFFSET_BASIS = 0x811c9dc5;
const FNV_PRIME = 0x01000193;

export function fnv1a32(str: string): number {
  let hash = FNV_OFFSET_BASIS;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, FNV_PRIME) >>> 0;
  }
  return hash >>> 0;
}

export function fnv1a32Hex(str: string): string {
  return fnv1a32(str).toString(16).padStart(8, "0");
}

function hashToken(token: string): string {
  try {
    return createHash("sha256").update(token).digest("hex").slice(0, 32);
  } catch {
    return fnv1a32(token).toString(16);
  }
}

export function getJitter(): number {
  try {
    return randomInt(0, 81);
  } catch {
    return Math.floor(Math.random() * 81);
  }
}

function normalizePlatform(p: string): string {
  switch (p) {
    case "darwin": return "darwin";
    case "win32": return "win32";
    case "linux": return "linux";
    default: return p;
  }
}
function normalizeArch(a: string): string {
  switch (a) {
    case "arm64": return "arm64";
    case "x64": return "x64";
    case "ia32": return "ia32";
    default: return a;
  }
}

export function getDynamicUserAgent(version?: string): string {
  const ver = version && /^\d+\.\d+\.\d+/.test(version) ? version.trim() : ANTIGRAVITY_VERSION_FALLBACK;
  try {
    const plat = normalizePlatform(osPlatform());
    const arc = normalizeArch(osArch());
    return `antigravity/${ver} ${plat}/${arc}`;
  } catch {
    return `antigravity/${ver}`;
  }
}

export function buildAntagravityHeaders(accessToken: string, opts: { userAgent?: string; extra?: Record<string,string> } = {}): Record<string,string> {
  const ua = opts.userAgent ?? getDynamicUserAgent();
  const h: Record<string,string> = {
    Authorization: `Bearer ${accessToken}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
  };
  if (opts.extra) {
    for (const [k,v] of Object.entries(opts.extra)) h[k]=v;
  }
  return h;
}

export function stripForbiddenHeaders(headers: Record<string,string>): Record<string,string> {
  if (!headers || typeof headers !== "object") return {};
  const forbidden = new Set(FORBIDDEN_HEADERS.map(h=>h.toLowerCase()));
  const out: Record<string,string> = {};
  for (const [k,v] of Object.entries(headers)) {
    if (!k) continue;
    const low = k.toLowerCase().trim();
    if (forbidden.has(low)) continue;
    if (low === "x-goog-user-project") continue;
    out[k]=v;
  }
  return out;
}

export function isRetryable(status: number): boolean {
  return status === 403 || status === 404 || status >= 500;
}

export async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs = FETCH_TIMEOUT_MS): Promise<Response> {
  const controller = new AbortController();
  const t = setTimeout(()=>controller.abort(), timeoutMs);
  try {
    const merged: RequestInit = { ...init, signal: controller.signal };
    if (init.signal) {
      const ext = init.signal as AbortSignal;
      if (ext.aborted) controller.abort();
      else ext.addEventListener("abort", ()=>controller.abort(), { once:true });
    }
    return await fetch(url, merged);
  } catch (e:any) {
    if (e?.name === "AbortError") throw new Error(`timeout ${timeoutMs}ms ${url}`);
    throw e;
  } finally {
    clearTimeout(t);
  }
}

// ---------------------------------------------------------------------------
// Project discovery — exact Gemini CLI behavior
// ---------------------------------------------------------------------------

export class ProjectDiscoveryError extends Error {
  public status?: number;
  public endpoint?: string;
  public retryable: boolean;
  constructor(msg:string, status?:number, endpoint?:string) {
    super(msg);
    this.name="ProjectDiscoveryError";
    this.status=status;
    this.endpoint=endpoint;
    this.retryable = status !== undefined ? isRetryable(status) : true;
  }
}

interface CacheEntry { projectId:string; timestamp:number; email?:string; }
const projectIdCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 60*60*1000;

export function getCachedProjectId(accessToken:string): string|null {
  const key=hashToken(accessToken);
  const e=projectIdCache.get(key);
  if (!e) return null;
  if (Date.now()-e.timestamp > CACHE_TTL_MS) { projectIdCache.delete(key); return null; }
  return e.projectId;
}
export function setCachedProjectId(accessToken:string, projectId:string, email?:string): void {
  projectIdCache.set(hashToken(accessToken), { projectId, timestamp: Date.now(), email });
}
export function clearProjectIdCache(): void { projectIdCache.clear(); }

function defaultMetadata() {
  return { ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI" };
}

function normalizeProjectId(raw:any): string|null {
  if (!raw) return null;
  if (typeof raw === "string") {
    const parts = raw.split("/");
    if (parts.includes("projects")) {
      const idx = parts.indexOf("projects");
      return parts[idx+1] ?? raw;
    }
    return raw;
  }
  if (typeof raw === "object") {
    const id = (raw as any).id ?? (raw as any).name;
    if (id && typeof id === "string") return normalizeProjectId(id);
  }
  return null;
}

/**
 * Observer notes: Gemini CLI does POST {endpoint}/v1internal:loadCodeAssist with {metadata}
 * no project. Server returns cloudaicompanionProject if exists, else null.
 */
export async function loadCodeAssist(opts:{accessToken:string; endpoint:string; projectId?:string; userAgent?:string;}): Promise<string|null> {
  const { accessToken, endpoint, projectId, userAgent } = opts;
  const url = `${endpoint.replace(/\/+$/,"")}${LOAD_METHOD}`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });
  const body: Record<string,any> = { metadata: defaultMetadata() };
  if (projectId && projectId !== FALLBACK_PROJECT_ID) body.cloudaicompanionProject = projectId;

  let res: Response;
  try {
    res = await fetchWithTimeout(url, { method:"POST", headers, body: JSON.stringify(body) }, FETCH_TIMEOUT_MS);
  } catch (e:any) {
    throw new ProjectDiscoveryError(`loadCodeAssist network failed at ${endpoint}: ${e.message}`, 0, endpoint);
  }
  if (!res.ok) {
    const text = await res.text().catch(()=>"" );
    throw new ProjectDiscoveryError(`loadCodeAssist failed ${res.status} at ${endpoint}: ${text.slice(0,500)}`, res.status, endpoint);
  }
  let data:any;
  try { data = await res.json(); } catch { throw new ProjectDiscoveryError(`loadCodeAssist invalid JSON at ${endpoint}`, 500, endpoint); }
  const raw = data.cloudaicompanionProject ?? data.cloudaicompanionProjectId ?? data.projectId ?? (data as any).response?.cloudaicompanionProject;
  return normalizeProjectId(raw);
}

/**
 * Observer notes: when load returns null, Gemini CLI calls onboardUser FREE then reload.
 */
export async function onboardUser(opts:{accessToken:string; endpoint:string; tierId?:string; userAgent?:string;}): Promise<string|null> {
  const { accessToken, endpoint, tierId="FREE", userAgent } = opts;
  const url = `${endpoint.replace(/\/+$/,"")}${ONBOARD_METHOD}`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });
  const body = { tierId, metadata: defaultMetadata() };
  let res: Response;
  try {
    res = await fetchWithTimeout(url, { method:"POST", headers, body: JSON.stringify(body) }, FETCH_TIMEOUT_MS);
  } catch (e:any) {
    throw new ProjectDiscoveryError(`onboardUser network failed at ${endpoint}: ${e.message}`, 0, endpoint);
  }
  if (!res.ok) {
    const text = await res.text().catch(()=>"" );
    throw new ProjectDiscoveryError(`onboardUser failed ${res.status} at ${endpoint}: ${text.slice(0,500)}`, res.status, endpoint);
  }
  let data:any;
  try { data = await res.json(); } catch { throw new ProjectDiscoveryError(`onboardUser invalid JSON at ${endpoint}`, 500, endpoint); }

  const direct = data.cloudaicompanionProject ?? data.response?.cloudaicompanionProject ?? data.response?.projectId;
  if (direct) {
    const norm = normalizeProjectId(direct);
    if (norm) return norm;
  }
  // LRO polling
  if (data.name && data.done === false) {
    const polled = await pollOperation({ accessToken, endpoint, operationName: data.name, userAgent });
    if (polled) return polled;
  }
  if (data.done && data.response) {
    const proj = data.response.cloudaicompanionProject ?? data.response.projectId;
    const norm = normalizeProjectId(proj);
    if (norm) return norm;
  }
  return null;
}

async function pollOperation(opts:{accessToken:string; endpoint:string; operationName:string; userAgent?:string; maxAttempts?:number;}): Promise<string|null> {
  const { accessToken, endpoint, operationName, userAgent, maxAttempts=5 } = opts;
  const base = endpoint.replace(/\/+$/,"");
  const url = `${base}/v1internal/operations/${operationName.split("/").pop()}`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });
  for (let attempt=0; attempt<maxAttempts; attempt++) {
    if (attempt>0) await new Promise(r=>setTimeout(r, Math.min(500*(2**(attempt-1)), 8000)));
    try {
      const res = await fetchWithTimeout(url, { method:"GET", headers }, FETCH_TIMEOUT_MS);
      if (!res.ok) continue;
      const data:any = await res.json().catch(()=>null);
      if (!data) continue;
      if (data.done) {
        const proj = data.response?.cloudaicompanionProject ?? data.response?.projectId ?? data.cloudaicompanionProject;
        const norm = normalizeProjectId(proj);
        if (norm) return norm;
        return null;
      }
    } catch { continue; }
  }
  return null;
}

export interface ResolveProjectIdOptions {
  accessToken:string;
  cachedProjectId?:string;
  email?:string;
  metadataSaver?: (pid:string)=>Promise<void>|void;
  userAgent?:string;
  endpoints?: readonly string[];
  includeAutopush?: boolean;
}
export interface ResolveResult {
  projectId:string;
  fromCache:boolean;
  endpointUsed?:string;
  isFallback:boolean;
}

/**
 * resolveProjectId — orquestrador principal:
 * 1. checa cache Map
 * 2. se cachedProjectId fornecido tenta load com ele
 * 3. senão load sem project (Gemini CLI exact)
 * 4. se null tenta onboardUser + load novamente
 * 5. se todos falham fallback rising-fact-p41fc com warning (funciona para Antigravity, 403 para Gemini CLI)
 * Nunca exige project do usuário.
 */
export async function resolveProjectId(opts: ResolveProjectIdOptions): Promise<ResolveResult> {
  const { accessToken, cachedProjectId, email, metadataSaver, userAgent = getDynamicUserAgent(), endpoints = ENDPOINT_ORDER, includeAutopush=false } = opts;
  if (!accessToken) throw new ProjectDiscoveryError("resolveProjectId requires accessToken");

  const cached = getCachedProjectId(accessToken);
  if (cached) return { projectId: cached, fromCache:true, isFallback: cached===FALLBACK_PROJECT_ID };

  const allEndpoints = includeAutopush ? [...endpoints, CODE_ASSIST_ENDPOINTS.AUTOPUSH] : endpoints;
  let lastError: ProjectDiscoveryError|null = null;

  for (const endpoint of allEndpoints) {
    try {
      let discovered: string|null = null;
      // a) tenta com cachedProjectId se houver
      if (cachedProjectId && cachedProjectId !== FALLBACK_PROJECT_ID) {
        try {
          discovered = await loadCodeAssist({ accessToken, endpoint, projectId: cachedProjectId, userAgent });
        } catch (e:any) {
          if (e instanceof ProjectDiscoveryError && !e.retryable) throw e;
          // se falhar com projeto, tenta sem projeto no mesmo endpoint
          try { discovered = await loadCodeAssist({ accessToken, endpoint, userAgent }); } catch (inner:any) {
            lastError = inner instanceof ProjectDiscoveryError ? inner : new ProjectDiscoveryError(String(inner), 500, endpoint);
            if (inner instanceof ProjectDiscoveryError && !isRetryable(inner.status??0)) throw inner;
            continue;
          }
        }
      } else {
        discovered = await loadCodeAssist({ accessToken, endpoint, userAgent });
      }

      if (!discovered) {
        try {
          const onboarded = await onboardUser({ accessToken, endpoint, tierId:"FREE", userAgent });
          if (onboarded) discovered = onboarded;
          else discovered = await loadCodeAssist({ accessToken, endpoint, userAgent });
        } catch (onboardErr:any) {
          lastError = onboardErr instanceof ProjectDiscoveryError ? onboardErr : new ProjectDiscoveryError(String(onboardErr), 500, endpoint);
          if (onboardErr instanceof ProjectDiscoveryError && !isRetryable(onboardErr.status??0)) throw onboardErr;
          continue;
        }
      }

      if (!discovered) {
        lastError = new ProjectDiscoveryError(`no project id from ${endpoint}`, 404, endpoint);
        continue;
      }

      setCachedProjectId(accessToken, discovered, email);
      if (metadataSaver) {
        try { await metadataSaver(discovered); } catch {}
      }
      return { projectId: discovered, fromCache:false, endpointUsed: endpoint, isFallback:false };
    } catch (err:any) {
      if (err instanceof ProjectDiscoveryError) {
        lastError = err;
        if (!err.retryable) throw err;
        continue;
      }
      lastError = new ProjectDiscoveryError(`unexpected error at ${endpoint}: ${err?.message ?? String(err)}`, 500, endpoint);
      continue;
    }
  }

  console.warn(`[antigravity-auth] WARNING: all ${allEndpoints.length} endpoints failed${lastError ? ` last: ${lastError.status} ${lastError.message.slice(0,200)}` : ""}. Falling back to ${FALLBACK_PROJECT_ID}. This works for Antigravity but will 403 for Gemini CLI models.`);

  setCachedProjectId(accessToken, FALLBACK_PROJECT_ID, email);
  if (metadataSaver) { try { await metadataSaver(FALLBACK_PROJECT_ID); } catch {} }
  return { projectId: FALLBACK_PROJECT_ID, fromCache:false, endpointUsed: undefined, isFallback:true };
}

// ---------------------------------------------------------------------------
// Request helpers — transform OpenAI/Anthropic → Gemini + CloudCode envelope
// ---------------------------------------------------------------------------

export const THINKING_LEVELS = ["minimal","low","medium","high","max"] as const;
export type ThinkingLevel = typeof THINKING_LEVELS[number];
export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = {
  minimal:1024, low:8192, medium:16384, high:32768, max:64000,
} as const;
export const TOOL_NAME_REGEX = /^[a-zA-Z][a-zA-Z0-9_]{0,63}$/;

function sanitizeToolName(name:string): string {
  if (typeof name !== "string") return `tool_${fnv1a32Hex(String(name??"")).slice(0,8)}`;
  let t = name.trim();
  if (!t) return `tool_${fnv1a32Hex(name).slice(0,8)}`;
  t = t.replace(/[^a-zA-Z0-9_]/g,"_").replace(/__+/g,"_");
  if (!/^[a-zA-Z]/.test(t)) t = `tool_${t.replace(/^[^a-zA-Z]+/,"")}`;
  t = t.slice(0,64);
  if (!TOOL_NAME_REGEX.test(t)) t = `a${t.slice(0,63)}`;
  return t;
}
function ensureUniqueToolNames(names:string[]): string[] {
  const seen = new Map<string,number>();
  const out: string[] = [];
  for (let raw of names) {
    let cand = raw;
    let cnt = seen.get(raw)??0;
    if (cnt>0 || out.includes(cand)) {
      let idx=1;
      while (out.includes(`${raw}_${idx}`)) idx++;
      cand = `${raw}_${idx}`.slice(0,64);
    }
    seen.set(raw,(seen.get(raw)??0)+1);
    out.push(cand);
  }
  return out;
}
function cleanJsonSchema(input:any, seen=new WeakSet()): any {
  if (input==null) return { type:"OBJECT", properties:{} };
  if (typeof input==="boolean") return input ? { type:"OBJECT", properties:{} } : { type:"OBJECT", properties:{}, description:"disallowed" };
  if (Array.isArray(input)) return input.map(i=>cleanJsonSchema(i,seen));
  if (typeof input!=="object") return { type:"STRING" };
  if (seen.has(input)) return { type:"OBJECT", properties:{} };
  seen.add(input);
  const allowed = new Set(["type","properties","required","description","enum","items","anyOf","oneOf","format","minimum","maximum","minLength","maxLength","pattern","title","nullable"]);
  const out:any = {};
  if (input.type) {
    let rt = Array.isArray(input.type) ? (input.type.find((t:any)=>t!=="null") ?? input.type[0]) : input.type;
    if (typeof rt==="string") out.type = rt.toUpperCase();
  }
  for (const k of Object.keys(input)) {
    if (!allowed.has(k)) continue;
    const v = (input as any)[k];
    if (k==="properties" && typeof v==="object" && v!==null) {
      out.properties={};
      for (const [pk,pv] of Object.entries(v)) out.properties[pk]=cleanJsonSchema(pv,seen);
    } else if ((k==="items" || k==="anyOf" || k==="oneOf") && v) {
      out[k]=cleanJsonSchema(v,seen);
    } else if (v!==undefined) {
      out[k]=v;
    }
  }
  if (!out.type && out.properties) out.type="OBJECT";
  if (!out.type) out.type="OBJECT";
  return out;
}
function validateAndSanitizeTools(rawTools?: any[]): { declarations:any[] } {
  if (!rawTools || !Array.isArray(rawTools) || rawTools.length===0) return { declarations:[] };
  const decls:any[]=[];
  for (const entry of rawTools) {
    if (!entry) continue;
    if (entry.functionDeclarations && Array.isArray(entry.functionDeclarations)) {
      for (const fd of entry.functionDeclarations) {
        if (!fd?.name) continue;
        decls.push({ name:sanitizeToolName(String(fd.name)), description: fd.description?String(fd.description).slice(0,1024):undefined, parameters: fd.parameters?cleanJsonSchema(fd.parameters):{type:"OBJECT",properties:{}}, originalName:String(fd.name) });
      }
      continue;
    }
    if (entry.type==="function" && entry.function) {
      const fn=entry.function;
      if (!fn.name) continue;
      decls.push({ name:sanitizeToolName(String(fn.name)), description: fn.description?String(fn.description).slice(0,1024):undefined, parameters: fn.parameters?cleanJsonSchema(fn.parameters):{type:"OBJECT",properties:{}}, originalName:String(fn.name) });
      continue;
    }
    if (entry.name) {
      const schemaRaw = entry.input_schema ?? entry.inputSchema ?? entry.parameters ?? entry.schema;
      decls.push({ name:sanitizeToolName(String(entry.name)), description: entry.description?String(entry.description).slice(0,1024):undefined, parameters: schemaRaw?cleanJsonSchema(schemaRaw):{type:"OBJECT",properties:{}}, originalName:String(entry.name) });
      continue;
    }
  }
  const names = decls.map(d=>d.name);
  const unique = ensureUniqueToolNames(names);
  for (let i=0;i<decls.length;i++) decls[i].name=unique[i];
  return { declarations: decls };
}

export function isGeminiCLIOnlyModel(modelId:string): boolean {
  if (!modelId) return false;
  const lower = modelId.trim().toLowerCase();
  if ((GEMINI_CLI_ONLY_MODELS as readonly string[]).includes(lower as any)) return true;
  if ((GEMINI_CLI_ONLY_MODELS as readonly string[]).some(m=>lower.includes(m))) return true;
  if (lower.includes("preview")) return true;
  if (lower.includes("gemini-3.6") || lower.includes("gemini-3.5") || lower.includes("gemini-3.1") || lower.startsWith("gemini-3-") || lower.startsWith("gemini-3")) return true;
  if (lower.startsWith("antigravity-gemini-3.6") || lower.startsWith("antigravity-gemini-3.5") || lower.startsWith("antigravity-gemini-3.1") || lower.startsWith("antigravity-gemini-3")) return true;
  return false;
}

export function shouldSkipSandbox(modelId:string): boolean {
  const lower = (modelId??"").toLowerCase();
  return lower.includes("3.6") || lower.includes("3.5") || lower.includes("preview") || lower.includes("gemini-3-flash") || lower.includes("gemini-3-pro") || lower.includes("gemini-3.1") || lower.includes("deep-think") || lower.includes("flash-image");
}

export function getEndpointsForModel(modelId:string, overrides?:string[]): string[] {
  if (overrides && overrides.length>0) return overrides.map(e=>e.replace(/\/+$/,"")).filter(Boolean);
  if (isGeminiCLIOnlyModel(modelId) || shouldSkipSandbox(modelId)) return [...ENDPOINT_ORDER_GEMINI_CLI];
  return [...ENDPOINT_ORDER];
}

function buildDynamicUserAgentFromPlatform(version?:string): string {
  return getDynamicUserAgent(version);
}

function buildCommonHeaders(opts:{accessToken:string; userAgent?:string; version?:string;}, style:"antigravity"|"gemini-cli"="antigravity"): Record<string,string> {
  const ua = opts.userAgent ?? buildDynamicUserAgentFromPlatform(opts.version);
  const headers: Record<string,string> = {
    Authorization: `Bearer ${opts.accessToken}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
  };
  // gemini-cli adds X-Goog-Api-Client but AM does not — observer includes only for gemini-cli pool when cli_first
  if (style==="gemini-cli") {
    try {
      const nodeVer = (process as any)?.versions?.node ?? "20.0.0";
      headers["X-Goog-Api-Client"] = `antigravity/${opts.version ?? ANTIGRAVITY_VERSION_FALLBACK} gl-node/${nodeVer} gax/4.9.0 grpc/1.14.0`;
      headers["Client-Metadata"] = `ideType=ANTIGRAVITY,platform=${normalizePlatform(osPlatform()).toUpperCase()},ideVersion=${opts.version ?? ANTIGRAVITY_VERSION_FALLBACK},pluginVersion=${PLUGIN_VERSION}`;
    } catch {}
  }
  return stripForbiddenHeaders(headers);
}

function buildClientMetadata(version?:string): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  try {
    const plat = normalizePlatform(osPlatform()).toUpperCase();
    const arc = normalizeArch(osArch()).toUpperCase();
    return [`ideType=ANTIGRAVITY`,`platform=${plat}`,`ideVersion=${ver}`,`pluginVersion=${PLUGIN_VERSION}`,`arch=${arc}`,`osVersion=${osRelease()}`].join(",");
  } catch {
    return `ideType=ANTIGRAVITY,platform=PLATFORM_UNSPECIFIED,ideVersion=${ver},pluginVersion=${PLUGIN_VERSION}`;
  }
}

export function mapModelToGroup(model:string): "antigravity"|"gemini-cli" {
  const lower = (model??"").toLowerCase();
  if (lower.includes("claude") || lower.includes("gpt-oss")) return "antigravity";
  if (lower.includes("gemini")) return lower.includes("preview") || lower.includes("3.6") || lower.includes("3.5") || lower.includes("3.1") || lower.includes("3-") ? "gemini-cli" : "antigravity";
  return "antigravity";
}

// deterministic ids
export function generateDeterministicId(seed:string): string {
  return fnv1a32Hex(seed);
}
export function generateSessionId(seed?:string, offsetEnabled?:boolean): string {
  const base = seed ?? `${Date.now()}-${randomBytes(4).toString("hex")}`;
  const offset = offsetEnabled ? randomInt(0,1001) : 0;
  return fnv1a32Hex(`${base}-${offset}-session`);
}
export function generateUserPromptId(seed?:string, offsetEnabled?:boolean): string {
  const base = seed ?? `${Date.now()}-${randomBytes(4).toString("hex")}`;
  const offset = offsetEnabled ? randomInt(0,1001) : 0;
  // 9router pid_offset trick 0-1000 added to user_prompt_id for anti-fingerprint jitter
  return fnv1a32Hex(`${base}-${offset}-user-prompt-${offsetEnabled?offset:0}`);
}

// ---------------------------------------------------------------------------
// Transform OpenAI/Anthropic messages → Gemini contents
// ---------------------------------------------------------------------------

type GeminiPart = { text?:string; inlineData?:{mimeType:string; data:string}; functionCall?:{name:string;args:any}; functionResponse?:{name:string; response:any}; thought?:boolean; thoughtSignature?:string; };
type GeminiContent = { role:"user"|"model"; parts:GeminiPart[]; };
type GeminiSystem = { parts:GeminiPart[] } | undefined;

interface TransformRequestOptions {
  model:string;
  messages?:any[];
  tools?:any[];
  system?:string|any;
  thinkingLevel?:string;
  thinkingBudget?:number;
  googleSearchEnabled?:boolean;
  generationConfig?:any;
  sessionSeed?:string;
  userPromptSeed?:string;
  projectId?:string;
  pidOffsetEnabled?:boolean;
}

interface TransformResult {
  contents:GeminiContent[];
  systemInstruction?:GeminiSystem;
  tools?:any[];
  toolConfig?:any;
  generationConfig?:any;
  sessionId:string;
  userPromptId:string;
  thinkingBudget?:number;
  thinkingLevel?:ThinkingLevel;
}

function extractThinkingLevel(modelId:string, explicit?:string): { level?:ThinkingLevel; budget?:number } {
  const exp = (explicit??"").toLowerCase().trim();
  if (exp && (THINKING_LEVELS as readonly string[]).includes(exp)) return { level: exp as ThinkingLevel, budget: THINKING_BUDGET_MAP[exp as ThinkingLevel] };
  const lower = (modelId??"").toLowerCase();
  for (const lvl of THINKING_LEVELS) if (lower.includes(`-${lvl}`)) return { level: lvl as ThinkingLevel, budget: THINKING_BUDGET_MAP[lvl as ThinkingLevel] };
  if (lower.includes("thinking")) return { level: lower.includes("claude") ? "medium" : "low", budget: THINKING_BUDGET_MAP[lower.includes("claude") ? "medium" : "low"] };
  return {};
}

function openAIContentToParts(content:any): GeminiPart[] {
  if (content==null) return [{ text:"" }];
  if (typeof content==="string") return [{ text: content }];
  if (Array.isArray(content)) {
    const parts:GeminiPart[]=[];
    for (const c of content) {
      if (!c) continue;
      if (typeof c==="string") parts.push({ text:c });
      else if (c.type==="text" && c.text) parts.push({ text: c.text });
      else if (c.type==="image_url" && c.image_url?.url) {
        // data url handling
        const url = c.image_url.url;
        const m = url.match(/^data:(.+);base64,(.+)$/);
        if (m) parts.push({ inlineData:{ mimeType:m[1], data:m[2] } });
        else parts.push({ text:`[image: ${url.slice(0,200)}]` });
      }
      else if (c.text) parts.push({ text: String(c.text) });
    }
    return parts.length?parts:[{text:""}];
  }
  if (typeof content==="object" && (content as any).text) return [{ text: String((content as any).text) }];
  return [{ text: String(content) }];
}

export function transformRequest(opts: TransformRequestOptions): TransformResult {
  const { model, messages=[], tools, system, thinkingLevel: explicitThinkingLevel, thinkingBudget: explicitBudget, googleSearchEnabled, generationConfig, sessionSeed, userPromptSeed, pidOffsetEnabled } = opts;

  const { level: inferredLevel, budget: inferredBudget } = extractThinkingLevel(model, explicitThinkingLevel);
  const finalLevel = inferredLevel ?? (explicitThinkingLevel as ThinkingLevel | undefined);
  const finalBudget = explicitBudget ?? inferredBudget ?? (finalLevel ? THINKING_BUDGET_MAP[finalLevel] : undefined);

  // system instruction extraction
  let sysText = "";
  if (typeof system==="string") sysText = system;
  else if (Array.isArray(system)) sysText = system.map(s=> typeof s==="string"?s:s.text??"").join("\n");
  else if (system && typeof system==="object" && (system as any).text) sysText = String((system as any).text);

  // also extract system role from messages
  const filteredMessages:any[] = [];
  for (const m of messages) {
    if (!m) continue;
    if (m.role==="system") {
      const t = typeof m.content==="string"?m.content: Array.isArray(m.content)?m.content.map((c:any)=>c.text??"").join("\n"):String(m.content??"");
      sysText = sysText ? `${sysText}\n${t}` : t;
    } else {
      filteredMessages.push(m);
    }
  }

  const systemInstruction: GeminiSystem = sysText ? { parts:[{ text: sysText }] } : undefined;

  const contents: GeminiContent[] = [];
  for (const m of filteredMessages) {
    if (!m) continue;
    const roleRaw = String(m.role??"user").toLowerCase();
    const role: "user"|"model" = roleRaw==="assistant" || roleRaw==="model" ? "model" : "user";

    // tool messages
    if (roleRaw==="tool" || roleRaw==="function") {
      const toolName = m.tool_call_id ?? m.name ?? m.toolName ?? "tool";
      const sanitizedName = sanitizeToolName(String(toolName));
      const contentStr = typeof m.content==="string" ? m.content : JSON.stringify(m.content??{});
      let parsed: any;
      try { parsed = JSON.parse(contentStr); } catch { parsed = { result: contentStr }; }
      contents.push({
        role:"user",
        parts:[{ functionResponse:{ name:sanitizedName, response: parsed } }],
      });
      continue;
    }

    // assistant with tool_calls
    if (role==="model" && Array.isArray(m.tool_calls) && m.tool_calls.length>0) {
      const parts: GeminiPart[]=[];
      const textParts = openAIContentToParts(m.content);
      for (const tp of textParts) if (tp.text) parts.push(tp);
      for (const tc of m.tool_calls) {
        const fn = tc.function ?? tc;
        const name = sanitizeToolName(String(fn.name ?? tc.name ?? "tool"));
        let args:any = fn.arguments ?? fn.args ?? {};
        if (typeof args==="string") { try { args=JSON.parse(args); } catch { args={ raw:args }; } }
        parts.push({ functionCall:{ name, args } });
      }
      if (parts.length>0) contents.push({ role, parts });
      continue;
    }

    // Anthropic tool_use
    if (Array.isArray(m.content) && m.content.some((c:any)=>c?.type==="tool_use")) {
      const parts: GeminiPart[]=[];
      for (const c of m.content) {
        if (c.type==="text") parts.push({ text:c.text });
        else if (c.type==="tool_use") parts.push({ functionCall:{ name:sanitizeToolName(c.name), args:c.input ?? {} } });
      }
      contents.push({ role, parts: parts.length?parts:[{text:""}] });
      continue;
    }

    // regular
    const parts = openAIContentToParts(m.content ?? "");
    // thinking blocks mapping when model is thinking variant: if parts contain thinking tag? skip for now
    contents.push({ role, parts: parts.length?parts:[{text:""}] });
  }

  // tools sanitization + google_search injection
  let geminiTools: any[] | undefined;
  if (tools && tools.length>0) {
    const { declarations } = validateAndSanitizeTools(tools);
    if (declarations.length>0) {
      geminiTools = [{ functionDeclarations: declarations.map(d=>({ name:d.name, description:d.description, parameters:d.parameters })) }];
    }
  }

  if (googleSearchEnabled) {
    const modelLower = model.toLowerCase();
    const isGemini = modelLower.includes("gemini");
    if (isGemini) {
      // inject google_search grounding tool as per Gemini spec
      if (!geminiTools) geminiTools=[];
      // avoid duplicate
      const hasSearch = geminiTools.some((t:any)=> t.googleSearch || t.google_search);
      if (!hasSearch) geminiTools.push({ googleSearch:{} });
    }
  }

  // generationConfig
  const genConfig:any = { ...(generationConfig??{}) };
  if (finalBudget) {
    // Gemini 3 thinking budget
    genConfig.thinkingConfig = { thinkingBudget: finalBudget, ...(finalLevel ? { thinkingLevel: finalLevel } : {}) };
  }
  // normalize temperature etc
  if (genConfig.temperature===undefined) genConfig.temperature = 1.0;

  const sessionId = generateSessionId(sessionSeed ?? `${model}-${contents.length}-${Date.now()}`, pidOffsetEnabled);
  const userPromptId = generateUserPromptId(userPromptSeed ?? `${model}-${sysText.slice(0,50)}-${Date.now()}`, pidOffsetEnabled);

  return {
    contents,
    systemInstruction,
    tools: geminiTools,
    generationConfig: genConfig,
    sessionId,
    userPromptId,
    thinkingBudget: finalBudget,
    thinkingLevel: finalLevel,
  };
}

export function buildCloudCodeBody(projectId:string, inner:TransformResult): Record<string,any> {
  // Gemini CLI exact wrapping: {model, project, request: {contents, systemInstruction, tools, generationConfig, toolConfig?}, user_prompt_id?, session_id? }
  const request:any = {
    contents: inner.contents,
  };
  if (inner.systemInstruction) request.systemInstruction = inner.systemInstruction;
  if (inner.tools && inner.tools.length>0) request.tools = inner.tools;
  if (inner.toolConfig) request.toolConfig = inner.toolConfig;
  if (inner.generationConfig) request.generationConfig = inner.generationConfig;

  return {
    model: undefined, // filled by caller wrapper
    project: projectId,
    request,
    // extra fields observed in Gemini CLI traffic: session_id and user_prompt_id aid quota tracking but not required
    session_id: inner.sessionId,
    user_prompt_id: inner.userPromptId,
  };
}

export interface BuildOptions {
  model:string;
  messages?:any[];
  tools?:any[];
  system?:any;
  thinkingLevel?:string;
  thinkingBudget?:number;
  googleSearchEnabled?:boolean;
  generationConfig?:any;
  accessToken:string;
  projectId:string;
  endpointOverrides?:string[];
  userAgent?:string;
  antigravityVersion?:string;
  methodSuffix?:string;
  sessionSeed?:string;
  userPromptSeed?:string;
  pidOffsetEnabled?:boolean;
}

export interface BuildResult {
  url:string;
  endpoints:string[];
  baseEndpoints:string[];
  headers:Record<string,string>;
  body:Record<string,any>;
  sessionId:string;
  userPromptId:string;
  isGeminiCLIOnly:boolean;
  method:string;
  innerRequest:TransformResult;
}

export function buildAntigravityRequest(options:BuildOptions): BuildResult {
  if (!options) throw new Error("build options required");
  const projectId = String(options.projectId??"").trim() || FALLBACK_PROJECT_ID;
  const token = String(options.accessToken??"").trim();
  if (!token) throw new Error("accessToken required");
  const model = String(options.model??"").trim();
  if (!model) throw new Error("model required");

  const inner = transformRequest({
    model: options.model,
    messages: options.messages,
    tools: options.tools,
    system: options.system,
    thinkingLevel: options.thinkingLevel,
    thinkingBudget: options.thinkingBudget,
    googleSearchEnabled: options.googleSearchEnabled,
    generationConfig: options.generationConfig,
    sessionSeed: options.sessionSeed,
    userPromptSeed: options.userPromptSeed,
    projectId,
    pidOffsetEnabled: options.pidOffsetEnabled,
  });

  const bases = getEndpointsForModel(model, options.endpointOverrides);
  const fullEndpoints = bases.map(b=> `${b.replace(/\/+$/,"")}${options.methodSuffix ?? STREAM_METHOD}`);

  const version = options.antigravityVersion ?? ANTIGRAVITY_VERSION_FALLBACK;
  const headers = buildCommonHeaders({ accessToken: token, userAgent: options.userAgent, version }, "antigravity");

  const bodyWrapper = buildCloudCodeBody(projectId, inner);
  // bodyWrapper.model set here
  bodyWrapper.model = model;
  // keep request key as spec requires {model, project, request}
  // Some daily endpoints expect also projectId top-level? include both for compat
  const body = {
    model: bodyWrapper.model,
    project: bodyWrapper.project,
    request: bodyWrapper.request,
    user_prompt_id: bodyWrapper.user_prompt_id,
    session_id: bodyWrapper.session_id,
  };

  return {
    url: fullEndpoints[0],
    endpoints: fullEndpoints,
    baseEndpoints: bases,
    headers,
    body,
    sessionId: inner.sessionId,
    userPromptId: inner.userPromptId,
    isGeminiCLIOnly: isGeminiCLIOnlyModel(model),
    method:"POST",
    innerRequest: inner,
  };
}

export function buildGeminiCLIRequest(options:BuildOptions): BuildResult {
  if (!options) throw new Error("build options required for Gemini CLI");
  const projectId = String(options.projectId??"").trim() || FALLBACK_PROJECT_ID;
  const token = String(options.accessToken??"").trim();
  if (!token) throw new Error("accessToken required");
  const model = String(options.model??"").trim();
  if (!model) throw new Error("model required for Gemini CLI");

  const inner = transformRequest({
    model: options.model,
    messages: options.messages,
    tools: options.tools,
    system: options.system,
    thinkingLevel: options.thinkingLevel,
    thinkingBudget: options.thinkingBudget,
    googleSearchEnabled: options.googleSearchEnabled,
    generationConfig: options.generationConfig,
    sessionSeed: options.sessionSeed,
    userPromptSeed: options.userPromptSeed,
    projectId,
    pidOffsetEnabled: options.pidOffsetEnabled,
  });

  const rawBases = getEndpointsForModel(model, options.endpointOverrides);
  const filteredBases = rawBases.filter(b=>!b.toLowerCase().includes("sandbox"));
  const bases = filteredBases.length>0 ? filteredBases : [CODE_ASSIST_ENDPOINTS.PROD];
  const fullEndpoints = bases.map(b=> `${b.replace(/\/+$/,"")}${options.methodSuffix ?? STREAM_METHOD}`);

  const version = options.antigravityVersion ?? ANTIGRAVITY_VERSION_FALLBACK;
  const headers = buildCommonHeaders({ accessToken: token, userAgent: options.userAgent, version }, "gemini-cli");

  const bodyWrapper = buildCloudCodeBody(projectId, inner);
  const body = {
    model,
    project: projectId,
    request: bodyWrapper.request,
    user_prompt_id: bodyWrapper.user_prompt_id,
    session_id: bodyWrapper.session_id,
  };

  return {
    url: fullEndpoints[0],
    endpoints: fullEndpoints,
    baseEndpoints: bases,
    headers,
    body,
    sessionId: inner.sessionId,
    userPromptId: inner.userPromptId,
    isGeminiCLIOnly:true,
    method:"POST",
    innerRequest: inner,
  };
}

export async function fetchWithCascade(buildResult:BuildResult, fetchOptions?:{signal?:AbortSignal; timeoutMs?:number;}): Promise<Response> {
  if (!buildResult || !Array.isArray(buildResult.endpoints) || buildResult.endpoints.length===0) throw new Error("buildResult with endpoints required");
  let lastError:Error|null=null;

  for (const endpointUrl of buildResult.endpoints) {
    const controller = new AbortController();
    const timeoutMs = fetchOptions?.timeoutMs ?? CONTENT_TIMEOUT_MS;
    const to = setTimeout(()=>controller.abort(), timeoutMs);

    const signal = fetchOptions?.signal ? (()=> {
      const combined = new AbortController();
      const onExt = ()=>combined.abort();
      fetchOptions.signal!.addEventListener("abort", onExt, { once:true });
      controller.signal.addEventListener("abort", ()=>combined.abort());
      return combined.signal;
    })() : controller.signal;

    try {
      const jitter = getJitter();
      if (jitter>0) await new Promise(r=>setTimeout(r,jitter));

      const headers = stripForbiddenHeaders(buildResult.headers);

      const res = await fetch(endpointUrl, {
        method: buildResult.method,
        headers,
        body: JSON.stringify(buildResult.body),
        signal,
      });

      if (res.status===403 || res.status===404 || res.status>=500) {
        lastError = new Error(`cascade retryable status ${res.status} at ${endpointUrl}`);
        continue;
      }
      clearTimeout(to);
      return res;
    } catch (e:any) {
      clearTimeout(to);
      lastError = e instanceof Error ? e : new Error(String(e));
      if (fetchOptions?.signal?.aborted) throw lastError;
      continue;
    } finally {
      clearTimeout(to);
    }
  }
  throw lastError ?? new Error("all endpoints failed in cascade");
}

// ---------------------------------------------------------------------------
// Account persistence — minimal inline implementation + reuse AccountManager if present
// ---------------------------------------------------------------------------

function resolveConfigDir(): string {
  const env = (process.env.OPENCODE_CONFIG_DIR?.trim() ?? "");
  if (env) return resolve(env);
  return join(homedir(), ".config", "opencode");
}
function resolveAccountsPath(custom?:string): string {
  if (custom) return resolve(custom);
  return join(resolveConfigDir(), "antigravity-accounts.json");
}

async function loadAccountsInline(filePath?:string): Promise<Account[]> {
  const fp = resolveAccountsPath(filePath);
  try {
    const content = await fsp.readFile(fp, "utf8");
    const parsed = JSON.parse(content);
    if (Array.isArray(parsed)) return parsed as Account[];
    if (Array.isArray(parsed.accounts)) return parsed.accounts as Account[];
    if (parsed.accounts && typeof parsed.accounts==="object") return Object.values(parsed.accounts) as Account[];
    return [];
  } catch { return []; }
}

async function saveAccountsInline(accounts:Account[], filePath?:string): Promise<void> {
  const fp = resolveAccountsPath(filePath);
  const dir = dirname(fp);
  try { await fsp.mkdir(dir, { recursive:true, mode:0o755 }); } catch {}
  const wrapper = { version:3, accounts, updatedAt: Date.now() };
  const tmp = `${fp}.tmp.${randomInt(100000,999999)}`;
  try {
    await fsp.writeFile(tmp, JSON.stringify(wrapper, null, 2), { mode:0o600 });
    await fsp.rename(tmp, fp);
    try { await fsp.chmod(fp, 0o600); } catch {}
  } catch {}
}

// Minimal AccountManager fallback that reuses inline loader + round-robin
class InlineAccountManager {
  private accounts: Account[] = [];
  private rotationIndex = 0;
  private loaded=false;
  private filePath: string;

  constructor(filePath?:string) { this.filePath = resolveAccountsPath(filePath); }

  async load(): Promise<void> {
    if (this.loaded) return;
    this.accounts = await loadAccountsInline(this.filePath);
    this.loaded=true;
  }
  async save(): Promise<void> { await saveAccountsInline(this.accounts, this.filePath); }

  list(): Account[] { return [...this.accounts]; }

  async getNextAccount(strategy:"round-robin"|"sticky"="round-robin"): Promise<Account|null> {
    await this.load();
    const healthy = this.accounts.filter(a=>!a.disabled && (!a.quotaExhaustedUntil || Date.now()>=a.quotaExhaustedUntil));
    if (healthy.length===0) return this.accounts[0]??null;
    if (strategy==="sticky" && healthy.length>0) return healthy[0];
    const idx = this.rotationIndex % healthy.length;
    const acc = healthy[idx];
    this.rotationIndex = (this.rotationIndex+1)%healthy.length;
    return acc;
  }

  async addAccount(a:Account): Promise<void> {
    await this.load();
    const existingIdx = this.accounts.findIndex(x=>x.email.toLowerCase()===a.email.toLowerCase());
    if (existingIdx>=0) this.accounts[existingIdx]={...this.accounts[existingIdx], ...a, updatedAt: Date.now()};
    else this.accounts.push({...a, createdAt: Date.now(), updatedAt: Date.now()});
    await this.save();
  }

  async markQuotaExhausted(email:string, durationMs=20*60*1000): Promise<void> {
    const acc = this.accounts.find(a=>a.email.toLowerCase()===email.toLowerCase());
    if (acc) { acc.quotaExhaustedUntil = Date.now()+durationMs; await this.save(); }
  }

  async refreshAccount(email:string): Promise<{accessToken?:string}|null> {
    // try oauth module if present
    try {
      const oauth = await import("./oauth.js");
      const acc = this.accounts.find(a=>a.email.toLowerCase()===email.toLowerCase());
      if (!acc?.refreshToken) return null;
      if (typeof oauth.refreshAccessToken==="function") {
        const tokens = await oauth.refreshAccessToken(acc.refreshToken);
        if (tokens?.access_token) {
          acc.accessToken = tokens.access_token;
          acc.expiry = Date.now() + (tokens.expires_in ?? 3600)*1000;
          await this.save();
          return { accessToken: tokens.access_token };
        }
      }
    } catch {}
    return null;
  }
}

// ---------------------------------------------------------------------------
// Quota — minimal dual pool + shouldSkipAccount
// ---------------------------------------------------------------------------

function mapModelToQuotaGroup(model:string): string {
  const lower = (model??"").toLowerCase();
  if (lower.includes("claude") || lower.includes("gpt-oss")) return "antigravity";
  if (lower.includes("gemini")) return "gemini-cli";
  return "antigravity";
}

class InlineQuotaManager {
  private exhausted: Map<string, { until:number; group?:string }> = new Map();

  shouldSkipAccount(email:string, model:string): boolean {
    const key = `${email.toLowerCase()}:${mapModelToQuotaGroup(model)}`;
    const entry = this.exhausted.get(key) ?? this.exhausted.get(email.toLowerCase());
    if (!entry) return false;
    if (Date.now()>=entry.until) { this.exhausted.delete(key); this.exhausted.delete(email.toLowerCase()); return false; }
    return true;
  }

  markExhausted(email:string, model:string, durationMs=20*60*1000, group?:string): void {
    const g = group ?? mapModelToQuotaGroup(model);
    this.exhausted.set(`${email.toLowerCase()}:${g}`, { until: Date.now()+durationMs, group:g });
  }

  isQuotaError(status:number, bodyText?:string): boolean {
    if (status===429) return true;
    if (!bodyText) return false;
    const lower = bodyText.toLowerCase();
    return lower.includes("quota") || lower.includes("exhausted") || lower.includes("limit") || lower.includes("resource_exhausted");
  }
}

// ---------------------------------------------------------------------------
// Streaming helpers — SSE tolerant parser + OpenAI/Anthropic transformers minimal
// ---------------------------------------------------------------------------

const SSE_DONE = "[DONE]";

function createSSEParser() {
  let buffer="";
  return {
    parseChunk(chunk:string): { data:string; event?:string }[] {
      buffer+=chunk;
      const events: {data:string;event?:string}[]=[];
      let idx;
      while ((idx=buffer.indexOf("\n\n"))>=0) {
        const block = buffer.slice(0,idx);
        buffer = buffer.slice(idx+2);
        const lines = block.split("\n");
        let data="";
        let event="";
        for (const line of lines) {
          if (line.startsWith("data:")) data+= (data? "\n":"") + line.slice(5).trimStart();
          else if (line.startsWith("event:")) event=line.slice(6).trim();
          else if (line.trim()==="") continue;
          else data+= (data? "\n":"") + line;
        }
        if (data) events.push({ data, event: event||undefined });
      }
      return events;
    },
    flush(): {data:string;event?:string}[] {
      if (!buffer.trim()) return [];
      const b=buffer; buffer="";
      const lines=b.split("\n");
      let data="";
      let event="";
      for (const line of lines) {
        if (line.startsWith("data:")) data+= (data? "\n":"") + line.slice(5).trimStart();
        else if (line.startsWith("event:")) event=line.slice(6).trim();
        else if (line.trim()) data+= (data? "\n":"") + line;
      }
      return data ? [{ data, event: event||undefined }] : [];
    }
  };
}

function normalizeGeminiPayload(raw:string): any[] {
  const out:any[]=[];
  const trimmed = raw.trim();
  if (!trimmed || trimmed===SSE_DONE) return out;
  let parsed:any;
  try { parsed = JSON.parse(trimmed); } catch {
    // sometimes wrapped as "{"response":...}"? try tolerant
    return out;
  }
  // cloudcode-pa returns {response: {candidates:[{content:{parts:[...]}}]}} or direct
  const unwrap = (obj:any): any[] => {
    if (!obj) return [];
    if (obj.response) return unwrap(obj.response);
    if (Array.isArray(obj.candidates)) return obj.candidates;
    if (obj.candidates) return unwrap(obj.candidates);
    if (obj.content) return [obj];
    return [obj];
  };
  const candidates = unwrap(parsed);
  for (const cand of candidates) {
    const content = cand.content ?? cand;
    const parts = content.parts ?? content.content?.parts ?? [];
    if (!Array.isArray(parts)) continue;
    for (const part of parts) out.push(part);
  }
  // also handle case where parsed is already part
  if (candidates.length===0 && (parsed.text || parsed.functionCall || parsed.thought)) out.push(parsed);
  return out;
}

function transformToOpenAIChunk(parts:any[], model:string, isFirst:boolean, isLast:boolean): any {
  // minimal OpenAI delta
  let text="";
  const toolCalls:any[]=[];
  let thought="";
  for (const p of parts) {
    if (p.text) text+=p.text;
    if (p.functionCall) toolCalls.push({ id:`call_${fnv1a32Hex(JSON.stringify(p.functionCall)).slice(0,8)}`, type:"function", function:{ name:p.functionCall.name, arguments: JSON.stringify(p.functionCall.args??{}) } });
    if (p.thought) thought+=p.thought;
  }
  const delta:any={ role: isFirst ? "assistant" : undefined, content: text || undefined };
  if (toolCalls.length>0) delta.tool_calls=toolCalls;
  const chunk:any = {
    id: `chatcmpl-${fnv1a32Hex(model+Date.now()).slice(0,12)}`,
    object:"chat.completion.chunk",
    created: Math.floor(Date.now()/1000),
    model,
    choices:[{ index:0, delta, finish_reason: isLast ? "stop" : null }],
  };
  return chunk;
}

// ---------------------------------------------------------------------------
// Main plugin class — bypass Project ID exactly as Gemini CLI
// ---------------------------------------------------------------------------

export class AntigravityPlugin {
  private accountManager: any;
  private quotaManager: InlineQuotaManager;
  private options: PluginOptions;
  private version: string = ANTIGRAVITY_VERSION_FALLBACK;
  private initialized=false;

  constructor(options: PluginOptions = {}) {
    this.options = options;
    this.quotaManager = new InlineQuotaManager();
    // try load external AccountManager for advanced persistence, fallback inline
    try {
      // will be lazy initialized in init()
      this.accountManager = new InlineAccountManager();
    } catch {
      this.accountManager = new InlineAccountManager();
    }
  }

  async init(): Promise<void> {
    if (this.initialized) return;
    try {
      const verMod = await import("./version.js").catch(()=>null);
      if (verMod && typeof verMod.getVersion==="function") {
        this.version = await verMod.getVersion().catch(()=>ANTIGRAVITY_VERSION_FALLBACK);
      }
    } catch { this.version = ANTIGRAVITY_VERSION_FALLBACK; }

    // attempt to use real AccountManager if exists (has richer refresh)
    try {
      const accMod = await import("./accounts.js").catch(()=>null);
      if (accMod && accMod.AccountManager) {
        const mgr = new accMod.AccountManager();
        await (mgr as any).load?.().catch(()=>{});
        // if has accounts, use it
        if ((mgr as any).accounts && (mgr as any).accounts.length>0) this.accountManager = mgr;
        else {
          // keep inline but copy accounts if external has
          await this.accountManager.load().catch(()=>{});
        }
      } else {
        await this.accountManager.load().catch(()=>{});
      }
    } catch {
      await this.accountManager.load().catch(()=>{});
    }

    this.initialized=true;
  }

  private getUserAgent(): string {
    try { return getDynamicUserAgent(this.version); } catch { return `antigravity/${this.version} linux/x64`; }
  }

  private shouldHandleModel(model:string): boolean {
    if (!model) return false;
    const lower = model.toLowerCase();
    return lower.includes("antigravity") || lower.includes("gemini") || lower.includes("claude") || lower.includes("gpt-oss") || MODELS_2026.some(m=>lower.includes(m.toLowerCase()));
  }

  private async getAccountForModel(model:string): Promise<Account|null> {
    const preferCliFirst = this.options.cli_first ?? false;
    // dual quota: if cli_first and gemini model, prefer gemini-cli pool first (preserve antigravity for claude)
    // observer implements as round-robin with skip
    let lastErr: any = null;
    for (let i=0;i<10;i++) {
      try {
        const candidate = await this.accountManager.getNextAccount?.(this.options.rotation_strategy ?? "round-robin").catch(()=>null) ?? await this.accountManager.getNextAccount(this.options.rotation_strategy ?? "round-robin").catch(()=>null) ?? null;
        if (!candidate) break;
        if (this.quotaManager.shouldSkipAccount(candidate.email, model)) continue;

        // cli_first: if gemini and candidate type is antigravity, try to find gemini-cli first? simple heuristic
        if (preferCliFirst && model.toLowerCase().includes("gemini")) {
          // if candidate is claude-only? we still allow but prefer gemini-cli: skip antigravity if another healthy exists
          const isAntigravityOnly = (candidate.type==="antigravity") && isGeminiCLIOnlyModel(model);
          // If gemini-cli only model, we should not skip antigravity but note that fallback project would 403 — try next once
          if (isAntigravityOnly) {
            // look ahead one more account in case multi-account
            const nextCandidate = await this.accountManager.getNextAccount?.("round-robin").catch(()=>null);
            if (nextCandidate && !this.quotaManager.shouldSkipAccount(nextCandidate.email, model)) {
              return nextCandidate as Account;
            }
          }
        }

        return candidate as Account;
      } catch (e) { lastErr=e; continue; }
    }
    // fallback any
    try {
      const anyAcc = await this.accountManager.getNextAccount?.().catch(()=>null) ?? await this.accountManager.getNextAccount().catch(()=>null);
      return anyAcc as Account|null;
    } catch { return null; }
  }

  private async refreshIfNeeded(account:Account): Promise<string> {
    if (account.accessToken && account.expiry && Date.now() < account.expiry - 5*60*1000) return account.accessToken;
    try {
      const refreshed = await (this.accountManager as any).refreshAccount?.(account.email).catch(()=>null) ?? null;
      if (refreshed?.accessToken) return refreshed.accessToken;
      if ((refreshed as any)?.access_token) return (refreshed as any).access_token;
    } catch {}
    try {
      const oauth = await import("./oauth.js");
      if (typeof (oauth as any).refreshAccessToken==="function" && account.refreshToken) {
        const tokens = await (oauth as any).refreshAccessToken(account.refreshToken);
        if (tokens?.access_token) {
          account.accessToken = tokens.access_token;
          account.expiry = Date.now() + (tokens.expires_in ?? 3600)*1000;
          await this.accountManager.save?.().catch(()=>{});
          return tokens.access_token;
        }
      }
    } catch {}
    if (account.accessToken) return account.accessToken;
    throw new Error(`no access token for ${account.email}`);
  }

  /**
   * handleFetch — intercepta fetch do opencode provider google.
   * Observer third-person: faz exatamente como Gemini CLI:
   * - se account.projectId ausente, chama resolveProjectId que faz loadCodeAssist SEM project, onboardUser se necessário, nunca exige project do usuário.
   * - wrapping {model, project, request} direto cloudcode-pa, sem localhost v1 proxy.
   * - cascade 403/404/5xx, strip x-goog-user-project, skip sandbox para gemini-3.6/3.5/preview.
   * - dual quota + cli_first + pid_offset.
   */
  async handleFetch(originalFetch: typeof fetch, input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    await this.init();

    const urlStr = typeof input==="string" ? input : input instanceof URL ? input.toString() : (input as Request).url ?? "";
    const method = (init?.method ?? (typeof input!=="string" && !(input instanceof URL) ? (input as Request).method : "POST") ?? "POST").toUpperCase();
    const bodyStr = (init?.body as string) ?? "";

    // only intercept POST to google / generative or our own transformed calls
    // opencode typically calls fetch to provider endpoint; body contains model
    let parsedBody:any = null;
    let model:string|undefined;
    let messages:any[]|undefined;
    let tools:any[]|undefined;
    let system:any|undefined;
    let thinkingLevel:string|undefined;
    let generationConfig:any|undefined;
    let isAlreadyWrapped = false;

    try {
      if (bodyStr) {
        parsedBody = JSON.parse(bodyStr);
        model = parsedBody?.model ?? parsedBody?.request?.model ?? parsedBody?.modelId ?? "";
        // detect if already in cloudcode envelope {model, project, request}
        if (parsedBody?.project && parsedBody?.request && parsedBody?.model) {
          isAlreadyWrapped = true;
          model = parsedBody.model;
        } else {
          messages = parsedBody?.messages ?? parsedBody?.request?.contents ?? undefined;
          tools = parsedBody?.tools ?? parsedBody?.request?.tools ?? undefined;
          system = parsedBody?.system ?? parsedBody?.systemInstruction ?? parsedBody?.request?.systemInstruction ?? undefined;
          thinkingLevel = parsedBody?.thinkingLevel ?? parsedBody?.thinking_level ?? parsedBody?.request?.thinkingLevel ?? undefined;
          generationConfig = parsedBody?.generationConfig ?? parsedBody?.request?.generationConfig ?? undefined;
        }
      }
    } catch {
      // not json, skip intercept
    }

    // if not our model, passthrough
    if (!isAlreadyWrapped && (!model || !this.shouldHandleModel(model))) {
      return originalFetch(input, init);
    }

    const effectiveModel = String(model ?? "").trim();
    if (!effectiveModel) return originalFetch(input, init);

    // account selection dual quota
    let account = await this.getAccountForModel(effectiveModel);
    if (!account) {
      return new Response(JSON.stringify({ error: `no antigravity accounts available for model ${effectiveModel} — run opencode auth login` }), { status: 401, headers: { "Content-Type":"application/json" } });
    }

    let accessToken: string;
    try {
      accessToken = await this.refreshIfNeeded(account);
    } catch (e:any) {
      return new Response(JSON.stringify({ error: `failed to refresh token for ${account.email}: ${e.message}` }), { status: 401 });
    }

    // bypass total Project ID — exactly Gemini CLI
    let projectId = (account as any).projectId?.trim() ?? "";
    if (!projectId) {
      try {
        const resolved = await resolveProjectId({
          accessToken,
          cachedProjectId: undefined,
          email: account.email,
          metadataSaver: async (pid:string) => {
            (account as any).projectId = pid;
            // save to manager
            try { await this.accountManager.save?.(); } catch {}
          },
          userAgent: this.getUserAgent(),
        });
        projectId = resolved.projectId;
      } catch (e:any) {
        // fallback still returns project id, but if throw -> use blinded fallback with warning
        projectId = FALLBACK_PROJECT_ID;
        console.warn(`[antigravity-auth] resolveProjectId failed for ${account.email}, using fallback ${FALLBACK_PROJECT_ID}: ${e.message}`);
      }
    }

    // transform request if not already wrapped
    let buildOpts: BuildOptions;
    if (isAlreadyWrapped) {
      // already {model, project, request} — ensure project is our resolved one
      const existingRequest = parsedBody.request ?? {};
      buildOpts = {
        model: effectiveModel,
        messages: existingRequest.contents ? [{ role:"user", content:"" }] : messages, // dummy, will be overridden since we already have request
        tools,
        system,
        thinkingLevel,
        generationConfig,
        accessToken,
        projectId,
        userAgent: this.getUserAgent(),
        antigravityVersion: this.version,
        pidOffsetEnabled: this.options.pid_offset_enabled ?? false,
        googleSearchEnabled: this.options.google_search_enabled ?? true,
      };
      // override inner via direct usage of parsedBody.request for preserving exact content if provided
      // but still rebuild to ensure deterministic ids
      buildOpts.messages = undefined; // we will inject directly below
    } else {
      buildOpts = {
        model: effectiveModel,
        messages,
        tools,
        system,
        thinkingLevel,
        generationConfig,
        accessToken,
        projectId,
        userAgent: this.getUserAgent(),
        antigravityVersion: this.version,
        pidOffsetEnabled: this.options.pid_offset_enabled ?? false,
        googleSearchEnabled: this.options.google_search_enabled ?? true,
      };
    }

    // Decide whether to use gemini-cli builder (prod-only) or antigravity generic
    const isCliOnly = isGeminiCLIOnlyModel(effectiveModel) || shouldSkipSandbox(effectiveModel);
    const builder = (this.options.cli_first && effectiveModel.toLowerCase().includes("gemini") && !effectiveModel.toLowerCase().includes("claude")) || isCliOnly ? buildGeminiCLIRequest : buildAntigravityRequest;

    let buildResult: BuildResult;
    try {
      buildResult = builder(buildOpts);

      // If original was already wrapped, preserve its request content but use our project and ids
      if (isAlreadyWrapped && parsedBody?.request) {
        // Keep original contents etc to avoid double transformation
        const originalReq = parsedBody.request;
        buildResult.body.request = {
          ...originalReq,
          // ensure generationConfig merged with thinking
          generationConfig: buildResult.body.request?.generationConfig ?? originalReq.generationConfig,
          tools: buildResult.body.request?.tools ?? originalReq.tools,
        };
        // update model/project remains
        buildResult.body.model = effectiveModel;
        buildResult.body.project = projectId;
      }
    } catch (e:any) {
      return new Response(JSON.stringify({ error: `failed to build antigravity request: ${e.message}` }), { status: 500 });
    }

    // cascade fetch with retry 403/404/5xx + strip forbidden headers
    const exec = async (): Promise<Response> => {
      let lastRes: Response | null = null;
      let lastError: Error | null = null;

      // attempt up to 2 account rotations on 403/429
      for (let accountAttempt=0; accountAttempt<2; accountAttempt++) {
        try {
          const response = await fetchWithCascade(buildResult, { timeoutMs: CONTENT_TIMEOUT_MS });

          // handle quota exhausted
          if (response.status===429 || (response.headers.get("content-type")?.includes("json") && false)) {
            // read body text for quota check but need clone
            const cloned = response.clone();
            const txt = await cloned.text().catch(()=>"" );
            if (this.quotaManager.isQuotaError(response.status, txt)) {
              this.quotaManager.markExhausted(account.email, effectiveModel, 60*60*1000);
              await (this.accountManager as any).markQuotaExhausted?.(account.email, 60*60*1000).catch(()=>{});
              // rotate account
              const nextAcc = await this.getAccountForModel(effectiveModel);
              if (nextAcc && nextAcc.email!==account.email) {
                account = nextAcc;
                try {
                  accessToken = await this.refreshIfNeeded(account);
                } catch {}
                // re-resolve projectId if missing for new account
                let newPid = (account as any).projectId?.trim() ?? "";
                if (!newPid) {
                  try {
                    const resolved = await resolveProjectId({
                      accessToken,
                      email: account.email,
                      metadataSaver: async (pid:string)=> { (account as any).projectId=pid; try{ await this.accountManager.save?.(); }catch{} },
                      userAgent: this.getUserAgent(),
                    });
                    newPid = resolved.projectId;
                  } catch { newPid = FALLBACK_PROJECT_ID; }
                }
                // rebuild with new token/project
                buildOpts.accessToken = accessToken;
                buildOpts.projectId = newPid;
                buildResult = builder(buildOpts);
                continue;
              }
            }
          }

          // success or non-retryable error — return response, but transform if needed
          lastRes = response;

          // if response is not ok and retryable, cascade already handled inside fetchWithCascade loop — but if final is 403/404 here, try next endpoint account rotation
          if (response.status===403 || response.status===404 || response.status>=500) {
            lastError = new Error(`retryable status ${response.status}`);
            // try next account rotation once
            if (accountAttempt===0) {
              const nextAcc = await this.getAccountForModel(effectiveModel);
              if (nextAcc && nextAcc.email!==account.email) {
                account = nextAcc;
                try { accessToken = await this.refreshIfNeeded(account); } catch {}
                buildOpts.accessToken = accessToken;
                buildOpts.projectId = (account as any).projectId ?? projectId;
                buildResult = builder(buildOpts);
                continue;
              }
            }
          }

          return response;
        } catch (e:any) {
          lastError = e instanceof Error ? e : new Error(String(e));
          // try next account if error retryable
          if (accountAttempt===0) {
            const nextAcc = await this.getAccountForModel(effectiveModel);
            if (nextAcc && nextAcc.email!==account.email) {
              account = nextAcc;
              try { accessToken = await this.refreshIfNeeded(account); } catch {}
              buildOpts.accessToken = accessToken;
              buildOpts.projectId = (account as any).projectId ?? projectId;
              buildResult = builder(buildOpts);
              continue;
            }
          }
        }
      }

      if (lastRes) return lastRes;
      throw lastError ?? new Error("all account attempts failed");
    };

    let response: Response;
    try {
      response = await exec();
    } catch (e:any) {
      // try fallback to other pool if cli_first enabled
      if (this.options.cli_first && !isCliOnly) {
        try {
          const fallbackBuild = buildGeminiCLIRequest({
            ...buildOpts,
            endpointOverrides: [CODE_ASSIST_ENDPOINTS.PROD],
          });
          response = await fetchWithCascade(fallbackBuild);
        } catch {
          return new Response(JSON.stringify({ error: `antigravity request failed after retries: ${e.message}` }), { status: 500, headers: { "Content-Type":"application/json" } });
        }
      } else {
        return new Response(JSON.stringify({ error: `antigravity request failed after retries: ${e.message}` }), { status: 500, headers: { "Content-Type":"application/json" } });
      }
    }

    // transform SSE to OpenAI-compatible if needed — detect client expects event-stream?
    const contentType = response.headers.get("content-type") ?? "";
    const isSSE = contentType.includes("text/event-stream") || response.url.includes("alt=sse") || effectiveModel.includes("gemini") || effectiveModel.includes("claude");

    // If caller originally asked for OpenAI SSE (common in opencode), we transform cloudcode SSE → OpenAI SSE lines
    // Observer notes: return text/event-stream with data: {...}\n\n lines
    if (isSSE && response.body) {
      const isAnthropic = (parsedBody?.anthropic_version !== undefined) || (urlStr.toLowerCase().includes("anthropic"));

      const parser = createSSEParser();
      const decoder = new TextDecoder();
      const encoder = new TextEncoder();

      const originalStream = response.body as ReadableStream<Uint8Array>;

      const transformedStream = new ReadableStream({
        async start(controller) {
          const reader = originalStream.getReader();
          let first = true;
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              const text = decoder.decode(value, { stream:true });
              const events = parser.parseChunk(text);
              for (const ev of events) {
                const payloads = normalizeGeminiPayload(ev.data);
                for (const part of payloads) {
                  const chunkObj = transformToOpenAIChunk([part], effectiveModel, first, false);
                  first = false;
                  const line = `data: ${JSON.stringify(chunkObj)}\n\n`;
                  controller.enqueue(encoder.encode(line));
                }
                // if event data is [DONE] close
                if (ev.data.trim()===SSE_DONE) {
                  controller.enqueue(encoder.encode(`data: ${SSE_DONE}\n\n`));
                }
              }
            }
            // flush
            const remaining = parser.flush();
            for (const ev of remaining) {
              const payloads = normalizeGeminiPayload(ev.data);
              for (const part of payloads) {
                const chunkObj = transformToOpenAIChunk([part], effectiveModel, first, false);
                first=false;
                controller.enqueue(encoder.encode(`data: ${JSON.stringify(chunkObj)}\n\n`));
              }
            }
            // final chunk with stop
            const finalChunk = {
              id: `chatcmpl-${fnv1a32Hex(effectiveModel+Date.now()).slice(0,12)}`,
              object:"chat.completion.chunk",
              created: Math.floor(Date.now()/1000),
              model: effectiveModel,
              choices:[{ index:0, delta:{}, finish_reason:"stop" }],
            };
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(finalChunk)}\n\n`));
            controller.enqueue(encoder.encode(`data: ${SSE_DONE}\n\n`));
            controller.close();
          } catch (e) {
            controller.error(e);
          }
        }
      });

      return new Response(transformedStream, {
        status: response.status,
        headers: {
          "Content-Type":"text/event-stream",
          "Cache-Control":"no-cache",
          Connection:"keep-alive",
          "X-Antigravity-Model": effectiveModel,
          "X-Antigravity-Project": projectId,
        },
      });
    }

    // non-streaming: try to transform JSON to OpenAI-compatible
    try {
      const text = await response.text();
      let json:any;
      try { json = JSON.parse(text); } catch { json = { text }; }

      // if already OpenAI shape, just return
      if (json.choices || json.content) {
        return new Response(JSON.stringify(json), { status: response.status, headers: { "Content-Type":"application/json" } });
      }

      // unwrap Gemini candidate to text
      const candidates = json.response?.candidates ?? json.candidates ?? [];
      let combinedText="";
      for (const cand of candidates) {
        const parts = cand.content?.parts ?? [];
        for (const p of parts) if (p.text) combinedText+=p.text;
      }
      // if we got text, wrap as OpenAI
      if (combinedText) {
        const openAI = {
          id: `chatcmpl-${fnv1a32Hex(effectiveModel+Date.now()).slice(0,12)}`,
          object:"chat.completion",
          created: Math.floor(Date.now()/1000),
          model: effectiveModel,
          choices:[{ index:0, message:{ role:"assistant", content: combinedText }, finish_reason:"stop" }],
        };
        return new Response(JSON.stringify(openAI), { status: 200, headers: { "Content-Type":"application/json" } });
      }

      return new Response(JSON.stringify(json), { status: response.status, headers: { "Content-Type":"application/json" } });
    } catch {
      return response;
    }
  }

  getPluginDefinition() {
    const self = this;
    return {
      id: PLUGIN_ID,
      version: PLUGIN_VERSION,
      name: "Antigravity Auth Next",
      description: "Enable Opencode to authenticate against Antigravity via OAuth — supports models 25/08/2026 (gemini-3.6/3.5/3.1/3/2.5, claude-opus-4-6-thinking, gpt-oss-120b), dual quota, auto-recovery, direct cloudcode-pa (no localhost v1), bypass Project ID as Gemini CLI via loadCodeAssist+onboardUser",
      async onInit() { await self.init(); },
      hooks: {
        "tool.execute.before": async (ctx:any)=> ctx,
        "tool.execute.after": async (ctx:any)=> ctx,
        "fetch": async (input: RequestInfo | URL, init?: RequestInit, next: typeof fetch) => {
          return self.handleFetch(next, input, init);
        },
      },
      auth: {
        provider:"google",
        async login() {
          const { startOAuthFlow } = await import("./oauth.js");
          const result = await startOAuthFlow();
          if (!(result as any)?.tokens?.refresh_token && !(result as any)?.refresh_token) throw new Error("OAuth failed no refresh_token");
          const tokens = (result as any).tokens ?? result;
          const userInfo = (result as any).userInfo ?? {};
          const email = userInfo.email ?? `user-${Date.now()}@gmail.com`;
          const refresh = tokens.refresh_token ?? (result as any).refresh_token;
          const access = tokens.access_token ?? (result as any).access_token;
          // try add via AccountManager
          try {
            const accMod = await import("./accounts.js");
            if (accMod.AccountManager) {
              const mgr = new accMod.AccountManager();
              await mgr.load();
              await (mgr as any).addAccount?.({ email, refreshToken: refresh, accessToken: access } as any) ?? await (mgr as any).add?.(email, refresh).catch(()=>{});
              await mgr.save();
            }
          } catch {
            // fallback inline
            const inline = new InlineAccountManager();
            await inline.load();
            await inline.addAccount({ email, refreshToken: refresh, accessToken: access });
          }
          return { email };
        },
        async list() { await self.init(); try { const m = self.accountManager; return (m as any).list?.() ?? (m as any).accounts ?? []; } catch { return []; } },
        async logout(email?:string) {
          try {
            const accMod = await import("./accounts.js");
            const mgr = new accMod.AccountManager();
            await mgr.load();
            if (email) await (mgr as any).remove?.(email);
            else await (mgr as any).clear?.();
            await mgr.save();
          } catch {
            const inline = new InlineAccountManager();
            await inline.load();
            if (!email) {
              await saveAccountsInline([]);
            } else {
              const accs = await loadAccountsInline();
              await saveAccountsInline(accs.filter(a=>a.email.toLowerCase()!==email.toLowerCase()));
            }
          }
        },
      },
      config: {
        schema: {
          cli_first: { type:"boolean", default:false, description:"Route Gemini models to Gemini CLI quota first (preserve Antigravity quota for Claude) — dual quota" },
          pid_offset_enabled: { type:"boolean", default:false, description:"Enable PID offset trick 0-1000 randomization for user_prompt_id (9router anti-fingerprint)" },
          google_search_enabled: { type:"boolean", default:true, description:"Enable google_search grounding injection for Gemini models" },
          quota_refresh_interval_minutes: { type:"number", default:15 },
          rotation_strategy: { type:"string", enum:["round-robin","sticky"], default:"round-robin" },
        },
        defaults: {
          cli_first:false,
          pid_offset_enabled:false,
          google_search_enabled:true,
          quota_refresh_interval_minutes:15,
          rotation_strategy:"round-robin",
        },
      },
      models: MODELS_2026.map(id=>({
        id,
        name: id,
        provider:"google",
        context: id.toLowerCase().includes("claude") ? 200000 : id.toLowerCase().includes("gpt-oss") ? 131072 : 1048576,
        output: id.toLowerCase().includes("claude") ? 64000 : id.toLowerCase().includes("gpt-oss") ? 32768 : 65535,
        modalities: { input:["text","image","pdf"], output:["text"] },
      })),
    };
  }
}

// singleton for opencode
let pluginInstance: AntigravityPlugin | null = null;

export function getPlugin(options?: PluginOptions): AntigravityPlugin {
  if (!pluginInstance) pluginInstance = new AntigravityPlugin(options);
  return pluginInstance;
}

export const plugin = getPlugin().getPluginDefinition();

export default plugin;
