/**
 * @file index.ts
 * @description Barrel ESM reexportando todo core, library-first root-first, ~30 modes compatible.
 * observer third-person.
 */

export * as Constants from "./constants.js";
export * from "./constants.js";

export * as Fingerprint from "./fingerprint.js";
export * from "./fingerprint.js";

export * as OAuth from "./oauth.js";
export * from "./oauth.js";

export * as Accounts from "./accounts.js";
export * from "./accounts.js";

export * as Project from "./project.js";
export * from "./project.js";

export * as Quota from "./quota.js";
export * from "./quota.js";

export * as Config from "./config.js";
export * from "./config.js";

export * as Debug from "./debug.js";
export * from "./debug.js";

export * as Version from "./version.js";
export * from "./version.js";

export * as RequestHelpers from "./request-helpers.js";
export * from "./request-helpers.js";

export * as Request from "./request.js";
export * from "./request.js";

export * as Streaming from "./streaming.js";
export * from "./streaming.js";

export * as Recovery from "./recovery.js";
export * from "./recovery.js";

export * as Search from "./search.js";
export * from "./search.js";

export * as CLI from "./cli.js";
export * from "./cli.js";

export * as PluginModule from "./plugin.js";
export * from "./plugin.js";

// default plugin export for opencode compatibility
import plugin from "./plugin.js";
export default plugin;

// named default for npm
export { default as plugin } from "./plugin.js";

// version
export const VERSION = "2.0.0" as const;
export const PLUGIN_ID = "opencode-antigravity-auth-next" as const;

/**
 * Library-first convenience: getPlugin()
 */
export { getPlugin } from "./plugin.js";

export * as Models2026 from "./models-2026.js";
export * from "./models-2026.js";
