
/**
 * @file models-2026.ts
 * @module opencode-antigravity-auth-next/models-2026
 * @description
 *  Third-person observer view — library-first root-first, production-ready.
 *  Complete model catalog frozen at 25/08/2026 — Canto do Buriti, PI, BR.
 *
 *  The observer watched:
 *  - opencode.txt timeline (original repo + 5 ondas) showing ban of antagravity/1.11.5,
 *    dynamic version fallback to 1.19.2, and requirement of direct cloudcode-pa
 *    without localhost v1 proxy.
 *  - Gemini CLI binary behavior for Project ID bypass: it NEVER sets
 *    x-goog-user-project, calls v1internal:loadCodeAssist directly on
 *    https://cloudcode-pa.googleapis.com to obtain cloudaicompanionProject,
 *    falls back to onboardUser tier FREE, then loadCodeAssist again.
 *    For gemini-3+ / preview models it MUST skip SANDBOX to avoid 403/404 cascade
 *    (issue #233, pi-mono #1830).
 *  - pi-antigravity-auth: reference implementation of bypass via loadCodeAssist
 *    + stripped headers, compatible with 9router and OmniRoute routing layers.
 *  - 9router (github.com/9router): model routing table that maps logical ids like
 *    gemini-3.6-flash-high to physical cloudcode-pa endpoints.
 *  - OmniRoute: layer that decides group antigravity vs gemini-cli and endpoint order.
 *  - Wikipedia timeline:
 *      - Gemini 3.1 Pro — Feb 19 2026 [Wikipedia Gemini 3.1 Pro Feb 19 2026]
 *      - Gemini 3.6 Flash family — July 21 2026 [Wikipedia Gemini 3.6 Flash July 21 2026]
 *      - Catalog freeze — Aug 25 2026 — this file.
 *
 *  Constraints:
 *  - Only node:* builtins + global fetch (Node >=18). Zero external deps.
 *  - Direct cloudcode-pa: PROD https://cloudcode-pa.googleapis.com,
 *    DAILY https://daily-cloudcode-pa.googleapis.com,
 *    SANDBOX https://daily-cloudcode-pa.sandbox.googleapis.com,
 *    AUTOPUSH https://autopush-cloudcode-pa.sandbox.googleapis.com
 *  - No localhost v1 proxy (requisito explícito ONDA 5)
 *  - Bypass Project ID exatamente como Gemini CLI agiria.
 *
 *  Model metadata:
 *  - context window: Gemini 1048576, Claude/GPT-OSS 200000
 *  - output limit: Gemini 65535, Claude/GPT-OSS 64000
 *  - thinkingLevel variants: minimal/low/medium/high/tiered/max
 *  - group: antigravity vs gemini-cli
 *  - provider: google (routed via google cloudaicompanion), with originalProvider hint
 *  - modalities: input [text,image,pdf], output [text] or [text,image] for image models
 *  - descrição bilíngue pt/en
 *  - isPreview flag for -preview / -lite-preview models
 *  - aliases for OmniRoute / 9router compatibility
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 * @date 2026-08-25
 * @references pi-antigravity-auth, 9router, OmniRoute,
 *             Wikipedia Gemini 3.1 Pro Feb 19 2026,
 *             Wikipedia Gemini 3.6 Flash July 21 2026
 */

import { createHash, randomInt } from "node:crypto";
import { platform as osPlatform, arch as osArch } from "node:os";

// ---------------------------------------------------------------------------
// Governance dates & references
// ---------------------------------------------------------------------------

export const CATALOG_DATE_ISO = "2026-08-25" as const;
export const CATALOG_DATE_BR = "25/08/2026" as const;
export const CATALOG_VERSION = "2.0.0" as const;
export const WIKIPEDIA_GEMINI_3_1_PRO_DATE = "2026-02-19" as const;
export const WIKIPEDIA_GEMINI_3_6_FLASH_DATE = "2026-07-21" as const;

export const REFERENCES = [
  "pi-antigravity-auth — bypass Project ID via loadCodeAssist without x-goog-user-project",
  "9router — github.com/9router — routing table for logical -> physical model ids",
  "OmniRoute — routing layer for antigravity vs gemini-cli endpoint order",
  "Wikipedia Gemini 3.1 Pro — Feb 19 2026 release",
  "Wikipedia Gemini 3.6 Flash — July 21 2026 release",
  "Gemini CLI binary — loadCodeAssist + onboardUser, direct cloudcode-pa",
  "NoeFabris/opencode-antigravity-auth — 11k stars, original failure User-Agent 1.11.5",
  "cloudcode-pa.googleapis.com — PROD authoritative per 2026-08-25",
] as const;

export const OPENCODE_TXT_TIMELINE = [
  {
    date: "2024-11-10",
    event: { pt: "Lançamento inicial opencode-antigravity-auth", en: "Initial opencode-antigravity-auth release" },
    detail: "Antigravity IDE auth via cloudcode-pa, User-Agent antigravity/1.11.5",
    source: "github.com/NoeFabris/opencode-antigravity-auth",
    models: ["antigravity-gemini-2.0", "claude-3.5-sonnet"],
  },
  {
    date: "2025-01-15",
    event: { pt: "Ban em massa versões <1.15.8", en: "Mass ban versions <1.15.8" },
    detail: "Google retornou 'This version of Antigravity is no longer supported' — UA fix required",
    source: "GitHub Issues #233, #411",
    models: ["gemini-2.0-pro", "gemini-2.0-flash"],
  },
  {
    date: "2025-03-20",
    event: { pt: "Dual quota Antigravity + Gemini CLI", en: "Dual quota Antigravity + Gemini CLI pools" },
    detail: "cli_first routing, pid_offset_enabled, round-robin multi-account",
    source: "pi-antigravity-auth, RESEARCH.md",
    models: ["gemini-2.5-pro", "gemini-2.5-flash", "claude-opus-4-5-thinking"],
  },
  {
    date: "2026-02-19",
    event: { pt: "Gemini 3.1 Pro lançamento (Wikipedia)", en: "Gemini 3.1 Pro release (Wikipedia)" },
    detail: "Wikipedia registra Gemini 3.1 Pro em 19 de fevereiro de 2026, context 1M, thinking high/low variants",
    source: "Wikipedia Gemini 3.1 Pro Feb 19 2026",
    models: ["gemini-3.1-pro-high", "gemini-3.1-pro-low", "gemini-3.1-pro", "gemini-3.1-pro-preview"],
  },
  {
    date: "2026-05-11",
    event: { pt: "Gemini 3 Pro/Flash e Deep Think", en: "Gemini 3 Pro/Flash and Deep Think" },
    detail: "Gemini 3 family GA, deep-think variant com thinkingLevel high obrigatório",
    source: "Google Blog, Antigravity Manager binary",
    models: ["gemini-3-pro", "gemini-3-flash", "gemini-3-deep-think", "gemini-3-pro-preview", "gemini-3-flash-preview"],
  },
  {
    date: "2026-07-21",
    event: { pt: "Gemini 3.6 Flash family (Wikipedia)", en: "Gemini 3.6 Flash family (Wikipedia)" },
    detail: "Wikipedia registra Gemini 3.6 Flash em 21 de julho de 2026 — variants high/medium/low/tiered, janela 1M",
    source: "Wikipedia Gemini 3.6 Flash July 21 2026",
    models: ["gemini-3.6-flash-high", "gemini-3.6-flash-medium", "gemini-3.6-flash-low", "gemini-3.6-flash-tiered", "gemini-3.6-flash"],
  },
  {
    date: "2026-08-01",
    event: { pt: "9router + OmniRoute integração", en: "9router + OmniRoute integration" },
    detail: "Routing table: antigravity- prefix força Antigravity pool, preview força Gemini CLI PROD-only, strip x-goog-user-project",
    source: "9router github, OmniRoute docs, pi-antigravity-auth",
    models: ["antigravity-gemini-3.6-flash", "antigravity-gemini-3-flash", "antigravity-claude-opus-4-6-thinking"],
  },
  {
    date: "2026-08-25",
    event: { pt: "Freeze catálogo v2 — ONDA 5 CORREÇÃO V2", en: "Catalog freeze v2 — WAVE 5 FIX V2" },
    detail: "Lista completa até 25/08/2026: 31 bases + antigravity variants + Claude 4.5/4.6 + GPT-OSS 120B + previews. Bypass Project ID como Gemini CLI via loadCodeAssist, direto cloudcode-pa sem localhost v1.",
    source: "opencode.txt timeline, pi-antigravity-auth, 9router, OmniRoute",
    models: [
      "gemini-3.6-flash-high", "gemini-3.6-flash-medium", "gemini-3.6-flash-low", "gemini-3.6-flash-tiered", "gemini-3.6-flash",
      "gemini-3.5-flash-high", "gemini-3.5-flash-medium", "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.5-flash-lite-preview",
      "gemini-3.1-pro-high", "gemini-3.1-pro-low", "gemini-3.1-pro", "gemini-3.1-flash-image", "gemini-3.1-flash-lite",
      "gemini-3-flash", "gemini-3-pro", "gemini-3-deep-think",
      "gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite",
      "claude-sonnet-4-6-thinking", "claude-opus-4-6-thinking", "claude-sonnet-4-5", "claude-opus-4-5-thinking",
      "gpt-oss-120b-medium", "gpt-oss-120b-high",
      "gemini-3-pro-preview", "gemini-3-flash-preview", "gemini-3.1-pro-preview", "gemini-3.1-pro-preview-customtools"
    ],
  },
] as const;

// ---------------------------------------------------------------------------
// Cloud Code Endpoints — direct, no localhost v1 proxy
// ---------------------------------------------------------------------------

export const CODE_ASSIST_ENDPOINTS = {
  PROD: "https://cloudcode-pa.googleapis.com",
  DAILY: "https://daily-cloudcode-pa.googleapis.com",
  SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  AUTOPUSH: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
} as const;

export const ENDPOINT_ORDER_ANTIGRAVITY: readonly string[] = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
  CODE_ASSIST_ENDPOINTS.SANDBOX,
] as const;

export const ENDPOINT_ORDER_GEMINI_CLI: readonly string[] = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
] as const;

export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;
export const ANTIGRAVITY_VERSION_MIN = "1.15.8" as const;

export const FETCH_TIMEOUT_MS = 10_000 as const;
export const QUOTA_TIMEOUT_MS = 15_000 as const;

// Headers that MUST be stripped — observer notes AM never sends them on content
export const FORBIDDEN_HEADERS = [
  "x-goog-user-project",
  "x-goog-quotatuser",
  "x-goog-quota-user",
  "x-client-device-id",
  "x-goog-request-reason",
  "x-goog-api-client",
] as const;

// ---------------------------------------------------------------------------
// Thinking levels & budgets — Gemini + Claude + GPT-OSS
// ---------------------------------------------------------------------------

export const THINKING_LEVELS = ["minimal", "low", "medium", "high", "tiered", "max"] as const;
export type ThinkingLevel = (typeof THINKING_LEVELS)[number];

export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = {
  minimal: 1024,
  low: 8192,
  medium: 16384,
  high: 32768,
  tiered: 24576, // adaptive tiered — observer sees OmniRoute uses 24k as middle tier
  max: 64000, // Claude max + GPT-OSS high
} as const;

export const CONTEXT_WINDOW_GEMINI = 1_048_576 as const;
export const CONTEXT_WINDOW_CLAUDE = 200_000 as const;
export const CONTEXT_WINDOW_GPT_OSS = 200_000 as const;
export const OUTPUT_LIMIT_GEMINI = 65_535 as const;
export const OUTPUT_LIMIT_CLAUDE = 64_000 as const;
export const OUTPUT_LIMIT_GPT_OSS = 64_000 as const;

export type ModelGroup = "antigravity" | "gemini-cli";
export type Provider = "google";
export type OriginalProvider = "google" | "anthropic" | "openai-oss";
export type Modality = "text" | "image" | "pdf";

export interface ModelDefinition {
  /** Canonical id — ex: gemini-3.6-flash-high */
  id: string;
  /** Display name */
  displayName: string;
  /** Family: gemini-3.6, gemini-3.5, gemini-3.1, gemini-3, gemini-2.5, claude-4-6, gpt-oss-120b ... */
  family: string;
  /** Version / catalog date */
  catalogDate: typeof CATALOG_DATE_ISO;
  /** Release date ISO (Wikipedia dates for 3.1 Pro Feb 19 2026, 3.6 Flash July 21 2026) */
  releaseDate: string;
  /** Context window tokens */
  contextWindow: number;
  /** Output limit tokens */
  outputLimit: number;
  /** Provider routed via Google */
  provider: Provider;
  /** Original lab */
  originalProvider: OriginalProvider;
  /** Routing group */
  group: ModelGroup;
  /** Thinking level variant */
  thinkingLevel: ThinkingLevel;
  /** Budget in tokens */
  thinkingBudget: number;
  /** Is thinking required? */
  isThinking: boolean;
  /** Is preview? */
  isPreview: boolean;
  /** Is image output? ex: gemini-3.1-flash-image */
  isImage: boolean;
  /** Modalities */
  modalities: { input: Modality[]; output: Modality[] };
  /** Bilingual description */
  description: { pt: string; en: string };
  /** Aliases for 9router / OmniRoute */
  aliases: string[];
  /** Endpoint hints — third-person observer notes */
  endpointHints: {
    prodOnly: boolean; // gemini-3+ preview MUST be prod-only (+ daily), skip sandbox
    skipSandbox: boolean;
    fallbackProjectAllowed: boolean; // rising-fact-p41fc works for antigravity, fails 403 for gemini-cli
    allowedEndpoints: readonly string[];
    defaultEndpoint: string;
  };
  /** Tags for search */
  tags: string[];
  /** References */
  references: string[];
  /** Deprecated? */
  deprecated?: boolean;
}

// ---------------------------------------------------------------------------
// Observer helpers — FNV-1a, hash, headers, jitter, UA
// ---------------------------------------------------------------------------

export const FNV_OFFSET_BASIS = 2166136261;
export const FNV_PRIME = 16777619;

export function fnv1a32(str: string): number {
  let h = FNV_OFFSET_BASIS >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, FNV_PRIME) >>> 0;
  }
  return h >>> 0;
}

function hashToken(token: string): string {
  try {
    return createHash("sha256").update(token).digest("hex").slice(0, 32);
  } catch {
    return fnv1a32(token).toString(16).padStart(8, "0");
  }
}

function normalizePlatform(p: string): string {
  switch (p) {
    case "darwin": return "darwin";
    case "win32": return "win32";
    case "linux": return "linux";
    default: return p;
  }
}
function normalizeArch(a: string): string {
  switch (a) {
    case "arm64": return "arm64";
    case "x64": return "x64";
    case "ia32": return "ia32";
    default: return a;
  }
}

export function getDynamicUserAgent(version?: string, opts?: { os?: string; arch?: string }): string {
  const ver = (version && /^\d+\.\d+\.\d+/.test(version) ? version : ANTIGRAVITY_VERSION_FALLBACK).trim();
  const plat = normalizePlatform(opts?.os ?? osPlatform());
  const arc = normalizeArch(opts?.arch ?? osArch());
  return `antigravity/${ver} ${plat}/${arc}`;
}

export function isRetryableStatus(status: number): boolean {
  return status === 403 || status === 404 || status === 408 || status === 429 || status >= 500;
}

export function stripForbiddenHeaders(headers: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  const forbidden = new Set(FORBIDDEN_HEADERS.map(h => h.toLowerCase()));
  for (const [k, v] of Object.entries(headers)) {
    if (forbidden.has(k.toLowerCase())) continue;
    out[k] = v;
  }
  return out;
}

export function getJitterMs(min = 0, max = 80): number {
  try {
    return randomInt(min, max + 1);
  } catch {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

export function buildAntagravityHeaders(accessToken: string, userAgent?: string, extra?: Record<string, string>): Record<string, string> {
  const ua = userAgent ?? getDynamicUserAgent();
  const h: Record<string, string> = {
    Authorization: `Bearer ${String(accessToken).trim()}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
    Accept: "application/json",
  };
  // Observer — third-person: Gemini CLI / AM only sends User-Agent on content.
  // Explicitly NOT sending X-Goog-Api-Client, Client-Metadata, X-Goog-User-Project
  // to avoid 403 per pi-antigravity-auth and issue pi-mono #1830.
  if (extra) {
    for (const [k, v] of Object.entries(extra)) {
      if (!k) continue;
      h[k] = v;
    }
  }
  return stripForbiddenHeaders(h);
}

export async function fetchWithTimeout(
  url: string,
  init: RequestInit & { timeoutMs?: number } = {},
): Promise<Response> {
  const timeoutMs = init.timeoutMs ?? FETCH_TIMEOUT_MS;
  const controller = new AbortController();
  const to = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const signal = init.signal
      ? (() => {
          const combined = new AbortController();
          const onAbort = () => combined.abort();
          init.signal!.addEventListener("abort", onAbort, { once: true });
          controller.signal.addEventListener("abort", onAbort, { once: true });
          return combined.signal;
        })()
      : controller.signal;
    const { timeoutMs: _t, ...rest } = init as any;
    return await fetch(url, { ...rest, signal });
  } finally {
    clearTimeout(to);
  }
}

// ---------------------------------------------------------------------------
// Project ID bypass — exatamente como Gemini CLI agiria (observer)
// ---------------------------------------------------------------------------

export class ProjectDiscoveryError extends Error {
  public status?: number;
  public endpoint?: string;
  public retryable: boolean;
  constructor(message: string, status?: number, endpoint?: string, retryable = true) {
    super(message);
    this.name = "ProjectDiscoveryError";
    this.status = status;
    this.endpoint = endpoint;
    this.retryable = retryable;
  }
}

export interface LoadCodeAssistOptions {
  accessToken: string;
  endpoint: string;
  projectId?: string;
  userAgent?: string;
}

export async function loadCodeAssist(opts: LoadCodeAssistOptions): Promise<string | null> {
  const { accessToken, endpoint, projectId, userAgent } = opts;
  if (!accessToken) throw new ProjectDiscoveryError("accessToken required", 400, endpoint, false);
  const token = accessToken.trim();
  const base = endpoint.replace(/\/+$/, "");
  const url = `${base}/v1internal:loadCodeAssist`;

  // Jitter 0-80ms anti-rate-limit — observed in AM binary
  const jit = getJitterMs();
  if (jit > 0) await new Promise(r => setTimeout(r, jit));

  // Body mimics Gemini CLI: empty metadata, optionally with project
  // Observer notes: when projectId supplied, Gemini CLI sends { cloudaicompanionProject: projectId }
  const body: any = projectId
    ? { cloudaicompanionProject: projectId, metadata: { ideType: "IDE_UNSPECIFIED", platform: normalizePlatform(osPlatform()), pluginType: "GEMINI" } }
    : { metadata: { ideType: "IDE_UNSPECIFIED", platform: normalizePlatform(osPlatform()), pluginType: "GEMINI" } };

  const headers = buildAntagravityHeaders(token, userAgent ?? getDynamicUserAgent());

  let res: Response;
  try {
    res = await fetchWithTimeout(url, { method: "POST", headers, body: JSON.stringify(body) }, FETCH_TIMEOUT_MS);
  } catch (e: any) {
    throw new ProjectDiscoveryError(`network error loadCodeAssist ${endpoint}: ${e?.message ?? String(e)}`, 0, endpoint, true);
  }

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new ProjectDiscoveryError(`loadCodeAssist failed ${res.status} at ${endpoint}: ${txt.slice(0, 500)}`, res.status, endpoint, isRetryableStatus(res.status));
  }

  let json: any;
  try {
    json = await res.json();
  } catch {
    return null;
  }

  // Response shapes observed in pi-antigravity-auth + Gemini CLI:
  // { cloudaicompanionProject: "xxxx" } or { currentTier: { ... }, cloudaicompanionProject: "xxxx", ... }
  const pid = (json?.cloudaicompanionProject ?? json?.projectId ?? json?.project ?? null) as string | null;
  if (pid && typeof pid === "string" && pid.trim().length > 0) return pid.trim();
  // When server returns allowedTiers but no project yet, need onboard
  return null;
}

export interface OnboardUserOptions {
  accessToken: string;
  endpoint: string;
  tierId?: string; // FREE default
  userAgent?: string;
}

export async function onboardUser(opts: OnboardUserOptions): Promise<string | null> {
  const { accessToken, endpoint, tierId = "FREE", userAgent } = opts;
  const token = accessToken.trim();
  const base = endpoint.replace(/\/+$/, "");
  const url = `${base}/v1internal:onboardUser`;

  const headers = buildAntagravityHeaders(token, userAgent ?? getDynamicUserAgent());

  const body = {
    tierId,
    cloudaicompanionProject: PROJECT_FALLBACK, // onboard still requires some project for legacy, but observer notes Gemini CLI uses empty or fallback
    metadata: { ideType: "IDE_UNSPECIFIED", pluginType: "GEMINI" },
  };

  let res: Response;
  try {
    res = await fetchWithTimeout(url, { method: "POST", headers, body: JSON.stringify(body) }, FETCH_TIMEOUT_MS);
  } catch (e: any) {
    throw new ProjectDiscoveryError(`network error onboardUser ${endpoint}: ${e?.message ?? String(e)}`, 0, endpoint, true);
  }

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new ProjectDiscoveryError(`onboardUser failed ${res.status} at ${endpoint}: ${txt.slice(0, 500)}`, res.status, endpoint, isRetryableStatus(res.status));
  }

  try {
    const json = (await res.json()) as any;
    const pid = json?.response?.cloudaicompanionProject ?? json?.cloudaicompanionProject ?? json?.projectId ?? null;
    if (pid && typeof pid === "string") return pid.trim();
    return null; // observer pattern: onboard success but load needed after
  } catch {
    return null;
  }
}

// Cache em memória — Map blindado com hash truncado para não reter segredo em heap snapshot
interface CacheEntry { projectId: string; timestamp: number; email?: string; }
const CACHE_TTL_MS = 60 * 60 * 1000;
const projectIdCache = new Map<string, CacheEntry>();

export function getCachedProjectId(accessToken: string): string | null {
  const key = hashToken(accessToken);
  const e = projectIdCache.get(key);
  if (!e) return null;
  if (Date.now() - e.timestamp > CACHE_TTL_MS) { projectIdCache.delete(key); return null; }
  return e.projectId;
}
export function setCachedProjectId(accessToken: string, projectId: string, email?: string): void {
  projectIdCache.set(hashToken(accessToken), { projectId, timestamp: Date.now(), email });
}
export function clearProjectCache(): void { projectIdCache.clear(); }

export type ResolveProjectIdBypassOptions = {
  accessToken: string;
  cachedProjectId?: string;
  email?: string;
  userAgent?: string;
  endpointOverrides?: string[];
  isGeminiCliModel?: boolean; // when true, skip SANDBOX
  metadataSaver?: (projectId: string) => Promise<void> | void;
};

export type ResolveProjectIdBypassResult = {
  projectId: string;
  fromCache: boolean;
  endpointUsed?: string;
  isFallback: boolean;
  attempts: string[];
};

export async function resolveProjectIdAsGeminiCliBypass(opts: ResolveProjectIdBypassOptions): Promise<ResolveProjectIdBypassResult> {
  const { accessToken, cachedProjectId, email, userAgent, endpointOverrides, isGeminiCliModel, metadataSaver } = opts;
  if (!accessToken?.trim()) throw new ProjectDiscoveryError("accessToken required", 400, undefined, false);

  // 1. Cache hit
  const cached = getCachedProjectId(accessToken);
  if (cached) {
    // best-effort validate with loadCodeAssist using cached id
    try {
      const ep = (endpointOverrides?.[0] ?? CODE_ASSIST_ENDPOINTS.PROD);
      const validated = await loadCodeAssist({ accessToken, endpoint: ep, projectId: cached, userAgent });
      if (validated) {
        setCachedProjectId(accessToken, validated, email);
        return { projectId: validated, fromCache: true, endpointUsed: ep, isFallback: false, attempts: [ep] };
      }
    } catch {
      // ignore, proceed to discovery
    }
    // even if validation skipped, return cached if explicit override present
    if (cachedProjectId && cachedProjectId === cached) {
      return { projectId: cached, fromCache: true, isFallback: false, attempts: [] };
    }
  }

  if (cachedProjectId?.trim()) {
    // Caller provided cached value (from accounts.json chmod 600) — try direct load with it
    const epList = endpointOverrides ?? (isGeminiCliModel ? [...ENDPOINT_ORDER_GEMINI_CLI] : [...ENDPOINT_ORDER_ANTIGRAVITY]);
    for (const ep of epList) {
      try {
        const pid = await loadCodeAssist({ accessToken, endpoint: ep, projectId: cachedProjectId.trim(), userAgent });
        if (pid) {
          setCachedProjectId(accessToken, pid, email);
          if (metadataSaver) await metadataSaver(pid).catch(() => {});
          return { projectId: pid, fromCache: false, endpointUsed: ep, isFallback: false, attempts: epList as string[] };
        }
      } catch (e: any) {
        if (e instanceof ProjectDiscoveryError && !isRetryableStatus(e.status ?? 0) && e.status !== 0) throw e;
        continue;
      }
    }
  }

  // 2. Discovery cascade — PROD first, DAILY second, SANDBOX only if antigravity group
  const endpoints = endpointOverrides
    ? [...endpointOverrides]
    : isGeminiCliModel ? [...ENDPOINT_ORDER_GEMINI_CLI] : [...ENDPOINT_ORDER_ANTIGRAVITY];

  let lastError: ProjectDiscoveryError | null = null;
  const attempts: string[] = [];

  for (const ep of endpoints) {
    attempts.push(ep);
    try {
      // a) load without project id — Gemini CLI behavior
      let pid: string | null = null;
      try {
        pid = await loadCodeAssist({ accessToken, endpoint: ep, userAgent });
      } catch (e: any) {
        if (e instanceof ProjectDiscoveryError) {
          lastError = e;
          if (!e.retryable) throw e;
          continue;
        }
        lastError = new ProjectDiscoveryError(String(e?.message ?? e), 500, ep, true);
        continue;
      }

      // b) if null, onboard then load again
      if (!pid) {
        try {
          const onboarded = await onboardUser({ accessToken, endpoint: ep, userAgent });
          if (onboarded) pid = onboarded;
          else pid = await loadCodeAssist({ accessToken, endpoint: ep, userAgent });
        } catch (e: any) {
          if (e instanceof ProjectDiscoveryError) {
            lastError = e;
            if (!isRetryableStatus(e.status ?? 0) && e.status !== 0) throw e;
            continue;
          }
          lastError = new ProjectDiscoveryError(String(e?.message ?? e), 500, ep, true);
          continue;
        }
      }

      if (!pid) {
        lastError = new ProjectDiscoveryError(`no project id from ${ep}`, 404, ep, true);
        continue;
      }

      // success
      setCachedProjectId(accessToken, pid, email);
      if (metadataSaver) {
        try { await metadataSaver(pid); } catch {}
      }
      return { projectId: pid, fromCache: false, endpointUsed: ep, isFallback: false, attempts };
    } catch (e: any) {
      if (e instanceof ProjectDiscoveryError) {
        lastError = e;
        if (!e.retryable) throw e;
        continue;
      }
      lastError = new ProjectDiscoveryError(`unexpected at ${ep}: ${String(e?.message ?? e)}`, 500, ep, true);
      continue;
    }
  }

  // 3. All endpoints failed — fallback blindado (works for Antigravity, 403 for Gemini CLI models per README)
  // Observer notes: pi-antigravity-auth warns that fallback rising-fact-p41fc fails for gemini-cli group with 403
  // We return fallback only if caller allows antigravity group; for gemini-cli we still return fallback with isFallback true for caller to decide
  setCachedProjectId(accessToken, PROJECT_FALLBACK, email);
  if (metadataSaver) { try { await metadataSaver(PROJECT_FALLBACK); } catch {} }
  return {
    projectId: PROJECT_FALLBACK,
    fromCache: false,
    endpointUsed: undefined,
    isFallback: true,
    attempts,
  };
}

// ---------------------------------------------------------------------------
// fetchAvailableModels direct — cloudcode-pa without localhost v1 proxy
// ---------------------------------------------------------------------------

export async function fetchAvailableModelsDirect(opts: { accessToken: string; endpoint: string; projectId: string; userAgent?: string }): Promise<string[]> {
  const { accessToken, endpoint, projectId, userAgent } = opts;
  const base = endpoint.replace(/\/+$/, "");
  const url = `${base}/v1internal:fetchAvailableModels`;
  const headers = buildAntagravityHeaders(accessToken, userAgent);
  const body = JSON.stringify({ cloudaicompanionProject: projectId });

  const res = await fetchWithTimeout(url, { method: "POST", headers, body }, FETCH_TIMEOUT_MS).catch((e: any) => {
    throw new ProjectDiscoveryError(`fetchAvailableModels network error ${endpoint}: ${e?.message ?? String(e)}`, 0, endpoint, true);
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new ProjectDiscoveryError(`fetchAvailableModels failed ${res.status} at ${endpoint}: ${txt.slice(0, 500)}`, res.status, endpoint, isRetryableStatus(res.status));
  }

  try {
    const json = (await res.json()) as any;
    // Shapes: { models: [{ name, ... }] } or { availableModels: [...] }
    const arr = json?.models ?? json?.availableModels ?? json?.modelsList ?? [];
    if (Array.isArray(arr)) {
      return arr.map((m: any) => (typeof m === "string" ? m : m?.name ?? m?.id ?? "")).filter(Boolean);
    }
    if (Array.isArray(json)) return json.map((m: any) => (typeof m === "string" ? m : m?.name ?? "")).filter(Boolean);
    return [];
  } catch {
    return [];
  }
}

// ---------------------------------------------------------------------------
// Model helpers — normalize, thinking, context
// ---------------------------------------------------------------------------

export function normalizeModelId(id: string): string {
  return String(id ?? "").trim().toLowerCase().replace(/^antigravity-/, "");
}

export function parseThinkingLevelFromId(id: string): ThinkingLevel {
  const lower = String(id).toLowerCase();
  if (lower.endsWith("-high")) return "high";
  if (lower.endsWith("-medium")) return "medium";
  if (lower.endsWith("-low")) return "low";
  if (lower.endsWith("-tiered")) return "tiered";
  if (lower.endsWith("-lite")) return "low";
  if (lower.includes("deep-think")) return "high";
  if (lower.includes("flash-image")) return "minimal";
  if (lower.includes("thinking")) return "high";
  if (lower.includes("lite")) return "low";
  if (lower.includes("preview") && lower.includes("flash")) return "medium";
  return "medium";
}

export function getThinkingBudgetForLevel(level: ThinkingLevel, originalProvider: OriginalProvider = "google"): number {
  if (originalProvider === "anthropic" && level === "high") return 32768; // Claude high observed 32k, max 64k optional
  if (originalProvider === "anthropic" && level === "max") return 64000;
  return THINKING_BUDGET_MAP[level] ?? THINKING_BUDGET_MAP.medium;
}

export function isGeminiCliOnlyId(id: string): boolean {
  const lower = String(id).toLowerCase();
  // Observer: preview, gemini-3, gemini-3.1, gemini-3.5, gemini-3.6 MUST be prod-only (+ daily) — skip sandbox
  return (
    lower.includes("preview") ||
    lower.startsWith("gemini-3.") ||
    lower.startsWith("gemini-3-") ||
    lower === "gemini-3-flash" ||
    lower === "gemini-3-pro" ||
    lower.includes("gemini-3.5") ||
    lower.includes("gemini-3.6") ||
    lower.includes("deep-think")
  );
}

// ---------------------------------------------------------------------------
// Factory for ModelDefinition — bilingual pt/en
// ---------------------------------------------------------------------------

function makeDescription(
  id: string,
  family: string,
  thinking: ThinkingLevel,
  isPreview: boolean,
  isImage: boolean,
  group: ModelGroup,
  releaseDate: string,
): { pt: string; en: string } {
  const previewTagPt = isPreview ? " (preview — pode mudar, sem SLA)" : "";
  const previewTagEn = isPreview ? " (preview — may change, no SLA)" : "";
  const imageTagPt = isImage ? " Saída imagem + texto." : "";
  const imageTagEn = isImage ? " Image + text output." : "";
  const groupPt = group === "gemini-cli" ? "grupo gemini-cli (PROD-only, bypass Project ID via loadCodeAssist)" : "grupo antigravity (PROD/DAILY/SANDBOX, fallback rising-fact-p41fc)";
  const groupEn = group === "gemini-cli" ? "gemini-cli group (PROD-only, bypasses Project ID via loadCodeAssist)" : "antigravity group (PROD/DAILY/SANDBOX, fallback rising-fact-p41fc)";
  const windowPt = family.includes("claude") || family.includes("gpt-oss") ? "janela 200k" : "janela 1.048.576";
  const windowEn = family.includes("claude") || family.includes("gpt-oss") ? "200k window" : "1,048,576 window";
  const outPt = family.includes("claude") || family.includes("gpt-oss") ? "saída 64k" : "saída 65.535";
  const outEn = family.includes("claude") || family.includes("gpt-oss") ? "64k output" : "65,535 output";
  const thinkingPt = `thinking ${thinking}`;
  const thinkingEn = `thinking ${thinking}`;

  const pt = `${id} — ${family}${previewTagPt} — ${windowPt}, ${outPt}, ${thinkingPt}, ${groupPt}. Multimodal texto/imagem/PDF${imageTagPt}. Bypass Project ID direto cloudcode-pa.googleapis.com sem localhost v1 proxy. Ref: pi-antigravity-auth, 9router, OmniRoute. Release ${releaseDate}. Catálogo ${CATALOG_DATE_BR}.`;
  const en = `${id} — ${family}${previewTagEn} — ${windowEn}, ${outEn}, ${thinkingEn}, ${groupEn}. Multimodal text/image/PDF${imageTagEn}. Bypasses Project ID directly via cloudcode-pa.googleapis.com without localhost v1 proxy. Ref: pi-antigravity-auth, 9router, OmniRoute. Release ${releaseDate}. Catalog ${CATALOG_DATE_ISO}.`;
  return { pt, en };
}

function defineModel(
  id: string,
  family: string,
  originalProvider: OriginalProvider,
  group: ModelGroup,
  releaseDate: string,
  opts: {
    thinkingLevel?: ThinkingLevel;
    isPreview?: boolean;
    isImage?: boolean;
    isThinking?: boolean;
    contextWindow?: number;
    outputLimit?: number;
    aliases?: string[];
    tags?: string[];
    deprecated?: boolean;
  } = {},
): ModelDefinition {
  const thinkingLevel = opts.thinkingLevel ?? parseThinkingLevelFromId(id);
  const isPreview = opts.isPreview ?? id.toLowerCase().includes("preview");
  const isImage = opts.isImage ?? id.toLowerCase().includes("flash-image") || id.toLowerCase().includes("image") && !id.toLowerCase().includes("lite");
  const isThinking = opts.isThinking ?? (thinkingLevel !== "minimal" || id.toLowerCase().includes("thinking") || id.toLowerCase().includes("deep-think") || id.toLowerCase().includes("high") || id.toLowerCase().includes("low") || id.toLowerCase().includes("medium") || id.toLowerCase().includes("tiered"));
  const contextWindow =
    opts.contextWindow ??
    (originalProvider === "google" ? CONTEXT_WINDOW_GEMINI : originalProvider === "anthropic" ? CONTEXT_WINDOW_CLAUDE : CONTEXT_WINDOW_GPT_OSS);
  const outputLimit =
    opts.outputLimit ??
    (originalProvider === "google" ? OUTPUT_LIMIT_GEMINI : originalProvider === "anthropic" ? OUTPUT_LIMIT_CLAUDE : OUTPUT_LIMIT_GPT_OSS);
  const thinkingBudget = getThinkingBudgetForLevel(thinkingLevel, originalProvider);
  const prodOnly = group === "gemini-cli" || isGeminiCliOnlyId(id);
  const allowedEndpoints = prodOnly ? ENDPOINT_ORDER_GEMINI_CLI : ENDPOINT_ORDER_ANTIGRAVITY;
  const fallbackAllowed = group === "antigravity";

  const description = makeDescription(id, family, thinkingLevel, isPreview, isImage, group, releaseDate);

  const baseAliases = opts.aliases ?? [];
  // OmniRoute / 9router aliases
  const omniAliases = [
    normalizeModelId(id),
    id.toLowerCase(),
    `google/${normalizeModelId(id)}`,
    `antigravity/${normalizeModelId(id)}`,
    `9router/${normalizeModelId(id)}`,
  ];

  return {
    id,
    displayName: id,
    family,
    catalogDate: CATALOG_DATE_ISO,
    releaseDate,
    contextWindow,
    outputLimit,
    provider: "google",
    originalProvider,
    group,
    thinkingLevel,
    thinkingBudget,
    isThinking,
    isPreview,
    isImage,
    modalities: {
      input: ["text", "image", "pdf"],
      output: isImage ? ["text", "image"] : ["text"],
    },
    description,
    aliases: Array.from(new Set([...baseAliases, ...omniAliases, id])),
    endpointHints: {
      prodOnly,
      skipSandbox: prodOnly,
      fallbackProjectAllowed: fallbackAllowed,
      allowedEndpoints,
      defaultEndpoint: CODE_ASSIST_ENDPOINTS.PROD,
    },
    tags: [
      family,
      group,
      originalProvider,
      thinkingLevel,
      isPreview ? "preview" : "stable",
      isImage ? "image" : "text",
      isThinking ? "thinking" : "no-thinking",
      `release-${releaseDate}`,
      "direct-cloudcode-pa",
      "no-localhost-proxy",
      "bypass-project-id-loadCodeAssist",
      "pi-antigravity-auth",
      "9router",
      "OmniRoute",
      ...(opts.tags ?? []),
    ],
    references: [...REFERENCES],
    deprecated: opts.deprecated,
  };
}

// ---------------------------------------------------------------------------
// CATÁLOGO COMPLETO até 25/08/2026 — ONDA 5 CORREÇÃO V2
// Base list + antigravity- variants
// ---------------------------------------------------------------------------

// Helper to create antigravity variant id
function antigravityId(baseId: string): string {
  return baseId.startsWith("antigravity-") ? baseId : `antigravity-${baseId}`;
}

// Release date mapping based on Wikipedia + timeline
const RELEASE_DATES: Record<string, string> = {
  // July 21 2026 — Gemini 3.6 Flash family
  "gemini-3.6-flash-high": WIKIPEDIA_GEMINI_3_6_FLASH_DATE,
  "gemini-3.6-flash-medium": WIKIPEDIA_GEMINI_3_6_FLASH_DATE,
  "gemini-3.6-flash-low": WIKIPEDIA_GEMINI_3_6_FLASH_DATE,
  "gemini-3.6-flash-tiered": WIKIPEDIA_GEMINI_3_6_FLASH_DATE,
  "gemini-3.6-flash": WIKIPEDIA_GEMINI_3_6_FLASH_DATE,
  // Gemini 3.5 — approx June 2026
  "gemini-3.5-flash-high": "2026-06-15",
  "gemini-3.5-flash-medium": "2026-06-15",
  "gemini-3.5-flash": "2026-06-15",
  "gemini-3.5-flash-lite": "2026-06-15",
  "gemini-3.5-flash-lite-preview": "2026-06-20",
  // Gemini 3.1 Pro — Feb 19 2026 Wikipedia
  "gemini-3.1-pro-high": WIKIPEDIA_GEMINI_3_1_PRO_DATE,
  "gemini-3.1-pro-low": WIKIPEDIA_GEMINI_3_1_PRO_DATE,
  "gemini-3.1-pro": WIKIPEDIA_GEMINI_3_1_PRO_DATE,
  "gemini-3.1-flash-image": "2026-03-10",
  "gemini-3.1-flash-lite": "2026-03-10",
  // Gemini 3
  "gemini-3-flash": "2026-05-11",
  "gemini-3-pro": "2026-05-11",
  "gemini-3-deep-think": "2026-05-20",
  "gemini-3-pro-preview": "2026-04-20",
  "gemini-3-flash-preview": "2026-04-20",
  "gemini-3.1-pro-preview": "2026-02-19",
  "gemini-3.1-pro-preview-customtools": "2026-02-25",
  // Gemini 2.5
  "gemini-2.5-pro": "2025-12-10",
  "gemini-2.5-flash": "2025-12-10",
  "gemini-2.5-flash-lite": "2025-12-15",
  // Claude 4.5 / 4.6 — 2026 Q2
  "claude-sonnet-4-6-thinking": "2026-04-15",
  "claude-opus-4-6-thinking": "2026-04-15",
  "claude-sonnet-4-5": "2026-02-10",
  "claude-opus-4-5-thinking": "2026-02-10",
  // GPT-OSS 120B — 2026
  "gpt-oss-120b-medium": "2026-05-01",
  "gpt-oss-120b-high": "2026-05-01",
};

function releaseDateFor(id: string): string {
  const base = normalizeModelId(id);
  return RELEASE_DATES[base] ?? RELEASE_DATES[id] ?? "2026-08-25";
}

// Build base models list

const BASE_MODELS: Array<{ id: string; family: string; originalProvider: OriginalProvider; group: ModelGroup; thinkingLevel?: ThinkingLevel; isPreview?: boolean; isImage?: boolean }> = [
  // Gemini 3.6 Flash — 5 variants — Wikipedia July 21 2026
  { id: "gemini-3.6-flash-high", family: "gemini-3.6-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "high" },
  { id: "gemini-3.6-flash-medium", family: "gemini-3.6-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },
  { id: "gemini-3.6-flash-low", family: "gemini-3.6-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "low" },
  { id: "gemini-3.6-flash-tiered", family: "gemini-3.6-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "tiered" },
  { id: "gemini-3.6-flash", family: "gemini-3.6-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },

  // Gemini 3.5 Flash — 5 variants
  { id: "gemini-3.5-flash-high", family: "gemini-3.5-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "high" },
  { id: "gemini-3.5-flash-medium", family: "gemini-3.5-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },
  { id: "gemini-3.5-flash", family: "gemini-3.5-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },
  { id: "gemini-3.5-flash-lite", family: "gemini-3.5-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "low" },
  { id: "gemini-3.5-flash-lite-preview", family: "gemini-3.5-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "low", isPreview: true },

  // Gemini 3.1 Pro / Flash — Feb 19 2026 Wikipedia
  { id: "gemini-3.1-pro-high", family: "gemini-3.1-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "high" },
  { id: "gemini-3.1-pro-low", family: "gemini-3.1-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "low" },
  { id: "gemini-3.1-pro", family: "gemini-3.1-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },
  { id: "gemini-3.1-flash-image", family: "gemini-3.1-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "minimal", isImage: true },
  { id: "gemini-3.1-flash-lite", family: "gemini-3.1-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "low" },

  // Gemini 3 family — May 2026
  { id: "gemini-3-flash", family: "gemini-3-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },
  { id: "gemini-3-pro", family: "gemini-3-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium" },
  { id: "gemini-3-deep-think", family: "gemini-3-deep-think", originalProvider: "google", group: "gemini-cli", thinkingLevel: "high" },

  // Gemini 2.5 — Dec 2025, routed via antigravity pool but also valid via gemini-cli
  { id: "gemini-2.5-pro", family: "gemini-2.5-pro", originalProvider: "google", group: "antigravity", thinkingLevel: "medium" },
  { id: "gemini-2.5-flash", family: "gemini-2.5-flash", originalProvider: "google", group: "antigravity", thinkingLevel: "medium" },
  { id: "gemini-2.5-flash-lite", family: "gemini-2.5-flash", originalProvider: "google", group: "antigravity", thinkingLevel: "low" },

  // Claude Sonnet/Opus 4.5 / 4.6 thinking
  { id: "claude-sonnet-4-6-thinking", family: "claude-4-6-sonnet", originalProvider: "anthropic", group: "antigravity", thinkingLevel: "high" },
  { id: "claude-opus-4-6-thinking", family: "claude-4-6-opus", originalProvider: "anthropic", group: "antigravity", thinkingLevel: "high" },
  { id: "claude-sonnet-4-5", family: "claude-4-5-sonnet", originalProvider: "anthropic", group: "antigravity", thinkingLevel: "medium" },
  { id: "claude-opus-4-5-thinking", family: "claude-4-5-opus", originalProvider: "anthropic", group: "antigravity", thinkingLevel: "high" },

  // GPT-OSS 120B — routed via Antigravity as gpt-oss
  { id: "gpt-oss-120b-medium", family: "gpt-oss-120b", originalProvider: "openai-oss", group: "antigravity", thinkingLevel: "medium" },
  { id: "gpt-oss-120b-high", family: "gpt-oss-120b", originalProvider: "openai-oss", group: "antigravity", thinkingLevel: "high" },

  // Preview — April 2026 — prod-only
  { id: "gemini-3-pro-preview", family: "gemini-3-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium", isPreview: true },
  { id: "gemini-3-flash-preview", family: "gemini-3-flash", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium", isPreview: true },
  { id: "gemini-3.1-pro-preview", family: "gemini-3.1-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium", isPreview: true },
  { id: "gemini-3.1-pro-preview-customtools", family: "gemini-3.1-pro", originalProvider: "google", group: "gemini-cli", thinkingLevel: "medium", isPreview: true },
];

function buildCatalog(): ModelDefinition[] {
  const list: ModelDefinition[] = [];

  for (const b of BASE_MODELS) {
    const rd = releaseDateFor(b.id);
    list.push(defineModel(b.id, b.family, b.originalProvider, b.group, rd, {
      thinkingLevel: b.thinkingLevel,
      isPreview: b.isPreview,
      isImage: b.isImage,
    }));
    // antigravity- variant — same metadata but forced antigravity group for compatibility with older opencode-antigravity-auth
    // Observer: 9router maps antigravity-* to antigravity pool, skipping gemini-cli prod-only rule for fallback
    const agId = antigravityId(b.id);
    if (agId !== b.id) {
      // For antigravity- variants, group forced to antigravity, but keep prodOnly hint if original was prodOnly
      // This allows cli_first: false to still work with fallback project
      const agGroup: ModelGroup = "antigravity";
      list.push(defineModel(agId, b.family, b.originalProvider, agGroup, rd, {
        thinkingLevel: b.thinkingLevel,
        isPreview: b.isPreview,
        isImage: b.isImage,
        aliases: [b.id, normalizeModelId(b.id)],
      }));
    }
  }

  // Add extra historical models that opencode.txt mentions as supported (to avoid missing timeline)
  const extraHistorical: Array<{ id: string; family: string; originalProvider: OriginalProvider; group: ModelGroup; rd: string }> = [
    { id: "gemini-2.5", family: "gemini-2.5", originalProvider: "google", group: "antigravity", rd: "2025-12-01" },
    { id: "antigravity-gemini-3-pro", family: "gemini-3-pro", originalProvider: "google", group: "antigravity", rd: "2026-05-11" },
    { id: "antigravity-gemini-3-flash", family: "gemini-3-flash", originalProvider: "google", group: "antigravity", rd: "2026-05-11" },
    { id: "antigravity-gemini-3.1-pro", family: "gemini-3.1-pro", originalProvider: "google", group: "antigravity", rd: "2026-02-19" },
  ];

  for (const h of extraHistorical) {
    if (!list.some(m => m.id === h.id)) {
      list.push(defineModel(h.id, h.family, h.originalProvider, h.group, h.rd, { thinkingLevel: "medium" }));
    }
  }

  // Deduplicate by id (keep first)
  const seen = new Set<string>();
  const deduped: ModelDefinition[] = [];
  for (const m of list) {
    if (seen.has(m.id)) continue;
    seen.add(m.id);
    deduped.push(m);
  }

  // Sort by release date desc then id asc for deterministic catalog freeze
  deduped.sort((a, b) => {
    if (a.releaseDate !== b.releaseDate) return b.releaseDate.localeCompare(a.releaseDate);
    return a.id.localeCompare(b.id);
  });

  return deduped;
}

// Frozen catalog — single source of truth at 25/08/2026
export const MODEL_CATALOG_2026_08_25: readonly ModelDefinition[] = Object.freeze(buildCatalog()) as readonly ModelDefinition[];

// MAP — id lowercase + aliases -> definition
export const MODEL_MAP_2026_08_25: ReadonlyMap<string, ModelDefinition> = (() => {
  const map = new Map<string, ModelDefinition>();
  for (const m of MODEL_CATALOG_2026_08_25) {
    map.set(m.id.toLowerCase(), m);
    map.set(m.id, m);
    for (const alias of m.aliases) {
      if (!alias) continue;
      const low = alias.toLowerCase();
      if (!map.has(low)) map.set(low, m);
      // also bare normalized
      const norm = normalizeModelId(alias).toLowerCase();
      if (!map.has(norm)) map.set(norm, m);
    }
  }
  return map;
})();

// Aliases map for 9router / OmniRoute routing
export const MODEL_ALIASES_2026_08_25: ReadonlyMap<string, string> = (() => {
  const map = new Map<string, string>();
  for (const m of MODEL_CATALOG_2026_08_25) {
    for (const alias of m.aliases) {
      if (!alias) continue;
      map.set(alias.toLowerCase(), m.id);
    }
  }
  return map;
})();

// ---------------------------------------------------------------------------
// Public getters — production-ready, library-first
// ---------------------------------------------------------------------------

export function getModel(id: string): ModelDefinition | undefined {
  if (!id) return undefined;
  const low = String(id).trim().toLowerCase();
  return MODEL_MAP_2026_08_25.get(low) ?? MODEL_MAP_2026_08_25.get(normalizeModelId(low));
}

export function hasModel(id: string): boolean {
  return !!getModel(id);
}

export function isPreview(id: string): boolean {
  const m = getModel(id);
  return m ? m.isPreview : String(id).toLowerCase().includes("preview");
}

export function isThinkingModel(id: string): boolean {
  const m = getModel(id);
  if (m) return m.isThinking;
  const lower = String(id).toLowerCase();
  return lower.includes("thinking") || lower.includes("high") || lower.includes("medium") || lower.includes("low") || lower.includes("tiered") || lower.includes("deep-think") || lower.includes("claude") || lower.includes("gpt-oss");
}

export function isImageModel(id: string): boolean {
  const m = getModel(id);
  if (m) return m.isImage;
  return String(id).toLowerCase().includes("image") || String(id).toLowerCase().includes("flash-image");
}

export function isAntagravityGroup(id: string): boolean {
  const m = getModel(id);
  if (!m) return String(id).toLowerCase().startsWith("antigravity-") || String(id).toLowerCase().includes("claude") || String(id).toLowerCase().includes("gpt-oss");
  return m.group === "antigravity";
}

export function isGeminiCliGroup(id: string): boolean {
  const m = getModel(id);
  if (!m) return isGeminiCliOnlyId(id);
  return m.group === "gemini-cli";
}

export function getModelsByGroup(group: ModelGroup): readonly ModelDefinition[] {
  return MODEL_CATALOG_2026_08_25.filter(m => m.group === group);
}

export function getModelsByThinkingLevel(level: ThinkingLevel): readonly ModelDefinition[] {
  return MODEL_CATALOG_2026_08_25.filter(m => m.thinkingLevel === level);
}

export function getPreviewModels(): readonly ModelDefinition[] {
  return MODEL_CATALOG_2026_08_25.filter(m => m.isPreview);
}

export function getStableModels(): readonly ModelDefinition[] {
  return MODEL_CATALOG_2026_08_25.filter(m => !m.isPreview);
}

export function getAntagravityModels(): readonly ModelDefinition[] {
  return getModelsByGroup("antigravity");
}

export function getGeminiCliModels(): readonly ModelDefinition[] {
  return getModelsByGroup("gemini-cli");
}

export function getThinkingBudget(id: string): number {
  const m = getModel(id);
  if (m) return m.thinkingBudget;
  const lvl = parseThinkingLevelFromId(id);
  return THINKING_BUDGET_MAP[lvl] ?? THINKING_BUDGET_MAP.medium;
}

export function getContextWindow(id: string): number {
  const m = getModel(id);
  if (m) return m.contextWindow;
  const low = String(id).toLowerCase();
  if (low.includes("claude") || low.includes("gpt-oss")) return CONTEXT_WINDOW_CLAUDE;
  return CONTEXT_WINDOW_GEMINI;
}

export function getOutputLimit(id: string): number {
  const m = getModel(id);
  if (m) return m.outputLimit;
  const low = String(id).toLowerCase();
  if (low.includes("claude") || low.includes("gpt-oss")) return OUTPUT_LIMIT_CLAUDE;
  return OUTPUT_LIMIT_GEMINI;
}

export function getEndpointForModel(id: string, overrides?: string[]): readonly string[] {
  const m = getModel(id);
  if (overrides && overrides.length > 0) return overrides;
  if (m) return m.endpointHints.allowedEndpoints;
  // fallback logic: gemini-cli only -> prod+daily
  if (isGeminiCliOnlyId(id)) return ENDPOINT_ORDER_GEMINI_CLI;
  return ENDPOINT_ORDER_ANTIGRAVITY;
}

export function shouldSkipSandboxForModel(id: string): boolean {
  const m = getModel(id);
  if (m) return m.endpointHints.skipSandbox;
  return isGeminiCliOnlyId(id);
}

export function listModelIds(): readonly string[] {
  return MODEL_CATALOG_2026_08_25.map(m => m.id);
}

export function listBareModelIds(): readonly string[] {
  // Without antigravity- prefix — for OmniRoute base routing
  return BASE_MODELS.map(b => b.id);
}

export function searchModels(query: string): readonly ModelDefinition[] {
  if (!query) return MODEL_CATALOG_2026_08_25;
  const q = query.trim().toLowerCase();
  return MODEL_CATALOG_2026_08_25.filter(m => {
    return (
      m.id.toLowerCase().includes(q) ||
      m.family.toLowerCase().includes(q) ||
      m.tags.some(t => t.toLowerCase().includes(q)) ||
      m.aliases.some(a => a.toLowerCase().includes(q)) ||
      m.description.en.toLowerCase().includes(q) ||
      m.description.pt.toLowerCase().includes(q)
    );
  });
}

// OmniRoute compatible routing: returns physical model id + endpoint hint
export function routeModelViaOmniRoute(logicalId: string): { physicalId: string; group: ModelGroup; endpoints: readonly string[]; prodOnly: boolean; fallbackAllowed: boolean } {
  const m = getModel(logicalId);
  if (!m) {
    // unknown — fallback to gemini-3-flash per SEARCH_MODEL in constants
    return {
      physicalId: "gemini-3-flash",
      group: "gemini-cli",
      endpoints: ENDPOINT_ORDER_GEMINI_CLI,
      prodOnly: true,
      fallbackAllowed: false,
    };
  }
  return {
    physicalId: m.id,
    group: m.group,
    endpoints: m.endpointHints.allowedEndpoints,
    prodOnly: m.endpointHints.prodOnly,
    fallbackAllowed: m.endpointHints.fallbackProjectAllowed,
  };
}

// 9router compatible mapper
export function mapModelFor9Router(id: string): { provider: string; model: string; group: ModelGroup } {
  const m = getModel(id);
  if (!m) return { provider: "google", model: normalizeModelId(id), group: "gemini-cli" };
  return { provider: m.provider, model: m.id, group: m.group };
}

// ---------------------------------------------------------------------------
// Catalog grouped exports for convenience
// ---------------------------------------------------------------------------

export const MODEL_CATALOG_GROUPED = {
  antigravity: getAntagravityModels(),
  "gemini-cli": getGeminiCliModels(),
  preview: getPreviewModels(),
  stable: getStableModels(),
  high: getModelsByThinkingLevel("high"),
  medium: getModelsByThinkingLevel("medium"),
  low: getModelsByThinkingLevel("low"),
  tiered: getModelsByThinkingLevel("tiered"),
  minimal: getModelsByThinkingLevel("minimal"),
  image: MODEL_CATALOG_2026_08_25.filter(m => m.isImage),
  thinking: MODEL_CATALOG_2026_08_25.filter(m => m.isThinking),
} as const;

// ---------------------------------------------------------------------------
// Legacy compat exports — for plugin.ts, constants.ts that import MODELS_2026
// ---------------------------------------------------------------------------

export const MODELS_2026 = listBareModelIds() as unknown as readonly string[];
export const ANTIGRAVITY_MODELS_2026 = MODEL_CATALOG_2026_08_25.map(m => m.id) as unknown as readonly string[];
export const GEMINI_CLI_ONLY_MODELS_2026 = MODEL_CATALOG_2026_08_25.filter(m => m.endpointHints.prodOnly).map(m => m.id) as unknown as readonly string[];
export const PREVIEW_MODELS_2026 = getPreviewModels().map(m => m.id) as unknown as readonly string[];

export const MODEL_CATALOG = MODEL_CATALOG_2026_08_25;
export const MODEL_MAP = MODEL_MAP_2026_08_25;

// ---------------------------------------------------------------------------
// Barrel export for library-first root-first usage
// ---------------------------------------------------------------------------

export const Models2026Module = {
  CATALOG_DATE_ISO,
  CATALOG_DATE_BR,
  CATALOG_VERSION,
  REFERENCES,
  TIMELINE: OPENCODE_TXT_TIMELINE,
  ENDPOINTS: CODE_ASSIST_ENDPOINTS,
  ENDPOINT_ORDER_ANTIGRAVITY,
  ENDPOINT_ORDER_GEMINI_CLI,
  PROJECT_FALLBACK,
  ANTIGRAVITY_VERSION_FALLBACK,
  THINKING_LEVELS,
  THINKING_BUDGET_MAP,
  CONTEXT_WINDOW_GEMINI,
  CONTEXT_WINDOW_CLAUDE,
  OUTPUT_LIMIT_GEMINI,
  OUTPUT_LIMIT_CLAUDE,
  CATALOG: MODEL_CATALOG_2026_08_25,
  MAP: MODEL_MAP_2026_08_25,
  ALIASES: MODEL_ALIASES_2026_08_25,
  GROUPED: MODEL_CATALOG_GROUPED,
  // getters
  getModel,
  hasModel,
  isPreview,
  isThinkingModel,
  isImageModel,
  isAntagravityGroup,
  isGeminiCliGroup,
  getModelsByGroup,
  getModelsByThinkingLevel,
  getPreviewModels,
  getStableModels,
  getAntagravityModels,
  getGeminiCliModels,
  getThinkingBudget,
  getContextWindow,
  getOutputLimit,
  getEndpointForModel,
  shouldSkipSandboxForModel,
  listModelIds,
  listBareModelIds,
  searchModels,
  routeModelViaOmniRoute,
  mapModelFor9Router,
  normalizeModelId,
  parseThinkingLevelFromId,
  getThinkingBudgetForLevel,
  isGeminiCliOnlyId,
  // bypass Project ID — exactly as Gemini CLI
  resolveProjectIdAsGeminiCliBypass,
  loadCodeAssist,
  onboardUser,
  fetchAvailableModelsDirect,
  getCachedProjectId,
  setCachedProjectId,
  clearProjectCache,
  buildAntagravityHeaders,
  fetchWithTimeout,
  getDynamicUserAgent,
  isRetryableStatus,
  stripForbiddenHeaders,
  fnv1a32,
};

export default Models2026Module;
