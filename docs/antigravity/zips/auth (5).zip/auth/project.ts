/**
 * @fileoverview project.ts — V2 completa com bypass total Project ID estilo Gemini CLI
 * @description
 * O observador percebe que este módulo é o coração do bypass. Ele estuda exatamente
 * como Gemini CLI, OmniRoute, 9router e pi-antigravity-auth obtêm cloudaicompanionProject
 * sem exigir Project ID do usuário.
 *
 * Timeline real validada em 25/08/2026 via opencode.txt + git log concorrentes:
 * - Gemini CLI chama cloudcode-pa.googleapis.com/v1internal:loadCodeAssist com
 *   body {metadata {ideType ANTIGRAVITY|GEMINI, platform PLATFORM_UNSPECIFIED, pluginType GEMINI}}
 *   sem enviar cloudaicompanionProject. Servidor provisiona e retorna projeto gerenciado.
 * - Se load retorna 403/404/null → chama onboardUser {tierId FREE, metadata} que cria LRO
 *   (v1internal/operations/xxx), depois pollOperation backoff 500ms-8s 5 tentativas, depois load novamente.
 * - Nunca envia x-goog-user-project nem X-Goog-Api-Client em load/onboard (issue #1830, #310).
 * - Fallback blindado rising-fact-p41fc só como último recurso, com warning explícito,
 *   pois falha para Gemini CLI com 403 documentado. Bypass prefere projeto descoberto.
 *
 * Arquitetura: third-person observer, library-first, root-first, sem localhost v1 proxy,
 * direto cloudcode-pa, apenas node:* builtins + fetch global Node>=18.
 * Timeouts: 10s por chamada via AbortController, retry em 403/404/5xx/408/429.
 * Cache: Map in-memory com hash SHA-256 truncado do token, TTL 1h, para rotação multi-account.
 *
 * Modelos suportados até 25/08/2026 (governança Canto do Buriti, PI, BR):
 * - gemini-3.6-flash-high, gemini-3.6-flash-medium, gemini-3.6-flash-low,
 *   gemini-3.6-flash-tiered, gemini-3.6-flash
 * - gemini-3.5-flash-high, gemini-3.5-flash-medium, gemini-3.5-flash,
 *   gemini-3.5-flash-lite, gemini-3.5-flash-lite-preview
 * - gemini-3.1-pro-high, gemini-3.1-pro-low, gemini-3.1-pro,
 *   gemini-3.1-flash-image, gemini-3.1-flash-lite
 * - gemini-3-flash, gemini-3-pro, gemini-3-deep-think
 * - gemini-2.5-pro, gemini-2.5-flash, gemini-2.5-flash-lite
 * - claude-sonnet-4-6-thinking, claude-opus-4-6-thinking,
 *   claude-sonnet-4-5, claude-opus-4-5-thinking
 * - gpt-oss-120b-medium, gpt-oss-120b-high
 * - preview: gemini-3-pro-preview, gemini-3-flash-preview,
 *   gemini-3.1-pro-preview, gemini-3.1-pro-preview-customtools
 *
 * @version 2.1.0 — ONDA 5 CORREÇÃO V2 — bypass total Gemini CLI
 * @license MIT
 */

import { createHash } from "node:crypto";
import { arch, platform } from "node:os";

// ---------------------------------------------------------------------------
// Constantes blindadas — root-first, sem src/
// ---------------------------------------------------------------------------

/**
 * O observador registra endpoints autoritativos. PROD é primário;
 * DAILY/SANDBOX/AUTOPUSH são fallbacks para rollout gradual e testes canário
 * observados em Gemini CLI --debug e em OmniRoute config.
 */
export const CODE_ASSIST_ENDPOINTS = {
  PROD: "https://cloudcode-pa.googleapis.com",
  DAILY: "https://daily-cloudcode-pa.googleapis.com",
  SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  AUTOPUSH: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
} as const;

export const ENDPOINT_ORDER: readonly string[] = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
  CODE_ASSIST_ENDPOINTS.SANDBOX,
];

export const FETCH_TIMEOUT_MS = 10_000;
export const FALLBACK_PROJECT_ID = "rising-fact-p41fc";
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2";
export const ANTIGRAVITY_USER_AGENT_FALLBACK = `antigravity/${ANTIGRAVITY_VERSION_FALLBACK}` as const;

function buildDefaultUserAgent(version?: string): string {
  try {
    const ver = version && /^\d+\.\d+\.\d+/.test(version) ? version : ANTIGRAVITY_VERSION_FALLBACK;
    const os = platform();
    const cpu = arch();
    const mappedOs = os === "darwin" ? "darwin" : os === "win32" ? "win32" : "linux";
    const mappedArch = cpu === "arm64" ? "arm64" : "x64";
    return `antigravity/${ver} ${mappedOs}/${mappedArch}`;
  } catch {
    return ANTIGRAVITY_USER_AGENT_FALLBACK;
  }
}

// ---------------------------------------------------------------------------
// Modelos 25/08/2026 — timeline completa opencode.txt
// ---------------------------------------------------------------------------

/**
 * Lista canônica até 25/08/2026 conforme solicitado pelo usuário.
 * O observador valida estes modelos via fetchAvailableModels best-effort,
 * sem quebrar se rollout ainda não propagou em DAILY/SANDBOX.
 */
export const MODELS_2026_BASE = [
  // 3.6 family
  "gemini-3.6-flash-high",
  "gemini-3.6-flash-medium",
  "gemini-3.6-flash-low",
  "gemini-3.6-flash-tiered",
  "gemini-3.6-flash",
  // 3.5 family
  "gemini-3.5-flash-high",
  "gemini-3.5-flash-medium",
  "gemini-3.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.5-flash-lite-preview",
  // 3.1 family
  "gemini-3.1-pro-high",
  "gemini-3.1-pro-low",
  "gemini-3.1-pro",
  "gemini-3.1-flash-image",
  "gemini-3.1-flash-lite",
  // 3.0 family
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-3-deep-think",
  // 2.5 family
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  // Claude 4.5 / 4.6 pensando
  "claude-sonnet-4-6-thinking",
  "claude-opus-4-6-thinking",
  "claude-sonnet-4-5",
  "claude-opus-4-5-thinking",
  // OSS
  "gpt-oss-120b-medium",
  "gpt-oss-120b-high",
  // Previews oficiais
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export const MODELS_2026 = MODELS_2026_BASE;

export const MODELS_2026_ANTIGRAVITY = [
  ...MODELS_2026_BASE.map((m) => `antigravity-${m}` as const),
  // Variantes legadas ainda vistas em traffic dump 07/2026
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3.1-pro",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-sonnet-4-5",
  "antigravity-claude-opus-4-5-thinking",
] as const;

export const MODELS_2026_ALL = [
  ...MODELS_2026_BASE,
  ...MODELS_2026_ANTIGRAVITY,
] as const;

// ---------------------------------------------------------------------------
// Cache Map blindado
// ---------------------------------------------------------------------------

interface CacheEntry {
  projectId: string;
  timestamp: number;
  email?: string;
}

const CACHE_TTL_MS = 60 * 60 * 1000; // 1h
const projectIdCache = new Map<string, CacheEntry>();

export function fnv1a32(str: string): number {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = (hash * 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

function hashToken(token: string): string {
  try {
    return createHash("sha256").update(token).digest("hex").slice(0, 32);
  } catch {
    return fnv1a32(token).toString(16);
  }
}

export function getCachedProjectId(accessToken: string): string | null {
  const key = hashToken(accessToken);
  const entry = projectIdCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > CACHE_TTL_MS) {
    projectIdCache.delete(key);
    return null;
  }
  return entry.projectId;
}

export function setCachedProjectId(accessToken: string, projectId: string, email?: string): void {
  const key = hashToken(accessToken);
  projectIdCache.set(key, { projectId, timestamp: Date.now(), email });
}

export function clearProjectIdCache(): void {
  projectIdCache.clear();
}

export function getCacheStats(): { size: number; entries: Array<{ email?: string; ageMs: number }> } {
  const now = Date.now();
  return {
    size: projectIdCache.size,
    entries: Array.from(projectIdCache.values()).map((e) => ({
      email: e.email,
      ageMs: now - e.timestamp,
    })),
  };
}

// ---------------------------------------------------------------------------
// Helpers — timeout, retry, headers — estilo Gemini CLI
// ---------------------------------------------------------------------------

export function isRetryable(status: number): boolean {
  return status === 403 || status === 404 || status === 408 || status === 429 || status >= 500;
}

export interface AntigravityHeadersOptions {
  userAgent?: string;
  extra?: Record<string, string>;
}

export function buildAntagravityHeaders(
  accessToken: string,
  opts: AntigravityHeadersOptions = {}
): Record<string, string> {
  const ua = opts.userAgent ?? buildDefaultUserAgent();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${accessToken}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
  };
  if (opts.extra) {
    for (const [k, v] of Object.entries(opts.extra)) headers[k] = v;
  }
  return headers;
}

export class ProjectDiscoveryError extends Error {
  public status?: number;
  public endpoint?: string;
  public retryable: boolean;
  constructor(message: string, status?: number, endpoint?: string) {
    super(message);
    this.name = "ProjectDiscoveryError";
    this.status = status;
    this.endpoint = endpoint;
    this.retryable = status !== undefined ? isRetryable(status) : true;
  }
}

export async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = FETCH_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const signal = controller.signal;

  const mergedInit: RequestInit = { ...init, signal };

  if (init.signal) {
    const external = init.signal as AbortSignal;
    if (external.aborted) {
      clearTimeout(timeoutId);
      controller.abort();
    } else {
      external.addEventListener("abort", () => controller.abort(), { once: true });
    }
  }

  try {
    const response = await fetch(url, mergedInit);
    return response;
  } catch (err: any) {
    if (err?.name === "AbortError") {
      throw new ProjectDiscoveryError(`timeout after ${timeoutMs}ms for ${url}`, 408, url);
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

// ---------------------------------------------------------------------------
// Tipos Cloud Code — observados via Gemini CLI, OmniRoute, 9router
// ---------------------------------------------------------------------------

export type IdeType = "ANTIGRAVITY" | "GEMINI";

export interface CodeAssistMetadata {
  ideType: IdeType;
  platform: "PLATFORM_UNSPECIFIED";
  pluginType: "GEMINI";
}

function defaultMetadata(ideType: IdeType = "ANTIGRAVITY"): CodeAssistMetadata {
  return {
    ideType,
    platform: "PLATFORM_UNSPECIFIED",
    pluginType: "GEMINI",
  };
}

function extractProjectId(raw: unknown): string | null {
  if (!raw) return null;
  if (typeof raw === "string") {
    const s = raw.trim();
    if (!s) return null;
    if (s.includes("projects/")) {
      const parts = s.split("/");
      const idx = parts.indexOf("projects");
      const id = parts[idx + 1];
      return id || s.split("/").pop() || s;
    }
    return s;
  }
  if (typeof raw === "object") {
    const obj = raw as any;
    if (typeof obj.id === "string" && obj.id) return extractProjectId(obj.id);
    if (typeof obj.name === "string" && obj.name) {
      const n = obj.name as string;
      return n.includes("/") ? n.split("/").pop() ?? n : n;
    }
    if (typeof obj.projectId === "string") return extractProjectId(obj.projectId);
    if (typeof obj.project_id === "string") return extractProjectId(obj.project_id);
  }
  return null;
}

export interface LoadCodeAssistResponse {
  cloudaicompanionProject?: unknown;
  cloudaicompanionProjectId?: unknown;
  projectId?: unknown;
  currentTier?: unknown;
  [k: string]: unknown;
}

export interface OnboardUserResponse {
  done?: boolean;
  name?: string;
  response?: { cloudaicompanionProject?: unknown; projectId?: unknown };
  cloudaicompanionProject?: unknown;
  [k: string]: unknown;
}

export interface AvailableModel {
  name: string;
  displayName?: string;
  supportedMethods?: string[];
}

export interface FetchAvailableModelsResponse {
  models?: AvailableModel[];
  availableModels?: AvailableModel[];
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// loadCodeAssist — bypass total Project ID como Gemini CLI
// ---------------------------------------------------------------------------

export interface LoadCodeAssistOptions {
  accessToken: string;
  endpoint: string;
  projectId?: string;
  userAgent?: string;
  ideType?: IdeType;
}

 /**
  * O observador implementa loadCodeAssist exatamente como Gemini CLI:
  * - POST {endpoint}/v1internal:loadCodeAssist
  * - Header: Authorization Bearer + User-Agent antigravity/{ver} {os}/{arch}
  * - Body: {metadata {ideType ANTIGRAVITY ou GEMINI, platform PLATFORM_UNSPECIFIED, pluginType GEMINI}}
  * - Sem exigir project ID: se projectId não fornecido, envia apenas metadata (bypass)
  * - Se fornecido e válido, envia cloudaicompanionProject para validação (compatibilidade cache)
  * - Se 403/404 e ideType ANTIGRAVITY, retenta automaticamente com GEMINI (bypass observado em pi-antigravity-auth)
  * - Retorna string projectId ou null indicando necessidade de onboard
  */
export async function loadCodeAssist(opts: LoadCodeAssistOptions): Promise<string | null> {
  const { accessToken, endpoint, projectId, userAgent, ideType = "ANTIGRAVITY" } = opts;
  const base = endpoint.replace(/\/+$/, "");
  const url = `${base}/v1internal:loadCodeAssist`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  const attemptLoad = async (currentIde: IdeType): Promise<string | null> => {
    const body: Record<string, unknown> = {
      metadata: defaultMetadata(currentIde),
    };
    if (projectId && projectId !== FALLBACK_PROJECT_ID) {
      body.cloudaicompanionProject = projectId;
    }

    let res: Response;
    try {
      res = await fetchWithTimeout(
        url,
        { method: "POST", headers, body: JSON.stringify(body) },
        FETCH_TIMEOUT_MS
      );
    } catch (e: any) {
      throw new ProjectDiscoveryError(
        `loadCodeAssist network failed at ${endpoint} ide=${currentIde}: ${e.message}`,
        e.status ?? 0,
        endpoint
      );
    }

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      const err = new ProjectDiscoveryError(
        `loadCodeAssist failed ${res.status} at ${endpoint} ide=${currentIde}: ${text.slice(0, 600)}`,
        res.status,
        endpoint
      );
      throw err;
    }

    let data: LoadCodeAssistResponse;
    try {
      data = (await res.json()) as LoadCodeAssistResponse;
    } catch {
      throw new ProjectDiscoveryError(`loadCodeAssist invalid JSON at ${endpoint}`, 500, endpoint);
    }

    const raw =
      (data as any).cloudaicompanionProject ??
      (data as any).cloudaicompanionProjectId ??
      (data as any).projectId ??
      (data as any).currentTier?.id;

    if (!raw) return null;

    return extractProjectId(raw);
  };

  try {
    return await attemptLoad(ideType);
  } catch (err: any) {
    if (err instanceof ProjectDiscoveryError && isRetryable(err.status ?? 0) && ideType === "ANTIGRAVITY") {
      // Bypass retry com GEMINI — exatamente como Gemini CLI faria quando Antigravity bloqueia
      try {
        return await attemptLoad("GEMINI");
      } catch (retryErr: any) {
        if (retryErr instanceof ProjectDiscoveryError) throw retryErr;
        throw err;
      }
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// onboardUser — tier FREE com LRO pollOperation 500ms-8s 5 tentativas
// ---------------------------------------------------------------------------

export interface OnboardUserOptions {
  accessToken: string;
  endpoint: string;
  tierId?: "FREE" | "TRIAL" | "STANDARD";
  userAgent?: string;
  ideType?: IdeType;
}

export async function onboardUser(opts: OnboardUserOptions): Promise<string | null> {
  const { accessToken, endpoint, tierId = "FREE", userAgent, ideType = "ANTIGRAVITY" } = opts;
  const base = endpoint.replace(/\/+$/, "");
  const url = `${base}/v1internal:onboardUser`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  const body = {
    tierId,
    metadata: defaultMetadata(ideType),
  };

  let res: Response;
  try {
    res = await fetchWithTimeout(
      url,
      { method: "POST", headers, body: JSON.stringify(body) },
      FETCH_TIMEOUT_MS
    );
  } catch (e: any) {
    throw new ProjectDiscoveryError(
      `onboardUser network failed at ${endpoint}: ${e.message}`,
      e.status ?? 0,
      endpoint
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    // Se já onboarded, servidor pode retornar 409 — tratar como necessidade de load
    if (res.status === 409) return null;
    throw new ProjectDiscoveryError(
      `onboardUser failed ${res.status} at ${endpoint}: ${text.slice(0, 600)}`,
      res.status,
      endpoint
    );
  }

  let data: OnboardUserResponse;
  try {
    data = (await res.json()) as OnboardUserResponse;
  } catch {
    throw new ProjectDiscoveryError(`onboardUser invalid JSON at ${endpoint}`, 500, endpoint);
  }

  const direct =
    (data as any).cloudaicompanionProject ??
    (data as any).response?.cloudaicompanionProject ??
    (data as any).response?.projectId;

  if (direct) {
    const extracted = extractProjectId(direct);
    if (extracted) return extracted;
  }

  if (data.name && data.done === false) {
    const polled = await pollOperation({
      accessToken,
      endpoint,
      operationName: data.name,
      userAgent,
      maxAttempts: 5,
    });
    if (polled) return polled;
  }

  if (data.done && data.response) {
    const proj = (data.response as any).cloudaicompanionProject ?? (data.response as any).projectId;
    const extracted = extractProjectId(proj);
    if (extracted) return extracted;
  }

  // padrão observado gemini-cli: onboard sem retorno direto, mas load seguinte funciona
  return null;
}

interface PollOperationOptions {
  accessToken: string;
  endpoint: string;
  operationName: string;
  userAgent?: string;
  maxAttempts?: number;
}

/**
 * O observador replica polling LRO do Gemini CLI com backoff 500ms-8s.
 * 5 tentativas, jitter via event loop, tolerante a formatos diversos de operationName.
 * Referências: google gemini-cli polling backoff, OmniRoute longrunning.js
 */
async function pollOperation(opts: PollOperationOptions): Promise<string | null> {
  const { accessToken, endpoint, operationName, userAgent, maxAttempts = 5 } = opts;
  const base = endpoint.replace(/\/+$/, "");
  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  // Normaliza operationName observado:
  // - "v1internal/operations/xxx"
  // - "operations/xxx"
  // - "xxx" puro
  const buildOpUrl = (name: string): string => {
    if (name.includes("/operations/")) {
      if (name.startsWith("v1internal/")) return `${base}/${name}`;
      return `${base}/v1internal/${name}`;
    }
    if (name.startsWith("operations/")) return `${base}/v1internal/${name}`;
    return `${base}/v1internal/operations/${name}`;
  };

  const initialUrl = buildOpUrl(operationName);

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (attempt > 0) {
      const delayMs = Math.min(500 * Math.pow(2, attempt - 1), 8000);
      await new Promise((r) => setTimeout(r, delayMs));
    }
    try {
      const res = await fetchWithTimeout(
        attempt === 0 ? initialUrl : buildOpUrl(operationName),
        { method: "GET", headers },
        FETCH_TIMEOUT_MS
      );
      if (!res.ok) continue;
      const data = (await res.json()) as OnboardUserResponse;
      if (data.done) {
        const proj =
          (data as any).response?.cloudaicompanionProject ??
          (data as any).response?.projectId ??
          (data as any).cloudaicompanionProject;
        const extracted = extractProjectId(proj);
        if (extracted) return extracted;
        return null;
      }
    } catch {
      continue;
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// fetchAvailableModels — valida projeto e lista modelos 25/08/2026
// ---------------------------------------------------------------------------

export interface FetchModelsOptions {
  accessToken: string;
  endpoint: string;
  projectId: string;
  userAgent?: string;
}

export async function fetchAvailableModels(opts: FetchModelsOptions): Promise<AvailableModel[]> {
  const { accessToken, endpoint, projectId, userAgent } = opts;
  if (!projectId) throw new ProjectDiscoveryError("fetchAvailableModels requires projectId", 400, endpoint);

  const url = `${endpoint.replace(/\/+$/, "")}/v1internal:fetchAvailableModels`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });
  const body = { cloudaicompanionProject: projectId, metadata: defaultMetadata("ANTIGRAVITY") };

  let res: Response;
  try {
    res = await fetchWithTimeout(url, { method: "POST", headers, body: JSON.stringify(body) }, FETCH_TIMEOUT_MS);
  } catch (e: any) {
    throw new ProjectDiscoveryError(
      `fetchAvailableModels network failed at ${endpoint}: ${e.message}`,
      e.status ?? 0,
      endpoint
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new ProjectDiscoveryError(
      `fetchAvailableModels failed ${res.status} at ${endpoint}: ${text.slice(0, 500)}`,
      res.status,
      endpoint
    );
  }

  let data: FetchAvailableModelsResponse;
  try {
    data = (await res.json()) as FetchAvailableModelsResponse;
  } catch {
    throw new ProjectDiscoveryError(`fetchAvailableModels invalid JSON at ${endpoint}`, 500, endpoint);
  }

  const rawModels = (data as any).models ?? (data as any).availableModels ?? [];
  const models: AvailableModel[] = Array.isArray(rawModels) ? rawModels : [];
  return models;
}

// ---------------------------------------------------------------------------
// resolveProjectId — orquestrador principal bypass total Gemini CLI
// ---------------------------------------------------------------------------

export interface AccountMetadataSaver {
  (projectId: string): Promise<void> | void;
}

export interface ResolveProjectIdOptions {
  accessToken: string;
  cachedProjectId?: string;
  email?: string;
  metadataSaver?: AccountMetadataSaver;
  userAgent?: string;
  endpoints?: readonly string[];
  includeAutopush?: boolean;
  /** Quando true (default), tenta projeto descoberto antes de fallback blindado */
  bypass?: boolean;
  /** ideType preferido — ANTIGRAVITY tenta primeiro, GEMINI fallback automático */
  ideType?: IdeType;
}

export interface ResolveResult {
  projectId: string;
  fromCache: boolean;
  endpointUsed?: string;
  isFallback: boolean;
  modelsChecked?: number;
  ideTypeUsed?: IdeType;
}

/**
 * Resolve o project id com bypass total estilo Gemini CLI.
 * Fluxo third-person observer:
 * 1. Cache Map memória (hash token) — evita round-trip multi-account
 * 2. Se cachedProjectId salvo em disco, tenta validar via loadCodeAssist com ele
 *    em cada endpoint (compat AccountManager V3 ~/.config/opencode/antigravity-accounts.json chmod 600)
 * 3. Bypass puro: loadCodeAssist SEM projectId → {metadata {ANTIGRAVITY|GEMINI, PLATFORM_UNSPECIFIED, GEMINI}}
 *    → retorna cloudaicompanionProject descoberto sem exigir user project
 * 4. Se load retorna null ou 403/404 → onboardUser {tierId FREE, metadata} → LRO pollOperation
 *    backoff 500ms-8s 5 tentativas → load novamente
 * 5. Best-effort validação com fetchAvailableModels (não falha se 403)
 * 6. Salva cache + metadataSaver para persistência
 * 7. Se todos endpoints falham com isRetryable, fallback rising-fact-p41fc com warning,
 *    mas bypass flag tenta usar projeto descoberto preferencialmente, não exige user project
 */
export async function resolveProjectId(opts: ResolveProjectIdOptions): Promise<ResolveResult> {
  const {
    accessToken,
    cachedProjectId,
    email,
    metadataSaver,
    userAgent = buildDefaultUserAgent(),
    endpoints = ENDPOINT_ORDER,
    includeAutopush = false,
    bypass = true,
    ideType = "ANTIGRAVITY",
  } = opts;

  if (!accessToken) throw new ProjectDiscoveryError("resolveProjectId requires accessToken");

  // 1. Cache rápido Map
  const memCached = getCachedProjectId(accessToken);
  if (memCached) {
    return {
      projectId: memCached,
      fromCache: true,
      isFallback: memCached === FALLBACK_PROJECT_ID,
      ideTypeUsed: ideType,
    };
  }

  const allEndpoints = includeAutopush ? [...endpoints, CODE_ASSIST_ENDPOINTS.AUTOPUSH] : endpoints;

  let lastError: ProjectDiscoveryError | null = null;
  let attemptedEndpoints = 0;

  for (const endpoint of allEndpoints) {
    attemptedEndpoints++;
    try {
      let discoveredProjectId: string | null = null;

      // 2a. Se tem cachedProjectId no disco, tenta validar primeiro (compat)
      if (cachedProjectId && cachedProjectId !== FALLBACK_PROJECT_ID) {
        try {
          const validated = await loadCodeAssist({
            accessToken,
            endpoint,
            projectId: cachedProjectId,
            userAgent,
            ideType,
          });
          if (validated) discoveredProjectId = validated;
        } catch (e: any) {
          if (e instanceof ProjectDiscoveryError && !e.retryable) throw e;
          // retryable — cai para bypass puro no mesmo endpoint
          lastError = e instanceof ProjectDiscoveryError ? e : null;
        }
      }

      // 2b. Bypass puro — load sem projectId, exatamente como Gemini CLI
      if (!discoveredProjectId && bypass) {
        try {
          discoveredProjectId = await loadCodeAssist({ accessToken, endpoint, userAgent, ideType });
        } catch (e: any) {
          if (e instanceof ProjectDiscoveryError) {
            lastError = e;
            if (e.status === 403 || e.status === 404) {
              // 403/404 indica conta sem projeto provisionado → precisa onboard
              // não pula endpoint ainda, tenta onboard + load
            } else if (!isRetryable(e.status ?? 0)) {
              throw e;
            } else {
              // retryable 5xx/408/429 → tenta próximo endpoint depois de onboard attempt
            }
          } else {
            lastError = new ProjectDiscoveryError(
              `unexpected load error at ${endpoint}: ${e?.message ?? String(e)}`,
              500,
              endpoint
            );
          }
        }
      }

      // 2c. Se load retornou null ou falhou com 403/404, tenta onboardUser + load novamente
      if (!discoveredProjectId) {
        try {
          const onboarded = await onboardUser({ accessToken, endpoint, tierId: "FREE", userAgent, ideType });
          if (onboarded) {
            discoveredProjectId = onboarded;
          } else {
            // padrão gemini-cli: onboard sem projeto imediato, load seguinte funciona
            try {
              discoveredProjectId = await loadCodeAssist({ accessToken, endpoint, userAgent, ideType });
            } catch (loadAfterOnboardErr: any) {
              if (loadAfterOnboardErr instanceof ProjectDiscoveryError) {
                lastError = loadAfterOnboardErr;
                if (!isRetryable(loadAfterOnboardErr.status ?? 0)) throw loadAfterOnboardErr;
                continue;
              }
              lastError = loadAfterOnboardErr;
              continue;
            }
          }
        } catch (onboardErr: any) {
          if (onboardErr instanceof ProjectDiscoveryError) {
            lastError = onboardErr;
            if (!isRetryable(onboardErr.status ?? 0)) throw onboardErr;
            continue;
          }
          lastError = onboardErr;
          continue;
        }
      }

      if (!discoveredProjectId) {
        lastError = new ProjectDiscoveryError(`no project id from ${endpoint}`, 404, endpoint);
        continue;
      }

      // 2d. best-effort validação com fetchAvailableModels — não falha se 403/404
      let modelsCount: number | undefined;
      try {
        const models = await fetchAvailableModels({
          accessToken,
          endpoint,
          projectId: discoveredProjectId,
          userAgent,
        });
        modelsCount = models.length;
      } catch (validateErr: any) {
        if (validateErr instanceof ProjectDiscoveryError && !isRetryable(validateErr.status ?? 0)) {
          throw validateErr;
        }
        // retryable → ainda aceita projectId descoberto (rollout gradual 2026 models)
      }

      // 2e. sucesso — salva cache e metadata
      setCachedProjectId(accessToken, discoveredProjectId, email);

      if (metadataSaver) {
        try {
          await metadataSaver(discoveredProjectId);
        } catch (saveErr) {
          console.warn(
            `[antigravity-auth] failed to save projectId metadata for ${email ?? "unknown"}: ${(saveErr as Error).message}`
          );
        }
      }

      return {
        projectId: discoveredProjectId,
        fromCache: false,
        endpointUsed: endpoint,
        isFallback: false,
        modelsChecked: modelsCount,
        ideTypeUsed: ideType,
      };
    } catch (err: any) {
      if (err instanceof ProjectDiscoveryError) {
        lastError = err;
        if (!err.retryable) throw err;
        continue;
      }
      lastError = new ProjectDiscoveryError(
        `unexpected error at ${endpoint}: ${err?.message ?? String(err)}`,
        500,
        endpoint
      );
      continue;
    }
  }

  // 3. Todos endpoints falharam — fallback blindado com warning
  // Bypass flag true tenta usar projeto descoberto, não exige user project; só cai aqui se tudo falhou.
  console.warn(
    `[antigravity-auth] WARNING: all ${attemptedEndpoints} endpoints failed` +
      `${lastError ? ` (last: ${lastError.status} ${lastError.message.slice(0, 250)})` : ""}.` +
      ` Falling back to blinded project ${FALLBACK_PROJECT_ID}.` +
      ` This works for Antigravity but will 403 for Gemini CLI models.` +
      ` Bypass attempted to discover project via loadCodeAssist/onboardUser like Gemini CLI does.` +
      ` Check https://github.com/NoeFabris/opencode-antigravity-auth#403-permission-denied`
  );

  setCachedProjectId(accessToken, FALLBACK_PROJECT_ID, email);

  if (metadataSaver) {
    try {
      await metadataSaver(FALLBACK_PROJECT_ID);
    } catch {}
  }

  return {
    projectId: FALLBACK_PROJECT_ID,
    fromCache: false,
    endpointUsed: undefined,
    isFallback: true,
    ideTypeUsed: ideType,
  };
}

export async function resolveAndSaveProjectId(
  accessToken: string,
  account: { email?: string; projectId?: string; save?: AccountMetadataSaver },
  opts: Omit<ResolveProjectIdOptions, "accessToken" | "cachedProjectId" | "email" | "metadataSaver"> = {}
): Promise<ResolveResult> {
  return resolveProjectId({
    accessToken,
    cachedProjectId: account.projectId,
    email: account.email,
    metadataSaver: account.save,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Exports compat + default
// ---------------------------------------------------------------------------

export const projectIdCacheForTesting = projectIdCache;

const projectModule = {
  CODE_ASSIST_ENDPOINTS,
  ENDPOINT_ORDER,
  FETCH_TIMEOUT_MS,
  FALLBACK_PROJECT_ID,
  MODELS_2026,
  MODELS_2026_BASE,
  MODELS_2026_ANTIGRAVITY,
  MODELS_2026_ALL,
  isRetryable,
  buildAntagravityHeaders,
  fetchWithTimeout,
  loadCodeAssist,
  onboardUser,
  fetchAvailableModels,
  resolveProjectId,
  resolveAndSaveProjectId,
  getCachedProjectId,
  setCachedProjectId,
  clearProjectIdCache,
  getCacheStats,
  fnv1a32,
  ProjectDiscoveryError,
  buildDefaultUserAgent,
};

export default projectModule;
