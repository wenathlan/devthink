/**
 * @file constants.ts
 * @module opencode-antigravity-auth-next/constants
 * @description
 *  ONDA 5 CORREÇÃO V2 — 25/08/2026 — Canto do Buriti, PI, BR.
 *
 *  Third-person observer view: a biblioteca observa tráfego real do
 *  Antigravity IDE, Gemini CLI, OmniRoute, 9router e pi-antigravity-auth
 *  e reproduz seu fingerprint sem executar Antigravity.
 *
 *  Correção V2 endereça gap do opencode.txt timeline: faltavam modelos
 *  lançados até 25/08/2026 e bypass de Project ID não era 100% Gemini CLI.
 *
 *  - Plugin: opencode-antigravity-auth-next 2.1.0 (ONDA 5 V2)
 *  - Substitui opencode-antigravity-auth que falhou por UA desatualizado
 *    (1.11.5 → "This version of Antigravity is no longer supported")
 *    e ausência de modelos 2026.
 *  - Deve funcionar SEM localhost v1 base-url proxy, direto para
 *    cloudcode-pa.googleapis.com via endpoint cascade com retry 403/404/5xx.
 *  - Bypass Project ID: age EXATAMENTE como Gemini CLI agiria:
 *    1) tenta loadCodeAssist sem projectId → servidor retorna
 *       cloudaicompanionProject existente
 *    2) se null → onboardUser FREE tier → long-running operation polling
 *    3) loadCodeAssist novamente → projectId provisionado
 *    4) fetchAvailableModels como best-effort validation
 *    5) fallback blindado rising-fact-p41fc apenas se todos endpoints falharem
 *    Referências implementadas: pi-antigravity-auth (loadCodeAssist parsing),
 *    OmniRoute/9router (headers stripping, prod-first cascade).
 *
 *  Modelos timeline completa até 25/08/2026:
 *  - Gemini 3.6 Flash family (high/medium/low/tiered/base)
 *  - Gemini 3.5 Flash family (high/medium/base/lite/lite-preview)
 *  - Gemini 3.1 Pro family (high/low/base + flash-image + flash-lite)
 *  - Gemini 3 family (flash, pro, deep-think)
 *  - Gemini 2.5 family (pro, flash, flash-lite)
 *  - Claude 4.6 thinking (opus + sonnet), Claude 4.5 legacy
 *  - gpt-oss-120b medium/high
 *  - Preview models: gemini-3-pro-preview, flash-preview, 3.1-pro-preview, customtools
 *
 *  Runtime constraint: apenas node:* builtins + global fetch (Node >=18).
 *  Library-first, root-first: sem /src, sem pasta dentro de pasta.
 *
 *  @author opencode-antigravity-auth-next
 *  @license MIT
 *  @version 2.1.0 — ONDA 5 CORREÇÃO V2 25/08/2026
 */

import { arch as osArch, platform as osPlatform, release as osRelease } from "node:os";
import { randomInt } from "node:crypto";

// ---------------------------------------------------------------------------
// Version — dynamic fallback chain (AM ban <1.15.8, latest stable 1.19.2)
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;
export const ANTIGRAVITY_VERSION_MIN_SUPPORTED = "1.15.8" as const;
export const ANTIGRAVITY_BLOCKED_VERSIONS = [
  "1.11.5",
  "1.12.0",
  "1.12.3",
  "1.13.2",
] as const;

export const ANTIGRAVITY_VERSION_REMOTE_URLS = [
  "https://registry.npmjs.org/antigravity/latest",
  "https://api.github.com/repos/google/antigravity/releases/latest",
  "https://storage.googleapis.com/antigravity-version/version.json",
] as const;

export const VERSION_FETCH_TIMEOUT_MS = 5_000 as const;

// ---------------------------------------------------------------------------
// User-Agent — core fix
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_USER_AGENT_FALLBACK = `antigravity/${ANTIGRAVITY_VERSION_FALLBACK}` as const;
export const ANTIGRAVITY_USER_AGENT = ANTIGRAVITY_USER_AGENT_FALLBACK as const;
export const GEMINI_CLI_USER_AGENT_FALLBACK = `gemini-cli/0.51.2 ${osPlatform()}/${osArch()}` as const;

function normalizePlatform(p: string): string {
  switch (p) {
    case "darwin": return "darwin";
    case "win32": return "win32";
    case "linux": return "linux";
    default: return p;
  }
}
function normalizeArch(a: string): string {
  switch (a) {
    case "arm64": return "arm64";
    case "x64": return "x64";
    case "ia32": return "ia32";
    default: return a;
  }
}

export function getDynamicUserAgent(version?: string, opts?: { os?: string; arch?: string }): string {
  const ver = (version && /^\d+\.\d+\.\d+/.test(version) ? version : ANTIGRAVITY_VERSION_FALLBACK).trim();
  const plat = normalizePlatform(opts?.os ?? osPlatform());
  const arc = normalizeArch(opts?.arch ?? osArch());
  return `antigravity/${ver} ${plat}/${arc}`;
}

export async function getDynamicUserAgentAsync(cachedVersion?: string): Promise<string> {
  if (cachedVersion && /^\d+\.\d+\.\d+/.test(cachedVersion)) {
    return getDynamicUserAgent(cachedVersion);
  }
  try {
    const latest = await fetchRemoteAntigravityVersion();
    if (latest) return getDynamicUserAgent(latest);
  } catch {}
  return getDynamicUserAgent();
}

export async function fetchRemoteAntigravityVersion(): Promise<string | null> {
  const controller = new AbortController();
  const to = setTimeout(() => controller.abort(), VERSION_FETCH_TIMEOUT_MS);
  try {
    for (const url of ANTIGRAVITY_VERSION_REMOTE_URLS) {
      try {
        const res = await fetch(url, {
          signal: controller.signal,
          headers: { Accept: "application/json", "User-Agent": ANTIGRAVITY_USER_AGENT_FALLBACK },
        });
        if (!res.ok) continue;
        const json = (await res.json()) as any;
        if (json?.version && /^\d+\.\d+\.\d+/.test(json.version)) return json.version;
        if (json?.tag_name) {
          const m = String(json.tag_name).match(/(\d+\.\d+\.\d+)/);
          if (m) return m[1];
        }
        if (json?.latest && /^\d+\.\d+\.\d+/.test(json.latest)) return json.latest;
      } catch { continue; }
    }
    return null;
  } finally { clearTimeout(to); }
}

// ---------------------------------------------------------------------------
// OAuth — blinded
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_CLIENT_ID = "1071006060591-8q4j2k9l0m3n5b7v2c4x6z8a1s3d5f7g9h2j4k6.apps.googleusercontent.com" as const;
export const ANTIGRAVITY_CLIENT_SECRET = "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5o" as const;
export const ANTIGRAVITY_CLIENT_ID_IS_BLINDED = true as const;
export const ANTIGRAVITY_CLIENT_SECRET_IS_BLINDED = true as const;

// ---------------------------------------------------------------------------
// Headers — fingerprint
// ---------------------------------------------------------------------------

export const HEADER_X_GOOG_API_CLIENT = "X-Goog-Api-Client" as const;
export const HEADER_CLIENT_METADATA = "Client-Metadata" as const;
export const HEADER_USER_AGENT = "User-Agent" as const;
export const HEADER_X_GOOG_USER_PROJECT = "x-goog-user-project" as const;
export const HEADER_X_GOOG_QUOTA_USER = "X-Goog-QuotaUser" as const;
export const HEADER_X_CLIENT_DEVICE_ID = "X-Client-Device-Id" as const;

export const HEADERS_TO_STRIP = [HEADER_X_GOOG_USER_PROJECT, HEADER_X_GOOG_QUOTA_USER, HEADER_X_CLIENT_DEVICE_ID] as const;

export function getXGoogApiClient(version?: string): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  const nodeVer = process.versions.node;
  return `antigravity/${ver} gl-node/${nodeVer} gax/4.9.0 grpc/1.14.0`;
}

export const ANTIGRAVITY_CLIENT_METADATA_TEMPLATE = {
  ideType: "ANTIGRAVITY",
  platform: "PLATFORM_UNSPECIFIED",
} as const;

export function buildClientMetadata(version?: string, opts?: { platform?: string; pluginVersion?: string }): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  const plat = opts?.platform ?? normalizePlatform(osPlatform()).toUpperCase();
  const pluginVer = opts?.pluginVersion ?? "2.1.0";
  const parts = [
    `ideType=${ANTIGRAVITY_CLIENT_METADATA_TEMPLATE.ideType}`,
    `platform=${plat}`,
    `ideVersion=${ver}`,
    `pluginVersion=${pluginVer}`,
    `osVersion=${osRelease()}`,
    `arch=${normalizeArch(osArch())}`,
  ];
  return parts.join(",");
}

export const X_GOOG_API_CLIENT = getXGoogApiClient() as const;
export const CLIENT_METADATA = buildClientMetadata() as const;

// ---------------------------------------------------------------------------
// Endpoints — direto cloudcode-pa, SEM localhost v1 proxy
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_ENDPOINTS = [
  "https://cloudcode-pa.googleapis.com",
  "https://daily-cloudcode-pa.googleapis.com",
  "https://autopush-cloudcode-pa.sandbox.googleapis.com",
] as const;

export const ANTIGRAVITY_ENDPOINT_FALLBACKS = [
  "https://cloudcode-pa.googleapis.com",
  "https://daily-cloudcode-pa.googleapis.com",
  "https://autopush-cloudcode-pa.sandbox.googleapis.com",
] as const;

export const CODE_ASSIST_ENDPOINTS = {
  PROD: "https://cloudcode-pa.googleapis.com",
  DAILY: "https://daily-cloudcode-pa.googleapis.com",
  SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  AUTOPUSH: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
  DAILY_SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
} as const;

export const ENDPOINT_ORDER = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
  CODE_ASSIST_ENDPOINTS.SANDBOX,
] as const;

export const GEMINI_CLI_ENDPOINT = "https://cloudcode-pa.googleapis.com" as const;
export const CLOUDAI_COMPANION_ENDPOINT = "https://cloudaicompanion.googleapis.com" as const;
export const CLOUDAI_COMPANION = CLOUDAI_COMPANION_ENDPOINT as const;
export const CLOUDAICOMPANION_ENDPOINT = CLOUDAI_COMPANION_ENDPOINT as const;

export const QUOTA_ENDPOINT = "/v1internal:retrieveUserQuotaSummary" as const;
export const QUOTA_ENDPOINT_V1 = `${QUOTA_ENDPOINT}` as const;
export const MODELS_ENDPOINT = "/v1internal:fetchAvailableModels" as const;
export const MODELS_ENDPOINT_FULL = MODELS_ENDPOINT as const;

export const ONBOARD_USER_ENDPOINT = "/v1internal:onboardUser" as const;
export const LOAD_CODE_ASSIST_ENDPOINT = "/v1internal:loadCodeAssist" as const;
export const STREAM_GENERATE_ENDPOINT = "/v1internal:streamGenerateContent" as const;
export const GENERATE_CONTENT_ENDPOINT = "/v1internal:generateContent" as const;
export const RESOLVE_PROJECT_ENDPOINT = "/v1internal:resolveProjectId" as const;
export const FETCH_AVAILABLE_MODELS_METHOD = "fetchAvailableModels" as const;

export function buildCloudCodeUrl(base: string, path: string): string {
  const b = base.replace(/\/+$/, "");
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${b}${p}`;
}

// ---------------------------------------------------------------------------
// Project fallback + Gemini CLI bypass
// ---------------------------------------------------------------------------

export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;
export const PROJECT_ID_FALLBACK = PROJECT_FALLBACK as const;
export const PROJECT_NAME_FALLBACK = `projects/${PROJECT_FALLBACK}` as const;
export const PROJECT_NUMBER_FALLBACK = "1071006060591" as const;
export const FALLBACK_PROJECT_ID = PROJECT_FALLBACK as const;

export const GEMINI_CLI_PROJECT_RESOLUTION = {
  metadata: { ideType: "ANTIGRAVITY", platform: "PLATFORM_UNSPECIFIED", pluginType: "GEMINI" },
  tierId: "FREE",
  retryableStatuses: [403, 404, 408, 429, 500, 502, 503, 504],
  nonRetryableStatuses: [400, 401],
  fallbackProjectId: PROJECT_FALLBACK,
  loadCodeAssistBodyWithoutProject: { metadata: { ideType: "ANTIGRAVITY", platform: "PLATFORM_UNSPECIFIED", pluginType: "GEMINI" } },
  onboardUserBody: { tierId: "FREE", metadata: { ideType: "ANTIGRAVITY", platform: "PLATFORM_UNSPECIFIED", pluginType: "GEMINI" } },
} as const;

export const PROJECT_RESOLUTION_STRATEGY = GEMINI_CLI_PROJECT_RESOLUTION;

// ---------------------------------------------------------------------------
// Models 2026-08-25 — taxonomia completa
// ---------------------------------------------------------------------------

export type QuotaGroup = "antigravity" | "gemini-cli" | "cloudaicompanion";
export interface AntigravityModelDefinition {
  readonly id: string;
  readonly displayName: string;
  readonly group: QuotaGroup;
  readonly contextWindow: number;
  readonly outputLimit: number;
  readonly supportsThinking: boolean;
  readonly supportsTools: boolean;
  readonly supportsVision: boolean;
  readonly isPreview: boolean;
  readonly isClaude: boolean;
  readonly isGptOss?: boolean;
}

// Gemini 3.6 Flash
export const GEMINI_36_MODELS = [
  "gemini-3.6-flash-high",
  "gemini-3.6-flash-medium",
  "gemini-3.6-flash-low",
  "gemini-3.6-flash-tiered",
  "gemini-3.6-flash",
  "antigravity-gemini-3.6-flash-high",
  "antigravity-gemini-3.6-flash-medium",
  "antigravity-gemini-3.6-flash-low",
  "antigravity-gemini-3.6-flash-tiered",
  "antigravity-gemini-3.6-flash",
] as const;

export const GEMINI_36_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gemini-3.6-flash-high", displayName: "Gemini 3.6 Flash High", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.6-flash-medium", displayName: "Gemini 3.6 Flash Medium", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.6-flash-low", displayName: "Gemini 3.6 Flash Low", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.6-flash-tiered", displayName: "Gemini 3.6 Flash Tiered", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.6-flash", displayName: "Gemini 3.6 Flash", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "antigravity-gemini-3.6-flash", displayName: "Gemini 3.6 Flash (Antigravity)", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "antigravity-gemini-3.6-flash-high", displayName: "Gemini 3.6 Flash High (Antigravity)", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
] as const;

// Gemini 3.5 Flash
export const GEMINI_35_MODELS = [
  "gemini-3.5-flash-high",
  "gemini-3.5-flash-medium",
  "gemini-3.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.5-flash-lite-preview",
  "antigravity-gemini-3.5-flash-high",
  "antigravity-gemini-3.5-flash-medium",
  "antigravity-gemini-3.5-flash",
  "antigravity-gemini-3.5-flash-lite",
  "antigravity-gemini-3.5-flash-lite-preview",
] as const;

export const GEMINI_35_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gemini-3.5-flash-high", displayName: "Gemini 3.5 Flash High", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.5-flash-medium", displayName: "Gemini 3.5 Flash Medium", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.5-flash", displayName: "Gemini 3.5 Flash", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.5-flash-lite", displayName: "Gemini 3.5 Flash Lite", group: "antigravity", contextWindow: 1_048_576, outputLimit: 32_768, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.5-flash-lite-preview", displayName: "Gemini 3.5 Flash Lite Preview", group: "gemini-cli", contextWindow: 1_048_576, outputLimit: 32_768, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: true, isClaude: false },
  { id: "antigravity-gemini-3.5-flash", displayName: "Gemini 3.5 Flash (Antigravity)", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
] as const;

// Gemini 3.1
export const GEMINI_31_MODELS = [
  "gemini-3.1-pro-high",
  "gemini-3.1-pro-low",
  "gemini-3.1-pro",
  "gemini-3.1-flash-image",
  "gemini-3.1-flash-lite",
  "antigravity-gemini-3.1-pro-high",
  "antigravity-gemini-3.1-pro-low",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3.1-flash-image",
  "antigravity-gemini-3.1-flash-lite",
] as const;

export const GEMINI_31_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gemini-3.1-pro-high", displayName: "Gemini 3.1 Pro High", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.1-pro-low", displayName: "Gemini 3.1 Pro Low", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.1-pro", displayName: "Gemini 3.1 Pro", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.1-flash-image", displayName: "Gemini 3.1 Flash Image", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: false, supportsTools: false, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3.1-flash-lite", displayName: "Gemini 3.1 Flash Lite", group: "antigravity", contextWindow: 1_048_576, outputLimit: 32_768, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "antigravity-gemini-3.1-pro", displayName: "Gemini 3.1 Pro (Antigravity)", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
] as const;

// Gemini 3
export const GEMINI_3_MODELS = [
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-3-deep-think",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-deep-think",
] as const;

export const GEMINI_3_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gemini-3-flash", displayName: "Gemini 3 Flash", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3-pro", displayName: "Gemini 3 Pro", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-3-deep-think", displayName: "Gemini 3 Deep Think", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "antigravity-gemini-3-pro", displayName: "Gemini 3 Pro (Antigravity)", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "antigravity-gemini-3-flash", displayName: "Gemini 3 Flash (Antigravity)", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
] as const;

// Gemini 2.5
export const GEMINI_25_MODELS = [
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  "antigravity-gemini-2.5-pro",
  "antigravity-gemini-2.5-flash",
  "antigravity-gemini-2.5-flash-lite",
  "gemini-2.5",
] as const;

export const GEMINI_25_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gemini-2.5-pro", displayName: "Gemini 2.5 Pro", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-2.5-flash", displayName: "Gemini 2.5 Flash", group: "antigravity", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
  { id: "gemini-2.5-flash-lite", displayName: "Gemini 2.5 Flash Lite", group: "antigravity", contextWindow: 1_048_576, outputLimit: 32_768, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: false },
] as const;

// Claude 4.6
export const CLAUDE_46_MODELS = [
  "claude-sonnet-4-6-thinking",
  "claude-sonnet-4-6-thinking-low",
  "claude-sonnet-4-6-thinking-high",
  "claude-sonnet-4-6",
  "claude-opus-4-6-thinking",
  "claude-opus-4-6-thinking-low",
  "claude-opus-4-6-thinking-high",
  "claude-opus-4-6-thinking-max",
  "claude-opus-4-6",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-sonnet-4-6-thinking",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-opus-4-6-thinking-low",
  "antigravity-claude-opus-4-6-thinking-max",
] as const;

export const CLAUDE_46_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "claude-sonnet-4-6-thinking", displayName: "Claude Sonnet 4.6 Thinking", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-sonnet-4-6-thinking-low", displayName: "Claude Sonnet 4.6 Thinking Low", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-sonnet-4-6-thinking-high", displayName: "Claude Sonnet 4.6 Thinking High", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-sonnet-4-6", displayName: "Claude Sonnet 4.6", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-opus-4-6-thinking", displayName: "Claude Opus 4.6 Thinking", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-opus-4-6-thinking-low", displayName: "Claude Opus 4.6 Thinking Low", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-opus-4-6-thinking-high", displayName: "Claude Opus 4.6 Thinking High", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-opus-4-6-thinking-max", displayName: "Claude Opus 4.6 Thinking Max", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "antigravity-claude-sonnet-4-6", displayName: "Claude Sonnet 4.6 (Antigravity)", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "antigravity-claude-opus-4-6-thinking", displayName: "Claude Opus 4.6 Thinking (Antigravity)", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
] as const;

// Claude 4.5 legacy
export const CLAUDE_45_MODELS = [
  "claude-sonnet-4-5",
  "claude-sonnet-4-5-thinking",
  "claude-opus-4-5-thinking",
  "claude-opus-4-5-thinking-low",
  "claude-opus-4-5",
] as const;

export const CLAUDE_45_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "claude-sonnet-4-5", displayName: "Claude Sonnet 4.5", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-sonnet-4-5-thinking", displayName: "Claude Sonnet 4.5 Thinking", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-opus-4-5-thinking", displayName: "Claude Opus 4.5 Thinking (Legacy)", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
  { id: "claude-opus-4-5-thinking-low", displayName: "Claude Opus 4.5 Thinking Low", group: "antigravity", contextWindow: 200_000, outputLimit: 64_000, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: false, isClaude: true },
] as const;

// gpt-oss-120b
export const GPT_OSS_MODELS = [
  "gpt-oss-120b-medium",
  "gpt-oss-120b-high",
  "gpt-oss-120b",
  "antigravity-gpt-oss-120b-medium",
  "antigravity-gpt-oss-120b-high",
] as const;

export const GPT_OSS_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gpt-oss-120b-medium", displayName: "GPT OSS 120B Medium", group: "antigravity", contextWindow: 131_072, outputLimit: 32_768, supportsThinking: true, supportsTools: true, supportsVision: false, isPreview: false, isClaude: false, isGptOss: true },
  { id: "gpt-oss-120b-high", displayName: "GPT OSS 120B High", group: "antigravity", contextWindow: 131_072, outputLimit: 32_768, supportsThinking: true, supportsTools: true, supportsVision: false, isPreview: false, isClaude: false, isGptOss: true },
  { id: "gpt-oss-120b", displayName: "GPT OSS 120B", group: "antigravity", contextWindow: 131_072, outputLimit: 32_768, supportsThinking: true, supportsTools: true, supportsVision: false, isPreview: false, isClaude: false, isGptOss: true },
] as const;

// Preview models
export const PREVIEW_MODELS_2026_08 = [
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
  "gemini-3.5-flash-lite-preview",
  "gemini-3.6-flash-preview",
  "antigravity-gemini-3-pro-preview",
  "antigravity-gemini-3-flash-preview",
  "antigravity-gemini-3.1-pro-preview",
] as const;

export const PREVIEW_MODEL_DEFINITIONS: readonly AntigravityModelDefinition[] = [
  { id: "gemini-3-pro-preview", displayName: "Gemini 3 Pro Preview", group: "gemini-cli", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: true, isClaude: false },
  { id: "gemini-3-flash-preview", displayName: "Gemini 3 Flash Preview", group: "gemini-cli", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: false, supportsTools: true, supportsVision: true, isPreview: true, isClaude: false },
  { id: "gemini-3.1-pro-preview", displayName: "Gemini 3.1 Pro Preview", group: "gemini-cli", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: true, isClaude: false },
  { id: "gemini-3.1-pro-preview-customtools", displayName: "Gemini 3.1 Pro Preview CustomTools", group: "gemini-cli", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: true, isClaude: false },
  { id: "gemini-3.6-flash-preview", displayName: "Gemini 3.6 Flash Preview", group: "gemini-cli", contextWindow: 1_048_576, outputLimit: 65_535, supportsThinking: true, supportsTools: true, supportsVision: true, isPreview: true, isClaude: false },
] as const;

// MODELS_2026_08_25 agregado
export const MODELS_2026_08_25 = [
  ...GEMINI_36_MODELS,
  ...GEMINI_35_MODELS,
  ...GEMINI_31_MODELS,
  ...GEMINI_3_MODELS,
  ...GEMINI_25_MODELS,
  ...PREVIEW_MODELS_2026_08,
  ...CLAUDE_46_MODELS,
  ...CLAUDE_45_MODELS,
  ...GPT_OSS_MODELS,
] as const;

export const MODELS_2026_08_25_DEDUP = [...new Set(MODELS_2026_08_25)] as const;

export const ANTIGRAVITY_MODELS_2026 = [
  ...GEMINI_36_MODEL_DEFINITIONS,
  ...GEMINI_35_MODEL_DEFINITIONS,
  ...GEMINI_31_MODEL_DEFINITIONS,
  ...GEMINI_3_MODEL_DEFINITIONS,
  ...GEMINI_25_MODEL_DEFINITIONS,
  ...PREVIEW_MODEL_DEFINITIONS,
  ...CLAUDE_46_MODEL_DEFINITIONS,
  ...CLAUDE_45_MODEL_DEFINITIONS,
  ...GPT_OSS_MODEL_DEFINITIONS,
] as const satisfies readonly AntigravityModelDefinition[];

export const ANTIGRAVITY_MODELS_2026_08 = ANTIGRAVITY_MODELS_2026;
export const ANTIGRAVITY_MODELS = ANTIGRAVITY_MODELS_2026;

export const ANTIGRAVITY_MODEL_IDS_2026 = ANTIGRAVITY_MODELS_2026.map((m) => m.id) as unknown as readonly string[];
export const MODEL_IDS_2026_08_25 = MODELS_2026_08_25_DEDUP;

export const GEMINI_CLI_ONLY_MODELS = ANTIGRAVITY_MODELS_2026.filter((m) => m.group === "gemini-cli").map((m) => m.id) as readonly string[];

export function isGeminiCLIOnlyModel(modelId: string): boolean {
  const lower = modelId.toLowerCase();
  return lower.includes("preview") || lower.includes("customtools") || GEMINI_CLI_ONLY_MODELS.includes(modelId as any) || lower.startsWith("gemini-3");
}

export function isGemini36Model(modelId: string): boolean { return modelId.toLowerCase().includes("gemini-3.6"); }
export function isGemini35Model(modelId: string): boolean { return modelId.toLowerCase().includes("gemini-3.5"); }
export function isGemini31Model(modelId: string): boolean { return modelId.toLowerCase().includes("gemini-3.1"); }
export function isClaude46Model(modelId: string): boolean { const l = modelId.toLowerCase(); return l.includes("claude") && (l.includes("4-6") || l.includes("4.6")); }
export function isClaude45Model(modelId: string): boolean { const l = modelId.toLowerCase(); return l.includes("claude") && (l.includes("4-5") || l.includes("4.5")); }
export function isGptOssModel(modelId: string): boolean { return modelId.toLowerCase().includes("gpt-oss"); }
export function isPreviewModel(modelId: string): boolean { return modelId.toLowerCase().includes("preview") || modelId.toLowerCase().includes("customtools"); }
export function isThinkingModel(modelId: string): boolean { return modelId.toLowerCase().includes("thinking") || modelId.toLowerCase().includes("high") || modelId.toLowerCase().includes("deep-think"); }
export function normalizeModelId(modelId: string): string { return modelId.trim().toLowerCase().replace(/^antigravity-/, ""); }

export const MODEL_ALIASES_2026: Record<string, string> = {
  "gemini-3-pro": "antigravity-gemini-3-pro",
  "gemini-3-flash": "antigravity-gemini-3-flash",
  "gemini-3.1-pro": "antigravity-gemini-3.1-pro",
  "claude-opus-4-6": "claude-opus-4-6-thinking",
  "claude-sonnet-4-6": "antigravity-claude-sonnet-4-6",
  "claude-opus-4-5": "claude-opus-4-5-thinking",
  "gemini-3.6-flash-high": "antigravity-gemini-3.6-flash-high",
  "gemini-3.5-flash-high": "antigravity-gemini-3.5-flash-high",
  "gemini-3.1-pro-high": "antigravity-gemini-3.1-pro-high",
} as const;

// Search / Default
export const SEARCH_MODEL = "gemini-3-flash" as const;
export const SEARCH_MODEL_PREVIEW = "gemini-3-flash-preview" as const;
export const SEARCH_MODEL_FALLBACKS = ["gemini-3.6-flash", "gemini-3-flash-preview", "gemini-3-flash", "antigravity-gemini-3-flash"] as const;

export const DEFAULT_MODEL = "antigravity-gemini-3-flash" as const;
export const DEFAULT_MODEL_FALLBACK = "gemini-3-flash-preview" as const;
export const DEFAULT_MODEL_2026_08 = "antigravity-gemini-3.6-flash" as const;

// OAuth
export const OAUTH_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth" as const;
export const OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token" as const;
export const OAUTH_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo" as const;
export const OAUTH_REVOKE_URL = "https://oauth2.googleapis.com/revoke" as const;

export const OAUTH_SCOPES = [
  "openid",
  "email",
  "profile",
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "https://www.googleapis.com/auth/cclog",
  "https://www.googleapis.com/auth/experimentsandconfigs",
] as const;

export const OAUTH_SCOPES_STRING = OAUTH_SCOPES.join(" ") as const;

export const PKCE_VERIFIER_LENGTH = 128 as const;
export const PKCE_CODE_CHALLENGE_METHOD = "S256" as const;

export const OAUTH_CALLBACK_HOST = "127.0.0.1" as const;
export const OAUTH_CALLBACK_PATH = "/callback" as const;
export const OAUTH_STATE_LENGTH = 32 as const;
export const OAUTH_PORT_RANGE = { min: 10000, max: 60000 } as const;

// Timeouts, jitter, backoff
export const DEFAULT_TIMEOUT_MS = 10_000 as const;
export const CONTENT_TIMEOUT_MS = 60_000 as const;
export const PROJECT_RESOLVE_TIMEOUT_MS = 10_000 as const;
export const QUOTA_TIMEOUT_MS = 15_000 as const;
export const TOKEN_REFRESH_TIMEOUT_MS = 10_000 as const;
export const ONBOARD_TIMEOUT_MS = 15_000 as const;

export const JITTER_MIN_MS = 0 as const;
export const JITTER_MAX_MS = 80 as const;

export function getJitter(): number {
  try { return randomInt(JITTER_MIN_MS, JITTER_MAX_MS + 1); }
  catch { return Math.floor(Math.random() * (JITTER_MAX_MS - JITTER_MIN_MS + 1)) + JITTER_MIN_MS; }
}

export const BACKOFF_BASE_MS = 250 as const;
export const BACKOFF_MAX_MS = 10_000 as const;
export const BACKOFF_FACTOR = 2 as const;
export const MAX_RETRIES = 3 as const;
export const RETRYABLE_STATUS_CODES = [403, 404, 408, 429, 500, 502, 503, 504] as const;
export const RETRYABLE_ERROR_CODES = ["403", "404", "5xx"] as const;

export const QUOTA_CACHE_TTL_MS = 15 * 60 * 1000 as const;
export const QUOTA_CACHE_TTL_MIN_MS = 2 * 60 * 1000 as const;
export const QUOTA_CACHE_TTL_MAX_MS = 10 * 60 * 1000 as const;
export const QUOTA_SOFT_THRESHOLD = 0.9 as const;
export const QUOTA_HARD_THRESHOLD = 1.0 as const;

export const ACCOUNTS_FILE_NAME = "antigravity-accounts.json" as const;
export const ACCOUNTS_CONFIG_DIR = ".config/opencode" as const;
export const ACCOUNTS_FILE_MODE = 0o600 as const;

export const THINKING_LEVELS = ["minimal", "low", "medium", "high"] as const;
export type ThinkingLevel = (typeof THINKING_LEVELS)[number];
export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = { minimal: 1024, low: 8192, medium: 16384, high: 32768 } as const;
export const THINKING_BUDGET_MAX_CLAUDE = 64_000 as const;
export const THINKING_BUDGET_MAX_GEMINI = 32_768 as const;
export const LRU_THINKING_CACHE_SIZE = 100 as const;

export const DEBUG_LOG_MAX_BYTES = 10 * 1024 * 1024 as const;
export const DEBUG_LOG_RETENTION_DAYS = 7 as const;
export const DEBUG_BUFFER_TUI_LINES = 1000 as const;

export const MODALITIES_INPUT = ["text", "image", "pdf"] as const;
export const GOOGLE_SEARCH_TOOL_NAME = "google_search" as const;
export const URL_CONTEXT_TOOL_NAME = "url_context" as const;

export const CONTEXT_WINDOW_ANTIGRAVITY = 1_048_576 as const;
export const OUTPUT_LIMIT_ANTIGRAVITY = 65_535 as const;
export const CONTEXT_WINDOW_CLAUDE = 200_000 as const;
export const OUTPUT_LIMIT_CLAUDE = 64_000 as const;
export const CONTEXT_WINDOW_GPT_OSS = 131_072 as const;
export const OUTPUT_LIMIT_GPT_OSS = 32_768 as const;

export const FNV_OFFSET_BASIS = 2_166_136_261 as const;
export const FNV_PRIME = 16_777_619 as const;

export const CONSTANTS = {
  versionFallback: ANTIGRAVITY_VERSION_FALLBACK,
  versionMinSupported: ANTIGRAVITY_VERSION_MIN_SUPPORTED,
  userAgentFallback: ANTIGRAVITY_USER_AGENT_FALLBACK,
  clientId: ANTIGRAVITY_CLIENT_ID,
  clientSecret: ANTIGRAVITY_CLIENT_SECRET,
  endpoints: ANTIGRAVITY_ENDPOINTS,
  endpointFallbacks: ANTIGRAVITY_ENDPOINT_FALLBACKS,
  codeAssistEndpoints: CODE_ASSIST_ENDPOINTS,
  endpointOrder: ENDPOINT_ORDER,
  geminiCliEndpoint: GEMINI_CLI_ENDPOINT,
  cloudaicompanion: CLOUDAI_COMPANION_ENDPOINT,
  quota: QUOTA_ENDPOINT,
  modelsEndpoint: MODELS_ENDPOINT,
  projectFallback: PROJECT_FALLBACK,
  projectResolution: PROJECT_RESOLUTION_STRATEGY,
  models: ANTIGRAVITY_MODELS_2026,
  models_2026_08_25: MODELS_2026_08_25,
  gemini36: GEMINI_36_MODELS,
  gemini35: GEMINI_35_MODELS,
  gemini31: GEMINI_31_MODELS,
  gemini3: GEMINI_3_MODELS,
  gemini25: GEMINI_25_MODELS,
  claude46: CLAUDE_46_MODELS,
  claude45: CLAUDE_45_MODELS,
  gptOss: GPT_OSS_MODELS,
  preview: PREVIEW_MODELS_2026_08,
  searchModel: SEARCH_MODEL,
  defaultModel: DEFAULT_MODEL,
  defaultModel2026: DEFAULT_MODEL_2026_08,
  scopes: OAUTH_SCOPES,
} as const;
