/**
 * @file auth.ts V3 — 20 auth logics correlated, gemini-3.7-flash GA Aug 13 2026, bypass like Gemini CLI, node:* first, professional optimized.
 */
import { createHash, randomBytes, randomInt } from "node:crypto";
import { createServer } from "node:http";
import { homedir, platform, arch, release } from "node:os";
import { join } from "node:path";
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync, renameSync, unlinkSync } from "node:fs";
import { exec } from "node:child_process";
export function generateVerifier(): string { const charset="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"; let v=""; const b=randomBytes(96); for(let i=0;i<128;i++) v+=charset[b[i % b.length] % charset.length]; return v; }
export function generateChallenge(v: string): string { return createHash("sha256").update(v).digest().toString("base64url"); }
export function generateState(): string { return randomBytes(32).toString("base64url"); }
export type CallbackResult={code:string; state:string};
export function createCallbackServer(timeoutMs=300000): Promise<{port:number; wait:Promise<CallbackResult>; close:()=>void}>{
  return new Promise((resolve,reject)=>{
    let resolveWait!: (v:CallbackResult)=>void; let rejectWait!: (e:Error)=>void;
    const wait=new Promise<CallbackResult>((res,rej)=>{ resolveWait=res; rejectWait=rej; });
    const server=createServer((req,res)=>{
      const url=new URL(req.url||"", "http://127.0.0.1");
      if(url.pathname==="/callback"){
        const code=url.searchParams.get("code"); const state=url.searchParams.get("state"); const err=url.searchParams.get("error");
        if(err){ res.writeHead(400,{"Content-Type":"text/html"}); res.end(`<h1>${err}</h1>`); rejectWait(new Error(err)); return; }
        if(code){ res.writeHead(200,{"Content-Type":"text/html"}); res.end("<h1>Auth success close</h1><script>window.close()</script>"); resolveWait({code, state: state||""}); }
        else { res.writeHead(400); res.end("missing code"); }
      } else { res.writeHead(404); res.end(); }
    });
    server.listen(0,"127.0.0.1",()=>{
      const addr=server.address() as any; const port=addr.port;
      const to=setTimeout(()=>{ try{server.close();}catch{}; rejectWait(new Error("timeout")); }, timeoutMs);
      (to as any).unref?.();
      resolve({port, wait, close:()=>{ clearTimeout(to); try{server.close();}catch{}}});
    });
    server.on("error",reject); server.unref();
  });
}
export function openBrowser(url: string){ const plat=platform(); const cmd=plat==="darwin"? `open "${url}"`: plat==="win32"? `start "" "${url}"`: `xdg-open "${url}"`; exec(cmd,()=>{}); console.log(`\nOpen manually:\n${url}\n`); }
const CLIENT_ID=process.env.ANTIGRAVITY_CLIENT_ID?.trim()||"1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com";
const CLIENT_SECRET=process.env.ANTIGRAVITY_CLIENT_SECRET?.trim()||"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";
const OAUTH_AUTH="https://accounts.google.com/o/oauth2/v2/auth";
const OAUTH_TOKEN="https://oauth2.googleapis.com/token";
const OAUTH_USERINFO="https://www.googleapis.com/oauth2/v2/userinfo";
const SCOPES=["openid","email","profile","https://www.googleapis.com/auth/cloud-platform","https://www.googleapis.com/auth/userinfo.email","https://www.googleapis.com/auth/userinfo.profile","https://www.googleapis.com/auth/cclog","https://www.googleapis.com/auth/experimentsandconfigs"].join(" ");
export type TokenResponse={access_token:string; refresh_token?:string; expires_in?:number; id_token?:string; token_type?:string; scope?:string; email?:string};
export function getUA(ver="1.19.2"): string { const p=platform()==="win32"?"win32":platform(); const a=arch()==="arm64"?"arm64":arch(); return `antigravity/${ver} ${p}/${a}`; }
async function fetchTimeout(url: string, init: RequestInit, ms=10000): Promise<Response>{ const ctrl=new AbortController(); const to=setTimeout(()=>ctrl.abort(), ms); try{ return await fetch(url,{...init, signal: ctrl.signal}); } finally{ clearTimeout(to);} }
export async function exchangeCode(code: string, verifier: string, redirectUri: string): Promise<TokenResponse>{ const body=new URLSearchParams({code, client_id: CLIENT_ID, client_secret: CLIENT_SECRET, redirect_uri: redirectUri, grant_type:"authorization_code", code_verifier: verifier}); const res=await fetchTimeout(OAUTH_TOKEN,{method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent": getUA()}, body: body.toString()}); if(!res.ok) throw new Error(`exchange ${res.status} ${await res.text()}`); return await res.json() as TokenResponse; }
export async function refreshAccessToken(rt: string): Promise<TokenResponse>{ const body=new URLSearchParams({client_id: CLIENT_ID, client_secret: CLIENT_SECRET, refresh_token: rt, grant_type:"refresh_token"}); const res=await fetchTimeout(OAUTH_TOKEN,{method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent": getUA()}, body: body.toString()}); if(!res.ok) throw new Error(`refresh ${res.status} ${await res.text()}`); return await res.json() as TokenResponse; }
export async function fetchUserInfo(at: string): Promise<{email:string; name?:string}>{ const res=await fetchTimeout(OAUTH_USERINFO,{headers:{Authorization:`Bearer ${at}`, "User-Agent": getUA()}}); if(!res.ok) throw new Error(`userinfo ${res.status}`); const j:any=await res.json(); return {email:j.email, name:j.name}; }
export function resolveConfigDir(): string { return process.env.OPENCODE_CONFIG_DIR?.trim()||join(homedir(),".config","opencode"); }
export function resolveAccountsPath(): string { return join(resolveConfigDir(),"antigravity-accounts.json"); }
export function atomicWrite(path: string, content: string){ try{ mkdirSync(resolveConfigDir(),{recursive:true, mode:0o700}); }catch{} const tmp=`${path}.tmp-${process.pid}-${randomInt(1000000)}`; writeFileSync(tmp, content,{encoding:"utf8", mode:0o600}); try{ chmodSync(tmp,0o600);}catch{} try{ renameSync(tmp, path);}catch{ writeFileSync(path, content,{encoding:"utf8", mode:0o600}); try{ unlinkSync(tmp);}catch{} } try{ chmodSync(path,0o600);}catch{} }
export type Account={email:string; refreshToken:string; accessToken?:string; expiry?:number; projectId?:string; disabled?:boolean; quotaExhaustedUntil?:number;};
export class AccountManager{
  private accounts: Account[]=[]; private locks=new Map<string,Promise<Account>>(); private rotationIdx=0; private stickyEmail:string|null=null;
  async load(){ try{ const p=resolveAccountsPath(); if(!existsSync(p)){ this.accounts=[]; return;} const raw=readFileSync(p,"utf8"); const j=JSON.parse(raw); if(Array.isArray(j)) this.accounts=j.map((a:any)=>({email:a.email, refreshToken:a.refresh_token||a.refreshToken, accessToken:a.access_token||a.accessToken, expiry:a.expiry, projectId:a.projectId, disabled:a.disabled})); else if(j.accounts&&Array.isArray(j.accounts)) this.accounts=j.accounts; else if(j.version===3&&j.accounts) this.accounts=Object.values(j.accounts) as any; else this.accounts=[]; }catch{ this.accounts=[]; } }
  async save(){ atomicWrite(resolveAccountsPath(), JSON.stringify(this.accounts,null,2)); }
  list(): Account[]{ return this.accounts; }
  async add(a: Account){ this.accounts=this.accounts.filter(x=>x.email!==a.email); this.accounts.push(a); await this.save(); }
  async remove(email: string){ this.accounts=this.accounts.filter(x=>x.email!==email); await this.save(); }
  getNext(strategy: "round-robin"|"sticky"="round-robin"): Account|null{ const active=this.accounts.filter(a=>!a.disabled&&(!a.quotaExhaustedUntil||Date.now()>a.quotaExhaustedUntil)); if(active.length===0) return null; if(strategy==="sticky"&&this.stickyEmail){ const f=active.find(a=>a.email===this.stickyEmail); if(f) return f;} const acc=active[this.rotationIdx % active.length]; this.rotationIdx=(this.rotationIdx+1)%active.length; this.stickyEmail=acc.email; return acc; }
  markExhausted(email: string, ms=3600000){ const a=this.accounts.find(x=>x.email===email); if(a){ a.quotaExhaustedUntil=Date.now()+ms; this.save().catch(()=>{});} }
  async refreshIfNeeded(email: string): Promise<string>{ const acc=this.accounts.find(a=>a.email===email); if(!acc) throw new Error("not found"); if(acc.accessToken&&acc.expiry&&Date.now()<acc.expiry-300000) return acc.accessToken; if(this.locks.has(email)) return (await this.locks.get(email)!)!.accessToken!; const p=(async()=>{ const tokens=await refreshAccessToken(acc.refreshToken); acc.accessToken=tokens.access_token; acc.expiry=Date.now()+(tokens.expires_in??3600)*1000; await this.save(); return acc; })(); this.locks.set(email,p); try{ const r=await p; return r.accessToken!; } finally{ this.locks.delete(email);} }
  async importManager(): Promise<number>{ const candidates=[join(homedir(),".config","antigravity-manager","accounts.json"), join(homedir(),".antigravity-manager","accounts.json")]; let added=0; for(const c of candidates){ try{ if(!existsSync(c)) continue; const raw=readFileSync(c,"utf8"); const j=JSON.parse(raw); const arr=Array.isArray(j)?j: j.accounts||[]; for(const x of arr){ const email=x.email; const rt=x.refresh_token||x.refreshToken; if(email&&rt&&!this.accounts.find(a=>a.email===email)){ this.accounts.push({email, refreshToken:rt}); added++; } } }catch{} } if(added>0) await this.save(); return added; }
}
export const ENDPOINTS=["https://daily-cloudcode-pa.googleapis.com","https://autopush-cloudcode-pa.sandbox.googleapis.com","https://cloudcode-pa.googleapis.com"] as const;
export const PROJECT_FALLBACK="rising-fact-p41fc" as const;
function isRetryable(s: number){ return s===403||s===404||s===408||s===429||s>=500; }
export async function loadCodeAssist(at: string, endpoint=ENDPOINTS[0]): Promise<string|null>{
  for(const base of [endpoint, ...ENDPOINTS.filter(e=>e!==endpoint)]){
    try{
      const res=await fetchTimeout(`${base}/v1internal:loadCodeAssist`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": getUA()}, body: JSON.stringify({metadata:{ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!res.ok){ if(isRetryable(res.status)) continue; return null; }
      const j:any=await res.json(); const proj=j.cloudaicompanionProject||j.project||j.cloudaicompanionProjectId;
      if(!proj) continue;
      if(typeof proj==="string") return proj.includes("/")? proj.split("/").pop()! : proj;
      if(proj.id) return proj.id;
      if(proj.projectId) return proj.projectId;
      if(proj.name) return proj.name.split("/").pop();
    }catch{ continue; }
  }
  return null;
}
export async function onboardUser(at: string): Promise<boolean>{
  for(const base of ENDPOINTS){
    try{
      const res=await fetchTimeout(`${base}/v1internal:onboardUser`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": getUA()}, body: JSON.stringify({tierId:"FREE", metadata:{ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!res.ok) continue;
      const j:any=await res.json(); const op=j.name||j.operation?.name;
      if(!op) return true;
      let delay=500;
      for(let i=0;i<5;i++){ await new Promise(r=>setTimeout(r,delay)); const poll=await fetchTimeout(`${base}/v1internal:operations/${op.split("/").pop()}`,{headers:{Authorization:`Bearer ${at}`,"User-Agent": getUA()}}); if(poll.ok){ const pj:any=await poll.json(); if(pj.done) return true; } delay=Math.min(delay*2,8000); }
      return true;
    }catch{ continue; }
  }
  return false;
}
export async function resolveProjectId(at: string, cached?: string): Promise<string>{
  if(cached&&cached!==PROJECT_FALLBACK) return cached;
  const discovered=await loadCodeAssist(at);
  if(discovered) return discovered;
  const onboarded=await onboardUser(at);
  if(onboarded){ const after=await loadCodeAssist(at); if(after) return after; }
  console.warn(`[auth] fallback ${PROJECT_FALLBACK}`);
  return PROJECT_FALLBACK;
}
export async function retrieveQuota(at: string, projectId=PROJECT_FALLBACK): Promise<{remaining:number; limit:number; used:number}|null>{
  for(const base of ENDPOINTS){
    try{
      const res=await fetchTimeout(`${base}/v1internal:retrieveUserQuotaSummary`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": getUA()}, body: JSON.stringify({project:`projects/${projectId}`})},15000);
      if(!res.ok){ if(isRetryable(res.status)) continue; return null; }
      const j:any=await res.json();
      return {remaining: Number(j.remainingQuota??j.remaining??100), limit: Number(j.limit??1000), used: Number(j.used??0)};
    }catch{ continue; }
  }
  return null;
}
export function mapModelToGroup(model: string): "antigravity"|"gemini-cli"{ const m=model.toLowerCase(); if(m.includes("preview")||m.startsWith("gemini-3.7")||m.startsWith("gemini-3.6")||m.startsWith("gemini-3.5")||m.startsWith("gemini-3.1")||m.startsWith("gemini-3")) return "gemini-cli"; return "antigravity"; }
export async function startOAuthFlow(): Promise<TokenResponse & {email?: string}>{
  const verifier=generateVerifier(); const challenge=generateChallenge(verifier); const state=generateState();
  const {port, wait, close}=await createCallbackServer();
  const redirect=`http://127.0.0.1:${port}/callback`;
  const authUrl=`${OAUTH_AUTH}?client_id=${encodeURIComponent(CLIENT_ID)}&redirect_uri=${encodeURIComponent(redirect)}&response_type=code&scope=${encodeURIComponent(SCOPES)}&code_challenge=${encodeURIComponent(challenge)}&code_challenge_method=S256&state=${encodeURIComponent(state)}&access_type=offline&prompt=consent`;
  openBrowser(authUrl);
  const {code}=await wait; close();
  const tokens=await exchangeCode(code, verifier, redirect);
  let email: string|undefined;
  try{ const info=await fetchUserInfo(tokens.access_token); email=info.email; }catch{}
  return {...tokens, email};
}
