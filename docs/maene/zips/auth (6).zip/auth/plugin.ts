/**
 * @file plugin.ts V3 — 20 plugin logics, gemini-3.7-flash GA Aug 13 2026, deps updated ^1.18.11, bypass like Gemini CLI.
 */
import { AccountManager, resolveProjectId, startOAuthFlow } from "./auth.js";
import { buildAntigravity, buildGeminiCLI, fetchCascade, isCLIOnly, normalizePayloads, parseSSEChunk, transformToOpenAI, transformToAnthropic, withAutoRecovery } from "./core.js";
import { MODELS_2026_08_25, DEFAULT_MODEL } from "./models.js";
export const PLUGIN_ID="opencode-antigravity-auth-next" as const;
export const VERSION="3.0.0" as const;
type Options={ cli_first?: boolean; pid_offset_enabled?: boolean; google_search_enabled?: boolean; quota_refresh_interval_minutes?: number; rotation_strategy?: "round-robin"|"sticky"; };
class AntigravityPlugin{
  private accounts=new AccountManager(); private opts: Options; private initDone=false;
  constructor(opts: Options={}){ this.opts=opts; }
  async init(){ if(this.initDone) return; await this.accounts.load().catch(()=>{}); this.initDone=true; }
  private shouldHandle(m: string){ const l=m.toLowerCase(); return l.includes("antigravity")||l.includes("gemini")||l.includes("claude")||l.includes("gpt-oss"); }
  private async getAccount(model: string){ for(let i=0;i<10;i++){ const acc=this.accounts.getNext(this.opts.rotation_strategy||"round-robin"); if(!acc) break; if(acc.quotaExhaustedUntil&&Date.now()<acc.quotaExhaustedUntil) continue; return acc; } return this.accounts.getNext(); }
  async handleFetch(orig: typeof fetch, input: RequestInfo|URL, init?: RequestInit): Promise<Response>{
    await this.init();
    const urlStr=typeof input==="string"? input: input instanceof URL? input.toString(): (input as Request).url||"";
    const bodyStr=(init?.body as string)||"";
    let model: string|undefined;
    try{ if(bodyStr){ const j=JSON.parse(bodyStr); model=j.model||j.request?.model; } }catch{}
    const check=model||urlStr;
    if(!this.shouldHandle(check)) return orig(input, init);
    const effectiveModel=model||DEFAULT_MODEL;
    const account=await this.getAccount(effectiveModel);
    if(!account) return new Response(JSON.stringify({error:"no account, run opencode auth login"}),{status:401, headers:{"Content-Type":"application/json"}});
    let accessToken: string;
    try{ accessToken=await this.accounts.refreshIfNeeded(account.email); }catch(e:any){ return new Response(JSON.stringify({error:`refresh failed ${e.message}`}),{status:401}); }
    let projectId=account.projectId||"rising-fact-p41fc";
    try{ projectId=await resolveProjectId(accessToken, account.projectId); account.projectId=projectId; await this.accounts.save().catch(()=>{}); }catch{}
    let messages:any[]=[]; let tools:any[]=[]; let system: string|undefined;
    try{ if(bodyStr){ const j=JSON.parse(bodyStr); messages=j.messages||j.request?.contents||[]; tools=j.tools||j.request?.tools||[]; system=j.system||j.systemInstruction; } }catch{}
    const isCLI=isCLIOnly(effectiveModel)||!!this.opts.cli_first;
    let build:any;
    try{
      const core = await import("./core.js");
      build = isCLI? core.buildGeminiCLI({ model: effectiveModel, messages, tools, system, googleSearch: this.opts.google_search_enabled??true, projectId, sessionSeed: `${account.email}`, userPromptSeed: effectiveModel, accessToken } as any) : core.buildAntigravity({ model: effectiveModel, messages, tools, system, googleSearch: this.opts.google_search_enabled??true, projectId, sessionSeed: `${account.email}`, userPromptSeed: effectiveModel, accessToken } as any);
    }catch(e:any){ return new Response(JSON.stringify({error:`transform failed ${e.message}`}),{status:400}); }
    const exec=async()=>{
      const res=await fetchCascade(build, 60000);
      if(!res.ok){ const txt=await res.text().catch(()=> ""); if(res.status===429||txt.toLowerCase().includes("quota")){ this.accounts.markExhausted(account.email); } if(res.status>=400) throw new Error(`${res.status} ${txt.slice(0,500)}`); }
      const isAnthropic=effectiveModel.toLowerCase().includes("claude");
      const stream=new ReadableStream({
        async start(controller){
          const reader=res.body?.getReader(); if(!reader){ controller.close(); return; }
          const decoder=new TextDecoder(); let leftover="";
          while(true){
            const {done, value}=await reader.read(); if(done) break;
            const text=decoder.decode(value,{stream:true});
            const events=parseSSEChunk(leftover+text); leftover="";
            for(const ev of events){
              const payloads=normalizePayloads(ev.data);
              for(const p of payloads){
                const out=isAnthropic? transformToAnthropic(p): transformToOpenAI(p);
                controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(out)}\n\n`));
              }
            }
          }
          controller.enqueue(new TextEncoder().encode(`data: [DONE]\n\n`)); controller.close();
        }
      });
      return new Response(stream,{status: res.status, headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}});
    };
    try{ return await withAutoRecovery(async()=>await exec(),3); }catch(e:any){ return new Response(JSON.stringify({error:`failed after retries ${e.message}`}),{status:500}); }
  }
  getDefinition(){
    const self=this;
    return {
      id: PLUGIN_ID, version: VERSION, name:"Antigravity Auth Next V3 — Gemini 3.7 Flash",
      description:"Enable Opencode to auth Antigravity via OAuth — direct cloudcode-pa no localhost v1, bypass project ID like Gemini CLI, models 25/08/2026 including gemini-3.7-flash GA Aug 13 2026, dual quota, auto-recovery",
      async onInit(){ await self.init(); },
      hooks:{ "fetch": async(input: RequestInfo|URL, init?: RequestInit, next: typeof fetch)=> self.handleFetch(next, input, init) },
      auth:{ provider:"google", async login(){ const r=await startOAuthFlow(); const email=r.email||`user-${Date.now()}@gmail.com`; await self.accounts.add({email, refreshToken: r.refresh_token!, accessToken: r.access_token, expiry: Date.now()+3600*1000}); return {email}; }, async list(){ await self.init(); return self.accounts.list(); }, async logout(email?: string){ if(email) await self.accounts.remove(email); else{ for(const a of self.accounts.list()) await self.accounts.remove(a.email);} } },
      config:{ schema:{ cli_first:{type:"boolean", default:false}, pid_offset_enabled:{type:"boolean", default:false}, google_search_enabled:{type:"boolean", default:true}, quota_refresh_interval_minutes:{type:"number", default:15}, rotation_strategy:{type:"string", enum:["round-robin","sticky"], default:"round-robin"} }, defaults:{ cli_first:false, pid_offset_enabled:false, google_search_enabled:true, quota_refresh_interval_minutes:15, rotation_strategy:"round-robin"} },
      models: MODELS_2026_08_25.map(m=>({ id: m.id, name: m.name, provider:"google", context: m.context, output: m.output, modalities: m.modalities })),
    };
  }
}
let instance: AntigravityPlugin|null=null;
export function getPlugin(opts?: Options){ if(!instance) instance=new AntigravityPlugin(opts); return instance; }
export const plugin=getPlugin().getDefinition();
export default plugin;
