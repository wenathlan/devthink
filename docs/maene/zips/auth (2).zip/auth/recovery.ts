/**
 * @file recovery.ts v5 auto-recovery session recovery context error.
 */
import { jitter } from "./core.js";
export type errorType="invalid_thinking_signature"|"tool_use_without_thinking"|"tool_result_missing"|"thinking_block_order"|"thinking_disabled_violation"|"prompt_too_long"|"tool_pairing"|"unknown";
export const detectError = (msg: string): errorType=>{ const l=msg.toLowerCase(); if(l.includes("thinking")&&l.includes("signature")) return "invalid_thinking_signature"; if(l.includes("tool_use")&&l.includes("thinking")) return "tool_use_without_thinking"; if(l.includes("tool_result")&&l.includes("missing")) return "tool_result_missing"; if(l.includes("thinking_block")&&l.includes("order")) return "thinking_block_order"; if(l.includes("thinking_disabled")||l.includes("thinking_violation")) return "thinking_disabled_violation"; if(l.includes("prompt_too_long")||l.includes("too many tokens")) return "prompt_too_long"; if(l.includes("tool_pairing")||l.includes("function_call")&&l.includes("not paired")) return "tool_pairing"; return "unknown"; };
export const isRecoverable = (t: errorType): boolean => ["tool_result_missing","thinking_block_order","thinking_disabled_violation","invalid_thinking_signature","tool_use_without_thinking"].includes(t);
export const withAutoRecovery = async <T>(fn: (attempt:number)=>Promise<T>, maxRetries=3): Promise<T>=>{ let last:any; for(let i=0;i<=maxRetries;i++){ try{ return await fn(i); }catch(e:any){ last=e; const d=Math.min(250*Math.pow(2,i)+jitter(),10000); await new Promise(r=>setTimeout(r,d)); } } throw last; };
export const sessionRecovery = (error: errorType, messages: any[]): any[]=>{ if(error==="tool_result_missing") return messages; if(error==="thinking_block_order") return messages.map((m:any)=> m.thinking&&m.text? {...m, parts:[{thought:true, text: m.thinking}, {text: m.text}]}: m); return messages; };
export const toast = (msg: string): void => { console.log(`[toast] ${msg}`); };
