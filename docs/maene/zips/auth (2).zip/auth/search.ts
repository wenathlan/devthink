/**
 * @file search.ts v5 google search grounding urlContext image generation.
 */
export const shouldEnableSearch = (model: string, cfg: any): boolean => { if(cfg?.google_search_enabled===true) return true; if(cfg?.google_search_enabled==="auto"){ const l=model.toLowerCase(); return l.includes("gemini")&&!l.includes("image"); } return false; };
export const buildSearchTools = (): any[] => [{ googleSearch:{} }, { urlContext:{} }];
export const parseGrounding = (meta: any): {uri: string; title?: string}[]=>{ const chunks=meta?.groundingChunks||meta?.grounding_chunks||[]; return chunks.map((c:any)=>c.web? {uri: c.web.uri, title: c.web.title}: null).filter(Boolean); };
export const isImageGenModel = (m: string): boolean => m.toLowerCase().includes("image")||m.includes("3.1-flash-image");
export const buildImageGenConfig = (aspect?: string): any => { const ar=aspect||process.env.OPENCODE_IMAGE_ASPECT_RATIO||"1:1"; return { imageConfig:{ aspectRatio: ar }, generationConfig:{ responseModalities:["TEXT","IMAGE"] }, safetySettings:[{category:"HARM_CATEGORY_HARASSMENT", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_HATE_SPEECH", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_DANGEROUS_CONTENT", threshold:"BLOCK_NONE"}] }; };
