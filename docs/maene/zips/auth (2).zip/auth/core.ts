/**
 * @file core.ts v5 definitive full researches 9router omniroute gemini-cli.
 * 20 logics correlated, lowercase.
 */
import { randomInt } from "node:crypto";
import { platform, arch, release } from "node:os";
export const fnv1a32 = (s: string): number => { let h=0x811c9dc5; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,0x01000193)>>>0; } return h>>>0; };
export const genId = (seed: string, p="id"): string => `${p}_${fnv1a32(seed).toString(16).padStart(8,"0")}${Date.now().toString(16).slice(-6)}`;
export const sessId = (s: string): string => genId(s, "sess");
export const upId = (s: string): string => genId(s, "up");
export const jitter = (): number => { try{ return randomInt(0,81); }catch{ return Math.floor(Math.random()*81); } };
export const ua = (v="1.19.2"): string => { const pl=platform()==="win32"?"win32":platform(); const a=arch()==="arm64"?"arm64":arch(); return `antigravity/${v} ${pl}/${a}`; };
export const apiClient = (v="1.19.2"): string => `antigravity/${v} gl-node/${process.versions.node} gccl/1.0.0 gax/1.0.0`;
export const fingerprint = (style: "antigravity"|"gemini-cli", v="1.19.2"): Record<string,string> => {
  const u=ua(v);
  // research: antigravity-manager only sends User-Agent on content requests, no X-Goog-QuotaUser, no X-Client-Device-Id, no Client-Metadata for content
  // but we keep minimal for bypass: only User-Agent and Content-Type, per fix align fingerprint headers to match AM behavior
  const h: Record<string,string> = { "User-Agent": u, "Content-Type":"application/json", "Accept":"application/json" };
  if(style==="gemini-cli") h["X-Goog-Api-Client"]=apiClient(v);
  // Client-Metadata only for some calls, not all - research shows AM only sends User-Agent on content
  return h;
};
export const FORBIDDEN=["x-goog-user-project","x-goog-quota-user","x-client-device-id","x-goog-request-reason"];
export const stripForbidden = (h: Record<string,string>): Record<string,string> => { const o: Record<string,string>={}; for(const [k,v] of Object.entries(h)){ if(!FORBIDDEN.includes(k.toLowerCase())) o[k]=v; } return o; };
export const isCLIOnly = (m: string): boolean => { const l=m.toLowerCase(); return l.includes("preview")||l.startsWith("gemini-3.7")||l.startsWith("gemini-3.6")||l.startsWith("gemini-3.5")||l.startsWith("gemini-3.1")||l.startsWith("gemini-3")||l.includes("customtools"); };
export const ENDPOINTS={ PROD:"https://cloudcode-pa.googleapis.com", DAILY:"https://daily-cloudcode-pa.googleapis.com", SANDBOX:"https://daily-cloudcode-pa.sandbox.googleapis.com" } as const;
export const endpointsForModel = (model: string): string[] => isCLIOnly(model)? [ENDPOINTS.PROD, ENDPOINTS.DAILY] : [ENDPOINTS.PROD, ENDPOINTS.DAILY, ENDPOINTS.SANDBOX];
export const ALLOWED=new Set(["type","properties","required","description","enum","items","anyOf","oneOf","format","minimum","maximum"]);
export const cleanSchema = (s: any, d=0): any => {
  if(d>12||!s||typeof s!=="object") return s;
  if(Array.isArray(s)) return s.map((x:any)=>cleanSchema(x,d+1));
  const out:any={};
  for(const [k,v] of Object.entries(s)){
    if(!ALLOWED.has(k)){
      if(k==="additionalProperties"||k==="default"||k==="$schema"){ out.description=(out.description||"")+` [${k}:${JSON.stringify(v).slice(0,100)}]`; continue; }
      continue;
    }
    out[k]= (k==="properties"||k==="items")? cleanSchema(v,d+1): v;
  }
  if(out.type) out.type=String(out.type).toUpperCase();
  return out.type? out: {type:"OBJECT"};
};
export const TOOL_REGEX=/^[a-zA-Z][a-zA-Z0-9_]{0,63}$/;
export const sanitizeToolName = (raw: string): string => { let n=String(raw||"").trim().replace(/[^a-zA-Z0-9_]/g,"_").replace(/__+/g,"_"); if(!n) return `tool_${fnv1a32(raw).toString(16)}`; if(/^[0-9]/.test(n)) n=`tool_${n}`; if(n.length>64) n=n.slice(0,64); if(!TOOL_REGEX.test(n)) n=`tool_${fnv1a32(n).toString(16)}`; return n; };
export const normalizeRole = (r: string): "user"|"model"|"system" => { const l=(r||"user").toLowerCase(); if(l==="assistant"||l==="model") return "model"; if(l==="system") return "system"; return "user"; };
export const BUDGET_MAP: Record<string,number>={ minimal:1024, low:8192, medium:16384, high:32768, max:64000, tiered:16384 };
export const mapBudget = (l: string): number => BUDGET_MAP[l.toLowerCase()]??8192;
export const parseVariant = (model: string): { base: string; thinking?: string; isPreview: boolean } => { const low=model.toLowerCase(); const isPreview=low.includes("preview"); const m=low.match(/(minimal|low|medium|high|max|tiered)/); return { base: model.replace(/-(low|high|medium|minimal|max|tiered)$/i,""), thinking: m?.[1], isPreview }; };
export const resolveModelId = (model: string): { id: string; group: "antigravity"|"gemini-cli"; isImage: boolean; } => {
  const l=model.toLowerCase();
  const isImage=l.includes("image");
  const group=l.startsWith("antigravity-")? "antigravity": l.includes("preview")||l.startsWith("gemini-3")? "gemini-cli": l.includes("claude")||l.includes("gpt-oss")? "antigravity": "antigravity";
  const id=l.replace(/^antigravity-/, "").replace(/^google\//, "");
  return { id, group, isImage };
};
export const isImageModel = (m: string): boolean => m.toLowerCase().includes("image")||m.includes("3.1-flash-image");
export const buildImageConfig = (aspect?: string): any => {
  const ar=aspect||process.env.OPENCODE_IMAGE_ASPECT_RATIO||"1:1";
  return { imageConfig:{ aspectRatio: ar }, safetySettings:[{category:"HARM_CATEGORY_HARASSMENT", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_HATE_SPEECH", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold:"BLOCK_NONE"},{category:"HARM_CATEGORY_DANGEROUS_CONTENT", threshold:"BLOCK_NONE"}] };
};
export type transformInput={ model: string; messages: any[]; tools?: any[]; system?: string; thinkingLevel?: string; googleSearch?: boolean; projectId?: string; sessionSeed?: string; userPromptSeed?: string; claudeToolHardening?: boolean; keepThinking?: boolean; };
export const transformRequest = (inp: transformInput)=>{
  const sys = inp.system ? [{ role:"system", content: inp.system }] : [];
  const contents = [...sys, ...(inp.messages||[]).map((m:any)=>({ role: normalizeRole(m.role||"user"), parts: Array.isArray(m.content)? m.content : [{ text: typeof m.content==="string"? m.content: JSON.stringify(m.content) }] }))];
  let tools:any[]=[];
  if(isImageModel(inp.model)){ tools=[]; }
  else if(inp.tools&&inp.tools.length>0){
    tools = inp.tools.map((t:any)=>{
      const fn=t.function||t; const name=sanitizeToolName(fn.name||t.name||"tool");
      const schema=cleanSchema(fn.parameters||fn.input_schema||t.parameters||{type:"object"});
      if(inp.claudeToolHardening&&inp.model.toLowerCase().includes("claude")){
        return { functionDeclarations:[{ name, description: `[hardening] ${fn.description||""}`, parameters: schema }]};
      }
      return { functionDeclarations:[{ name, description: fn.description||"", parameters: schema }]};
    }).slice(0,128);
  }
  if(inp.googleSearch){ tools.push({ googleSearch:{} }); tools.push({ urlContext:{} }); }
  const budget = inp.thinkingLevel? mapBudget(inp.thinkingLevel): undefined;
  const base:any={ model: inp.model, contents, tools, generationConfig:{ thinkingConfig: budget? { thinkingBudget: budget }: undefined } };
  if(isImageModel(inp.model)){ Object.assign(base, buildImageConfig()); base.generationConfig.responseModalities=["TEXT","IMAGE"]; }
  if(inp.keepThinking){ base.generationConfig.thinkingConfig.keepThinking=true; }
  return { ...base, sessionId: sessId(inp.sessionSeed||inp.model+Date.now()), userPromptId: upId(inp.userPromptSeed||inp.model) };
};
export const buildAntigravity = (inp: transformInput & { accessToken: string })=>{
  const inner=transformRequest(inp);
  const project=inp.projectId||"rising-fact-p41fc";
  const body={ project:`projects/${project}`, model: inp.model, request:{ model: inp.model, contents: inner.contents, tools: inner.tools, systemInstruction: inner.contents.find((c:any)=>c.role==="system")? { parts: [{text: inp.system||""}] }: undefined, generationConfig: inner.generationConfig }, sessionId: inner.sessionId, userPromptId: inner.userPromptId };
  const bases=endpointsForModel(inp.model);
  const endpoints=bases.map(b=>`${b}/v1internal:streamGenerateContent?alt=sse`);
  const headers={ ...fingerprint("antigravity"), Authorization:`Bearer ${inp.accessToken}` };
  return { url: endpoints[0], endpoints, headers: stripForbidden(headers), body, sessionId: inner.sessionId, userPromptId: inner.userPromptId };
};
export const buildGeminiCLI = (inp: transformInput & { accessToken: string })=>{
  const inner=transformRequest(inp);
  const project=inp.projectId||"rising-fact-p41fc";
  const body={ project:`projects/${project}`, model: inp.model, request:{ model: inp.model, contents: inner.contents.filter((c:any)=>c.role!=="system"), tools: inner.tools, generationConfig: inner.generationConfig }, sessionId: inner.sessionId, userPromptId: inner.userPromptId };
  const bases=endpointsForModel(inp.model).filter(b=>!b.includes("sandbox"));
  const endpoints=bases.map(b=>`${b}/v1internal:streamGenerateContent?alt=sse`);
  const headers={ ...fingerprint("gemini-cli"), Authorization:`Bearer ${inp.accessToken}` };
  return { url: endpoints[0], endpoints, headers: stripForbidden(headers), body, sessionId: inner.sessionId, userPromptId: inner.userPromptId };
};
export const fetchCascade = async (build: any, timeoutMs=60000): Promise<Response>=>{
  let last:any=null;
  for(const ep of build.endpoints){
    try{
      const j=jitter(); if(j>0) await new Promise(r=>setTimeout(r,j));
      const c=new AbortController(); const t=setTimeout(()=>c.abort(), timeoutMs);
      const r=await fetch(ep,{ method:"POST", headers: build.headers, body: JSON.stringify(build.body), signal: c.signal });
      clearTimeout(t);
      if(r.status===403||r.status===404||r.status>=500){ last=new Error(`retry ${r.status}`); continue; }
      return r;
    }catch(e){ last=e; continue; }
  }
  throw last||new Error("all endpoints failed");
};
