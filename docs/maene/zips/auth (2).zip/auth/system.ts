/**
 * @file system.ts v5 debug logger singleton rotation 10mb cleanup 7d buffer 1000 redaction + config + version + validate.
 */
import { homedir } from "node:os";
import { join } from "node:path";
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync, readdirSync, statSync, unlinkSync, renameSync } from "node:fs";
import { randomInt } from "node:crypto";
export const cfgDir = (): string => process.env.OPENCODE_CONFIG_DIR?.trim()||join(homedir(),".config","opencode");
export const logsDir = (): string => join(cfgDir(),"antigravity-logs");
export const redactSecrets = (s: string): string => s.replace(/Bearer\s+[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/g, "Bearer [REDACTED]").replace(/refresh_token[^\s]*/gi, "refresh_token=[REDACTED]");
export class debugLogger{
  private static inst: debugLogger|null=null;
  private buffer: string[]=[]; private maxBuf=1000;
  static get(): debugLogger{ if(!debugLogger.inst) debugLogger.inst=new debugLogger(); return debugLogger.inst!; }
  log(msg: string): void{ const line=`[${new Date().toISOString()}] ${redactSecrets(msg)}`; this.buffer.push(line); if(this.buffer.length>this.maxBuf) this.buffer.shift(); try{ mkdirSync(logsDir(),{recursive:true}); const p=join(logsDir(),`antigravity-${new Date().toISOString().slice(0,10)}.log`); writeFileSync(p, this.buffer.join("\n")+"\n",{flag:"a"}); const st=statSync(p); if(st.size>10*1024*1024){ const bak=`${p}.1`; try{ renameSync(p, bak);}catch{} } }catch{} }
  cleanup(): void{ try{ const files=readdirSync(logsDir()); const now=Date.now(); for(const f of files){ const fp=join(logsDir(),f); try{ const st=statSync(fp); if(now-st.mtimeMs>7*24*3600*1000) unlinkSync(fp); }catch{} } }catch{} }
}
export const VERSION_FALLBACK="1.19.2" as const;
export const fetchVersionChain = async (): Promise<string>=>{
  const urls=["https://autoupdater.antigravity.google.com/version", "https://registry.npmjs.org/antigravity/latest", "https://api.github.com/repos/antigravity/antigravity/releases/latest"];
  for(const u of urls){
    try{ const r=await fetch(u,{headers:{"User-Agent":"antigravity/1.19.2"}}); if(!r.ok) continue; const j:any=await r.json().catch(async()=>({text: await r.text()})); const v=j.version||j.tag_name||j.text||""; if(v) return String(v).replace(/^v/,""); }catch{ continue; }
  }
  return VERSION_FALLBACK;
};
export const loadConfig = (): any=>{ try{ const p=join(cfgDir(),"antigravity.json"); if(!existsSync(p)) return {}; return JSON.parse(readFileSync(p,"utf8")); }catch{ return {}; } };
export const saveConfig = (c: any): void=>{ try{ mkdirSync(cfgDir(),{recursive:true, mode:0o700}); const p=join(cfgDir(),"antigravity.json"); const tmp=`${p}.tmp-${process.pid}-${randomInt(1000000)}`; writeFileSync(tmp, JSON.stringify(c,null,2),{encoding:"utf8", mode:0o600}); try{ chmodSync(tmp,0o600);}catch{} try{ renameSync(tmp,p);}catch{ writeFileSync(p, JSON.stringify(c,null,2),{encoding:"utf8", mode:0o600}); } try{ chmodSync(p,0o600);}catch{} }catch{} };
