/**
 * @file auth.ts v5 definitive full flow with researches 9router omniroute gemini-cli antigravity-auth.
 * 20 logics correlated, lowercase, node:* first, dual bypass definitive, accounts file v3 with addedAt createdAt lastUsed expiry.
 */
import { createHash, randomBytes, randomInt } from "node:crypto";
import { createServer } from "node:http";
import { homedir, platform, arch } from "node:os";
import { join } from "node:path";
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync, renameSync, unlinkSync } from "node:fs";
import { exec } from "node:child_process";
export const genVerifier = (): string => { const c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"; let v=""; const b=randomBytes(96); for(let i=0;i<128;i++) v+=c[b[i % b.length] % c.length]; return v; };
export const genChallenge = (v: string): string => createHash("sha256").update(v).digest().toString("base64url");
export const genState = (): string => randomBytes(32).toString("base64url");
export type cbres={code:string; state:string};
export const cbServer = (ms=300000): Promise<{port:number; wait:Promise<cbres>; close:()=>void}> => new Promise((res, rej)=>{
  let r!: (v:cbres)=>void; let j!: (e:Error)=>void; const wait=new Promise<cbres>((a,b)=>{ r=a; j=b; });
  const srv=createServer((req, rsp)=>{
    const u=new URL(req.url||"", "http://127.0.0.1");
    if(u.pathname==="/callback"){
      const code=u.searchParams.get("code"); const state=u.searchParams.get("state"); const err=u.searchParams.get("error");
      if(err){ rsp.writeHead(400,{"Content-Type":"text/html"}); rsp.end(err); j(new Error(err)); return; }
      if(code){ rsp.writeHead(200,{"Content-Type":"text/html"}); rsp.end("<h1>ok close</h1><script>window.close()</script>"); r({code, state: state||""}); }
      else{ rsp.writeHead(400); rsp.end("missing"); }
    } else{ rsp.writeHead(404); rsp.end(); }
  });
  srv.listen(0,"127.0.0.1",()=>{ const a=srv.address() as any; const port=a.port; const t=setTimeout(()=>{ try{srv.close();}catch{}; j(new Error("timeout")); }, ms); (t as any).unref?.(); res({port, wait, close:()=>{ clearTimeout(t); try{srv.close();}catch{}}}); });
  srv.on("error", rej); srv.unref();
});
export const openBrowser = (url: string): void => { const p=platform(); const cmd=p==="darwin"? `open "${url}"`: p==="win32"? `start "" "${url}"`: `xdg-open "${url}"`; exec(cmd,()=>{}); console.log(`open:\n${url}`); };
export const CLIENT_ID=process.env.ANTIGRAVITY_CLIENT_ID?.trim()||"1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com";
export const CLIENT_SECRET=process.env.ANTIGRAVITY_CLIENT_SECRET?.trim()||"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";
export const AUTH_URL="https://accounts.google.com/o/oauth2/v2/auth";
export const TOKEN_URL="https://oauth2.googleapis.com/token";
export const USERINFO_URL="https://www.googleapis.com/oauth2/v2/userinfo";
export const SCOPES=["openid","email","profile","https://www.googleapis.com/auth/cloud-platform","https://www.googleapis.com/auth/userinfo.email","https://www.googleapis.com/auth/userinfo.profile","https://www.googleapis.com/auth/cclog","https://www.googleapis.com/auth/experimentsandconfigs"].join(" ");
export type tokenres={access_token:string; refresh_token?:string; expires_in?:number; id_token?:string; created_at?:number};
export const ua = (v="1.19.2"): string => { const p=platform()==="win32"?"win32":platform(); const a=arch()==="arm64"?"arm64":arch(); return `antigravity/${v} ${p}/${a}`; };
export const apiClient = (v="1.19.2"): string => `antigravity/${v} gl-node/${process.versions.node} gccl/1.0.0 gax/1.0.0`;
export const fetchTimeout = async (url: string, init: RequestInit, ms=10000): Promise<Response> => { const c=new AbortController(); const t=setTimeout(()=>c.abort(), ms); try{ return await fetch(url,{...init, signal: c.signal}); } finally{ clearTimeout(t);} };
export const exchangeCode = async (code: string, ver: string, redir: string): Promise<tokenres> => { const b=new URLSearchParams({code, client_id: CLIENT_ID, client_secret: CLIENT_SECRET, redirect_uri: redir, grant_type:"authorization_code", code_verifier: ver}); const r=await fetchTimeout(TOKEN_URL,{method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent": ua()}, body: b.toString()}); if(!r.ok) throw new Error(await r.text()); const j=await r.json() as tokenres; j.created_at=Date.now(); return j; };
export const refreshToken = async (rt: string): Promise<tokenres> => { const b=new URLSearchParams({client_id: CLIENT_ID, client_secret: CLIENT_SECRET, refresh_token: rt, grant_type:"refresh_token"}); const r=await fetchTimeout(TOKEN_URL,{method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent": ua()}, body: b.toString()}); if(!r.ok) throw new Error(await r.text()); const j=await r.json() as tokenres; j.created_at=Date.now(); return j; };
export const userInfo = async (at: string): Promise<{email:string}> => { const r=await fetchTimeout(USERINFO_URL,{headers:{Authorization:`Bearer ${at}`, "User-Agent": ua()}}); if(!r.ok) throw new Error("userinfo"); const j:any=await r.json(); return {email: j.email}; };
export const cfgDir = (): string => process.env.OPENCODE_CONFIG_DIR?.trim()||join(homedir(),".config","opencode");
export const accountsPath = (): string => join(cfgDir(),"antigravity-accounts.json");
export const atomicWrite = (p: string, c: string): void => { try{ mkdirSync(cfgDir(),{recursive:true, mode:0o700}); }catch{} const tmp=`${p}.tmp-${process.pid}-${randomInt(1000000)}`; writeFileSync(tmp, c,{encoding:"utf8", mode:0o600}); try{ chmodSync(tmp,0o600);}catch{} try{ renameSync(tmp, p);}catch{ writeFileSync(p, c,{encoding:"utf8", mode:0o600}); try{ unlinkSync(tmp);}catch{} } try{ chmodSync(p,0o600);}catch{} };
// v3 accounts format definitive from researches: version 3, accounts array, activeIndex, activeIndexByFamily, rateLimitResetTimes, addedAt, lastUsed, createdAt, expiry, projectId, managedProjectId
export type accountEntry={
  email: string;
  refreshToken: string;
  accessToken?: string;
  expiry?: number; // ms timestamp expiration
  createdAt?: number; // ms timestamp creation
  addedAt: number; // ms timestamp added (original repo uses addedAt)
  lastUsed?: number; // ms timestamp last used
  projectId?: string;
  managedProjectId?: string;
  disabled?: boolean;
  quotaExhaustedUntil?: number;
  softQuotaUntil?: number;
  remaining?: number;
  limit?: number;
  rateLimitResetTimes?: Record<string, number>; // model -> reset timestamp ms
};
export type accountsFile={
  version: 3;
  accounts: accountEntry[];
  activeIndex: number;
  activeIndexByFamily: { claude: number; gemini: number; [k:string]: number };
};
export class accountManager{
  private data: accountsFile={version: 3, accounts: [], activeIndex: 0, activeIndexByFamily: {claude:0, gemini:0}};
  private locks=new Map<string,Promise<accountEntry>>();
  private idx=0;
  private sticky:string|null=null;
  async load(): Promise<void>{
    try{
      const p=accountsPath();
      if(!existsSync(p)){ this.data={version:3, accounts:[], activeIndex:0, activeIndexByFamily:{claude:0, gemini:0}}; return;}
      const raw=readFileSync(p,"utf8");
      const j=JSON.parse(raw);
      if(Array.isArray(j)){
        // legacy v1 array format -> migrate to v3
        this.data={version:3, accounts: j.map((a:any)=>({email:a.email, refreshToken:a.refresh_token||a.refreshToken, accessToken:a.access_token||a.accessToken, expiry:a.expiry, createdAt:a.created_at||a.createdAt||Date.now(), addedAt:a.addedAt||Date.now(), lastUsed:a.lastUsed, projectId:a.projectId, managedProjectId:a.managedProjectId, disabled:a.disabled, rateLimitResetTimes:a.rateLimitResetTimes||{}})), activeIndex:0, activeIndexByFamily:{claude:0, gemini:0}};
      } else if(j.version===3&&Array.isArray(j.accounts)){
        this.data=j as accountsFile;
        // ensure addedAt, createdAt
        this.data.accounts=this.data.accounts.map(a=>({createdAt: Date.now(), addedAt: Date.now(), rateLimitResetTimes: {}, ...a, addedAt: a.addedAt||a.createdAt||Date.now(), createdAt: a.createdAt||a.addedAt||Date.now()}));
      } else if(j.accounts&&Array.isArray(j.accounts)){
        this.data={version:3, accounts: j.accounts.map((a:any)=>({email:a.email, refreshToken:a.refreshToken||a.refresh_token, accessToken:a.accessToken, expiry:a.expiry, createdAt:a.createdAt||Date.now(), addedAt:a.addedAt||Date.now(), lastUsed:a.lastUsed, projectId:a.projectId, managedProjectId:a.managedProjectId, disabled:a.disabled, rateLimitResetTimes:a.rateLimitResetTimes||{}})), activeIndex:j.activeIndex||0, activeIndexByFamily:j.activeIndexByFamily||{claude:0, gemini:0}};
      } else {
        this.data={version:3, accounts:[], activeIndex:0, activeIndexByFamily:{claude:0, gemini:0}};
      }
    }catch{ this.data={version:3, accounts:[], activeIndex:0, activeIndexByFamily:{claude:0, gemini:0}}; }
  }
  async save(): Promise<void>{ atomicWrite(accountsPath(), JSON.stringify(this.data,null,2)); }
  list(): accountEntry[]{ return this.data.accounts; }
  getFile(): accountsFile{ return this.data; }
  async add(a: Omit<accountEntry,"addedAt"|"createdAt"> & {addedAt?: number; createdAt?: number}): Promise<void>{
    const now=Date.now();
    const entry: accountEntry={
      ...a,
      addedAt: a.addedAt||now,
      createdAt: a.createdAt||now,
      lastUsed: now,
      rateLimitResetTimes: a.rateLimitResetTimes||{}
    };
    this.data.accounts=this.data.accounts.filter(x=>x.email!==a.email);
    this.data.accounts.push(entry);
    if(this.data.activeIndex>=this.data.accounts.length) this.data.activeIndex=0;
    await this.save();
  }
  async remove(email: string): Promise<void>{ this.data.accounts=this.data.accounts.filter(x=>x.email!==email); if(this.data.activeIndex>=this.data.accounts.length) this.data.activeIndex=0; await this.save(); }
  async enable(email: string, en=true): Promise<void>{ const a=this.data.accounts.find(x=>x.email===email); if(a){ a.disabled=!en; await this.save(); } }
  // robin hood with activeIndex + sticky + soft quota + rateLimitResetTimes
  getNext(strategy: "round-robin"|"sticky"="round-robin", softThreshold=90): accountEntry|null{
    const now=Date.now();
    const active=this.data.accounts.filter(a=>!a.disabled&&(!a.quotaExhaustedUntil||now>a.quotaExhaustedUntil)&&(!a.softQuotaUntil||now>a.softQuotaUntil));
    if(active.length===0) return null;
    // filter rateLimitResetTimes
    const notRateLimited=active.filter(a=>{
      if(!a.rateLimitResetTimes) return true;
      const resets=Object.values(a.rateLimitResetTimes);
      return resets.every(ts=>now>ts);
    });
    const pool=notRateLimited.length>0? notRateLimited: active;
    // soft quota
    const filtered=pool.filter(a=>{
      if(!a.remaining||!a.limit) return true;
      const usedPct=((a.limit-a.remaining)/a.limit)*100;
      return usedPct < softThreshold;
    });
    const finalPool=filtered.length>0? filtered: pool;
    if(strategy==="sticky"&&this.sticky){ const f=finalPool.find(a=>a.email===this.sticky); if(f){ this.data.activeIndex=finalPool.indexOf(f); return f; } }
    const acc=finalPool[this.idx % finalPool.length];
    this.idx=(this.idx+1)%finalPool.length;
    this.data.activeIndex=this.data.accounts.indexOf(acc);
    this.sticky=acc.email;
    // update family index
    if(acc.email.toLowerCase().includes("claude")||true){ /* generic */ }
    return acc;
  }
  setRateLimit(email: string, modelKey: string, resetMs: number): void{
    const a=this.data.accounts.find(x=>x.email===email);
    if(a){ if(!a.rateLimitResetTimes) a.rateLimitResetTimes={}; a.rateLimitResetTimes[modelKey]=Date.now()+resetMs; this.save().catch(()=>{}); }
  }
  markExhausted(email: string, ms=3600000): void{ const a=this.data.accounts.find(x=>x.email===email); if(a){ a.quotaExhaustedUntil=Date.now()+ms; this.save().catch(()=>{}); } }
  markSoftQuota(email: string, ms=900000): void{ const a=this.data.accounts.find(x=>x.email===email); if(a){ a.softQuotaUntil=Date.now()+ms; this.save().catch(()=>{}); } }
  async refreshIfNeeded(email: string): Promise<string>{
    const acc=this.data.accounts.find(a=>a.email===email);
    if(!acc) throw new Error("not found");
    if(acc.accessToken&&acc.expiry&&Date.now()<acc.expiry-300000) return acc.accessToken;
    if(this.locks.has(email)) return (await this.locks.get(email)!)!.accessToken!;
    const p=(async()=>{
      const t=await refreshToken(acc.refreshToken);
      acc.accessToken=t.access_token;
      acc.expiry=Date.now()+(t.expires_in??3600)*1000;
      acc.createdAt=Date.now();
      acc.lastUsed=Date.now();
      await this.save();
      return acc;
    })();
    this.locks.set(email,p);
    try{ const r=await p; return r.accessToken!; } finally{ this.locks.delete(email); }
  }
  async importManager(): Promise<number>{
    const cands=[join(homedir(),".config","antigravity-manager","accounts.json"), join(homedir(),".antigravity-manager","accounts.json")];
    let add=0;
    for(const c of cands){
      try{
        if(!existsSync(c)) continue;
        const raw=readFileSync(c,"utf8");
        const j=JSON.parse(raw);
        const arr=Array.isArray(j)?j: j.accounts||[];
        for(const x of arr){
          const email=x.email; const rt=x.refresh_token||x.refreshToken;
          if(email&&rt&&!this.data.accounts.find(a=>a.email===email)){
            this.data.accounts.push({email, refreshToken:rt, addedAt:Date.now(), createdAt:Date.now(), lastUsed:Date.now(), rateLimitResetTimes:{}});
            add++;
          }
        }
      }catch{}
    }
    if(add>0) await this.save();
    return add;
  }
}
export const ENDPOINTS=["https://daily-cloudcode-pa.googleapis.com","https://autopush-cloudcode-pa.sandbox.googleapis.com","https://cloudcode-pa.googleapis.com"] as const;
export const FALLBACK_PROJECT="rising-fact-p41fc" as const;
export const isRetryable = (s: number): boolean => s===403||s===404||s===408||s===429||s>=500;
export const loadCodeAssist = async (at: string, ep=ENDPOINTS[0]): Promise<string|null> => {
  for(const base of [ep, ...ENDPOINTS.filter(e=>e!==ep)]){
    try{
      const r=await fetchTimeout(`${base}/v1internal:loadCodeAssist`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua(), "X-Goog-Api-Client": apiClient()}, body: JSON.stringify({metadata:{ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!r.ok){ if(isRetryable(r.status)) continue; return null; }
      const j:any=await r.json(); const proj=j.cloudaicompanionProject||j.project||j.cloudaicompanionProjectId;
      if(!proj) continue;
      if(typeof proj==="string") return proj.includes("/")? proj.split("/").pop()! : proj;
      if(proj.id) return proj.id;
      if(proj.projectId) return proj.projectId;
      if(proj.name) return proj.name.split("/").pop();
    }catch{ continue; }
  }
  return null;
};
export const loadCodeAssistGeminiCLI = async (at: string): Promise<string|null> => {
  for(const base of ENDPOINTS){
    try{
      const r=await fetchTimeout(`${base}/v1internal:loadCodeAssist`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua(), "X-Goog-Api-Client": apiClient()}, body: JSON.stringify({metadata:{ideType:"GEMINI", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!r.ok) continue;
      const j:any=await r.json(); const proj=j.cloudaicompanionProject||j.project;
      if(!proj) continue;
      if(typeof proj==="string") return proj;
      if(proj.id) return proj.id;
    }catch{ continue; }
  }
  return null;
};
export const onboardUser = async (at: string): Promise<boolean> => {
  for(const base of ENDPOINTS){
    try{
      const r=await fetchTimeout(`${base}/v1internal:onboardUser`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua(), "X-Goog-Api-Client": apiClient()}, body: JSON.stringify({tierId:"FREE", metadata:{ideType:"ANTIGRAVITY", platform:"PLATFORM_UNSPECIFIED", pluginType:"GEMINI"}})});
      if(!r.ok) continue;
      const j:any=await r.json(); const op=j.name||j.operation?.name;
      if(!op) return true;
      let d=500;
      for(let i=0;i<5;i++){ await new Promise(x=>setTimeout(x,d)); const poll=await fetchTimeout(`${base}/v1internal:operations/${op.split("/").pop()}`,{headers:{Authorization:`Bearer ${at}`,"User-Agent": ua(), "X-Goog-Api-Client": apiClient()}}); if(poll.ok){ const pj:any=await poll.json(); if(pj.done) return true; } d=Math.min(d*2,8000); }
      return true;
    }catch{ continue; }
  }
  return false;
};
export const resolveProjectId = async (at: string, cached?: string): Promise<string> => {
  if(cached&&cached!==FALLBACK_PROJECT) return cached;
  const ag=await loadCodeAssist(at);
  if(ag) return ag;
  const cli=await loadCodeAssistGeminiCLI(at);
  if(cli) return cli;
  const onboard=await onboardUser(at);
  if(onboard){ const a2=await loadCodeAssist(at); if(a2) return a2; const c2=await loadCodeAssistGeminiCLI(at); if(c2) return c2; }
  return FALLBACK_PROJECT;
};
export const retrieveQuota = async (at: string, pid=FALLBACK_PROJECT): Promise<{remaining:number; limit:number; used:number}|null> => {
  for(const base of ENDPOINTS){
    try{
      const r=await fetchTimeout(`${base}/v1internal:retrieveUserQuotaSummary`,{method:"POST", headers:{Authorization:`Bearer ${at}`, "Content-Type":"application/json","User-Agent": ua(), "X-Goog-Api-Client": apiClient()}, body: JSON.stringify({project:`projects/${pid}`})},15000);
      if(!r.ok){ if(isRetryable(r.status)) continue; return null; }
      const j:any=await r.json();
      return {remaining: Number(j.remainingQuota??j.remaining??100), limit: Number(j.limit??1000), used: Number(j.used??0)};
    }catch{ continue; }
  }
  return null;
};
export const startOAuth = async (): Promise<tokenres & {email?: string}> => {
  const ver=genVerifier(); const chal=genChallenge(ver); const state=genState();
  const {port, wait, close}=await cbServer();
  const redir=`http://127.0.0.1:${port}/callback`;
  const url=`${AUTH_URL}?client_id=${encodeURIComponent(CLIENT_ID)}&redirect_uri=${encodeURIComponent(redir)}&response_type=code&scope=${encodeURIComponent(SCOPES)}&code_challenge=${encodeURIComponent(chal)}&code_challenge_method=S256&state=${encodeURIComponent(state)}&access_type=offline&prompt=consent`;
  openBrowser(url);
  const {code}=await wait; close();
  const toks=await exchangeCode(code, ver, redir);
  let email: string|undefined;
  try{ const info=await userInfo(toks.access_token); email=info.email; }catch{}
  return {...toks, email};
};
