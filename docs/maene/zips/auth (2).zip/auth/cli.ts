/**
 * @file cli.ts v5 definitive full flow login mode selection robin hood accounts v3.
 */
import { createInterface } from "node:readline";
import { join } from "node:path";
import { existsSync, readFileSync, writeFileSync, chmodSync, mkdirSync } from "node:fs";
import { accountManager, retrieveQuota, startOAuth, cfgDir, accountsPath } from "./auth.js";
import { MODELS_2026_08_25 } from "./models.js";
import { debugLogger } from "./system.js";
const OPENCODE_JSON=join(cfgDir(),"opencode.json");
const banner = (): void=>{ console.log(`\n╔════════════════════════════════════════════════════╗\n║  opencode-antigravity-auth-next v5.0.0 definitive  ║\n║  Gemini 3.7 Flash GA Aug 13 2026 + Robin Hood + Dual Bypass  ║\n╚════════════════════════════════════════════════════╝\n`); };
const q = (rl:any, s:string): Promise<string>=> new Promise(res=>rl.question(s, (a:string)=>res(a)));
const login = async (): Promise<void>=>{
  const rl=createInterface({input: process.stdin, output: process.stdout});
  console.log("[login] mode: 1 add accounts 2 fresh start");
  const mode=await q(rl,"mode 1/2 [1]: ");
  rl.close();
  const r=await startOAuth();
  if(!r.refresh_token) throw new Error("no refresh_token");
  const email=r.email||`user-${Date.now()}@gmail.com`;
  const mgr=new accountManager(); await mgr.load().catch(()=>{});
  if(mode.trim()==="2"){ for(const a of mgr.list()) await mgr.remove(a.email); }
  await mgr.add({email, refreshToken: r.refresh_token, accessToken: r.access_token, expiry: Date.now()+3600*1000});
  console.log(`✅ logged in ${email} saved to ${accountsPath()} v3 format addedAt createdAt expiry`);
};
const listAcc = async (): Promise<void>=>{
  const mgr=new accountManager(); await mgr.load().catch(()=>{});
  const f=mgr.getFile();
  console.log(`version ${f.version} activeIndex ${f.activeIndex} activeIndexByFamily ${JSON.stringify(f.activeIndexByFamily)}`);
  const list=mgr.list();
  if(list.length===0) console.log("no accounts"); else list.forEach((a,i)=>console.log(` ${i+1}. ${a.email} addedAt ${new Date(a.addedAt).toISOString()} createdAt ${a.createdAt? new Date(a.createdAt).toISOString(): "n/a"} lastUsed ${a.lastUsed? new Date(a.lastUsed).toISOString(): "n/a"} expiry ${a.expiry? new Date(a.expiry).toISOString(): "n/a"} projectId ${a.projectId||"n/a"} remaining ${a.remaining||"n/a"}/${a.limit||"n/a"} rateLimit ${JSON.stringify(a.rateLimitResetTimes||{})} ${a.disabled?"disabled":""} ${a.quotaExhaustedUntil?"quota":""}`));
};
const quota = async (): Promise<void>=>{
  const mgr=new accountManager(); await mgr.load().catch(()=>{});
  for(const acc of mgr.list()){
    if(acc.disabled) continue;
    try{
      if(!acc.accessToken){ console.log(` ${acc.email}: no token`); continue; }
      const qq=await retrieveQuota(acc.accessToken, acc.projectId);
      if(qq){ acc.remaining=qq.remaining; acc.limit=qq.limit; acc.lastUsed=Date.now(); await mgr.save(); }
      console.log(` ${acc.email}: ${qq? `${qq.remaining}/${qq.limit} used ${qq.used}`: "failed"}`);
    }catch(e:any){ console.log(` ${acc.email}: ${e.message}`); }
  }
};
const configure = async (): Promise<void>=>{
  try{ mkdirSync(cfgDir(),{recursive:true, mode:0o700}); }catch{}
  const modelsConfig: any={};
  for(const m of MODELS_2026_08_25){
    const variants: any={};
    for(const v of m.thinking) variants[v]={thinkingLevel: v};
    if(m.id.includes("claude-opus")){ variants.low={thinkingConfig:{thinkingBudget:8192}}; variants.max={thinkingConfig:{thinkingBudget:32768}}; }
    modelsConfig[m.id]={ name: m.name, limit:{context: m.context, output: m.output}, modalities: m.modalities, variants, release: m.release };
  }
  let existing:any={};
  if(existsSync(OPENCODE_JSON)) try{ existing=JSON.parse(readFileSync(OPENCODE_JSON,"utf8")); }catch{}
  existing["$schema"]=existing["$schema"]||"https://opencode.ai/config.json";
  existing.plugin=existing.plugin||[];
  if(!existing.plugin.includes("opencode-antigravity-auth-next@latest")) existing.plugin.push("opencode-antigravity-auth-next@latest");
  existing.provider=existing.provider||{}; existing.provider.google=existing.provider.google||{}; existing.provider.google.models={...(existing.provider.google.models||{}), ...modelsConfig};
  const tmp=`${OPENCODE_JSON}.tmp-${process.pid}`;
  writeFileSync(tmp, JSON.stringify(existing,null,2), {encoding:"utf8", mode:0o600}); try{ chmodSync(tmp,0o600);}catch{}
  writeFileSync(OPENCODE_JSON, JSON.stringify(existing,null,2), {encoding:"utf8", mode:0o600}); try{ chmodSync(OPENCODE_JSON,0o600);}catch{}
  console.log(`✅ configured ${Object.keys(modelsConfig).length} models`);
};
const diagnostics = async (): Promise<void>=>{
  console.log("=== diagnostics v5 ===");
  console.log(`cfgDir ${cfgDir()}`);
  console.log(`accountsPath ${accountsPath()} exists ${existsSync(accountsPath())}`);
  if(existsSync(accountsPath())){ const raw=readFileSync(accountsPath(),"utf8"); console.log(raw.slice(0,1000)); }
  console.log(`opencode.json ${existsSync(OPENCODE_JSON)}`);
  console.log(`models ${MODELS_2026_08_25.length}`);
};
const menu = async (): Promise<void>=>{
  banner();
  const rl=createInterface({input: process.stdin, output: process.stdout});
  while(true){
    console.log("\nmenu:\n 1. login add\n 2. list v3 format\n 3. quotas\n 4. configure all models\n 5. diagnostics accounts file\n 6. exit\n");
    const ans=await q(rl,"→ ");
    try{
      if(ans.trim()==="1") await login();
      else if(ans.trim()==="2") await listAcc();
      else if(ans.trim()==="3") await quota();
      else if(ans.trim()==="4") await configure();
      else if(ans.trim()==="5") await diagnostics();
      else if(ans.trim()==="6"){ rl.close(); console.log("bye"); return; }
    }catch(e:any){ console.error(e.message); }
  }
};
const main = async (): Promise<void>=>{
  const cmd=process.argv[2]?.toLowerCase();
  if(!cmd) return menu();
  if(cmd==="login") await login();
  else if(cmd==="list") await listAcc();
  else if(cmd==="quota") await quota();
  else if(cmd.includes("config")) await configure();
  else if(cmd==="diagnostics") await diagnostics();
  else if(cmd==="menu") await menu();
};
if(new URL(import.meta.url).pathname===process.argv[1]||process.argv[1]?.endsWith("cli.ts")) main().catch(e=>{ console.error(e); process.exit(1); });
export { login, listAcc, quota, configure, diagnostics, menu };
