/**
 * @fileoverview accounts.ts - Account Manager Core para opencode-antigravity-auth
 * @module auth/accounts
 * @description
 *  Gerenciamento multi-conta produção-ready para plugin opencode-antigravity-auth.
 *  - Suporte a múltiplas contas Google com refresh token
 *  - Storage em ~/.config/opencode/antigravity-accounts.json (chmod 600, atomic write)
 *  - Round-robin + sticky active account
 *  - Double-checked locking para refresh de access token
 *  - Detecção de quota/429 com rotação automática
 *  - Background refresh de tokens próximos ao expiry
 *  - Import de antigravity-manager (múltiplos formatos legados)
 *  - Bypass headers Gemini CLI oficial
 *
 *  Zero dependências externas: apenas node:* builtins + fetch global (Node 18+).
 *
 * @author ONDA 3 - Módulos Core
 * @license MIT
 * @version 3.0.0
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";

// ============================================================================
// 00. CONSTANTES BLINDADAS - BYPASS GEMINI CLI
// ============================================================================

/** OAuth2 Client ID oficial Gemini CLI - raw sem suffix */
export const GEMINI_CLI_CLIENT_ID_RAW =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j" as const;

/** OAuth2 Client ID completo */
export const GEMINI_CLI_OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;

export const GEMINI_CLI_OAUTH_CLIENT_SECRET =
  "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" as const;

export const OAUTH_SCOPES = [
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
] as const;

export const OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token" as const;
export const OAUTH_USERINFO_URL =
  "https://www.googleapis.com/oauth2/v3/userinfo" as const;

/** Headers de bypass - valores canônicos exigidos pela ONDA3 */
export const GEMINI_CLI_USER_AGENT = "GeminiCLI/0.35.3" as const;
export const GEMINI_CLI_USER_AGENT_FULL =
  "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1" as const;
export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;
export const CLIENT_METADATA =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const CLOUDCODE_BASE_URL = "https://cloudcode-pa.googleapis.com" as const;

export const CLOUDCODE_ENDPOINTS = {
  loadCodeAssist: `${CLOUDCODE_BASE_URL}/v1internal:loadCodeAssist`,
  onboardUser: `${CLOUDCODE_BASE_URL}/v1internal:onboardUser`,
  fetchAvailableModels: `${CLOUDCODE_BASE_URL}/v1internal:fetchAvailableModels`,
  generateContent: `${CLOUDCODE_BASE_URL}/v1internal:generateContent`,
  streamGenerateContent: `${CLOUDCODE_BASE_URL}/v1internal:streamGenerateContent`,
  retrieveUserQuotaSummary: `${CLOUDCODE_BASE_URL}/v1internal:retrieveUserQuotaSummary`,
} as const;

export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;

export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type Model2026 = (typeof MODELS_2026)[number];

// ============================================================================
// 01. TIPOS CORE
// ============================================================================

export interface OAuthClientConfig {
  clientId: string;
  clientSecret: string;
}

export type OAuthClientKey =
  | "gemini-cli"
  | "antigravity-manager"
  | "antigravity"
  | "custom"
  | string;

export interface AccountMetadataV3 {
  /** Email normalizado lower-case */
  email: string;
  /** Refresh token OAuth2 (long-lived) */
  refreshToken: string;
  /** Access token atual (short-lived, 1h) */
  accessToken?: string;
  /** Epoch ms quando accessToken expira */
  expiryDate?: number;
  /** Project ID Cloud vinculado (ou fallback) */
  projectId?: string;
  /** Se conta está habilitada para uso */
  enabled: boolean;
  /** Chave identificadora do client OAuth usado */
  oauthClientKey: OAuthClientKey;
  /** Config OAuth custom, se oauthClientKey=custom */
  oauthClientConfig?: OAuthClientConfig;
  /** Epoch ms do último refresh bem-sucedido */
  lastRefresh?: number;
  /** Epoch ms da criação do registro */
  createdAt: number;
  /** Epoch ms do último uso (para LRU / rotação) */
  lastUsedAt?: number;
  /** Contador consecutivo de falhas (quota, 401, etc) */
  failureCount?: number;
  /** Motivo do disable temporário */
  disabledReason?: string;
  /** Epoch ms até quando conta fica desabilitada (cooldown) */
  disabledUntil?: number;
  /** Scopes que essa conta possui (opcional para auditoria) */
  scopes?: string[];
}

export interface AccountStore {
  /** Versão do schema - sempre 3 */
  version: 3;
  /** Lista de contas */
  accounts: AccountMetadataV3[];
  /** Email ativo no modo sticky */
  activeEmail?: string | null;
  /** Índice de rotação round-robin */
  rotationIndex?: number;
  /** Estratégia de seleção: round-robin (default) ou sticky */
  rotationStrategy?: "round-robin" | "sticky";
  /** Quando store foi criado */
  createdAt?: number;
  /** Último update */
  updatedAt?: number;
  /** Última rotação por erro */
  lastRotationAt?: number;
  /** Email que causou última rotação (para debug) */
  lastRotatedFrom?: string;
}

export type RotationStrategy = "round-robin" | "sticky";

export interface AddAccountInput {
  email: string;
  refreshToken: string;
  accessToken?: string;
  expiryDate?: number;
  projectId?: string;
  enabled?: boolean;
  oauthClientKey?: OAuthClientKey;
  oauthClientConfig?: OAuthClientConfig;
  scopes?: string[];
}

export interface ImportResult {
  imported: number;
  skipped: number;
  updated: number;
  errors: string[];
  sources: string[];
  accounts: AccountMetadataV3[];
}

export interface TokenRefreshResponse {
  access_token: string;
  expires_in: number;
  token_type: string;
  scope?: string;
  id_token?: string;
}

// ============================================================================
// 02. HELPERS DE PATH & FS - PRODUÇÃO-READY
// ============================================================================

function resolveOpenCodeBaseDir(): string {
  const envDir = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (envDir && envDir.length > 0) {
    return path.resolve(envDir);
  }
  return path.join(os.homedir(), ".config", "opencode");
}

export function resolveAccountsFilePath(customDir?: string): string {
  if (customDir) {
    return path.join(path.resolve(customDir), "antigravity-accounts.json");
  }
  const base = resolveOpenCodeBaseDir();
  return path.join(base, "antigravity-accounts.json");
}

function ensureDirExists(dir: string): void {
  try {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  } catch {
    // best effort - ignora se já existe
  }
  // Garante permissão 0700 mesmo se já existia
  try {
    fs.chmodSync(dir, 0o700);
  } catch {
    // pode falhar em alguns filesystems / containers
  }
}

/**
 * Escrita atômica com chmod 600
 * - Escreve em arquivo temp no mesmo diretório
 * - chmod 600
 * - rename atômico
 */
function atomicWriteFileJson(filePath: string, data: string): void {
  const dir = path.dirname(filePath);
  ensureDirExists(dir);

  const tmpSuffix = crypto.randomBytes(6).toString("hex");
  const tmpPath = `${filePath}.tmp.${process.pid}.${tmpSuffix}`;

  try {
    // Escreve temp com modo restritivo
    fs.writeFileSync(tmpPath, data, { encoding: "utf8", mode: 0o600 });
    try {
      fs.chmodSync(tmpPath, 0o600);
    } catch {
      // ignore
    }
    // Rename atômico (mesmo filesystem)
    fs.renameSync(tmpPath, filePath);
    try {
      fs.chmodSync(filePath, 0o600);
    } catch {
      // ignore
    }
  } finally {
    // Limpeza best-effort do temp se falhou antes do rename
    try {
      if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    } catch {
      // ignore
    }
  }
}

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

function isValidEmail(email: string): boolean {
  // RFC simples, suficiente para bypass local
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function nowMs(): number {
  return Date.now();
}

function buildDefaultStore(): AccountStore {
  const t = nowMs();
  return {
    version: 3,
    accounts: [],
    activeEmail: null,
    rotationIndex: 0,
    rotationStrategy: "round-robin",
    createdAt: t,
    updatedAt: t,
  };
}

function sanitizeStore(raw: unknown): AccountStore {
  const def = buildDefaultStore();

  if (!raw || typeof raw !== "object") return def;

  const obj = raw as Record<string, unknown>;

  // Suporta versão antiga sem version ou com version 1/2
  const accountsRaw = Array.isArray(obj.accounts) ? obj.accounts : [];
  const accounts: AccountMetadataV3[] = [];

  for (const a of accountsRaw) {
    const normalized = normalizeAccountRaw(a);
    if (normalized) accounts.push(normalized);
  }

  // Também suporta formato legado onde root é array
  if (accounts.length === 0 && Array.isArray(raw)) {
    for (const a of raw as unknown[]) {
      const n = normalizeAccountRaw(a);
      if (n) accounts.push(n);
    }
  }

  const activeEmail =
    typeof obj.activeEmail === "string" ? normalizeEmail(obj.activeEmail) : null;

  const rotIdx =
    typeof obj.rotationIndex === "number" && Number.isFinite(obj.rotationIndex)
      ? Math.max(0, Math.floor(obj.rotationIndex))
      : 0;

  const rotationStrategy =
    obj.rotationStrategy === "sticky" || obj.rotationStrategy === "round-robin"
      ? obj.rotationStrategy
      : "round-robin";

  return {
    version: 3,
    accounts,
    activeEmail,
    rotationIndex: rotIdx % Math.max(1, accounts.length || 1),
    rotationStrategy,
    createdAt:
      typeof obj.createdAt === "number" ? obj.createdAt : def.createdAt,
    updatedAt: nowMs(),
    lastRotationAt:
      typeof obj.lastRotationAt === "number" ? obj.lastRotationAt : undefined,
    lastRotatedFrom:
      typeof obj.lastRotatedFrom === "string" ? obj.lastRotatedFrom : undefined,
  };
}

function normalizeAccountRaw(raw: unknown): AccountMetadataV3 | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;

  const emailRaw =
    (r.email as string) ??
    (r.user_email as string) ??
    (r.userEmail as string) ??
    (r.account as string) ??
    "";

  if (typeof emailRaw !== "string" || !isValidEmail(emailRaw)) return null;
  const email = normalizeEmail(emailRaw);

  const refreshTokenRaw =
    (r.refreshToken as string) ??
    (r.refresh_token as string) ??
    (r.refresh as string) ??
    (r.token as any)?.refresh_token ??
    (r.tokens as any)?.refresh_token ??
    "";

  if (typeof refreshTokenRaw !== "string" || refreshTokenRaw.length < 10)
    return null;

  const accessToken =
    typeof r.accessToken === "string"
      ? (r.accessToken as string)
      : typeof r.access_token === "string"
        ? (r.access_token as string)
        : (r.token as any)?.access_token ?? undefined;

  let expiryDate: number | undefined;
  if (typeof r.expiryDate === "number") expiryDate = r.expiryDate;
  else if (typeof r.expiry_date === "number") expiryDate = r.expiry_date;
  else if (typeof r.expiryDate === "string") {
    const n = Number(r.expiryDate);
    if (Number.isFinite(n)) expiryDate = n;
  } else if (typeof r.expires_at === "number") {
    // pode ser segundos ou ms - heurística
    expiryDate = r.expires_at > 1e12 ? r.expires_at : r.expires_at * 1000;
  } else if ((r.token as any)?.expiry_date) {
    expiryDate = (r.token as any).expiry_date;
  } else if (typeof r.expires_in === "number") {
    // se tem expires_in mas não expiry, calcula com lastRefresh ou agora
    const base =
      typeof r.lastRefresh === "number" ? r.lastRefresh : nowMs();
    expiryDate = base + r.expires_in * 1000;
  }

  const projectId =
    (r.projectId as string) ??
    (r.project_id as string) ??
    (r.cloudaicompanionProject as string) ??
    (r.project as string) ??
    PROJECT_FALLBACK;

  const enabled = typeof r.enabled === "boolean" ? r.enabled : true;

  const oauthClientKey: OAuthClientKey =
    typeof r.oauthClientKey === "string"
      ? (r.oauthClientKey as string)
      : typeof r.oauth_client_key === "string"
        ? (r.oauth_client_key as string)
        : "gemini-cli";

  let oauthClientConfig: OAuthClientConfig | undefined;
  if (r.oauthClientConfig && typeof r.oauthClientConfig === "object") {
    const cfg = r.oauthClientConfig as Record<string, unknown>;
    if (typeof cfg.clientId === "string" && typeof cfg.clientSecret === "string") {
      oauthClientConfig = {
        clientId: cfg.clientId,
        clientSecret: cfg.clientSecret,
      };
    }
  }

  const lastRefresh =
    typeof r.lastRefresh === "number"
      ? r.lastRefresh
      : typeof r.last_refresh === "number"
        ? r.last_refresh
        : undefined;

  const createdAt =
    typeof r.createdAt === "number"
      ? r.createdAt
      : typeof r.created_at === "number"
        ? r.created_at
        : nowMs();

  const lastUsedAt =
    typeof r.lastUsedAt === "number" ? r.lastUsedAt : undefined;

  const failureCount =
    typeof r.failureCount === "number" ? Math.max(0, r.failureCount) : 0;

  const disabledReason =
    typeof r.disabledReason === "string" ? r.disabledReason : undefined;

  const disabledUntil =
    typeof r.disabledUntil === "number" ? r.disabledUntil : undefined;

  const scopes = Array.isArray(r.scopes)
    ? (r.scopes as string[]).filter((s) => typeof s === "string")
    : undefined;

  return {
    email,
    refreshToken: refreshTokenRaw,
    accessToken: typeof accessToken === "string" ? accessToken : undefined,
    expiryDate,
    projectId: typeof projectId === "string" ? projectId : PROJECT_FALLBACK,
    enabled,
    oauthClientKey,
    oauthClientConfig,
    lastRefresh,
    createdAt,
    lastUsedAt,
    failureCount,
    disabledReason,
    disabledUntil,
    scopes,
  };
}

// ============================================================================
// 03. OAUTH REFRESH - BARE FETCH COM BYPASS HEADERS
// ============================================================================

const REFRESH_BUFFER_MS = 5 * 60 * 1000; // 5 min
const BACKGROUND_REFRESH_BUFFER_MS = 10 * 60 * 1000; // 10 min

function buildTokenRefreshHeaders(): Record<string, string> {
  return {
    "Content-Type": "application/x-www-form-urlencoded",
    "User-Agent": GEMINI_CLI_USER_AGENT_FULL,
    "X-Goog-Api-Client": X_GOOG_API_CLIENT,
    "Client-Metadata": CLIENT_METADATA,
    Accept: "application/json",
  };
}

function resolveOAuthClientForAccount(
  acct: AccountMetadataV3
): OAuthClientConfig {
  if (acct.oauthClientConfig?.clientId && acct.oauthClientConfig?.clientSecret) {
    return acct.oauthClientConfig;
  }
  // Default blindado Gemini CLI
  return {
    clientId: GEMINI_CLI_OAUTH_CLIENT_ID,
    clientSecret: GEMINI_CLI_OAUTH_CLIENT_SECRET,
  };
}

async function performTokenRefresh(
  acct: AccountMetadataV3
): Promise<TokenRefreshResponse> {
  const client = resolveOAuthClientForAccount(acct);

  const body = new URLSearchParams({
    client_id: client.clientId,
    client_secret: client.clientSecret,
    refresh_token: acct.refreshToken,
    grant_type: "refresh_token",
  });

  const headers = buildTokenRefreshHeaders();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);

  try {
    const res = await fetch(OAUTH_TOKEN_URL, {
      method: "POST",
      headers,
      body: body.toString(),
      signal: controller.signal,
    });

    const text = await res.text();
    let json: any;
    try {
      json = JSON.parse(text);
    } catch {
      json = { raw: text };
    }

    if (!res.ok) {
      const err: any = new Error(
        `Token refresh failed for ${acct.email}: ${res.status} ${json.error_description || json.error || text.slice(0, 500)}`
      );
      err.status = res.status;
      err.code = json.error;
      err.response = json;
      err.email = acct.email;
      throw err;
    }

    if (!json.access_token || typeof json.expires_in !== "number") {
      throw new Error(
        `Invalid token response for ${acct.email}: missing access_token/expires_in`
      );
    }

    return json as TokenRefreshResponse;
  } finally {
    clearTimeout(timeout);
  }
}

function isTokenExpired(acct: AccountMetadataV3, bufferMs = REFRESH_BUFFER_MS): boolean {
  if (!acct.accessToken) return true;
  if (!acct.expiryDate) return true;
  return acct.expiryDate <= nowMs() + bufferMs;
}

// ============================================================================
// 04. QUOTA / 429 DETECTION
// ============================================================================

const QUOTA_ERROR_PATTERNS = [
  /quota/i,
  /rate limit/i,
  /rate_limit/i,
  /too many requests/i,
  /429/,
  /resource_exhausted/i,
  /RESOURCE_EXHAUSTED/,
  /quota_exceeded/i,
  /QUOTA_EXCEEDED/,
  /user_rate_limit/i,
  /Request throttled/i,
  /billing/i, // às vezes quota vem com billing
];

export function isQuotaError(err: unknown): boolean {
  if (!err) return false;

  // Direct number
  if (typeof err === "number") return err === 429;

  const asAny = err as any;

  // status / code fields
  const status =
    asAny.status ??
    asAny.statusCode ??
    asAny.code ??
    (asAny.response && (asAny.response.status || asAny.response.statusCode));

  if (status === 429) return true;
  if (status === 403 || status === "403") {
    // 403 pode ser quota, checar mensagem
    const msg = (
      asAny.message ||
      asAny.error_description ||
      asAny.error ||
      JSON.stringify(asAny.response || asAny) ||
      ""
    ).toString();
    if (QUOTA_ERROR_PATTERNS.some((re) => re.test(msg))) return true;
    // Para 403 genérico no Code Assist, tratamos como quota quando endpoint é generate*
    // Mas conservador: só se mencionar quota
    return false;
  }

  const message = (
    asAny.message ||
    asAny.error ||
    asAny.error_description ||
    (typeof err === "string" ? err : "") ||
    JSON.stringify(asAny).slice(0, 2000)
  )
    .toString()
    .toLowerCase();

  return QUOTA_ERROR_PATTERNS.some((re) => re.test(message));
}

function parseErrorStatus(err: unknown): number | undefined {
  if (!err) return undefined;
  const a = err as any;
  return (
    a.status ??
    a.statusCode ??
    a.code ??
    (a.response && (a.response.status || a.response.statusCode)) ??
    undefined
  );
}

// ============================================================================
// 05. AccountManager CLASS
// ============================================================================

export interface AccountManagerOptions {
  /** Override do diretório base (default ~/.config/opencode) */
  configDir?: string;
  /** Nome do arquivo (default antigravity-accounts.json) */
  fileName?: string;
  /** Estratégia padrão se store não tem */
  rotationStrategy?: RotationStrategy;
  /** Path completo custom (tem precedência sobre configDir+fileName) */
  filePath?: string;
  /** Logger opcional */
  logger?: {
    info?: (msg: string, ...args: any[]) => void;
    warn?: (msg: string, ...args: any[]) => void;
    error?: (msg: string, ...args: any[]) => void;
    debug?: (msg: string, ...args: any[]) => void;
  };
  /** Desabilita background auto-refresh timer */
  disableBackgroundTimer?: boolean;
}

export class AccountManager {
  private readonly storePath: string;
  private store: AccountStore;
  private rotationIdx: number;
  private readonly refreshLocks = new Map<string, Promise<AccountMetadataV3>>();
  private backgroundTimer?: NodeJS.Timeout;
  private readonly logger: AccountManagerOptions["logger"];
  private readonly options: AccountManagerOptions;

  constructor(opts: AccountManagerOptions = {}) {
    this.options = opts;
    this.logger = opts.logger ?? {};

    if (opts.filePath) {
      this.storePath = path.resolve(opts.filePath);
    } else {
      const baseDir = opts.configDir
        ? path.resolve(opts.configDir)
        : resolveOpenCodeBaseDir();
      const fileName = opts.fileName ?? "antigravity-accounts.json";
      this.storePath = path.join(baseDir, fileName);
    }

    this.store = this.loadAccounts();
    this.rotationIdx = this.store.rotationIndex ?? 0;

    // Auto background timer se habilitado (a cada 5 min)
    if (!opts.disableBackgroundTimer) {
      // unref para não bloquear exit
      this.backgroundTimer = setInterval(() => {
        this.backgroundRefresh().catch((e) => {
          this.logger?.warn?.(
            `[accounts] backgroundRefresh failed: ${(e as Error).message}`
          );
        });
      }, 5 * 60 * 1000);
      if (this.backgroundTimer && typeof (this.backgroundTimer as any).unref === "function") {
        (this.backgroundTimer as any).unref();
      }
    }
  }

  // --------------------------------------------------------------------------
  // STORAGE - loadAccounts / saveAccounts (atomic chmod 600)
  // --------------------------------------------------------------------------

  /**
   * Carrega contas de ~/.config/opencode/antigravity-accounts.json
   * - Cria file se não existe com store default
   * - chmod 600 em toda leitura/escrita
   * - Sanitiza schema V3
   */
  loadAccounts(): AccountStore {
    let rawContent: string | null = null;

    try {
      // Garante dir existe antes de tentar ler
      ensureDirExists(path.dirname(this.storePath));

      if (!fs.existsSync(this.storePath)) {
        const def = buildDefaultStore();
        if (this.options.rotationStrategy) {
          def.rotationStrategy = this.options.rotationStrategy;
        }
        this.store = def;
        this.saveAccounts(); // cria file inicial com 600
        this.logger?.info?.(`[accounts] created new store at ${this.storePath}`);
        return { ...def };
      }

      // Chmod 600 mesmo na leitura (hardening)
      try {
        fs.chmodSync(this.storePath, 0o600);
      } catch {
        // ignore
      }

      rawContent = fs.readFileSync(this.storePath, { encoding: "utf8" });
    } catch (err) {
      this.logger?.warn?.(
        `[accounts] failed to read store at ${this.storePath}: ${(err as Error).message}, using default`
      );
      const def = buildDefaultStore();
      this.store = def;
      return { ...def };
    }

    try {
      const parsed = rawContent ? JSON.parse(rawContent) : null;
      const sanitized = sanitizeStore(parsed);
      if (this.options.rotationStrategy && !parsed?.rotationStrategy) {
        sanitized.rotationStrategy = this.options.rotationStrategy;
      }
      // Normaliza rotation index contra tamanho atual
      const len = Math.max(1, sanitized.accounts.length);
      sanitized.rotationIndex = (sanitized.rotationIndex ?? 0) % len;

      this.store = sanitized;
      this.rotationIdx = sanitized.rotationIndex ?? 0;
      return { ...sanitized, accounts: [...sanitized.accounts] };
    } catch (err) {
      this.logger?.warn?.(
        `[accounts] invalid JSON at ${this.storePath}: ${(err as Error).message}, returning default`
      );
      const def = buildDefaultStore();
      this.store = def;
      return { ...def };
    }
  }

  /**
   * Salva store em disco atômico com chmod 600
   */
  saveAccounts(): void {
    const toSave: AccountStore = {
      ...this.store,
      version: 3,
      rotationIndex: this.rotationIdx,
      updatedAt: nowMs(),
    };

    // Sanitiza novamente antes de salvar (remove undefined extras)
    const cleanAccounts = toSave.accounts.map((a) => {
      // Remove campos undefined para JSON limpo
      const copy: Record<string, unknown> = { ...a };
      Object.keys(copy).forEach((k) => {
        if (copy[k] === undefined) delete copy[k];
      });
      return copy as unknown as AccountMetadataV3;
    });

    const payload: AccountStore = {
      ...toSave,
      accounts: cleanAccounts,
    };

    const json = JSON.stringify(payload, null, 2) + "\n";

    try {
      atomicWriteFileJson(this.storePath, json);
      this.logger?.debug?.(`[accounts] saved ${cleanAccounts.length} accounts to ${this.storePath}`);
    } catch (err) {
      this.logger?.error?.(
        `[accounts] failed to save store: ${(err as Error).message}`
      );
      throw err;
    }
  }

  /**
   * Salva store custom atomic - usado para testes / import
   */
  saveAccountsAtomic(store: AccountStore): void {
    this.store = sanitizeStore(store);
    this.rotationIdx = this.store.rotationIndex ?? 0;
    this.saveAccounts();
  }

  // --------------------------------------------------------------------------
  // QUERY - contadores e listagens
  // --------------------------------------------------------------------------

  getAccountCount(): number {
    return this.store.accounts.length;
  }

  getEnabledAccounts(): AccountMetadataV3[] {
    const t = nowMs();
    return this.store.accounts.filter((a) => {
      if (!a.enabled) return false;
      // Respeita cooldown de disabledUntil e auto re-habilita se expirou
      if (a.disabledUntil && a.disabledUntil > t) return false;
      // Se disabledUntil expirou mas ainda está com enabled=false por razão temporária, reabilita lazily?
      // Não auto reabilita aqui, apenas filtra; a lógica de expiração é tratada em backgroundRefresh
      return true;
    });
  }

  listAccounts(): AccountMetadataV3[] {
    return [...this.store.accounts];
  }

  /** Lista com refreshToken mascarado (seguro para log/UI) */
  listAccountsMasked(): Array<Omit<AccountMetadataV3, "refreshToken"> & { refreshTokenMasked: string }> {
    return this.store.accounts.map((a) => {
      const masked = a.refreshToken.length > 12
        ? `${a.refreshToken.slice(0, 6)}...${a.refreshToken.slice(-4)}`
        : "***";
      const { refreshToken: _rt, ...rest } = a;
      return {
        ...rest,
        refreshTokenMasked: masked,
      };
    });
  }

  findAccount(email: string): AccountMetadataV3 | undefined {
    const norm = normalizeEmail(email);
    return this.store.accounts.find((a) => normalizeEmail(a.email) === norm);
  }

  private findAccountIndex(email: string): number {
    const norm = normalizeEmail(email);
    return this.store.accounts.findIndex((a) => normalizeEmail(a.email) === norm);
  }

  // --------------------------------------------------------------------------
  // MUTATIONS - add / remove / enable / disable / setActive
  // --------------------------------------------------------------------------

  /**
   * Adiciona nova conta. Se email já existe, atualiza refreshToken e demais dados.
   * Retorna conta adicionada/atualizada.
   */
  addAccount(input: AddAccountInput): AccountMetadataV3 {
    if (!input.email || !isValidEmail(input.email)) {
      throw new Error(`addAccount: invalid email ${input.email}`);
    }
    if (!input.refreshToken || input.refreshToken.length < 10) {
      throw new Error(`addAccount: invalid refreshToken for ${input.email}`);
    }

    const email = normalizeEmail(input.email);
    const now = nowMs();

    const existingIdx = this.findAccountIndex(email);

    const base: AccountMetadataV3 = {
      email,
      refreshToken: input.refreshToken,
      accessToken: input.accessToken,
      expiryDate: input.expiryDate,
      projectId: input.projectId ?? PROJECT_FALLBACK,
      enabled: input.enabled ?? true,
      oauthClientKey: input.oauthClientKey ?? "gemini-cli",
      oauthClientConfig: input.oauthClientConfig,
      lastRefresh: undefined,
      createdAt: now,
      lastUsedAt: undefined,
      failureCount: 0,
      scopes: input.scopes,
    };

    if (existingIdx >= 0) {
      // Update preservando createdAt e enabled se não especificado
      const prev = this.store.accounts[existingIdx];
      const merged: AccountMetadataV3 = {
        ...prev,
        ...base,
        createdAt: prev.createdAt,
        enabled: input.enabled ?? prev.enabled,
        failureCount: 0, // reset ao re-add
        disabledReason: undefined,
        disabledUntil: undefined,
      };
      // Se veio novo refreshToken, atualiza, senão mantém antigo? No nosso caso input sempre tem refreshToken
      this.store.accounts[existingIdx] = merged;
      this.logger?.info?.(`[accounts] updated existing account ${email}`);
      this.saveAccounts();
      return merged;
    } else {
      this.store.accounts.push(base);
      // Se primeira conta, vira ativa
      if (!this.store.activeEmail) {
        this.store.activeEmail = email;
      }
      this.logger?.info?.(`[accounts] added account ${email}`);
      this.saveAccounts();
      return base;
    }
  }

  /**
   * Remove conta por email. Retorna true se removeu.
   */
  removeAccount(email: string): boolean {
    const idx = this.findAccountIndex(email);
    if (idx < 0) return false;

    const removed = this.store.accounts.splice(idx, 1)[0];
    this.logger?.info?.(`[accounts] removed account ${removed.email}`);

    // Ajusta activeEmail se era a removida
    if (
      this.store.activeEmail &&
      normalizeEmail(this.store.activeEmail) === normalizeEmail(email)
    ) {
      this.store.activeEmail =
        this.store.accounts.length > 0
          ? this.store.accounts[0].email
          : null;
    }

    // Ajusta rotationIndex
    if (this.rotationIdx >= this.store.accounts.length) {
      this.rotationIdx = 0;
    }

    this.saveAccounts();
    return true;
  }

  getActiveAccount(): AccountMetadataV3 | null {
    const enabled = this.getEnabledAccounts();
    if (enabled.length === 0) {
      // Fallback: retorna qualquer conta ativa mesmo que em cooldown? Não, retorna null se realmente vazio
      // Se existe conta mas todas em cooldown, tenta retornar primeira com menor disabledUntil
      const all = this.store.accounts.filter((a) => a.enabled);
      if (all.length === 0) return null;
      // Se todas em cooldown, retorna a com disabledUntil mais antigo (próxima a liberar)
      const sorted = [...all].sort(
        (a, b) => (a.disabledUntil ?? 0) - (b.disabledUntil ?? 0)
      );
      return sorted[0] ?? null;
    }

    const strategy = this.store.rotationStrategy ?? "round-robin";

    if (strategy === "sticky" && this.store.activeEmail) {
      const sticky = enabled.find(
        (a) => normalizeEmail(a.email) === normalizeEmail(this.store.activeEmail!)
      );
      if (sticky) {
        // Atualiza lastUsedAt lazy
        sticky.lastUsedAt = nowMs();
        return sticky;
      }
      // Sticky aponta para conta desabilitada - fallback round-robin
    }

    // Round-robin
    if (this.rotationIdx >= enabled.length || this.rotationIdx < 0) {
      this.rotationIdx = 0;
    }

    const account = enabled[this.rotationIdx];
    // Avança ponteiro para próxima chamada (in-memory, persistimos depois)
    this.rotationIdx = (this.rotationIdx + 1) % enabled.length;
    this.store.rotationIndex = this.rotationIdx;
    this.store.activeEmail = account.email;
    if (account) account.lastUsedAt = nowMs();

    // Save lazy não-bloqueante? Para persistir rotação, salva mas sem falhar se erro
    try {
      this.saveAccounts();
    } catch {
      // ignore save error in getActiveAccount to keep hot path
    }

    return account;
  }

  /** Define conta ativa (modo sticky override). Também seta estratégia para sticky opcionalmente. */
  setActive(email: string, opts?: { sticky?: boolean }): AccountMetadataV3 {
    const acct = this.findAccount(email);
    if (!acct) throw new Error(`setActive: account not found ${email}`);

    // Se conta desabilitada e não está em cooldown expirado, ainda permite setar mas avisa
    if (!acct.enabled) {
      this.logger?.warn?.(
        `[accounts] setActive called for disabled account ${email}, enabling temporarily`
      );
    }

    this.store.activeEmail = acct.email;
    if (opts?.sticky) {
      this.store.rotationStrategy = "sticky";
    }
    // Alinha rotationIdx para que round-robin continue daqui se trocar estratégia
    const enabled = this.getEnabledAccounts();
    const idx = enabled.findIndex(
      (a) => normalizeEmail(a.email) === normalizeEmail(email)
    );
    if (idx >= 0) this.rotationIdx = idx;

    acct.lastUsedAt = nowMs();
    this.saveAccounts();
    return acct;
  }

  enableAccount(email: string): AccountMetadataV3 {
    const acct = this.findAccount(email);
    if (!acct) throw new Error(`enableAccount: not found ${email}`);
    acct.enabled = true;
    acct.failureCount = 0;
    acct.disabledReason = undefined;
    acct.disabledUntil = undefined;
    this.saveAccounts();
    return acct;
  }

  disableAccount(
    email: string,
    reason?: string,
    cooldownMs?: number
  ): AccountMetadataV3 {
    const acct = this.findAccount(email);
    if (!acct) throw new Error(`disableAccount: not found ${email}`);
    acct.enabled = false;
    acct.disabledReason = reason ?? "manually disabled";
    if (cooldownMs && cooldownMs > 0) {
      acct.disabledUntil = nowMs() + cooldownMs;
      // Se tem cooldown, mantemos enabled=false até expirar, mas background irá reabilitar
    }
    this.saveAccounts();
    return acct;
  }

  // Compat aliases exigidos pela task
  enable(email: string): AccountMetadataV3 {
    return this.enableAccount(email);
  }

  disable(email: string, reason?: string, cooldownMs?: number): AccountMetadataV3 {
    return this.disableAccount(email, reason, cooldownMs);
  }

  // --------------------------------------------------------------------------
  // ROTATION ON ERROR - detecção 429/quota
  // --------------------------------------------------------------------------

  /**
   * Detecta erro de quota/429 e rotaciona para próxima conta habilitada.
   * Aceita assinaturas flexíveis:
   * - rotateOnError(error)
   * - rotateOnError(email, error)
   * - rotateOnError(error, email)
   */
  rotateOnError(
    errorOrEmail: unknown,
    maybeErrorOrEmail?: unknown
  ): AccountMetadataV3 | null {
    let currentEmail: string | undefined;
    let error: unknown;

    // Heurística de parsing de assinatura
    if (typeof errorOrEmail === "string" && isValidEmail(errorOrEmail)) {
      currentEmail = errorOrEmail;
      error = maybeErrorOrEmail;
    } else if (
      typeof maybeErrorOrEmail === "string" &&
      isValidEmail(maybeErrorOrEmail as string)
    ) {
      currentEmail = maybeErrorOrEmail as string;
      error = errorOrEmail;
    } else {
      // Primeiro arg é erro
      error = errorOrEmail;
      if (
        typeof maybeErrorOrEmail === "string" &&
        isValidEmail(maybeErrorOrEmail as string)
      ) {
        currentEmail = maybeErrorOrEmail as string;
      }
    }

    if (!isQuotaError(error)) {
      // Não é quota - não rotaciona
      this.logger?.debug?.(
        `[accounts] rotateOnError called but not quota error: ${String((error as any)?.message ?? error).slice(0, 200)}`
      );
      return null;
    }

    // Resolve conta atual
    let currentAcct: AccountMetadataV3 | undefined;
    if (currentEmail) {
      currentAcct = this.findAccount(currentEmail);
    } else {
      // Tenta usar activeEmail do store
      const active = this.getActiveAccount();
      if (active) {
        currentAcct = active;
        currentEmail = active.email;
      }
    }

    if (currentAcct) {
      currentAcct.failureCount = (currentAcct.failureCount ?? 0) + 1;
      // Se falha consecutiva >=3, coloca em cooldown 30min
      const cooldown =
        currentAcct.failureCount >= 3
          ? 30 * 60 * 1000
          : currentAcct.failureCount >= 2
            ? 10 * 60 * 1000
            : 5 * 60 * 1000;

      currentAcct.disabledUntil = nowMs() + cooldown;
      currentAcct.disabledReason = `quota/429 detected (${parseErrorStatus(error) ?? "quota"}) failureCount=${currentAcct.failureCount}`;

      // Se failureCount >=5, desabilita realmente até import/manual enable
      if (currentAcct.failureCount >= 5) {
        currentAcct.enabled = false;
        this.logger?.warn?.(
          `[accounts] account ${currentAcct.email} disabled after ${currentAcct.failureCount} quota failures`
        );
      }

      this.store.lastRotationAt = nowMs();
      this.store.lastRotatedFrom = currentAcct.email;
    }

    const enabled = this.getEnabledAccounts().filter((a) => {
      // Exclui a conta atual que causou erro
      if (currentEmail && normalizeEmail(a.email) === normalizeEmail(currentEmail))
        return false;
      return true;
    });

    if (enabled.length === 0) {
      // Nenhuma outra disponível - tenta todas, incluindo atual se ainda não desabilitou hard
      const allEnabled = this.getEnabledAccounts();
      if (allEnabled.length === 0) {
        this.logger?.warn?.(`[accounts] rotateOnError: no enabled accounts left`);
        try {
          this.saveAccounts();
        } catch {}
        return null;
      }
      // Se só a atual estava disponível e foi colocada em cooldown, não há para onde rotacionar
      // Retorna null e caller deve fazer backoff
      this.logger?.warn?.(
        `[accounts] rotateOnError: only current account ${currentEmail} was enabled, now in cooldown`
      );
      try {
        this.saveAccounts();
      } catch {}
      return null;
    }

    // Round-robin para próxima
    if (this.rotationIdx >= enabled.length) this.rotationIdx = 0;
    const next = enabled[this.rotationIdx];
    this.rotationIdx = (this.rotationIdx + 1) % enabled.length;
    this.store.rotationIndex = this.rotationIdx;
    this.store.activeEmail = next.email;
    next.lastUsedAt = nowMs();

    this.logger?.info?.(
      `[accounts] rotated from ${currentEmail ?? "unknown"} to ${next.email} due to quota error`
    );

    try {
      this.saveAccounts();
    } catch {}

    return next;
  }

  // --------------------------------------------------------------------------
  // TOKEN REFRESH - double-checked locking
  // --------------------------------------------------------------------------

  /**
   * Refresh com double-checked locking
   * - Checa expiry antes de lock
   * - Se lock existente, espera lock e re-checa
   * - Só então realiza refresh
   */
  async refreshAccessTokenIfNeeded(
    email: string,
    force = false
  ): Promise<AccountMetadataV3> {
    const acct = this.findAccount(email);
    if (!acct) throw new Error(`refreshAccessTokenIfNeeded: account not found ${email}`);

    // Fast path - token ainda válido e não force
    if (!force && !isTokenExpired(acct)) {
      return acct;
    }

    const key = normalizeEmail(acct.email);

    // Se já tem lock, aguarda e re-checa (double-checked)
    const existingLock = this.refreshLocks.get(key);
    if (existingLock) {
      this.logger?.debug?.(`[accounts] waiting existing refresh lock for ${acct.email}`);
      const waited = await existingLock;
      // Segunda checagem após lock liberar
      if (!force && !isTokenExpired(waited)) {
        return waited;
      }
      // Se ainda expirou (refresh falhou e manteve token antigo?), continua para novo refresh abaixo
    }

    // Cria novo lock
    const refreshPromise = (async (): Promise<AccountMetadataV3> => {
      // Double-checked locking - segunda checagem dentro do lock
      const fresh = this.findAccount(email);
      if (!fresh) throw new Error(`Account disappeared during refresh ${email}`);

      if (!force && !isTokenExpired(fresh)) {
        return fresh;
      }

      this.logger?.info?.(`[accounts] refreshing access token for ${fresh.email}`);

      try {
        const tokenRes = await performTokenRefresh(fresh);

        // Atualiza conta em memória (pega referência mais recente novamente)
        const targetIdx = this.findAccountIndex(email);
        if (targetIdx < 0) throw new Error(`Account vanished after refresh ${email}`);
        const target = this.store.accounts[targetIdx];

        target.accessToken = tokenRes.access_token;
        target.expiryDate = nowMs() + tokenRes.expires_in * 1000;
        target.lastRefresh = nowMs();
        target.failureCount = 0;
        target.disabledReason = undefined;
        target.disabledUntil = undefined;
        // Garante enabled se foi desabilitado por auth error
        if (!target.enabled && target.disabledReason?.includes("auth")) {
          target.enabled = true;
        }

        // Atualiza projeto? não na etapa de token

        this.saveAccounts();
        this.logger?.info?.(
          `[accounts] refresh OK for ${target.email}, expires in ${tokenRes.expires_in}s`
        );
        return target;
      } catch (err) {
        const status = parseErrorStatus(err);
        const errMsg = (err as Error).message || String(err);

        this.logger?.warn?.(
          `[accounts] refresh failed for ${acct.email}: ${status ?? ""} ${errMsg.slice(0, 300)}`
        );

        // Se refresh falhou por invalid_grant / 400 / 401 -> refresh token inválido, desabilita
        if (
          status === 400 ||
          status === 401 ||
          errMsg.includes("invalid_grant") ||
          errMsg.includes("expired") ||
          errMsg.includes("revoked")
        ) {
          const idx = this.findAccountIndex(email);
          if (idx >= 0) {
            const t = this.store.accounts[idx];
            t.failureCount = (t.failureCount ?? 0) + 1;
            if (t.failureCount >= 2) {
              t.enabled = false;
              t.disabledReason = `refresh failed: ${errMsg.slice(0, 200)}`;
            }
            try {
              this.saveAccounts();
            } catch {}
          }
        }

        throw err;
      }
    })();

    this.refreshLocks.set(key, refreshPromise);

    try {
      const result = await refreshPromise;
      return result;
    } finally {
      // Limpa lock sempre
      if (this.refreshLocks.get(key) === refreshPromise) {
        this.refreshLocks.delete(key);
      }
    }
  }

  /**
   * Retorna access token válido, refrescando se necessário.
   * Se email não fornecido, usa conta ativa (round-robin/sticky)
   */
  async getValidAccessToken(email?: string): Promise<string> {
    let acct: AccountMetadataV3 | null | undefined;

    if (email) {
      acct = this.findAccount(email);
      if (!acct) throw new Error(`getValidAccessToken: account not found ${email}`);
    } else {
      acct = this.getActiveAccount();
      if (!acct) throw new Error(`getValidAccessToken: no active account available`);
    }

    if (!acct.enabled) {
      // Se está em cooldown mas expirou, reabilita lazy
      if (acct.disabledUntil && acct.disabledUntil <= nowMs()) {
        acct.enabled = true;
        acct.disabledUntil = undefined;
        acct.disabledReason = undefined;
        acct.failureCount = 0;
        try {
          this.saveAccounts();
        } catch {}
      } else {
        throw new Error(`Account ${acct.email} is disabled: ${acct.disabledReason ?? "unknown"}`);
      }
    }

    const refreshed = await this.refreshAccessTokenIfNeeded(acct.email);
    if (!refreshed.accessToken) {
      throw new Error(`Failed to obtain access token for ${refreshed.email}`);
    }
    return refreshed.accessToken;
  }

  // --------------------------------------------------------------------------
  // BACKGROUND REFRESH
  // --------------------------------------------------------------------------

  /**
   * Refresh em background de todas contas habilitadas próximas ao expiry
   * - Não bloqueia callers
   * - Usa allSettled para não falhar conjunto
   */
  async backgroundRefresh(): Promise<void> {
    // Reload do disco antes para pegar alterações externas
    try {
      this.loadAccounts();
    } catch {
      // ignora
    }

    const enabled = this.getEnabledAccounts();
    if (enabled.length === 0) return;

    const toRefresh = enabled.filter((a) => {
      // Se tem disabledUntil futuro, pula
      if (a.disabledUntil && a.disabledUntil > nowMs()) return false;
      // Se token falta ou expira em < BACKGROUND buffer, refresh
      return isTokenExpired(a, BACKGROUND_REFRESH_BUFFER_MS);
    });

    if (toRefresh.length === 0) {
      this.logger?.debug?.(`[accounts] backgroundRefresh: no accounts need refresh`);
      return;
    }

    this.logger?.info?.(
      `[accounts] backgroundRefresh: refreshing ${toRefresh.length}/${enabled.length} accounts`
    );

    const results = await Promise.allSettled(
      toRefresh.map((a) => this.refreshAccessTokenIfNeeded(a.email).catch((e) => {
        // Para não quebrar allSettled com throw extra
        throw e;
      }))
    );

    const fails = results.filter((r) => r.status === "rejected").length;
    if (fails > 0) {
      this.logger?.warn?.(`[accounts] backgroundRefresh: ${fails} failures`);
    }
  }

  /**
   * Inicia background refresh sem await (fire-and-forget)
   */
  triggerBackgroundRefresh(): void {
    this.backgroundRefresh().catch(() => {});
  }

  // --------------------------------------------------------------------------
  // IMPORT FROM antigravity-manager
  // --------------------------------------------------------------------------

  private static getAntigravityManagerCandidatePaths(): string[] {
    const home = os.homedir();
    return [
      path.join(home, ".config", "antigravity-manager", "accounts.json"),
      path.join(home, ".antigravity-manager", "accounts.json"),
      path.join(home, ".config", "antigravity-manager", "credentials.json"),
      path.join(home, ".config", "antigravity", "accounts.json"),
      path.join(home, ".antigravity", "accounts.json"),
      path.join(home, ".antigravity", "auth.json"),
      path.join(home, ".config", "antigravity", "auth.json"),
      path.join(home, ".gemini", "antigravity", "accounts.json"),
      path.join(home, ".config", "opencode", "auth", "antigravity-accounts.json"),
      path.join(home, ".config", "opencode", "auth", "gemini-cli-tokens.json"),
      path.join(home, ".config", "opencode", "antigravity.json"),
      // Legacy antigravity-manager sqlite? não, só json
    ];
  }

  private static extractAccountsFromRaw(raw: unknown): unknown[] {
    if (!raw) return [];

    // Caso 1: array direto
    if (Array.isArray(raw)) return raw;

    if (typeof raw !== "object") return [];

    const obj = raw as Record<string, unknown>;

    // Caso 2: { accounts: [...] }
    if (Array.isArray(obj.accounts)) return obj.accounts as unknown[];

    // Caso 3: { credentials: [...] } ou { tokens: [...] }
    if (Array.isArray(obj.credentials)) return obj.credentials as unknown[];
    if (Array.isArray(obj.tokens)) return obj.tokens as unknown[];

    // Caso 4: { <email>: { refresh_token, ... } } map
    const keys = Object.keys(obj);
    const looksLikeEmailMap = keys.some((k) => k.includes("@"));
    if (looksLikeEmailMap) {
      return keys.map((k) => {
        const v = obj[k];
        if (typeof v === "object" && v !== null) {
          return { email: k, ...(v as object) };
        }
        return { email: k, refreshToken: v };
      });
    }

    // Caso 5: { version: ..., data: [...] } wrapper
    if (Array.isArray(obj.data)) return obj.data as unknown[];
    if (obj.data && typeof obj.data === "object") {
      const inner = obj.data as Record<string, unknown>;
      if (Array.isArray(inner.accounts)) return inner.accounts as unknown[];
    }

    // Caso 6: single account object
    if ((obj.email as string) || (obj.refresh_token as string) || (obj.refreshToken as string)) {
      return [raw];
    }

    return [];
  }

  /**
   * Importa contas de instalações antigravity-manager existentes
   * Tenta múltiplos paths e formatos legados, mergeia no store atual sem duplicatas.
   */
  async importFromAntigravityManager(): Promise<ImportResult> {
    const candidates = AccountManager.getAntigravityManagerCandidatePaths();
    const result: ImportResult = {
      imported: 0,
      skipped: 0,
      updated: 0,
      errors: [],
      sources: [],
      accounts: [],
    };

    // Reload atual para merge seguro
    try {
      this.loadAccounts();
    } catch {}

    const existingEmails = new Set(
      this.store.accounts.map((a) => normalizeEmail(a.email))
    );

    for (const p of candidates) {
      // Pula o próprio arquivo de destino para não re-importar a si mesmo
      if (path.resolve(p) === path.resolve(this.storePath)) continue;

      if (!fs.existsSync(p)) continue;

      try {
        const content = fs.readFileSync(p, { encoding: "utf8" });
        const parsed = JSON.parse(content);
        const rawAccounts = AccountManager.extractAccountsFromRaw(parsed);

        if (rawAccounts.length === 0) {
          result.errors.push(`${p}: no accounts extracted`);
          continue;
        }

        result.sources.push(p);
        this.logger?.info?.(`[accounts] import candidate ${p} -> ${rawAccounts.length} raw`);

        for (const raw of rawAccounts) {
          const normalized = normalizeAccountRaw(raw);
          if (!normalized) {
            result.skipped++;
            continue;
          }

          const normEmail = normalizeEmail(normalized.email);
          if (existingEmails.has(normEmail)) {
            // Se já existe, mas novo tem refreshToken diferente ou accessToken mais novo, atualiza?
            const existing = this.findAccount(normEmail);
            if (existing) {
              // Atualiza se: novo accessToken existe e é mais novo, ou refresh token diferente e antigo tem failureCount
              const shouldUpdate =
                (normalized.accessToken &&
                  normalized.expiryDate &&
                  (!existing.expiryDate ||
                    normalized.expiryDate > existing.expiryDate)) ||
                (existing.failureCount ?? 0) > 0;

              if (shouldUpdate) {
                existing.refreshToken = normalized.refreshToken;
                if (normalized.accessToken) existing.accessToken = normalized.accessToken;
                if (normalized.expiryDate) existing.expiryDate = normalized.expiryDate;
                if (normalized.projectId) existing.projectId = normalized.projectId;
                existing.failureCount = 0;
                existing.disabledReason = undefined;
                existing.disabledUntil = undefined;
                existing.enabled = true;
                result.updated++;
              } else {
                result.skipped++;
              }
            } else {
              result.skipped++;
            }
            continue;
          }

          // Força client key antigravity-manager para rastreio
          if (!normalized.oauthClientKey || normalized.oauthClientKey === "gemini-cli") {
            normalized.oauthClientKey = "antigravity-manager";
          }
          // Garante que tem oauth config default se não tem
          if (!normalized.oauthClientConfig) {
            normalized.oauthClientConfig = {
              clientId: GEMINI_CLI_OAUTH_CLIENT_ID,
              clientSecret: GEMINI_CLI_OAUTH_CLIENT_SECRET,
            };
          }

          this.store.accounts.push(normalized);
          existingEmails.add(normEmail);
          result.imported++;
          result.accounts.push(normalized);
        }
      } catch (e) {
        result.errors.push(`${p}: ${(e as Error).message}`);
      }
    }

    if (result.imported > 0 || result.updated > 0) {
      try {
        this.saveAccounts();
      } catch (e) {
        result.errors.push(`save after import failed: ${(e as Error).message}`);
      }
    }

    this.logger?.info?.(
      `[accounts] import finished: imported=${result.imported} updated=${result.updated} skipped=${result.skipped} sources=${result.sources.length}`
    );

    return result;
  }

  /** Alias compat solicitado na tarefa */
  async importFromAntigravity(): Promise<ImportResult> {
    return this.importFromAntigravityManager();
  }

  /** Alias adicional para retrocompatibilidade */
  async importAccounts(): Promise<ImportResult> {
    return this.importFromAntigravityManager();
  }

  // --------------------------------------------------------------------------
  // LIFECYCLE / UTIL
  // --------------------------------------------------------------------------

  /** Limpa timer de background (útil em testes) */
  destroy(): void {
    if (this.backgroundTimer) {
      clearInterval(this.backgroundTimer);
      this.backgroundTimer = undefined;
    }
    this.refreshLocks.clear();
  }

  /** Path do arquivo */
  getStorePath(): string {
    return this.storePath;
  }

  /** Store raw (clone) */
  getStore(): AccountStore {
    return {
      ...this.store,
      accounts: [...this.store.accounts],
    };
  }

  /** Define estratégia de rotação */
  setRotationStrategy(strategy: RotationStrategy): void {
    this.store.rotationStrategy = strategy;
    this.saveAccounts();
  }
}

// ============================================================================
// 06. SINGLETON DEFAULT + HELPERS DE EXPORT
// ============================================================================

let _defaultManager: AccountManager | null = null;

/** Retorna instância singleton default (lazy) */
export function getDefaultAccountManager(
  opts?: AccountManagerOptions
): AccountManager {
  if (!_defaultManager) {
    _defaultManager = new AccountManager(opts);
  }
  return _defaultManager;
}

/** Reseta singleton (testes) */
export function resetDefaultAccountManager(): void {
  if (_defaultManager) {
    _defaultManager.destroy();
    _defaultManager = null;
  }
}

/** Helper rápido para obter token válido usando singleton */
export async function getValidAccessToken(
  email?: string,
  opts?: AccountManagerOptions
): Promise<string> {
  const mgr = getDefaultAccountManager(opts);
  return mgr.getValidAccessToken(email);
}

/** Helper rápido para obter conta ativa */
export function getActiveAccount(opts?: AccountManagerOptions): AccountMetadataV3 | null {
  const mgr = getDefaultAccountManager(opts);
  return mgr.getActiveAccount();
}

// ============================================================================
// 07. EXPORT DEFAULT - compat CJS/ESM
// ============================================================================

export default AccountManager;

export const ACCOUNTS_FILE_PATH = resolveAccountsFilePath();

export const CONSTANTS = {
  CLIENT_ID_RAW: GEMINI_CLI_CLIENT_ID_RAW,
  CLIENT_ID: GEMINI_CLI_OAUTH_CLIENT_ID,
  CLIENT_SECRET: GEMINI_CLI_OAUTH_CLIENT_SECRET,
  SCOPES: OAUTH_SCOPES,
  TOKEN_URL: OAUTH_TOKEN_URL,
  USER_AGENT: GEMINI_CLI_USER_AGENT,
  USER_AGENT_FULL: GEMINI_CLI_USER_AGENT_FULL,
  X_GOOG_API_CLIENT,
  CLIENT_METADATA,
  CLOUDCODE_BASE_URL,
  CLOUDCODE_ENDPOINTS,
  PROJECT_FALLBACK,
  MODELS_2026,
  ACCOUNTS_FILE_PATH,
} as const;
