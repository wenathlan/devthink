/**
 * @fileoverview recovery.ts - ONDA 4 - Plugin Core
 * @module auth/recovery
 * @description Motor de auto-recovery completo produção-ready para o plugin
 *              opencode-antigravity-auth com bypass Gemini CLI.
 *
 *              Responsabilidades:
 *              - Cache LRU interno para signatures de thinking (evita revalidação e preserva integridade)
 *              - Detectores de erros: thinking block signature inválida, tool_use sem thinking,
 *                session boundary e falhas de tool
 *              - Estratégias de recuperação: continue, undo guidance, keep_thinking preservation
 *                e injeção de thinking preservado entre turns
 *              - Utilitários de detecção, construção de planos de recovery, helpers de transformação
 *              - Wrapper withAutoRecovery com backoff exponencial + jitter
 *
 *              Zero dependências externas: apenas node:* builtins + fetch global.
 *              Compatível com Models 2026 e spoof Gemini CLI oficial.
 *
 * @author ONDA 4 - Plugin Core
 * @license MIT
 * @since 2026
 */

import * as crypto from "node:crypto";

// ============================================================================
// 00. CONSTANTES CANÔNICAS DO BYPASS (duplicadas localmente para zero-dep)
// ============================================================================

export const GEMINI_CLI_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;
export const GEMINI_CLI_CLIENT_SECRET = "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" as const;

export const GEMINI_CLI_USER_AGENT =
  "GeminiCLI/0.35.3 (linux; x64; GitHub) google-api-nodejs-client/9.15.1" as const;
export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;
export const X_CLIENT_METADATA_RAW =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;
export const CODE_ASSIST_BASE = "https://cloudcode-pa.googleapis.com" as const;

export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type ModelId2026 = (typeof MODELS_2026)[number];

const MODELS_2026_SET = new Set<string>(MODELS_2026 as readonly string[]);
const THINKING_MODELS_2026 = new Set<string>([
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
  "gemini-2.5-pro",
]);

// ============================================================================
// 01. TIPOS FUNDAMENTAIS - COMPAT ANTHROPIC / GEMINI / OPENCODE
// ============================================================================

export type Role = "user" | "assistant" | "system" | "tool";

export interface ThinkingBlock {
  type: "thinking";
  thinking: string;
  signature?: string;
  // alguns proxies retornam redacted_thinking
  redacted_thinking?: string;
  // metadados internos
  _preserved?: boolean;
  _injected?: boolean;
}

export interface TextBlock {
  type: "text";
  text: string;
}

export interface ToolUseBlock {
  type: "tool_use";
  id: string;
  name: string;
  input: unknown;
  // flag interna
  _missingThinking?: boolean;
}

export interface ToolResultBlock {
  type: "tool_result";
  tool_use_id: string;
  content: string | Array<{ type: string; text?: string }>;
  is_error?: boolean;
}

export type ContentBlock = ThinkingBlock | TextBlock | ToolUseBlock | ToolResultBlock | Record<string, unknown>;

export interface ChatMessage {
  role: Role;
  content: string | ContentBlock[];
  // alguns SDKs permitem array direto
  _sessionId?: string;
  _timestamp?: number;
}

export type ChatMessages = ChatMessage[];

// Error detection result
export type RecoveryErrorCode =
  | "INVALID_THINKING_SIGNATURE"
  | "TOOL_USE_WITHOUT_THINKING"
  | "SESSION_BOUNDARY"
  | "TOOL_FAILURE"
  | "CONTEXT_OVERFLOW"
  | "RATE_LIMIT"
  | "UNKNOWN";

export interface DetectedError {
  code: RecoveryErrorCode;
  message: string;
  details?: Record<string, unknown>;
  recoverable: boolean;
  index?: number; // message index onde ocorreu
  blockIndex?: number;
}

export interface DetectionReport {
  errors: DetectedError[];
  hasInvalidSignature: boolean;
  hasMissingThinking: boolean;
  hasSessionBoundary: boolean;
  hasToolFailure: boolean;
  shouldRecover: boolean;
}

// Recovery strategies
export type RecoveryStrategy =
  | "STRIP_INVALID_SIGNATURE"
  | "INJECT_PRESERVED_THINKING"
  | "KEEP_THINKING_PRESERVE"
  | "CONTINUE_RESUME"
  | "UNDO_GUIDANCE"
  | "RETRY_WITH_BACKOFF"
  | "REBUILD_MESSAGES"
  | "RESET_THINKING_CACHE";

export interface RecoveryAction {
  strategy: RecoveryStrategy;
  reason: string;
  priority: number; // menor = executa primeiro
  payload?: Record<string, unknown>;
}

export interface RecoveryPlan {
  id: string;
  createdAt: number;
  errors: DetectedError[];
  actions: RecoveryAction[];
  transformedMessages?: ChatMessages;
  keepThinking?: string | null;
  preservedSignature?: string | null;
  shouldRetry: boolean;
  retryDelayMs?: number;
  metadata?: Record<string, unknown>;
}

// Wrapper executor types
export type ExecutorFn<T = unknown> = (
  messages: ChatMessages,
  opts?: { signal?: AbortSignal; attempt?: number; plan?: RecoveryPlan },
) => Promise<T>;

export interface AutoRecoveryOptions {
  maxAttempts?: number; // default 4
  baseDelayMs?: number; // default 450
  maxDelayMs?: number; // default 7500
  jitter?: boolean; // default true
  failFastOnNonRecoverable?: boolean; // default true
  modelId?: ModelId2026 | string;
  sessionId?: string;
  preservationStore?: ThinkingPreservationStore;
  signatureCache?: ThinkingSignatureCache;
  onRecoveryAttempt?: (attempt: number, plan: RecoveryPlan, delayMs: number) => void;
  onDetectedErrors?: (report: DetectionReport) => void;
  signal?: AbortSignal;
  logger?: Pick<Console, "debug" | "info" | "warn" | "error">;
}

// ============================================================================
// 02. LRU CACHE GENÉRICO - PRODUÇÃO READY
// ============================================================================

/**
 * LRUCache genérico implementação zero-dep, produção-ready.
 * - O(1) get/set via Map ordered
 * - Eviction LRU automática
 * - Stats para observabilidade
 */
export class LRUCache<K, V> {
  private readonly capacity: number;
  private readonly cache: Map<K, V>;
  private hits = 0;
  private misses = 0;
  private evictions = 0;

  constructor(capacity: number) {
    if (!Number.isFinite(capacity) || capacity <= 0) {
      throw new Error(`LRUCache capacity must be >0, got ${capacity}`);
    }
    this.capacity = Math.floor(capacity);
    this.cache = new Map<K, V>();
  }

  get(key: K): V | undefined {
    if (!this.cache.has(key)) {
      this.misses++;
      return undefined;
    }
    const value = this.cache.get(key)!;
    // move to MRU end
    this.cache.delete(key);
    this.cache.set(key, value);
    this.hits++;
    return value;
  }

  set(key: K, value: V): void {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= this.capacity) {
      const lruKey = this.cache.keys().next().value as K;
      this.cache.delete(lruKey);
      this.evictions++;
    }
    this.cache.set(key, value);
  }

  has(key: K): boolean {
    return this.cache.has(key);
  }

  delete(key: K): boolean {
    return this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
    this.hits = 0;
    this.misses = 0;
    this.evictions = 0;
  }

  get size(): number {
    return this.cache.size;
  }

  get cap(): number {
    return this.capacity;
  }

  keys(): IterableIterator<K> {
    return this.cache.keys();
  }

  values(): IterableIterator<V> {
    return this.cache.values();
  }

  entries(): IterableIterator<[K, V]> {
    return this.cache.entries();
  }

  toArray(): Array<[K, V]> {
    return [...this.cache.entries()];
  }

  // MRU -> LRU
  toMRUArray(): Array<[K, V]> {
    return [...this.cache.entries()].reverse();
  }

  stats(): { size: number; capacity: number; hits: number; misses: number; evictions: number; hitRate: number } {
    const total = this.hits + this.misses;
    return {
      size: this.cache.size,
      capacity: this.capacity,
      hits: this.hits,
      misses: this.misses,
      evictions: this.evictions,
      hitRate: total === 0 ? 0 : this.hits / total,
    };
  }
}

// ============================================================================
// 03. THINKING SIGNATURE CACHE - LRU ESPECÍFICO PARA SIGNATURES
// ============================================================================

export interface ThinkingSignatureEntry {
  signature: string;
  thinkingHash: string;
  thinkingPreview: string; // first 120 chars
  modelId: string;
  createdAt: number;
  lastUsedAt: number;
  useCount: number;
  valid: boolean;
  length: number;
}

export function fnv1a32(input: string): number {
  let hash = 0x811c9dc5;
  const buf = Buffer.from(input, "utf8");
  for (let i = 0; i < buf.length; i++) {
    hash ^= buf[i]!;
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

export function hashThinkingContent(thinking: string): string {
  // usa sha256 truncado para colisão baixa + fnv para velocidade fallback
  try {
    const sha = crypto.createHash("sha256").update(thinking, "utf8").digest("hex").slice(0, 16);
    const fnv = fnv1a32(thinking).toString(16).padStart(8, "0");
    return `${sha}_${fnv}`;
  } catch {
    const fnv = fnv1a32(thinking).toString(16).padStart(8, "0");
    return `fnv_${fnv}`;
  }
}

export function isBase64ishSig(sig: string): boolean {
  if (!sig || typeof sig !== "string") return false;
  const trimmed = sig.trim();
  if (trimmed.length < 16) return false; // signatures curtas são inválidas
  if (trimmed.length > 8192) return false; // anomalia
  // base64 + url safe
  const b64re = /^[A-Za-z0-9+/=_-]+$/;
  if (!b64re.test(trimmed)) return false;
  // pelo menos algum padding ou comprimento múltiplo heurístico não exigido, mas deve decodificar parcialmente
  try {
    // tenta decodificar: se for url-safe converte
    const normalized = trimmed.replace(/-/g, "+").replace(/_/g, "/");
    const buf = Buffer.from(normalized, "base64");
    if (buf.length < 8) return false; // muito curta decodificada
    return true;
  } catch {
    return false;
  }
}

export function isValidThinkingSignature(signature: unknown): boolean {
  if (typeof signature !== "string") return false;
  if (signature.trim().length === 0) return false;
  return isBase64ishSig(signature);
}

export class ThinkingSignatureCache {
  private readonly lru: LRUCache<string, ThinkingSignatureEntry>;
  private readonly hashToSig: Map<string, string>; // thinkingHash -> signature

  constructor(capacity = 256) {
    this.lru = new LRUCache<string, ThinkingSignatureEntry>(capacity);
    this.hashToSig = new Map<string, string>();
  }

  /**
   * Salva signature válida associada a thinking content.
   */
  store(thinking: string, signature: string, modelId = PROJECT_FALLBACK): ThinkingSignatureEntry | null {
    if (!thinking || !isValidThinkingSignature(signature)) return null;
    const thinkingHash = hashThinkingContent(thinking);
    const now = Date.now();
    const entry: ThinkingSignatureEntry = {
      signature,
      thinkingHash,
      thinkingPreview: thinking.slice(0, 120),
      modelId,
      createdAt: now,
      lastUsedAt: now,
      useCount: 1,
      valid: true,
      length: signature.length,
    };
    this.lru.set(signature, entry);
    this.hashToSig.set(thinkingHash, signature);
    return entry;
  }

  getBySignature(signature: string): ThinkingSignatureEntry | undefined {
    const entry = this.lru.get(signature);
    if (entry) {
      entry.lastUsedAt = Date.now();
      entry.useCount++;
    }
    return entry;
  }

  getByThinking(thinking: string): ThinkingSignatureEntry | undefined {
    const h = hashThinkingContent(thinking);
    const sig = this.hashToSig.get(h);
    if (!sig) return undefined;
    return this.getBySignature(sig);
  }

  getByHash(hash: string): ThinkingSignatureEntry | undefined {
    const sig = this.hashToSig.get(hash);
    if (!sig) return undefined;
    return this.getBySignature(sig);
  }

  hasValid(thinking: string, signature: string): boolean {
    if (!isValidThinkingSignature(signature)) return false;
    const bySig = this.lru.get(signature);
    if (!bySig) return false;
    return bySig.valid && bySig.thinkingHash === hashThinkingContent(thinking);
  }

  /**
   * Tenta recuperar signature válida para um thinking preservado.
   */
  tryRestore(thinking: string): string | null {
    const entry = this.getByThinking(thinking);
    if (!entry || !entry.valid) return null;
    if (!isValidThinkingSignature(entry.signature)) return null;
    return entry.signature;
  }

  invalidate(signature: string): void {
    const entry = this.lru.get(signature);
    if (entry) {
      entry.valid = false;
    }
  }

  sweepInvalid(): number {
    let removed = 0;
    for (const [sig, entry] of this.lru.toArray()) {
      if (!entry.valid || !isValidThinkingSignature(entry.signature)) {
        this.lru.delete(sig);
        this.hashToSig.delete(entry.thinkingHash);
        removed++;
      }
    }
    return removed;
  }

  size(): number {
    return this.lru.size;
  }

  stats() {
    return this.lru.stats();
  }

  clear(): void {
    this.lru.clear();
    this.hashToSig.clear();
  }

  recentValidSignatures(limit = 5): ThinkingSignatureEntry[] {
    return this.lru
      .toMRUArray()
      .map(([, v]) => v)
      .filter((e) => e.valid)
      .slice(0, limit);
  }
}

// Singleton global (pode ser resetado em testes)
let globalSignatureCache: ThinkingSignatureCache | null = null;

export function getGlobalSignatureCache(): ThinkingSignatureCache {
  if (!globalSignatureCache) {
    globalSignatureCache = new ThinkingSignatureCache(256);
  }
  return globalSignatureCache;
}

export function resetGlobalSignatureCache(): void {
  globalSignatureCache?.clear();
  globalSignatureCache = null;
}

// ============================================================================
// 04. THINKING PRESERVATION STORE - KEEP_THINKING ENTRE TURNS
// ============================================================================

export interface PreservedThinking {
  id: string;
  sessionId: string;
  thinking: string;
  signature: string | null;
  modelId: string;
  messageIndex: number;
  createdAt: number;
  lastInjectedAt?: number;
  injectCount: number;
}

export class ThinkingPreservationStore {
  private readonly store: LRUCache<string, PreservedThinking>; // sessionId -> preserved
  private readonly history: LRUCache<string, PreservedThinking[]>; // sessionId -> list últimas

  constructor(capacity = 128) {
    this.store = new LRUCache<string, PreservedThinking>(capacity);
    this.history = new LRUCache<string, PreservedThinking[]>(capacity);
  }

  preserve(
    sessionId: string,
    thinking: string,
    signature: string | null,
    modelId: string,
    messageIndex: number,
  ): PreservedThinking {
    const id = `${sessionId}:${Date.now()}:${fnv1a32(thinking).toString(16)}`;
    const entry: PreservedThinking = {
      id,
      sessionId,
      thinking,
      signature: signature && isValidThinkingSignature(signature) ? signature : null,
      modelId,
      messageIndex,
      createdAt: Date.now(),
      injectCount: 0,
    };
    this.store.set(sessionId, entry);
    // histórico
    const hist = this.history.get(sessionId) ?? [];
    hist.unshift(entry);
    if (hist.length > 10) hist.pop();
    this.history.set(sessionId, hist);
    return entry;
  }

  get(sessionId: string): PreservedThinking | undefined {
    return this.store.get(sessionId);
  }

  getHistory(sessionId: string): PreservedThinking[] {
    return this.history.get(sessionId) ?? [];
  }

  markInjected(sessionId: string): void {
    const entry = this.store.get(sessionId);
    if (entry) {
      entry.lastInjectedAt = Date.now();
      entry.injectCount++;
    }
  }

  clear(sessionId?: string): void {
    if (sessionId) {
      this.store.delete(sessionId);
      this.history.delete(sessionId);
    } else {
      this.store.clear();
      this.history.clear();
    }
  }

  /**
   * Retorna thinking mais recente válido para injeção, se existir.
   */
  getInjectable(sessionId: string): PreservedThinking | null {
    const entry = this.store.get(sessionId);
    if (!entry) return null;
    if (!entry.thinking || entry.thinking.trim().length < 8) return null;
    return entry;
  }
}

let globalPreservationStore: ThinkingPreservationStore | null = null;

export function getGlobalPreservationStore(): ThinkingPreservationStore {
  if (!globalPreservationStore) {
    globalPreservationStore = new ThinkingPreservationStore(128);
  }
  return globalPreservationStore;
}

export function resetGlobalPreservationStore(): void {
  globalPreservationStore?.clear();
  globalPreservationStore = null;
}

// ============================================================================
// 05. DETECTORES DE ERROS - THINKING SIGNATURE, TOOL_USE SEM THINKING, ETC
// ============================================================================

export const DETECTOR_PATTERNS = {
  invalidSignature: [
    /thinking.*signature.*invalid/i,
    /signature.*invalid.*thinking/i,
    /invalid.*thinking.*block/i,
    /thinking.*block.*signature/i,
    /signature.*must.*be.*provided/i,
    /thinking.*requires.*signature/i,
    /redacted.*thinking.*mismatch/i,
    /signature.*malformed/i,
    /anthropic.*thinking.*signature/i,
  ],
  missingThinkingForToolUse: [
    /tool_use.*requires.*thinking/i,
    /thinking.*required.*before.*tool_use/i,
    /tool_use.*without.*thinking/i,
    /expected.*thinking.*block/i,
    /missing.*thinking.*block/i,
    /thinking.*must.*precede.*tool/i,
  ],
  sessionBoundary: [
    /session.*boundary/i,
    /conversation.*too.*long/i,
    /context.*window.*exceeded/i,
    /maximum.*context/i,
    /token.*limit.*exceeded/i,
    /conversation.*ended/i,
    /session.*expired/i,
    /please.*start.*new.*conversation/i,
    /context.*length.*exceeded/i,
    /input.*too.*long/i,
  ],
  toolFailure: [
    /tool.*failed/i,
    /tool.*error/i,
    /tool_use.*failed/i,
    /execution.*failed/i,
    /tool.*exception/i,
  ],
  contextOverflow: [
    /prompt.*too.*long/i,
    /too.*many.*tokens/i,
    /context.*overflow/i,
    /max.*tokens.*exceeded/i,
  ],
  rateLimit: [
    /rate.*limit/i,
    /quota.*exceeded/i,
    /too.*many.*requests/i,
    /429/,
    /resource.*exhausted/i,
  ],
};

function matchPatterns(text: string, patterns: RegExp[]): boolean {
  return patterns.some((re) => re.test(text));
}

function stringifyError(err: unknown): string {
  if (!err) return "";
  if (typeof err === "string") return err;
  if (err instanceof Error) return `${err.name}: ${err.message}\n${(err as any).stack ?? ""}`;
  try {
    return JSON.stringify(err);
  } catch {
    return String(err);
  }
}

function extractBlocks(message: ChatMessage): ContentBlock[] {
  const c = message.content;
  if (typeof c === "string") return [{ type: "text", text: c } as TextBlock];
  if (Array.isArray(c)) return c as ContentBlock[];
  return [];
}

/**
 * Detector: thinking block com signature inválida
 */
export function detectInvalidSignatureBlocks(messages: ChatMessages): DetectedError[] {
  const errors: DetectedError[] = [];
  messages.forEach((msg, msgIdx) => {
    if (msg.role !== "assistant") return;
    const blocks = extractBlocks(msg);
    blocks.forEach((blk: any, blkIdx) => {
      if (blk?.type !== "thinking") return;
      const thinking = blk.thinking ?? blk.redacted_thinking ?? "";
      const sig = blk.signature;
      // casos inválidos:
      // - thinking não vazio mas signature ausente
      // - signature presente mas malformada
      // - thinking redacted sem signature
      if (typeof thinking === "string" && thinking.trim().length > 0) {
        if (sig == null || typeof sig !== "string" || sig.trim() === "") {
          errors.push({
            code: "INVALID_THINKING_SIGNATURE",
            message: `Thinking block at msg ${msgIdx} blk ${blkIdx} missing signature`,
            details: { msgIdx, blkIdx, thinkingPreview: thinking.slice(0, 80) },
            recoverable: true,
            index: msgIdx,
            blockIndex: blkIdx,
          });
        } else if (!isValidThinkingSignature(sig)) {
          errors.push({
            code: "INVALID_THINKING_SIGNATURE",
            message: `Thinking block at msg ${msgIdx} blk ${blkIdx} has malformed signature: ${String(sig).slice(0, 30)}`,
            details: { msgIdx, blkIdx, sigPreview: String(sig).slice(0, 40), thinkingPreview: thinking.slice(0, 80) },
            recoverable: true,
            index: msgIdx,
            blockIndex: blkIdx,
          });
        }
      } else if (blk.redacted_thinking && !blk.signature) {
        // redacted thinking requires signature in Anthropic API 2026
        errors.push({
          code: "INVALID_THINKING_SIGNATURE",
          message: `Redacted thinking at msg ${msgIdx} blk ${blkIdx} missing signature`,
          details: { msgIdx, blkIdx },
          recoverable: true,
          index: msgIdx,
          blockIndex: blkIdx,
        });
      }
    });
  });
  return errors;
}

/**
 * Detector: tool_use sem thinking preceding quando thinking mode ativo
 */
export function detectToolUseWithoutThinking(messages: ChatMessages, modelId?: string): DetectedError[] {
  const errors: DetectedError[] = [];
  const isThinkingModel = modelId ? THINKING_MODELS_2026.has(modelId) : true; // default assume thinking necessário
  if (!isThinkingModel) return errors;

  messages.forEach((msg, msgIdx) => {
    if (msg.role !== "assistant") return;
    const blocks = extractBlocks(msg);
    let hasThinkingBeforeTool = false;
    // varre sequencial
    for (let i = 0; i < blocks.length; i++) {
      const b: any = blocks[i];
      if (b?.type === "thinking" && typeof b.thinking === "string" && b.thinking.trim().length > 0) {
        hasThinkingBeforeTool = true;
      }
      if (b?.type === "tool_use") {
        if (!hasThinkingBeforeTool) {
          // verifica se há thinking em mensagem assistant anterior recente preservada? se não, erro
          errors.push({
            code: "TOOL_USE_WITHOUT_THINKING",
            message: `tool_use '${b.name ?? "unknown"}' at msg ${msgIdx} blk ${i} without preceding thinking block`,
            details: { msgIdx, blockIndex: i, toolName: b.name, toolId: b.id },
            recoverable: true,
            index: msgIdx,
            blockIndex: i,
          });
        }
        // Após tool_use, reset flag para próximo tool_use na mesma mensagem? Anthropic requer thinking only once per turn geralmente,
        // mas para safety consideramos que um thinking cobre todos tool_use do mesmo turn.
        // então não resetamos.
      }
    }
  });
  return errors;
}

/**
 * Detector: session boundary / context overflow a partir de erro e mensagens
 */
export function detectSessionBoundary(error: unknown, messages?: ChatMessages): DetectedError[] {
  const errors: DetectedError[] = [];
  const errStr = stringifyError(error);

  if (matchPatterns(errStr, DETECTOR_PATTERNS.sessionBoundary)) {
    errors.push({
      code: "SESSION_BOUNDARY",
      message: `Session boundary detected: ${errStr.slice(0, 200)}`,
      details: { raw: errStr.slice(0, 500) },
      recoverable: true,
    });
  }
  if (matchPatterns(errStr, DETECTOR_PATTERNS.contextOverflow)) {
    errors.push({
      code: "CONTEXT_OVERFLOW",
      message: `Context overflow detected: ${errStr.slice(0, 200)}`,
      details: { raw: errStr.slice(0, 500) },
      recoverable: true,
    });
  }
  if (matchPatterns(errStr, DETECTOR_PATTERNS.rateLimit)) {
    errors.push({
      code: "RATE_LIMIT",
      message: `Rate limit / quota: ${errStr.slice(0, 200)}`,
      details: { raw: errStr.slice(0, 500) },
      recoverable: true,
    });
  }

  // Heurística sobre mensagens: se última mensagem assistant muito longa truncada
  if (messages && messages.length > 0) {
    const last = messages[messages.length - 1];
    if (last.role === "assistant") {
      const blocks = extractBlocks(last);
      const textLen = blocks.reduce((acc: number, b: any) => {
        if (b?.type === "text" && typeof b.text === "string") return acc + b.text.length;
        if (b?.type === "thinking" && typeof b.thinking === "string") return acc + b.thinking.length;
        return acc;
      }, 0);
      if (textLen > 120_000) {
        errors.push({
          code: "CONTEXT_OVERFLOW",
          message: `Last assistant message too long (${textLen} chars) likely truncated`,
          details: { textLen },
          recoverable: true,
          index: messages.length - 1,
        });
      }
    }
    // se conversa > 200 mensagens, risco de boundary
    if (messages.length > 180) {
      errors.push({
        code: "SESSION_BOUNDARY",
        message: `Conversation very long (${messages.length} messages), possible session boundary`,
        details: { messageCount: messages.length },
        recoverable: false, // só observação, não auto recover a menos que haja erro explícito
      });
    }
  }

  return errors;
}

/**
 * Detector: falhas de tool_result com is_error
 */
export function detectToolFailures(messages: ChatMessages): DetectedError[] {
  const errors: DetectedError[] = [];
  messages.forEach((msg, msgIdx) => {
    if (msg.role !== "tool" && !(msg.role === "user" && Array.isArray(msg.content))) {
      // em Anthropic, tool_result vem como user role com block tool_result
      // cobre ambos formatos
      if (msg.role !== "user") return;
    }
    const blocks = extractBlocks(msg);
    blocks.forEach((blk: any, blkIdx) => {
      if (blk?.type !== "tool_result") return;
      if (blk.is_error) {
        const contentStr = typeof blk.content === "string" ? blk.content : JSON.stringify(blk.content).slice(0, 400);
        errors.push({
          code: "TOOL_FAILURE",
          message: `Tool failure at msg ${msgIdx} blk ${blkIdx} id ${blk.tool_use_id}: ${contentStr.slice(0, 150)}`,
          details: { msgIdx, blkIdx, tool_use_id: blk.tool_use_id, contentPreview: contentStr.slice(0, 200) },
          recoverable: true,
          index: msgIdx,
          blockIndex: blkIdx,
        });
      }
      // também detecta conteúdo com padrões de erro mesmo se is_error false (proxy as vezes esconde)
      if (typeof blk.content === "string" && matchPatterns(blk.content, DETECTOR_PATTERNS.toolFailure)) {
        errors.push({
          code: "TOOL_FAILURE",
          message: `Tool failure pattern in content at msg ${msgIdx} blk ${blkIdx}`,
          details: { msgIdx, blkIdx, tool_use_id: blk.tool_use_id, contentPreview: blk.content.slice(0, 200) },
          recoverable: true,
          index: msgIdx,
          blockIndex: blkIdx,
        });
      }
    });
  });
  return errors;
}

/**
 * Detector: erro bruto da API (HTTP / JSON) contendo assinatura inválida
 */
export function detectInvalidSignatureFromError(error: unknown): DetectedError[] {
  const errStr = stringifyError(error);
  if (!matchPatterns(errStr, DETECTOR_PATTERNS.invalidSignature) && !matchPatterns(errStr, DETECTOR_PATTERNS.missingThinkingForToolUse)) {
    return [];
  }
  const errors: DetectedError[] = [];
  if (matchPatterns(errStr, DETECTOR_PATTERNS.invalidSignature)) {
    errors.push({
      code: "INVALID_THINKING_SIGNATURE",
      message: `API reports invalid thinking signature: ${errStr.slice(0, 250)}`,
      details: { raw: errStr.slice(0, 600) },
      recoverable: true,
    });
  }
  if (matchPatterns(errStr, DETECTOR_PATTERNS.missingThinkingForToolUse)) {
    errors.push({
      code: "TOOL_USE_WITHOUT_THINKING",
      message: `API reports tool_use without thinking: ${errStr.slice(0, 250)}`,
      details: { raw: errStr.slice(0, 600) },
      recoverable: true,
    });
  }
  return errors;
}

/**
 * Orquestrador completo de detecção
 */
export function detectAllErrors(error: unknown, messages: ChatMessages, modelId?: string): DetectionReport {
  const fromErrorSig = detectInvalidSignatureFromError(error);
  const fromBlocksSig = detectInvalidSignatureBlocks(messages);
  const fromMissingThinking = detectToolUseWithoutThinking(messages, modelId);
  const fromSession = detectSessionBoundary(error, messages);
  const fromTool = detectToolFailures(messages);

  const all = [...fromErrorSig, ...fromBlocksSig, ...fromMissingThinking, ...fromSession, ...fromTool];

  const hasInvalidSignature = all.some((e) => e.code === "INVALID_THINKING_SIGNATURE");
  const hasMissingThinking = all.some((e) => e.code === "TOOL_USE_WITHOUT_THINKING");
  const hasSessionBoundary = all.some((e) => e.code === "SESSION_BOUNDARY" || e.code === "CONTEXT_OVERFLOW");
  const hasToolFailure = all.some((e) => e.code === "TOOL_FAILURE");

  const recoverableCount = all.filter((e) => e.recoverable).length;

  return {
    errors: all,
    hasInvalidSignature,
    hasMissingThinking,
    hasSessionBoundary,
    hasToolFailure,
    shouldRecover: recoverableCount > 0,
  };
}

// ============================================================================
// 06. CONSTRUÇÃO DE PLANOS DE RECOVERY
// ============================================================================

function genPlanId(): string {
  try {
    return `rcv_${crypto.randomBytes(6).toString("hex")}_${Date.now().toString(36)}`;
  } catch {
    return `rcv_${Math.random().toString(36).slice(2, 10)}_${Date.now().toString(36)}`;
  }
}

export interface BuildPlanOptions {
  sessionId?: string;
  modelId?: string;
  preservationStore?: ThinkingPreservationStore;
  signatureCache?: ThinkingSignatureCache;
  messages: ChatMessages;
}

export function buildRecoveryPlan(report: DetectionReport, opts: BuildPlanOptions): RecoveryPlan {
  const actions: RecoveryAction[] = [];
  let keepThinking: string | null = null;
  let preservedSignature: string | null = null;

  const preservationStore = opts.preservationStore ?? getGlobalPreservationStore();
  const signatureCache = opts.signatureCache ?? getGlobalSignatureCache();
  const sessionId = opts.sessionId ?? "default";

  // prioridade: 0 = mais urgente
  if (report.hasInvalidSignature) {
    actions.push({
      strategy: "STRIP_INVALID_SIGNATURE",
      reason: "Remove thinking blocks com signature inválida e tenta restaurar do cache LRU",
      priority: 0,
      payload: {
        invalidCount: report.errors.filter((e) => e.code === "INVALID_THINKING_SIGNATURE").length,
      },
    });
    // tenta restaurar thinking via cache
    const preserved = preservationStore.getInjectable(sessionId);
    if (preserved) {
      keepThinking = preserved.thinking;
      preservedSignature = preserved.signature ?? signatureCache.tryRestore(preserved.thinking) ?? null;

      if (preserved.thinking && preservedSignature) {
        actions.push({
          strategy: "INJECT_PRESERVED_THINKING",
          reason: `Injeta thinking preservado da sessão ${sessionId} com signature restaurada do cache`,
          priority: 1,
          payload: {
            preservedId: preserved.id,
            hasSignature: !!preservedSignature,
            thinkingPreview: preserved.thinking.slice(0, 60),
          },
        });
      }
    } else {
      // fallback: recent valid signatures do cache global
      const recent = signatureCache.recentValidSignatures(1)[0];
      if (recent) {
        actions.push({
          strategy: "INJECT_PRESERVED_THINKING",
          reason: "Cache LRU tem signature válida recente para tentar injeção",
          priority: 1,
          payload: { recentModelId: recent.modelId, sigLen: recent.length },
        });
      }
    }
  }

  if (report.hasMissingThinking) {
    actions.push({
      strategy: "KEEP_THINKING_PRESERVE",
      reason: "tool_use sem thinking - preservar thinking entre turns e injetar",
      priority: 2,
      payload: {
        missingCount: report.errors.filter((e) => e.code === "TOOL_USE_WITHOUT_THINKING").length,
      },
    });

    if (!keepThinking) {
      const preserved = preservationStore.getInjectable(sessionId);
      if (preserved) {
        keepThinking = preserved.thinking;
        preservedSignature = preserved.signature ?? signatureCache.tryRestore(preserved.thinking) ?? null;
        actions.push({
          strategy: "INJECT_PRESERVED_THINKING",
          reason: "Injeta thinking preservado para satisfazer requirement thinking->tool_use",
          priority: 3,
          payload: { preservedId: preserved.id },
        });
      } else {
        // gera thinking sintético mínimo se nada preservado - último recurso
        actions.push({
          strategy: "KEEP_THINKING_PRESERVE",
          reason: "Sem thinking preservado - será gerado placeholder pensando curto para desbloqueio",
          priority: 4,
          payload: { synthetic: true },
        });
      }
    }
  }

  if (report.hasToolFailure) {
    actions.push({
      strategy: "UNDO_GUIDANCE",
      reason: "Tool falhou - injetar guidance de undo / correção",
      priority: 5,
      payload: {
        failCount: report.errors.filter((e) => e.code === "TOOL_FAILURE").length,
        failures: report.errors.filter((e) => e.code === "TOOL_FAILURE").map((e) => e.details),
      },
    });
  }

  if (report.hasSessionBoundary) {
    actions.push({
      strategy: "CONTINUE_RESUME",
      reason: "Session boundary / context overflow - usar strategy continue",
      priority: 6,
      payload: {
        boundaryErrors: report.errors.filter((e) => e.code === "SESSION_BOUNDARY" || e.code === "CONTEXT_OVERFLOW"),
      },
    });
    actions.push({
      strategy: "REBUILD_MESSAGES",
      reason: "Reconstruir histórico compactando mensagens antigas para caber contexto",
      priority: 7,
    });
  }

  // Sempre finaliza com retry backoff se houver algo recuperável
  if (report.shouldRecover) {
    actions.push({
      strategy: "RETRY_WITH_BACKOFF",
      reason: "Erros recuperáveis detectados - agendar retry com backoff exponencial",
      priority: 10,
    });
  }

  actions.sort((a, b) => a.priority - b.priority);

  const shouldRetry = report.shouldRecover && actions.length > 0;

  return {
    id: genPlanId(),
    createdAt: Date.now(),
    errors: report.errors,
    actions,
    keepThinking,
    preservedSignature,
    shouldRetry,
    metadata: {
      modelId: opts.modelId,
      sessionId,
      modelIsThinking: opts.modelId ? THINKING_MODELS_2026.has(opts.modelId) : undefined,
    },
  };
}

// ============================================================================
// 07. HELPERS DE TRANSFORMAÇÃO DE MENSAGENS
// ============================================================================

export function cloneMessages(messages: ChatMessages): ChatMessages {
  return messages.map((m) => {
    const content = typeof m.content === "string" ? m.content : (m.content as any[]).map((b: any) => ({ ...b }));
    return { ...m, content } as ChatMessage;
  });
}

/**
 * Remove thinking blocks com signature inválida.
 * Se houver cache, tenta restaurar; senão remove ou marca como redacted.
 */
export function stripInvalidSignatures(
  messages: ChatMessages,
  signatureCache?: ThinkingSignatureCache,
): { messages: ChatMessages; removedCount: number; restoredCount: number } {
  const cache = signatureCache ?? getGlobalSignatureCache();
  let removedCount = 0;
  let restoredCount = 0;

  const out: ChatMessages = messages.map((msg) => {
    if (msg.role !== "assistant") return msg;
    const blocks = extractBlocks(msg);
    const newBlocks: ContentBlock[] = [];

    for (const blk of blocks) {
      const b: any = blk;
      if (b?.type !== "thinking") {
        newBlocks.push(b);
        continue;
      }
      const sigValid = isValidThinkingSignature(b.signature);
      if (!sigValid) {
        // tenta restaurar do cache via thinking hash
        const thinking: string = b.thinking ?? b.redacted_thinking ?? "";
        if (thinking) {
          const restoredSig = cache.tryRestore(thinking);
          if (restoredSig) {
            newBlocks.push({ ...b, signature: restoredSig, _preserved: true } as any);
            restoredCount++;
            continue;
          }
        }
        // remoção: para Claude 2026, se removemos thinking, precisamos garantir que não quebra tool_use
        // estratégia: se thinking inválido, converte para text com aviso + marca removel ou mantém thinking mas sem signature se modelo gemini aceita
        // Aqui removemos de fato - será reinjetado depois se keep_thinking ativo
        removedCount++;
        continue;
      } else {
        // válido - armazena no cache
        if (typeof b.thinking === "string" && b.thinking.length > 0) {
          cache.store(b.thinking, b.signature, "auto-detected");
        }
        newBlocks.push(b);
      }
    }

    return { ...msg, content: newBlocks } as ChatMessage;
  });

  return { messages: out, removedCount, restoredCount };
}

/**
 * Garante que toda mensagem assistant com tool_use tenha thinking precedente.
 * Se não houver, injeta thinking preservado ou sintético mínimo.
 */
export function ensureThinkingBeforeToolUse(
  messages: ChatMessages,
  preservedThinking: string | null,
  preservedSignature: string | null,
  opts?: { syntheticFallback?: boolean; modelId?: string },
): { messages: ChatMessages; injectedCount: number } {
  let injectedCount = 0;
  const syntheticThinking =
    "Analisando o contexto anterior e a necessidade de usar ferramentas para continuar a tarefa. " +
    "Vou manter coerência com o raciocínio anterior preservado e executar o próximo passo necessário.";

  const out = cloneMessages(messages);

  for (let mi = 0; mi < out.length; mi++) {
    const msg = out[mi]!;
    if (msg.role !== "assistant") continue;
    const blocks = extractBlocks(msg);
    let hasThinking = blocks.some((b: any) => b?.type === "thinking" && typeof b.thinking === "string" && b.thinking.trim().length > 0);
    const hasToolUse = blocks.some((b: any) => b?.type === "tool_use");

    if (hasToolUse && !hasThinking) {
      const thinkingToInject = preservedThinking && preservedThinking.trim().length > 10 ? preservedThinking : syntheticThinking;
      const sigToInject = preservedSignature && isValidThinkingSignature(preservedSignature) ? preservedSignature : undefined;

      const thinkingBlock: ThinkingBlock = {
        type: "thinking",
        thinking: thinkingToInject,
        ...(sigToInject ? { signature: sigToInject } : {}),
        _injected: true,
        _preserved: !!preservedThinking,
      };

      // injeta no início da mensagem
      const newContent: ContentBlock[] = [thinkingBlock, ...(blocks as ContentBlock[])];
      out[mi] = { ...msg, content: newContent } as ChatMessage;
      injectedCount++;
    }
  }

  return { messages: out, injectedCount };
}

/**
 * Injeta thinking preservado entre turns (keep_thinking strategy).
 * Se assistant já tem thinking, não sobrescreve - apenas garante preservação.
 * Se não, prefixa.
 */
export function injectPreservedThinking(
  messages: ChatMessages,
  preserved: PreservedThinking | null,
  signatureCache?: ThinkingSignatureCache,
): { messages: ChatMessages; injected: boolean } {
  if (!preserved || !preserved.thinking) {
    return { messages, injected: false };
  }

  const out = cloneMessages(messages);
  // injeta como mensagem system de contexto ou prefixo na última user? Estratégia adotada:
  // Adiciona um novo bloco de contexto "thinking continuity" em forma de assistant note na última posição antes da última user,
  // ou se a última é user, adicionamos thinking preservation note como user content para orientar.
  // Melhor prática para Anthropic thinking: injetar no histórico como assistant thinking válido anterior, não como user.

  // Vamos inserir antes da última user message, como assistant thinking preservado, se houver.
  // Para manter compat, vamos anexar ao primeiro assistant com tool_use que não tem thinking, ou simplesmente guardar para próximo turn.

  // Implementação simples: se última mensagem é user, adiciona uma nova assistant com thinking preservado antes dela.
  // Isso simula keep_thinking entre turns.
  const lastUserIdx = (() => {
    for (let i = out.length - 1; i >= 0; i--) {
      if (out[i]!.role === "user") return i;
    }
    return -1;
  })();

  const cache = signatureCache ?? getGlobalSignatureCache();
  let sig = preserved.signature;
  if (!sig || !isValidThinkingSignature(sig)) {
    sig = cache.tryRestore(preserved.thinking) ?? null;
  }

  const block: ThinkingBlock = {
    type: "thinking",
    thinking: preserved.thinking,
    ...(sig && isValidThinkingSignature(sig) ? { signature: sig } : {}),
    _preserved: true,
    _injected: true,
  };

  const assistantPreserveMsg: ChatMessage = {
    role: "assistant",
    content: [block, { type: "text", text: "[thinking preserved from previous turn - continuity maintained]" } as TextBlock],
  };

  if (lastUserIdx >= 0) {
    // inserir antes da última user se houver pelo menos 1 mensagem antes
    out.splice(lastUserIdx, 0, assistantPreserveMsg);
  } else {
    // append
    out.push(assistantPreserveMsg);
  }

  return { messages: out, injected: true };
}

/**
 * Mensagem "continue" para session boundary recovery.
 * Otimizada para bypass Gemini CLI - mantém fingerprint ideType UNSPECIFIED etc.
 */
export function buildContinueMessage(opts?: {
  sessionId?: string;
  modelId?: string;
  truncatedCount?: number;
  includePreserved?: boolean;
}): ChatMessage {
  const parts = [
    "Continue from where you left off.",
    "Preserve the previous thinking context and complete the remaining tasks.",
    "Do not restart - resume exactly from the last checkpoint.",
  ];
  if (opts?.truncatedCount && opts.truncatedCount > 0) {
    parts.push(`Note: ${opts.truncatedCount} older messages were compacted due to context limits, but core thinking is preserved.`);
  }
  if (opts?.includePreserved) {
    parts.push("Use the preserved thinking blocks to maintain coherence.");
  }
  // extra instruction para Claude thinking models 2026
  if (opts?.modelId && THINKING_MODELS_2026.has(opts.modelId)) {
    parts.push("Keep thinking block signature valid and include thinking before any tool_use.");
  }

  return {
    role: "user",
    content: parts.join(" "),
  };
}

/**
 * Mensagem de undo guidance quando tool falha.
 */
export function buildUndoGuidanceMessage(failures: DetectedError[], opts?: { sessionId?: string }): ChatMessage {
  const failureSummaries = failures
    .slice(0, 3)
    .map((f) => {
      const toolId = (f.details as any)?.tool_use_id ?? "unknown";
      const preview = (f.details as any)?.contentPreview ?? f.message;
      return `- Tool ${toolId}: ${String(preview).slice(0, 120)}`;
    })
    .join("\n");

  const guidance =
    `The previous tool execution failed:\n${failureSummaries}\n\n` +
    `Please UNDO / revert any partial changes if needed, explain the failure briefly, ` +
    `and retry with corrected parameters. Do not repeat the same failing call verbatim. ` +
    `If the failure is unrecoverable, propose an alternative approach. ` +
    `Keep thinking preserved across turns.`;

  return {
    role: "user",
    content: guidance,
  };
}

/**
 * Reconstrução compactada de mensagens para session boundary / context overflow.
 * Mantém system prompt, últimas N mensagens, e resume meio.
 */
export function rebuildMessagesCompacted(
  messages: ChatMessages,
  opts?: { keepLast?: number; keepSystem?: boolean },
): { messages: ChatMessages; compactedCount: number } {
  const keepLast = opts?.keepLast ?? 20;
  const keepSystem = opts?.keepSystem ?? true;

  if (messages.length <= keepLast) {
    return { messages: cloneMessages(messages), compactedCount: 0 };
  }

  const systemMsgs = keepSystem ? messages.filter((m) => m.role === "system") : [];
  const nonSystem = messages.filter((m) => m.role !== "system");

  if (nonSystem.length <= keepLast) {
    return { messages: cloneMessages(messages), compactedCount: 0 };
  }

  const toKeep = nonSystem.slice(-keepLast);
  const toCompact = nonSystem.slice(0, -keepLast);
  const compactedCount = toCompact.length;

  // cria resumo do trecho compactado
  const summaryText = `[Context compacted: ${compactedCount} earlier messages summarized. Core tasks, thinking signatures and tool results preserved. Continue without restarting.]`;

  const summaryMsg: ChatMessage = {
    role: "user",
    content: summaryText,
  };

  const newMessages: ChatMessages = [...cloneMessages(systemMsgs), summaryMsg, ...cloneMessages(toKeep)];

  return { messages: newMessages, compactedCount };
}

/**
 * Transformador master para retry - aplica plano.
 */
export function transformMessagesForRetry(
  originalMessages: ChatMessages,
  plan: RecoveryPlan,
  opts?: {
    sessionId?: string;
    signatureCache?: ThinkingSignatureCache;
    preservationStore?: ThinkingPreservationStore;
  },
): ChatMessages {
  let working = cloneMessages(originalMessages);
  const signatureCache = opts?.signatureCache ?? getGlobalSignatureCache();
  const preservationStore = opts?.preservationStore ?? getGlobalPreservationStore();
  const sessionId = opts?.sessionId ?? (plan.metadata as any)?.sessionId ?? "default";

  for (const action of plan.actions) {
    switch (action.strategy) {
      case "STRIP_INVALID_SIGNATURE": {
        const result = stripInvalidSignatures(working, signatureCache);
        working = result.messages;
        break;
      }
      case "INJECT_PRESERVED_THINKING": {
        if (plan.keepThinking) {
          const preserved = preservationStore.get(sessionId);
          if (preserved) {
            const res = injectPreservedThinking(working, preserved, signatureCache);
            working = res.messages;
          } else if (plan.keepThinking) {
            // cria preserved temporário da plan
            const tmp: PreservedThinking = {
              id: `tmp_${plan.id}`,
              sessionId,
              thinking: plan.keepThinking,
              signature: plan.preservedSignature ?? null,
              modelId: (plan.metadata as any)?.modelId ?? PROJECT_FALLBACK,
              messageIndex: working.length,
              createdAt: Date.now(),
              injectCount: 0,
            };
            const res = injectPreservedThinking(working, tmp, signatureCache);
            working = res.messages;
          }
        }
        break;
      }
      case "KEEP_THINKING_PRESERVE": {
        const { messages, injectedCount } = ensureThinkingBeforeToolUse(
          working,
          plan.keepThinking ?? null,
          plan.preservedSignature ?? null,
          { modelId: (plan.metadata as any)?.modelId },
        );
        working = messages;
        // se não injetou mas há tool_use sem thinking, força injeção extra
        void injectedCount;
        break;
      }
      case "UNDO_GUIDANCE": {
        const toolFailures = plan.errors.filter((e) => e.code === "TOOL_FAILURE");
        if (toolFailures.length > 0) {
          const undoMsg = buildUndoGuidanceMessage(toolFailures, { sessionId });
          working = [...working, undoMsg];
        }
        break;
      }
      case "CONTINUE_RESUME": {
        const boundaryErrs = plan.errors.filter((e) => e.code === "SESSION_BOUNDARY" || e.code === "CONTEXT_OVERFLOW");
        const compacted = (action.payload as any)?.compactedCount as number | undefined;
        const contMsg = buildContinueMessage({
          sessionId,
          modelId: (plan.metadata as any)?.modelId,
          truncatedCount: compacted,
          includePreserved: !!plan.keepThinking,
        });
        // se há boundary, também compacta histórico
        if (boundaryErrs.length > 0) {
          const rebuilt = rebuildMessagesCompacted(working, { keepLast: 24, keepSystem: true });
          working = rebuilt.messages;
        }
        working = [...working, contMsg];
        break;
      }
      case "REBUILD_MESSAGES": {
        const rebuilt = rebuildMessagesCompacted(working, { keepLast: 24, keepSystem: true });
        working = rebuilt.messages;
        break;
      }
      case "RESET_THINKING_CACHE": {
        signatureCache.sweepInvalid();
        break;
      }
      case "RETRY_WITH_BACKOFF":
        // noop transform, só delay
        break;
      default:
        break;
    }
  }

  return working;
}

// ============================================================================
// 08. PRESERVATION HOOKS - CHAMAR APÓS RESPOSTAS VÁLIDAS
// ============================================================================

export function preserveThinkingFromMessages(
  messages: ChatMessages,
  opts: { sessionId: string; modelId: string; signatureCache?: ThinkingSignatureCache; preservationStore?: ThinkingPreservationStore },
): number {
  const cache = opts.signatureCache ?? getGlobalSignatureCache();
  const store = opts.preservationStore ?? getGlobalPreservationStore();
  let preservedCount = 0;

  messages.forEach((msg, idx) => {
    if (msg.role !== "assistant") return;
    const blocks = extractBlocks(msg);
    for (const blk of blocks) {
      const b: any = blk;
      if (b?.type === "thinking" && typeof b.thinking === "string" && b.thinking.trim().length > 10) {
        const sig = typeof b.signature === "string" ? b.signature : null;
        if (sig && isValidThinkingSignature(sig)) {
          cache.store(b.thinking, sig, opts.modelId);
        }
        store.preserve(opts.sessionId, b.thinking, sig, opts.modelId, idx);
        preservedCount++;
      }
    }
  });

  return preservedCount;
}

export function preserveThinkingFromResponse(
  response: unknown,
  opts: { sessionId: string; modelId: string; signatureCache?: ThinkingSignatureCache; preservationStore?: ThinkingPreservationStore },
): number {
  // tenta extrair thinking do formato Anthropic/Gemini response genérico
  try {
    const respObj: any = response;
    let contents: any[] = [];

    // Anthropic style: content array
    if (Array.isArray(respObj?.content)) contents = respObj.content;
    else if (Array.isArray(respObj?.candidates?.[0]?.content?.parts)) contents = respObj.candidates[0].content.parts;
    else if (Array.isArray(respObj?.candidates?.[0]?.content)) contents = respObj.candidates[0].content;
    else if (typeof respObj?.text === "function") {
      // streaming maybe
      return 0;
    }

    const cache = opts.signatureCache ?? getGlobalSignatureCache();
    const store = opts.preservationStore ?? getGlobalPreservationStore();

    let count = 0;
    for (const c of contents) {
      if (c?.type === "thinking" && typeof c.thinking === "string") {
        const sig = typeof c.signature === "string" ? c.signature : null;
        if (sig && isValidThinkingSignature(sig)) {
          cache.store(c.thinking, sig, opts.modelId);
        }
        store.preserve(opts.sessionId, c.thinking, sig, opts.modelId, 0);
        count++;
      }
      // Gemini pode retornar thinking em objeto separado
      if (c?.thinking && typeof c.thinking === "string") {
        const sig = c.signature ?? null;
        store.preserve(opts.sessionId, c.thinking, sig, opts.modelId, 0);
        count++;
      }
    }
    return count;
  } catch {
    return 0;
  }
}

// ============================================================================
// 09. BACKOFF EXPONENCIAL
// ============================================================================

export function exponentialBackoff(attempt: number, baseMs: number, maxMs: number, jitter: boolean): number {
  const exp = Math.min(maxMs, baseMs * Math.pow(2, attempt));
  if (!jitter) return Math.floor(exp);
  // jitter full: random 0..exp
  // usamos decorrelated jitter com base para evitar thundering herd
  try {
    const rand = crypto.randomInt(0, 1000) / 1000; // 0..0.999
    const jittered = exp * (0.5 + rand * 0.5); // 50%..100% do exp
    return Math.floor(Math.min(maxMs, jittered));
  } catch {
    const jittered = exp * (0.5 + Math.random() * 0.5);
    return Math.floor(Math.min(maxMs, jittered));
  }
}

export function sleepMs(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason ?? new Error("Aborted"));
      return;
    }
    const timeout = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);

    const onAbort = () => {
      clearTimeout(timeout);
      reject(signal?.reason ?? new Error("Aborted"));
    };

    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

// ============================================================================
// 10. WRAPPER withAutoRecovery - NÚCLEO DO MOTOR
// ============================================================================

export class AutoRecoveryExhaustedError extends Error {
  public readonly attempts: number;
  public readonly lastPlan?: RecoveryPlan;
  public readonly lastError: unknown;

  constructor(message: string, lastError: unknown, attempts: number, lastPlan?: RecoveryPlan) {
    super(message);
    this.name = "AutoRecoveryExhaustedError";
    this.attempts = attempts;
    this.lastError = lastError;
    this.lastPlan = lastPlan;
  }
}

/**
 * Wrapper principal com auto-recovery completo.
 *
 * Fluxo:
 *  1. Executa executor com messages originais
 *  2. Em erro ou resposta inválida, roda detectores
 *  3. Se recuperável, constrói RecoveryPlan, transforma messages, backoff, retry
 *  4. Preserva thinking válido após sucesso (keep_thinking)
 *
 * Zero-dep, apenas node:* + fetch global.
 *
 * @example
 * const result = await withAutoRecovery(
 *   async (msgs) => callAntigravity(msgs),
 *   originalMessages,
 *   { maxAttempts: 4, modelId: "antigravity-claude-opus-4-6-thinking", sessionId: "sess_123" }
 * );
 */
export async function withAutoRecovery<T>(
  executor: ExecutorFn<T>,
  messages: ChatMessages,
  opts?: AutoRecoveryOptions,
): Promise<T> {
  const maxAttempts = opts?.maxAttempts ?? 4;
  const baseDelayMs = opts?.baseDelayMs ?? 450;
  const maxDelayMs = opts?.maxDelayMs ?? 7500;
  const jitter = opts?.jitter ?? true;
  const failFast = opts?.failFastOnNonRecoverable ?? true;

  const signatureCache = opts?.signatureCache ?? getGlobalSignatureCache();
  const preservationStore = opts?.preservationStore ?? getGlobalPreservationStore();
  const sessionId = opts?.sessionId ?? "default";
  const modelId = opts?.modelId ?? PROJECT_FALLBACK;
  const logger = opts?.logger ?? console;

  if (!Array.isArray(messages)) {
    throw new TypeError("withAutoRecovery: messages must be array");
  }

  let workingMessages = cloneMessages(messages);
  let lastError: unknown = null;
  let lastPlan: RecoveryPlan | undefined;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    // abort check
    if (opts?.signal?.aborted) {
      throw opts.signal.reason ?? new Error("withAutoRecovery aborted");
    }

    try {
      const result = await executor(workingMessages, {
        signal: opts?.signal,
        attempt,
        plan: lastPlan,
      });

      // detecção pós-sucesso: verifica se resultado contém thinking inválido que exigiria recovery mesmo sem throw
      // ex.: proxy retorna 200 mas content com signature inválida
      // extrai mensagens do resultado para validar
      try {
        const msgForCheck: ChatMessages = extractMessagesFromResultForCheck(result, workingMessages);
        const postReport = detectAllErrors(null, msgForCheck, modelId);
        if (postReport.hasInvalidSignature) {
          // se retorno contém signature inválida, trata como erro recuperável
          throw new Error(`Post-exec invalid thinking signature detected: ${postReport.errors.map((e) => e.message).join("; ")}`);
        }
        // preservação keep_thinking após sucesso válido
        preserveThinkingFromMessages(msgForCheck, { sessionId, modelId, signatureCache, preservationStore });
        preserveThinkingFromResponse(result, { sessionId, modelId, signatureCache, preservationStore });
      } catch (preserveErr) {
        // se preserve falhar, não deve quebrar sucesso - loga se logger debug ativo
        if ((preserveErr as Error)?.message?.includes("invalid thinking signature")) {
          // se o próprio check detectou inválido, propaga para retry
          throw preserveErr;
        }
        // senão ignora
      }

      // sucesso real
      return result;
    } catch (err) {
      lastError = err;

      const detectionReport = detectAllErrors(err, workingMessages, modelId);

      if (opts?.onDetectedErrors) {
        try {
          opts.onDetectedErrors(detectionReport);
        } catch {
          // ignore callback errors
        }
      }

      // Se não recuperável e failFast, lança direto
      if (!detectionReport.shouldRecover) {
        if (failFast) {
          throw err;
        }
        // se não failFast, tenta um retry simples com backoff mesmo assim para rate limit etc
        if (detectionReport.errors.some((e) => e.code === "RATE_LIMIT")) {
          // allow retry
        } else {
          throw err;
        }
      }

      const plan = buildRecoveryPlan(detectionReport, {
        sessionId,
        modelId,
        messages: workingMessages,
        preservationStore,
        signatureCache,
      });

      lastPlan = plan;

      // se shouldRetry false após plano, aborta
      if (!plan.shouldRetry) {
        throw err;
      }

      // aplica transformação de mensagens
      const transformed = transformMessagesForRetry(workingMessages, plan, {
        sessionId,
        signatureCache,
        preservationStore,
      });
      workingMessages = transformed;
      plan.transformedMessages = cloneMessages(transformed);

      const delayMs = exponentialBackoff(attempt, baseDelayMs, maxDelayMs, jitter);
      plan.retryDelayMs = delayMs;

      if (opts?.onRecoveryAttempt) {
        try {
          opts.onRecoveryAttempt(attempt + 1, plan, delayMs);
        } catch {
          // ignore
        }
      }

      // logging minimalista (não polui) - somente se logger tem debug
      try {
        logger.debug?.(
          `[recovery] attempt ${attempt + 1}/${maxAttempts} plan=${plan.id} errors=${plan.errors
            .map((e) => e.code)
            .join(",")} actions=${plan.actions.map((a) => a.strategy).join("->")} delay=${delayMs}ms`,
        );
      } catch {
        // ignore
      }

      // último attempt não dorme
      if (attempt < maxAttempts - 1) {
        try {
          await sleepMs(delayMs, opts?.signal);
        } catch (abortErr) {
          throw abortErr;
        }
      }
      // loop continua
    }
  }

  throw new AutoRecoveryExhaustedError(
    `Auto-recovery exhausted after ${maxAttempts} attempts. Last error: ${stringifyError(lastError).slice(0, 400)}`,
    lastError,
    maxAttempts,
    lastPlan,
  );
}

/**
 * Tenta extrair ChatMessages a partir de resultado genérico para checagem pós-exec.
 * Suporta:
 *  - array direto
 *  - object com {messages}
 *  - Anthropic {content: [...]}
 *  - Gemini {candidates[0].content}
 */
function extractMessagesFromResultForCheck(result: unknown, fallback: ChatMessages): ChatMessages {
  try {
    const r: any = result;
    if (Array.isArray(r) && r.length > 0 && r[0]?.role) {
      return r as ChatMessages;
    }
    if (Array.isArray(r?.messages)) {
      return r.messages as ChatMessages;
    }
    if (Array.isArray(r?.content)) {
      // assistant message
      return [{ role: "assistant", content: r.content as ContentBlock[] }];
    }
    if (r?.candidates?.[0]?.content) {
      const cand = r.candidates[0];
      if (Array.isArray(cand.content)) {
        return [{ role: "assistant", content: cand.content }];
      }
      if (cand.content?.parts) {
        // convert gemini parts to content blocks for detection
        const parts = cand.content.parts;
        const blocks: ContentBlock[] = parts.map((p: any) => {
          if (p.text) return { type: "text", text: p.text } as TextBlock;
          if (p.thinking) return { type: "thinking", thinking: p.thinking, signature: p.signature } as ThinkingBlock;
          return p;
        });
        return [{ role: "assistant", content: blocks }];
      }
    }
    // fallback: use working messages + result as text
    return fallback;
  } catch {
    return fallback;
  }
}

// ============================================================================
// 11. UTILITÁRIOS DE ALTO NÍVEL - FACADE PARA PLUGIN
// ============================================================================

export interface RecoveryFacadeOptions {
  sessionId: string;
  modelId: string;
  maxAttempts?: number;
}

/**
 * Cria wrapper pré-configurado para uso no plugin opencode-antigravity-auth.
 * Já vem com LRU global e preservation.
 */
export function createRecoveryFacade(opts: RecoveryFacadeOptions) {
  const signatureCache = getGlobalSignatureCache();
  const preservationStore = getGlobalPreservationStore();

  return {
    signatureCache,
    preservationStore,

    /**
     * Detecta erros nas mensagens atuais (sem executar)
     */
    detect(messages: ChatMessages, error?: unknown): DetectionReport {
      return detectAllErrors(error ?? null, messages, opts.modelId);
    },

    /**
     * Constrói plano sem executar.
     */
    plan(report: DetectionReport, messages: ChatMessages): RecoveryPlan {
      return buildRecoveryPlan(report, {
        sessionId: opts.sessionId,
        modelId: opts.modelId,
        messages,
        signatureCache,
        preservationStore,
      });
    },

    /**
     * Transforma mensagens segundo plano.
     */
    transform(messages: ChatMessages, plan: RecoveryPlan): ChatMessages {
      return transformMessagesForRetry(messages, plan, {
        sessionId: opts.sessionId,
        signatureCache,
        preservationStore,
      });
    },

    /**
     * Executa com auto-recovery.
     */
    async exec<T>(executor: ExecutorFn<T>, messages: ChatMessages, extra?: Partial<AutoRecoveryOptions>): Promise<T> {
      return withAutoRecovery(executor, messages, {
        maxAttempts: opts.maxAttempts ?? 4,
        sessionId: opts.sessionId,
        modelId: opts.modelId,
        signatureCache,
        preservationStore,
        ...extra,
      });
    },

    /**
     * Preserva thinking manualmente.
     */
    preserve(messages: ChatMessages): number {
      return preserveThinkingFromMessages(messages, {
        sessionId: opts.sessionId,
        modelId: opts.modelId,
        signatureCache,
        preservationStore,
      });
    },

    clear() {
      preservationStore.clear(opts.sessionId);
    },
  };
}

// ============================================================================
// 12. HELPERS DE COMPATIBILIDADE - BUILDER USER PROMPT ID FNV (sem dependências)
// ============================================================================

export function buildUserPromptId(input: string, seed?: string): string {
  const base = seed ? `${input}|${seed}` : input;
  const h = fnv1a32(base).toString(16).padStart(8, "0");
  return `agyp_${h}`;
}

export function buildSessionIdFromCwd(cwd?: string): string {
  const dir = cwd ?? process.cwd();
  const h = fnv1a32(dir).toString(16).padStart(8, "0");
  return `sess_${h}`;
}

// ============================================================================
// 13. CONSTANTS EXPORT & DEFAULT BUNDLE
// ============================================================================

export const RecoveryConstants = {
  GEMINI_CLI_CLIENT_ID,
  GEMINI_CLI_CLIENT_SECRET,
  GEMINI_CLI_USER_AGENT,
  X_GOOG_API_CLIENT,
  X_CLIENT_METADATA_RAW,
  PROJECT_FALLBACK,
  MODELS_2026,
  DETECTOR_PATTERNS,
} as const;

export const Recovery = {
  // caches
  LRUCache,
  ThinkingSignatureCache,
  getGlobalSignatureCache,
  resetGlobalSignatureCache,
  ThinkingPreservationStore,
  getGlobalPreservationStore,
  resetGlobalPreservationStore,

  // validators
  isValidThinkingSignature,
  isBase64ishSig,
  hashThinkingContent,
  fnv1a32,

  // detectors
  detectInvalidSignatureBlocks,
  detectToolUseWithoutThinking,
  detectSessionBoundary,
  detectToolFailures,
  detectInvalidSignatureFromError,
  detectAllErrors,
  DETECTOR_PATTERNS,

  // plan
  buildRecoveryPlan,

  // transformers
  cloneMessages,
  stripInvalidSignatures,
  ensureThinkingBeforeToolUse,
  injectPreservedThinking,
  buildContinueMessage,
  buildUndoGuidanceMessage,
  rebuildMessagesCompacted,
  transformMessagesForRetry,

  // preservation
  preserveThinkingFromMessages,
  preserveThinkingFromResponse,

  // backoff
  exponentialBackoff,
  sleepMs,

  // wrapper
  withAutoRecovery,
  AutoRecoveryExhaustedError,
  createRecoveryFacade,

  // helpers
  buildUserPromptId,
  buildSessionIdFromCwd,

  // constants
  RecoveryConstants,
} as const;

export default Recovery;
