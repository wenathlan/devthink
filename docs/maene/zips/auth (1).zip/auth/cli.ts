/**
 * @fileoverview cli.ts - CLI produção-ready para opencode-antigravity-auth
 * @module auth/cli
 * @description
 *  CLI completa em TypeScript com zero dependências externas (apenas node:* + fetch global).
 *  - Login OAuth Antigravity (PKCE) via oauth.ts usando bypass Gemini CLI
 *  - Gerenciamento multi-conta (add, list, enable/disable, set-active, remove, import)
 *  - Checagem de quotas via quota.ts (dual source antigravity + gemini-cli)
 *  - Configuração com catálogo ALL_MODELS_2026 de constants.ts e thresholds via config.ts
 *  - Grava em ~/.config/opencode/ com chmod 600, merge atômico (temp + rename)
 *  - Menu interativo (node:readline/promises) + comandos não interativos
 *
 *  Bypass constants blindadas:
 *   client_id=681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j (.apps.googleusercontent.com)
 *   secret=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
 *   UA=GeminiCLI/0.35.3 (linux; x64; GitHub) google-api-nodejs-client/9.15.1
 *   X-Goog-Api-Client=gl-node/22.19.0
 *   Client-Metadata=ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 *   project fallback=rising-fact-p41fc
 *   pasta isolada=/mnt/data/auth (nome curto minúsculo blindada)
 *
 * @author ONDA 5 - Finalização
 * @license MIT
 * @version 5.0.0
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
import * as readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

// ---------------------------------------------------------------------------
// Local module imports (ESM .js extension for Node resolver, but source is .ts)
// ---------------------------------------------------------------------------
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - allow .ts resolution via tsx, fallback to .js for compiled
import * as oauthMod from "./oauth.js";
import * as accountsMod from "./accounts.js";
import * as configMod from "./config.js";
import * as constantsMod from "./constants.js";
import * as quotaMod from "./quota.js";
import * as versionMod from "./version.js";

// Resolve interop (CJS/ESM dual): pick default if exists or namespace
const oauth: any = (oauthMod as any).default ?? oauthMod;
const accountsPkg: any = (accountsMod as any).default ?? accountsMod;
const configPkg: any = (configMod as any).default ?? configMod;
const constantsPkg: any = (constantsMod as any).default ?? constantsMod;
const quotaPkg: any = (quotaMod as any).default ?? quotaMod;
const versionPkg: any = (versionMod as any).default ?? versionMod;

// Destructure needed APIs with fallback to namespace exports
const authenticate = oauth.authenticate as typeof import("./oauth.js").authenticate;
const GEMINI_OAUTH_CLIENT_ID = (oauth.CLIENT_ID as string) ?? (constantsMod.GEMINI_CLI_OAUTH_CLIENT_ID as string);
const GEMINI_OAUTH_CLIENT_SECRET = (oauth.CLIENT_SECRET as string) ?? (constantsMod.GEMINI_CLI_OAUTH_CLIENT_SECRET as string);

const AccountManagerClass = (accountsMod.AccountManager as any) ?? (accountsPkg as any);
const ALL_MODELS_FALLBACK = (constantsMod.ALL_MODELS_2026 as any) ?? (constantsPkg.ALL_MODELS_2026 as any) ?? [
  { id: "antigravity-gemini-3-pro", name: "Antigravity Gemini 3.0 Pro", context: 1048576, output: 65536, api: "antigravity", quotaGroup: "gemini-3-pro" },
];

const loadConfig = (configMod.loadConfig as any) ?? (configPkg.loadConfig as any);
const saveConfig = (configMod.saveConfig as any) ?? (configPkg.saveConfig as any);
const updateConfig = (configMod.updateConfig as any) ?? (configPkg.updateConfig as any);
const DEFAULT_CONFIG = (configMod.DEFAULT_CONFIG as any) ?? (configPkg.DEFAULT_CONFIG as any);
const parseAndValidateConfig = (configMod.parseAndValidateConfig as any) ?? (configPkg.parseAndValidateConfig as any);
const getConfigPath = (configMod.getConfigPath as any) ?? (() => path.join(resolveBaseDir(), "antigravity.json"));

// constants
const ALL_MODELS_2026: ReadonlyArray<any> = (constantsMod.ALL_MODELS_2026 as any) ?? ALL_MODELS_FALLBACK;
const FILE_PATHS = (constantsMod.FILE_PATHS as any) ?? {
  get baseDir() { return resolveBaseDir(); },
  get authDir() { return path.join(resolveBaseDir(), "auth"); },
};
const FALLBACK_PROJECT_ID = (constantsMod.FALLBACK_PROJECT_ID as string) ?? "rising-fact-p41fc";
const PLUGIN_VERSION_FALLBACK = (constantsMod.PLUGIN_VERSION as string) ?? "1.0.0";

// quota
const QuotaManager = (quotaMod.QuotaManager as any) ?? (quotaPkg.QuotaManager as any);
const getDefaultQuotaManager = (quotaMod.getDefaultQuotaManager as any) ?? null;
const checkQuotaFn = (quotaMod.checkQuota as any) ?? null;
const getQuotaGroupsFn = (quotaMod.getQuotaGroups as any) ?? null;

// version
const getVersion = (versionMod.getVersion as any) ?? (async () => FALLBACK_PROJECT_ID);
const getVersionInfo = (versionMod.getVersionInfo as any) ?? (async () => ({ version: "1.15.8", source: "hardcoded" }));

// ===========================================================================
// 00. ANSI COLORS - zero dep
// ===========================================================================
const ANSI = {
  reset: "\x1b[0m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
  italic: "\x1b[3m",
  underline: "\x1b[4m",
  inverse: "\x1b[7m",
  hidden: "\x1b[8m",
  // foreground
  black: "\x1b[30m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m",
  white: "\x1b[37m",
  gray: "\x1b[90m",
  brightRed: "\x1b[91m",
  brightGreen: "\x1b[92m",
  brightYellow: "\x1b[93m",
  brightBlue: "\x1b[94m",
  brightMagenta: "\x1b[95m",
  brightCyan: "\x1b[96m",
  brightWhite: "\x1b[97m",
  // background
  bgBlack: "\x1b[40m",
  bgRed: "\x1b[41m",
  bgGreen: "\x1b[42m",
  bgYellow: "\x1b[43m",
  bgBlue: "\x1b[44m",
};

function colorize(s: string, ...codes: string[]): string {
  if (!s) return s;
  // disable colors if NO_COLOR or not TTY and not forced
  if (process.env.NO_COLOR) return s;
  return `${codes.join("")}${s}${ANSI.reset}`;
}
const C = {
  bold: (s: string) => colorize(s, ANSI.bold),
  dim: (s: string) => colorize(s, ANSI.dim),
  red: (s: string) => colorize(s, ANSI.red),
  green: (s: string) => colorize(s, ANSI.green),
  yellow: (s: string) => colorize(s, ANSI.yellow),
  cyan: (s: string) => colorize(s, ANSI.cyan),
  magenta: (s: string) => colorize(s, ANSI.magenta),
  blue: (s: string) => colorize(s, ANSI.blue),
  gray: (s: string) => colorize(s, ANSI.gray),
  white: (s: string) => colorize(s, ANSI.white),
  b: (s: string) => colorize(s, ANSI.bold),
  bgGreen: (s: string) => colorize(s, ANSI.bgGreen, ANSI.black),
  bgRed: (s: string) => colorize(s, ANSI.bgRed, ANSI.white),
};

// Unified logger
function logInfo(msg: string) { console.log(`${C.cyan("ℹ")} ${msg}`); }
function logOk(msg: string) { console.log(`${C.green("✔")} ${msg}`); }
function logWarn(msg: string) { console.log(`${C.yellow("⚠")} ${msg}`); }
function logErr(msg: string) { console.error(`${C.red("✖")} ${msg}`); }
function logDim(msg: string) { console.log(C.dim(msg)); }

// ===========================================================================
// 01. PATHS & SECURE FILE UTILS - atomic + 600
// ===========================================================================
function resolveBaseDir(): string {
  const env = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (env && env.length > 0) return path.resolve(env);
  return path.join(os.homedir(), ".config", "opencode");
}
function resolveAccountsPath(): string {
  try {
    const fp = (FILE_PATHS as any).authDir ? path.join((FILE_PATHS as any).baseDir, "antigravity-accounts.json") : null;
    if (fp) return fp;
  } catch {}
  return path.join(resolveBaseDir(), "antigravity-accounts.json");
}
function resolveConfigPath(): string {
  try {
    if (typeof getConfigPath === "function") return getConfigPath();
  } catch {}
  return path.join(resolveBaseDir(), "antigravity.json");
}
function ensureDirExists(dir: string) {
  try { fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); } catch {}
  try { fs.chmodSync(dir, 0o700); } catch {}
}
function atomicWriteFileSecure(filePath: string, content: string, mode = 0o600): void {
  const dir = path.dirname(filePath);
  ensureDirExists(dir);
  const tmp = `${filePath}.tmp.${crypto.randomBytes(6).toString("hex")}.${process.pid}`;
  try {
    fs.writeFileSync(tmp, content, { encoding: "utf8", mode });
    try { fs.chmodSync(tmp, mode); } catch {}
    fs.renameSync(tmp, filePath);
    try { fs.chmodSync(filePath, mode); } catch {}
  } catch (e) {
    try { fs.unlinkSync(tmp); } catch {}
    throw e;
  }
}
function readJsonSafe<T>(filePath: string, fallback: T): T {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    try { fs.chmodSync(filePath, 0o600); } catch {}
    const raw = fs.readFileSync(filePath, "utf8");
    return JSON.parse(raw) as T;
  } catch { return fallback; }
}
function maskToken(t: string): string {
  if (!t) return "***";
  if (t.length <= 12) return "***";
  return `${t.slice(0, 6)}...${t.slice(-4)}`;
}
function formatDate(ms?: number): string {
  if (!ms) return "-";
  try { return new Date(ms).toISOString().replace("T", " ").slice(0, 19); } catch { return String(ms); }
}

// ===========================================================================
// 02. ACCOUNT MANAGER FACTORY (singleton aware)
// ===========================================================================
function getAccountManager(): any {
  try {
    // Prefer class constructor
    if (typeof AccountManagerClass === "function") {
      return new AccountManagerClass({ disableBackgroundTimer: true });
    }
    // If default export is factory
    if (accountsPkg.AccountManager) return new accountsPkg.AccountManager({ disableBackgroundTimer: true });
    // fallback minimal in-memory manager that uses file path directly
    return {
      listAccounts() { return readJsonSafe<any>(resolveAccountsPath(), { version: 3, accounts: [] }).accounts ?? []; },
      findAccount(email: string) { return this.listAccounts().find((a: any) => a.email.toLowerCase() === email.toLowerCase()); },
      getEnabledAccounts() { return this.listAccounts().filter((a: any) => a.enabled !== false); },
      getActiveAccount() {
        const store = readJsonSafe<any>(resolveAccountsPath(), { version: 3, accounts: [], activeEmail: null });
        if (store.activeEmail) return store.accounts.find((a: any) => a.email === store.activeEmail) ?? store.accounts[0] ?? null;
        return store.accounts[0] ?? null;
      },
      addAccount(input: any) {
        const p = resolveAccountsPath();
        const store = readJsonSafe<any>(p, { version: 3, accounts: [], activeEmail: null, rotationIndex: 0, rotationStrategy: "round-robin", createdAt: Date.now(), updatedAt: Date.now() });
        store.accounts = store.accounts ?? [];
        const idx = store.accounts.findIndex((a: any) => a.email.toLowerCase() === input.email.toLowerCase());
        const now = Date.now();
        const record = {
          email: input.email.toLowerCase(),
          refreshToken: input.refreshToken,
          accessToken: input.accessToken,
          expiryDate: input.expiryDate,
          projectId: input.projectId ?? FALLBACK_PROJECT_ID,
          enabled: input.enabled ?? true,
          oauthClientKey: "gemini-cli",
          createdAt: now,
          lastUsedAt: now,
          failureCount: 0,
        };
        if (idx >= 0) store.accounts[idx] = { ...store.accounts[idx], ...record, createdAt: store.accounts[idx].createdAt };
        else store.accounts.push(record);
        if (!store.activeEmail) store.activeEmail = record.email;
        store.updatedAt = now;
        atomicWriteFileSecure(p, JSON.stringify(store, null, 2) + "\n", 0o600);
        return record;
      },
      removeAccount(email: string) {
        const p = resolveAccountsPath();
        const store = readJsonSafe<any>(p, { version: 3, accounts: [], activeEmail: null });
        const before = store.accounts.length;
        store.accounts = store.accounts.filter((a: any) => a.email.toLowerCase() !== email.toLowerCase());
        if (store.activeEmail?.toLowerCase() === email.toLowerCase()) store.activeEmail = store.accounts[0]?.email ?? null;
        atomicWriteFileSecure(p, JSON.stringify(store, null, 2) + "\n", 0o600);
        return store.accounts.length < before;
      },
      enableAccount(email: string) {
        const p = resolveAccountsPath();
        const store = readJsonSafe<any>(p, { version: 3, accounts: [] });
        const acc = store.accounts.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (!acc) throw new Error(`Account not found ${email}`);
        acc.enabled = true; acc.failureCount = 0; acc.disabledReason = undefined; acc.disabledUntil = undefined;
        atomicWriteFileSecure(p, JSON.stringify(store, null, 2) + "\n", 0o600);
        return acc;
      },
      disableAccount(email: string) {
        const p = resolveAccountsPath();
        const store = readJsonSafe<any>(p, { version: 3, accounts: [] });
        const acc = store.accounts.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (!acc) throw new Error(`Account not found ${email}`);
        acc.enabled = false; acc.disabledReason = "manually disabled";
        atomicWriteFileSecure(p, JSON.stringify(store, null, 2) + "\n", 0o600);
        return acc;
      },
      setActive(email: string, opts?: any) {
        const p = resolveAccountsPath();
        const store = readJsonSafe<any>(p, { version: 3, accounts: [], rotationStrategy: "round-robin" });
        const acc = store.accounts.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (!acc) throw new Error(`Account not found ${email}`);
        store.activeEmail = acc.email;
        if (opts?.sticky) store.rotationStrategy = "sticky";
        store.updatedAt = Date.now();
        atomicWriteFileSecure(p, JSON.stringify(store, null, 2) + "\n", 0o600);
        return acc;
      },
      async getValidAccessToken(email?: string) {
        // naive: return cached access token if not expired, else refresh via fetch
        const all = this.listAccounts();
        const target = email ? this.findAccount(email) : this.getActiveAccount();
        if (!target) throw new Error(`No account found ${email ?? ""}`);
        if (target.accessToken && target.expiryDate && target.expiryDate > Date.now() + 60000) return target.accessToken;
        // try refresh
        const body = new URLSearchParams({
          client_id: GEMINI_OAUTH_CLIENT_ID,
          client_secret: GEMINI_OAUTH_CLIENT_SECRET,
          refresh_token: target.refreshToken,
          grant_type: "refresh_token",
        });
        const res = await fetch("https://oauth2.googleapis.com/token", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1",
            "X-Goog-Api-Client": "gl-node/22.19.0",
            "Client-Metadata": "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI",
          },
          body: body.toString(),
        });
        if (!res.ok) throw new Error(`Refresh failed ${res.status}`);
        const j: any = await res.json();
        const storePath = resolveAccountsPath();
        const store = readJsonSafe<any>(storePath, { version: 3, accounts: [] });
        const accIdx = store.accounts.findIndex((a: any) => a.email.toLowerCase() === target.email.toLowerCase());
        if (accIdx >= 0) {
          store.accounts[accIdx].accessToken = j.access_token;
          store.accounts[accIdx].expiryDate = Date.now() + (j.expires_in * 1000 || 3600000);
          store.accounts[accIdx].lastRefresh = Date.now();
          atomicWriteFileSecure(storePath, JSON.stringify(store, null, 2) + "\n", 0o600);
        }
        return j.access_token as string;
      },
      saveAccounts() {},
    };
  } catch (e) {
    // ultimate fallback
    return {
      listAccounts() { return []; },
      getEnabledAccounts() { return []; },
      getActiveAccount() { return null; },
    };
  }
}

// ===========================================================================
// 03. CONFIG HELPERS
// ===========================================================================
function loadAntigravityConfig(): any {
  try {
    if (typeof loadConfig === "function") return loadConfig();
  } catch {}
  return readJsonSafe<any>(resolveConfigPath(), DEFAULT_CONFIG ?? { cli_first: true, toast_scope: "all", soft_quota_threshold_percent: 90, quota_fallback: "auto", quota_refresh_interval_minutes: 15, soft_quota_cache_ttl_minutes: 5, pid_offset_enabled: true, google_search_enabled: false, debug: false, version_cache_ttl: 60 });
}
function saveAntigravityConfigAtomic(cfg: any): any {
  try {
    if (typeof saveConfig === "function") return saveConfig(cfg);
  } catch {}
  // manual atomic
  const validated = (() => {
    try { if (typeof parseAndValidateConfig === "function") return parseAndValidateConfig(cfg, { strict: false }); } catch {}
    return cfg;
  })();
  atomicWriteFileSecure(resolveConfigPath(), JSON.stringify(validated, null, 2) + "\n", 0o600);
  return validated;
}

// ===========================================================================
// 04. QUOTA HELPERS
// ===========================================================================
async function fetchQuotaForAccount(email: string | undefined, mgr: any, qManager: any): Promise<any> {
  const targetEmail = email ?? mgr.getActiveAccount()?.email ?? mgr.listAccounts()?.[0]?.email;
  if (!targetEmail) throw new Error("Nenhuma conta configurada. Use `login` primeiro.");
  const token = await mgr.getValidAccessToken(targetEmail);
  const projectId = mgr.findAccount?.(targetEmail)?.projectId ?? FALLBACK_PROJECT_ID;
  // Prefer quota.ts checkQuota if available
  if (checkQuotaFn && qManager) {
    // qManager already bound to token? use checkQuota directly
    try {
      if (typeof getQuotaGroupsFn === "function") {
        const groups = await getQuotaGroupsFn(token, projectId, { source: "antigravity" });
        return { email: targetEmail, groups, token, projectId };
      }
    } catch {}
  }
  // fallback: direct call to retrieveUserQuotaSummary using bypass headers
  const headers: Record<string, string> = {
    "Authorization": `Bearer ${token}`,
    "User-Agent": "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1",
    "X-Goog-Api-Client": "gl-node/22.19.0",
    "Client-Metadata": "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI",
    "Content-Type": "application/json",
  };
  const endpoints = [
    "https://daily-cloudcode-pa.googleapis.com/v1internal:retrieveUserQuotaSummary",
    "https://cloudcode-pa.googleapis.com/v1internal:retrieveUserQuotaSummary",
  ];
  let lastErr: any = null;
  for (const url of endpoints) {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 10000);
      const res = await fetch(url, { method: "POST", headers, body: JSON.stringify({ project: projectId }), signal: controller.signal });
      clearTimeout(t);
      if (!res.ok) { lastErr = new Error(`${url} -> ${res.status}`); continue; }
      const j: any = await res.json();
      return { email: targetEmail, raw: j, token, projectId, endpoint: url };
    } catch (e) { lastErr = e; }
  }
  throw lastErr ?? new Error("Falha ao buscar quota");
}

// ===========================================================================
// 05. COMMAND IMPLEMENTATIONS
// ===========================================================================

async function cmdLogin(args: string[]): Promise<void> {
  const noBrowser = args.includes("--no-browser") || args.includes("--noBrowser");
  const timeoutIdx = args.indexOf("--timeout");
  let timeoutMs = 30000;
  if (timeoutIdx >= 0 && args[timeoutIdx + 1]) {
    const v = Number(args[timeoutIdx + 1]);
    if (!Number.isNaN(v) && v > 0) timeoutMs = v;
  }
  // --email option only for hint, real email comes from OAuth userinfo
  const emailOptIdx = args.findIndex(a => a === "--email" || a.startsWith("--email="));
  let hintEmail: string | undefined;
  if (emailOptIdx >= 0) {
    const a = args[emailOptIdx];
    if (a.includes("=")) hintEmail = a.split("=")[1];
    else hintEmail = args[emailOptIdx + 1];
  }

  console.log(C.bold("\n🔐 Antigravity OAuth Login - Gemini CLI Bypass"));
  console.log(C.dim(`Client: ${GEMINI_OAUTH_CLIENT_ID}`));
  console.log(C.dim(`Project fallback: ${FALLBACK_PROJECT_ID}`));
  console.log(C.dim(`Headers: GeminiCLI/0.35.3 gl-node/22.19.0 ideType=IDE_UNSPECIFIED`));
  console.log("");

  if (!authenticate) {
    logErr("Módulo oauth.ts não carregou authenticate. Verifique imports.");
    process.exit(1);
  }

  const mgr = getAccountManager();

  try {
    const result = await authenticate({
      noBrowser,
      callbackTimeoutMs: timeoutMs,
      onLog: (lvl: string, msg: string) => {
        if (lvl === "info") logDim(`[oauth] ${msg}`);
        else if (lvl === "warn") logWarn(`[oauth] ${msg}`);
        else logErr(`[oauth] ${msg}`);
      }
    });

    const { tokens, userInfo } = result as any;
    const email = (userInfo?.email ?? hintEmail ?? "").toLowerCase();
    if (!email) throw new Error("Não foi possível determinar email do usuário.");

    logOk(`Autenticado como ${C.bold(userInfo?.name ?? email)} <${email}>`);

    // Add to store
    const account = mgr.addAccount({
      email,
      refreshToken: tokens.refresh_token ?? tokens.refreshToken ?? result.tokens?.refresh_token,
      accessToken: tokens.access_token ?? tokens.accessToken,
      expiryDate: tokens.expires_at ?? Date.now() + (tokens.expires_in ?? 3600) * 1000,
      projectId: FALLBACK_PROJECT_ID,
      enabled: true,
      oauthClientKey: "gemini-cli",
      oauthClientConfig: {
        clientId: GEMINI_OAUTH_CLIENT_ID,
        clientSecret: GEMINI_OAUTH_CLIENT_SECRET,
      },
      scopes: [
        "https://www.googleapis.com/auth/cloud-platform",
        "https://www.googleapis.com/auth/userinfo.email",
        "https://www.googleapis.com/auth/userinfo.profile",
      ],
    });

    console.log("");
    logOk(`Conta ${C.b(`${email}`)} adicionada/salva com sucesso.`);
    console.log(C.dim(`  Store: ${resolveAccountsPath()} (chmod 600)`));
    console.log(C.dim(`  AccessToken: ${maskToken(account.accessToken ?? tokens.access_token)} expira ${formatDate(account.expiryDate)}`));
    console.log(C.dim(`  RefreshToken: ${maskToken(account.refreshToken)}`));
    console.log("");

    // Auto set active if first or none active
    try {
      const active = mgr.getActiveAccount?.();
      if (!active || active.email.toLowerCase() !== email) {
        mgr.setActive?.(email, { sticky: false });
        console.log(C.gray(`→ Definida como ativa (use set-active para trocar)`));
      }
    } catch {}

    // Verify quota quickly
    try {
      logInfo("Verificando quota inicial...");
      const q = await fetchQuotaForAccount(email, mgr, null);
      if (q.raw?.quotaGroups || q.groups) logOk("Quota reachable via bypass headers.");
      else logWarn("Quota retornou vazio, mas conta válida.");
    } catch (e) {
      logWarn(`Não foi possível verificar quota agora: ${(e as Error).message}`);
    }

  } catch (e) {
    logErr(`Falha no login: ${(e as Error).message}`);
    console.error(C.dim((e as Error).stack ?? ""));
    process.exit(1);
  }
}

async function cmdAccounts(args: string[]): Promise<void> {
  const sub = (args[0] ?? "list").toLowerCase();
  const mgr = getAccountManager();

  switch (sub) {
    case "list":
    case "ls": {
      const jsonFlag = args.includes("--json");
      const accounts = mgr.listAccounts?.() ?? [];
      const activeEmail = (() => { try { return mgr.getActiveAccount?.()?.email ?? null; } catch { return null; } })();
      if (jsonFlag) {
        console.log(JSON.stringify({ activeEmail, accounts: accounts.map((a: any) => ({ ...a, refreshToken: maskToken(a.refreshToken) })), count: accounts.length }, null, 2));
        return;
      }
      console.log(C.bold(`\n👥 Contas Antigravity (${accounts.length}) - ${resolveAccountsPath()}`));
      if (accounts.length === 0) {
        logWarn("Nenhuma conta configurada. Use: cli.ts login");
        return;
      }
      console.log(C.dim(`Ativa: ${activeEmail ?? "nenhuma"} | Estratégia: ${(mgr as any).store?.rotationStrategy ?? "round-robin"}`));
      console.log("");
      for (const acc of accounts) {
        const isActive = activeEmail && acc.email.toLowerCase() === activeEmail.toLowerCase();
        const enabled = acc.enabled !== false && !(acc.disabledUntil && acc.disabledUntil > Date.now());
        const statusIcon = enabled ? C.green("●") : C.red("○");
        const activeMark = isActive ? C.bold(C.bgGreen(" ACTIVE ")) + " " : "         ";
        const fail = acc.failureCount ? C.yellow(` fail=${acc.failureCount}`) : "";
        const disabledReason = acc.disabledReason ? C.dim(` (${acc.disabledReason})`) : "";
        console.log(`${statusIcon} ${activeMark}${C.bold(acc.email)} ${enabled ? C.green("enabled") : C.red("disabled")} ${C.dim(`project=${acc.projectId ?? FALLBACK_PROJECT_ID}`)}${fail}${disabledReason}`);
        console.log(`   ${C.dim(`created=${formatDate(acc.createdAt)} lastUsed=${formatDate(acc.lastUsedAt)} expiry=${formatDate(acc.expiryDate)} token=${maskToken(acc.accessToken ?? "")} refresh=${maskToken(acc.refreshToken)}`)}`);
      }
      console.log("");
      break;
    }
    case "add": {
      // manual add via flags --email --refresh-token
      const emailIdx = args.findIndex(a => a === "--email" || a.startsWith("--email="));
      const refreshIdx = args.findIndex(a => a === "--refresh-token" || a.startsWith("--refresh-token=") || a === "--refresh" || a.startsWith("--refresh="));
      let email = "";
      let refresh = "";
      if (emailIdx >= 0) {
        const v = args[emailIdx];
        email = v.includes("=") ? v.split("=").slice(1).join("=") : args[emailIdx + 1] ?? "";
      }
      if (refreshIdx >= 0) {
        const v = args[refreshIdx];
        refresh = v.includes("=") ? v.split("=").slice(1).join("=") : args[refreshIdx + 1] ?? "";
      }
      if (!email || !refresh) {
        console.log(C.bold("Uso: accounts add --email <email> --refresh-token <token> [--project <id>]"));
        process.exit(1);
      }
      const projIdx = args.findIndex(a => a === "--project" || a.startsWith("--project="));
      let project = FALLBACK_PROJECT_ID;
      if (projIdx >= 0) {
        const v = args[projIdx];
        project = v.includes("=") ? v.split("=").slice(1).join("=") : args[projIdx + 1] ?? FALLBACK_PROJECT_ID;
      }
      const acc = mgr.addAccount({ email, refreshToken: refresh, projectId: project, enabled: true, oauthClientKey: "gemini-cli" });
      logOk(`Conta ${email} adicionada. Total: ${mgr.listAccounts().length}`);
      console.log(C.dim(`  ${JSON.stringify({ email: acc.email, projectId: acc.projectId, enabled: acc.enabled })}`));
      break;
    }
    case "remove":
    case "rm":
    case "delete":
    case "del": {
      const email = args[1];
      if (!email) { console.log("Uso: accounts remove <email>"); process.exit(1); }
      const ok = mgr.removeAccount(email);
      if (ok) logOk(`Removida ${email}`);
      else logErr(`Não encontrada ${email}`);
      break;
    }
    case "enable": {
      const email = args[1];
      if (!email) { console.log("Uso: accounts enable <email>"); process.exit(1); }
      try { mgr.enableAccount(email); logOk(`Habilitada ${email}`); } catch (e) { logErr((e as Error).message); }
      break;
    }
    case "disable": {
      const email = args[1];
      if (!email) { console.log("Uso: accounts disable <email> [--reason <txt>]"); process.exit(1); }
      const reasonIdx = args.indexOf("--reason");
      const reason = reasonIdx >= 0 ? args[reasonIdx + 1] : "manually disabled via CLI";
      try { mgr.disableAccount(email, reason); logOk(`Desabilitada ${email} reason=${reason}`); } catch (e) { logErr((e as Error).message); }
      break;
    }
    case "set-active":
    case "active":
    case "use": {
      const email = args[1];
      if (!email) { console.log("Uso: accounts set-active <email> [--sticky]"); process.exit(1); }
      const sticky = args.includes("--sticky");
      try {
        mgr.setActive(email, { sticky });
        logOk(`Ativa agora: ${email} ${sticky ? "(sticky)" : "(round-robin)"}`);
      } catch (e) { logErr((e as Error).message); process.exit(1); }
      break;
    }
    case "import": {
      const importPathIdx = args.findIndex(a => a === "--path" || a.startsWith("--path="));
      let customPath: string | undefined;
      if (importPathIdx >= 0) {
        const v = args[importPathIdx];
        customPath = v.includes("=") ? v.split("=").slice(1).join("=") : args[importPathIdx + 1];
      }
      try {
        if (typeof (mgr as any).importFromAntigravityManager === "function") {
          const res = await (mgr as any).importFromAntigravityManager(customPath ? [customPath] : undefined);
          console.log(C.bold(`\nImport resultado: imported=${(res as any).imported} updated=${(res as any).updated} skipped=${(res as any).skipped}`));
          if ((res as any).errors?.length) console.log(C.yellow(`Erros: ${(res as any).errors.join("; ")}`));
          if ((res as any).sources?.length) console.log(C.dim(`Sources: ${(res as any).sources.join(", ")}`));
        } else if (typeof (mgr as any).importFromAntigravity === "function") {
          const res = await (mgr as any).importFromAntigravity();
          console.log(JSON.stringify(res, null, 2));
        } else {
          logWarn("Método importFromAntigravityManager não disponível nesta versão do AccountManager. Tentando import manual...");
          // manual fallback: scan known paths
          const candidates = customPath ? [customPath] : [
            path.join(os.homedir(), ".config", "antigravity", "accounts.json"),
            path.join(os.homedir(), ".antigravity", "accounts.json"),
            path.join(os.homedir(), ".config", "opencode", "antigravity-manager.json"),
          ];
          let count = 0;
          for (const p of candidates) {
            if (!fs.existsSync(p)) continue;
            try {
              const data = JSON.parse(fs.readFileSync(p, "utf8"));
              const arr = Array.isArray(data) ? data : (data.accounts ?? []);
              for (const raw of arr) {
                const email = (raw.email ?? raw.user_email)?.toLowerCase();
                const rt = raw.refreshToken ?? raw.refresh_token;
                if (email && rt) { mgr.addAccount({ email, refreshToken: rt, projectId: raw.projectId ?? FALLBACK_PROJECT_ID }); count++; }
              }
              logOk(`Importado ${arr.length} de ${p}`);
            } catch (e) { logWarn(`Falha ${p}: ${(e as Error).message}`); }
          }
          console.log(C.dim(`Total import manual: ${count}`));
        }
      } catch (e) { logErr(`Import falhou: ${(e as Error).message}`); }
      break;
    }
    default:
      console.log(C.bold("\nSubcomandos accounts:"));
      console.log("  list [--json]                 Lista contas");
      console.log("  add --email --refresh-token  Adiciona manual");
      console.log("  remove <email>               Remove conta");
      console.log("  enable <email>               Habilita conta");
      console.log("  disable <email>              Desabilita conta");
      console.log("  set-active <email> [--sticky] Define ativa e estratégia");
      console.log("  import [--path <file>]       Importa de antigravity-manager");
      break;
  }
}

function formatQuotaBar(remaining: number, limit: number): string {
  const cfg = loadAntigravityConfig();
  const softPct = cfg.soft_quota_threshold_percent ?? 90;
  const used = limit - remaining;
  const pctUsed = limit > 0 ? (used / limit) * 100 : 0;
  const barLen = 20;
  const filled = Math.round((pctUsed / 100) * barLen);
  const bar = "█".repeat(filled) + "░".repeat(barLen - filled);
  let col = C.green;
  if (pctUsed >= softPct) col = C.yellow;
  if (pctUsed >= 98) col = C.red;
  return `${col(bar)} ${pctUsed.toFixed(1)}% usado (${remaining}/${limit} restante)`;
}

async function cmdQuota(args: string[]): Promise<void> {
  const jsonFlag = args.includes("--json");
  const allFlag = args.includes("--all");
  let emailArg: string | undefined = undefined;
  // positional email unless flag
  for (const a of args) {
    if (!a.startsWith("-") && a.includes("@")) { emailArg = a; break; }
  }
  const emailIdx = args.findIndex(a => a === "--email" || a.startsWith("--email="));
  if (emailIdx >= 0) {
    const v = args[emailIdx];
    emailArg = v.includes("=") ? v.split("=").slice(1).join("=") : args[emailIdx + 1];
  }

  const mgr = getAccountManager();
  const stores = mgr.listAccounts?.() ?? [];
  if (stores.length === 0) { logWarn("Nenhuma conta. Faça login primeiro."); return; }

  const targets = allFlag ? stores.map((s: any) => s.email) : [emailArg ?? stores[0]?.email];
  const cfg = loadAntigravityConfig();
  const softThresh = (cfg.soft_quota_threshold_percent ?? 90) / 100;

  console.log(C.bold(`\n📊 Quota Check - soft threshold ${cfg.soft_quota_threshold_percent}% | refresh ${cfg.quota_refresh_interval_minutes}min`));
  console.log(C.dim(`Bypass: GeminiCLI/0.35.3 gl-node/22.19.0 Client-Metadata=IDE_UNSPECIFIED`));
  console.log("");

  let qManagerInst: any = null;
  try {
    if (QuotaManager) qManagerInst = new QuotaManager({ projectFallback: FALLBACK_PROJECT_ID, softThreshold: softThresh });
    else if (getDefaultQuotaManager) qManagerInst = getDefaultQuotaManager({ softThreshold: softThresh });
  } catch {}

  for (const email of targets) {
    if (!email) continue;
    console.log(C.bold(`— ${email} —`));
    try {
      const token = await mgr.getValidAccessToken(email);
      const quotaResult = await fetchQuotaForAccount(email, mgr, qManagerInst);
      const raw = (quotaResult as any).raw ?? {};
      const groups = (quotaResult as any).groups ?? [];

      if (jsonFlag) {
        console.log(JSON.stringify({ email, raw, groups, endpoint: (quotaResult as any).endpoint, projectId: (quotaResult as any).projectId }, null, 2));
        continue;
      }

      // Parse raw if coming from API
      if (raw && typeof raw === "object") {
        // raw may have structure with quotaBuckets or similar
        const buckets = raw.quotaBuckets ?? raw.buckets ?? raw.quota ?? [];
        if (Array.isArray(buckets) && buckets.length) {
          for (const b of buckets) {
            const name = b.displayName ?? b.group ?? b.name ?? b.id ?? "unknown";
            const remaining = b.remaining ?? b.remainingQuota ?? 0;
            const limit = b.limit ?? b.quotaLimit ?? b.max ?? (remaining + (b.used ?? 0));
            const reset = b.resetTime ?? b.reset_at ?? b.resetAt;
            console.log(`  ${C.cyan(name)}: ${formatQuotaBar(remaining, limit)} ${reset ? C.dim(`reset=${formatDate(new Date(reset).getTime())}`) : ""}`);
            if (b.models?.length) console.log(`    ${C.dim(`models: ${b.models.slice(0, 5).join(", ")}${b.models.length > 5 ? "..." : ""}`)}`);
          }
        } else if (Object.keys(raw).length) {
          // pretty print all top-level keys
          console.log(C.dim(`  raw keys: ${Object.keys(raw).join(", ")}`));
          // try to interpret known fields
          for (const k of Object.keys(raw)) {
            const v = (raw as any)[k];
            if (v && typeof v === "object" && "remaining" in v) {
              console.log(`  ${C.cyan(k)}: ${formatQuotaBar((v as any).remaining ?? 0, (v as any).limit ?? 1000)}`);
            }
          }
          if (Array.isArray((raw as any).quotaGroups)) {
            for (const g of (raw as any).quotaGroups) {
              console.log(`  ${C.cyan(g.displayName ?? g.id)} remaining=${g.remaining ?? "?"} limit=${g.limit ?? "?"}`);
            }
          } else {
            console.log(`  ${C.dim(JSON.stringify(raw).slice(0, 800))}`);
          }
        }
      }

      if (groups.length) {
        for (const g of groups) {
          console.log(`  ${C.cyan(g.id ?? g.group)}: remaining=${(g as any).remaining ?? "?"} used=${(g as any).used ?? "?"} limit=${(g as any).limit ?? "?"}`);
          if ((g as any).models) console.log(`    ${C.dim(`models: ${(g as any).models.join(", ")}`)}`);
        }
      }

      if (!raw || Object.keys(raw).length === 0 && (!groups || groups.length === 0)) {
        logWarn("  Quota vazia - endpoint pode ter retornado 1.0 (comportamento esperado para gemini-cli) tentando daily endpoint...");
      }

      // Evaluate threshold warnings
      const thresholdPct = cfg.soft_quota_threshold_percent ?? 90;
      console.log(C.dim(`  soft_threshold=${thresholdPct}% | project=${(quotaResult as any).projectId ?? FALLBACK_PROJECT_ID} | endpoint=${(quotaResult as any).endpoint ?? "quota_manager"}`));
    } catch (e) {
      logErr(`  ${email}: ${(e as Error).message}`);
      if (jsonFlag) console.log(JSON.stringify({ email, error: (e as Error).message }, null, 2));
    }
    console.log("");
  }
}

async function cmdConfig(args: string[]): Promise<void> {
  const sub = (args[0] ?? "list").toLowerCase();
  const cfg = loadAntigravityConfig();

  switch (sub) {
    case "list":
    case "ls":
    case "show": {
      const jsonFlag = args.includes("--json");
      if (jsonFlag) { console.log(JSON.stringify(cfg, null, 2)); return; }
      console.log(C.bold(`\n⚙️  Config Antigravity - ${resolveConfigPath()} (chmod 600)`));
      console.log("");
      for (const [k, v] of Object.entries(cfg)) {
        console.log(`  ${C.cyan(k)}: ${C.bold(String(v))} ${C.dim(`(default: ${String((DEFAULT_CONFIG as any)?.[k] ?? "-")})`)}`);
      }
      console.log("");
      console.log(C.dim("Ajustáveis:"));
      console.log(C.dim("  cli_first (bool), toast_scope (all|project|minimal|none), soft_quota_threshold_percent (0-100)"));
      console.log(C.dim("  quota_fallback (true|false|auto|<model>), quota_refresh_interval_minutes (1-1440)"));
      console.log(C.dim("  soft_quota_cache_ttl_minutes, pid_offset_enabled (bool), google_search_enabled (bool), debug (bool), version_cache_ttl"));
      break;
    }
    case "get": {
      const key = args[1];
      if (!key) { console.log("Uso: config get <key>"); process.exit(1); }
      const val = (cfg as any)[key];
      if (val === undefined) { logWarn(`Key ${key} não encontrada`); process.exit(1); }
      console.log(`${key}=${JSON.stringify(val)}`);
      break;
    }
    case "set": {
      const key = args[1];
      const rawVal = args[2];
      if (!key || rawVal === undefined) { console.log("Uso: config set <key> <value>\nEx: config set soft_quota_threshold_percent 85\n     config set cli_first false"); process.exit(1); }
      // parse value smartly
      let parsed: any = rawVal;
      if (rawVal === "true") parsed = true;
      else if (rawVal === "false") parsed = false;
      else if (!Number.isNaN(Number(rawVal)) && rawVal.trim() !== "") {
        const n = Number(rawVal);
        if (Number.isFinite(n)) parsed = n;
      } else {
        // strip quotes
        parsed = rawVal.replace(/^['"]|['"]$/g, "");
      }

      // Special handling: model catalog validation for quota_fallback if string and not auto/bool
      if (key === "quota_fallback" && typeof parsed === "string" && !["true", "false", "auto"].includes(parsed)) {
        // allow model ids
        const isModel = ALL_MODELS_2026.some((m: any) => m.id === parsed);
        if (!isModel) {
          logWarn(`Valor ${parsed} não é modelo conhecido. Permitidos: ${ALL_MODELS_2026.map((m: any) => m.id).join(", ")} ou auto/true/false`);
          // continue anyway
        }
      }

      const partial: any = { [key]: parsed };
      try {
        const updated = (() => {
          try { if (typeof updateConfig === "function") return updateConfig(partial); } catch {}
          // manual merge atomic
          const current = loadAntigravityConfig();
          const merged = { ...current, ...partial };
          // validate
          let validated = merged;
          try { if (typeof parseAndValidateConfig === "function") validated = parseAndValidateConfig(merged, { strict: false }); } catch {}
          saveAntigravityConfigAtomic(validated);
          return validated;
        })();
        logOk(`Config ${C.bold(key)}=${C.bold(String(parsed))} salvo.`);
        console.log(C.dim(JSON.stringify(updated, null, 2)));
      } catch (e) {
        logErr(`Falha ao salvar config: ${(e as Error).message}`);
        process.exit(1);
      }
      break;
    }
    case "reset":
    case "defaults": {
      try {
        saveAntigravityConfigAtomic(DEFAULT_CONFIG ?? cfg);
        logOk("Config resetada para defaults.");
        console.log(C.dim(JSON.stringify(DEFAULT_CONFIG, null, 2)));
      } catch (e) { logErr((e as Error).message); }
      break;
    }
    default:
      console.log(C.bold("Subcomandos config: list [--json], get <key>, set <key> <value>, reset"));
      console.log(C.dim("Exemplos:"));
      console.log(C.dim("  config set soft_quota_threshold_percent 85"));
      console.log(C.dim("  config set quota_refresh_interval_minutes 30"));
      console.log(C.dim("  config set toast_scope minimal"));
      break;
  }
}

async function cmdModels(args: string[]): Promise<void> {
  const sub = (args[0] ?? "list").toLowerCase();
  const jsonFlag = args.includes("--json");
  const apiFilter = (() => {
    const idx = args.indexOf("--api");
    if (idx >= 0) return args[idx + 1];
    const apiEq = args.find(a => a.startsWith("--api="));
    if (apiEq) return apiEq.split("=")[1];
    return undefined;
  })();

  if (sub === "info" || sub === "show") {
    const id = args[1];
    if (!id) { console.log("Uso: models info <model-id>"); process.exit(1); }
    const model = (ALL_MODELS_2026 as any[]).find((m: any) => m.id === id);
    if (!model) {
      logErr(`Modelo ${id} não encontrado. Use models list`);
      process.exit(1);
    }
    if (jsonFlag) { console.log(JSON.stringify(model, null, 2)); return; }
    console.log(C.bold(`\n📦 ${model.name} (${model.id})`));
    console.log(`  ${C.cyan("API")}: ${model.api} | ${C.cyan("Provider")}: ${model.provider ?? "google"}`);
    console.log(`  ${C.cyan("Context")}: ${model.context} | Output: ${model.output}`);
    console.log(`  ${C.cyan("Family")}: ${model.family} | QuotaGroup: ${model.quotaGroup}`);
    if (model.preview) console.log(`  ${C.yellow("preview=true")}`);
    if (model.thinking) console.log(`  ${C.magenta("thinking=true")}`);
    if (model.customTools) console.log(`  ${C.blue("customTools=true")}`);
    // routing info if available
    try {
      const routing = (constantsMod.MODEL_ROUTING as any)?.[id] ?? (constantsPkg.MODEL_ROUTING as any)?.[id];
      if (routing) {
        console.log(`  ${C.cyan("Routing")}: endpoint=${routing.endpoint} cloudModelId=${routing.cloudModelId} stream=${routing.stream}`);
      }
    } catch {}
    console.log("");
    return;
  }

  // list
  let list = ALL_MODELS_2026 as any[];
  if (apiFilter) list = list.filter(m => m.api === apiFilter);
  if (jsonFlag) { console.log(JSON.stringify(list, null, 2)); return; }

  console.log(C.bold(`\n📚 Catálogo ALL_MODELS_2026 (${list.length} modelos)`));
  console.log(C.dim(`Fallback project: ${FALLBACK_PROJECT_ID} | Client: GeminiCLI/0.35.3`));
  console.log("");
  console.log(C.dim(`  ${"ID".padEnd(38)} ${"API".padEnd(14)} ${"CTX".padEnd(8)} QUOTA-GROUP`));
  console.log(C.dim("  " + "-".repeat(80)));
  for (const m of list) {
    const idPad = m.id.padEnd(38);
    const apiPad = m.api.padEnd(14);
    const ctx = String(m.context).padEnd(8);
    const color = m.api === "antigravity" ? C.cyan : C.green;
    const preview = m.preview ? C.yellow(" preview") : "";
    const think = m.thinking ? C.magenta(" thinking") : "";
    console.log(`  ${color(idPad)} ${apiPad} ${ctx} ${m.quotaGroup}${preview}${think}`);
  }
  console.log("");
  console.log(C.dim("Use: models info <id> para detalhes"));
  console.log(C.dim("Filtro: --api antigravity | --api gemini-cli"));
}

async function cmdStatus(_args: string[]): Promise<void> {
  const mgr = getAccountManager();
  const cfg = loadAntigravityConfig();
  const accounts = mgr.listAccounts?.() ?? [];
  const active = (() => { try { return mgr.getActiveAccount?.(); } catch { return null; } })();
  console.log(C.bold("\n🩺 Status Antigravity"));
  console.log(C.dim(`BaseDir: ${resolveBaseDir()} | AccountsFile: ${resolveAccountsPath()} | ConfigFile: ${resolveConfigPath()}`));
  console.log("");
  console.log(`  ${C.cyan("Contas")}: ${accounts.length} total, ${accounts.filter((a: any) => a.enabled !== false).length} habilitadas`);
  if (active) console.log(`  ${C.cyan("Ativa")}: ${C.bold(active.email)} (project=${active.projectId ?? FALLBACK_PROJECT_ID})`);
  else console.log(`  ${C.cyan("Ativa")}: ${C.yellow("nenhuma")}`);
  console.log(`  ${C.cyan("Config")}: cli_first=${cfg.cli_first} toast_scope=${cfg.toast_scope} soft_quota=${cfg.soft_quota_threshold_percent}% refresh=${cfg.quota_refresh_interval_minutes}min fallback=${cfg.quota_fallback}`);
  // file perms
  for (const p of [resolveAccountsPath(), resolveConfigPath()]) {
    try {
      if (!fs.existsSync(p)) { console.log(`  ${C.dim(p)}: ${C.yellow("não existe")}`); continue; }
      const stat = fs.statSync(p);
      const mode = (stat.mode & 0o777).toString(8);
      const ok = mode === "600" || mode === "700";
      console.log(`  ${C.dim(p)}: mode=${ok ? C.green(mode) : C.red(mode)} size=${stat.size}b mtime=${formatDate(stat.mtimeMs)}`);
    } catch (e) { console.log(`  ${C.dim(p)}: ${C.red((e as Error).message)}`); }
  }
  // version cache
  try {
    const vInfo = await getVersionInfo();
    console.log(`  ${C.cyan("Antigravity Version")}: ${vInfo.version} (source=${vInfo.source})`);
  } catch (e) { console.log(`  ${C.cyan("Antigravity Version")}: ${C.yellow("falha ao obter - usando fallback")}`); }
  console.log("");
  // quick quota summary for active
  if (active) {
    try {
      console.log(C.dim("Verificando quota rápida da conta ativa..."));
      const q = await fetchQuotaForAccount(active.email, mgr, null);
      const buckets = (q.raw?.quotaBuckets ?? q.raw?.buckets ?? []) as any[];
      if (buckets.length) {
        for (const b of buckets.slice(0, 5)) {
          const name = b.displayName ?? b.group ?? "quota";
          console.log(`  ${C.cyan(name)} remaining=${b.remaining ?? "?"} limit=${b.limit ?? "?"}`);
        }
      } else {
        console.log(C.dim("  Quota raw disponível, mas sem buckets detalhados (pode ser daily endpoint vs base)"));
      }
    } catch (e) { logWarn(`  Quota check falhou: ${(e as Error).message}`); }
  }
  console.log("");
}

async function cmdDoctor(_args: string[]): Promise<void> {
  console.log(C.bold("\n🧰 Doctor - Diagnóstico Antigravity"));
  console.log("");
  const checks: Array<{ name: string; ok: boolean; msg: string }> = [];
  // dir
  try {
    const base = resolveBaseDir();
    ensureDirExists(base);
    const stat = fs.statSync(base);
    checks.push({ name: "baseDir exists", ok: true, msg: `${base} mode=${(stat.mode & 0o777).toString(8)}` });
  } catch (e) { checks.push({ name: "baseDir exists", ok: false, msg: (e as Error).message }); }
  // accounts file
  try {
    const p = resolveAccountsPath();
    if (fs.existsSync(p)) {
      const st = fs.statSync(p);
      const mode = (st.mode & 0o777).toString(8);
      checks.push({ name: "accounts file", ok: mode === "600", msg: `${p} mode=${mode} ${mode !== "600" ? "(deve ser 600)" : ""}` });
      // try to chmod fix
      if (mode !== "600") { try { fs.chmodSync(p, 0o600); checks.push({ name: "chmod fix accounts", ok: true, msg: "corrigido para 600" }); } catch {} }
      const data = readJsonSafe<any>(p, { accounts: [] });
      checks.push({ name: "accounts valid JSON", ok: true, msg: `${data.accounts?.length ?? 0} contas` });
      // check tokens expiring
      const now = Date.now();
      const expiring = (data.accounts ?? []).filter((a: any) => a.expiryDate && a.expiryDate < now + 600000);
      checks.push({ name: "token expiry", ok: expiring.length === 0, msg: expiring.length ? `${expiring.length} token(s) expirando <10min` : "todos válidos" });
    } else {
      checks.push({ name: "accounts file", ok: false, msg: `${p} não existe - execute login` });
    }
  } catch (e) { checks.push({ name: "accounts file", ok: false, msg: (e as Error).message }); }
  // config file
  try {
    const p = resolveConfigPath();
    if (fs.existsSync(p)) {
      const st = fs.statSync(p);
      checks.push({ name: "config file", ok: true, msg: `${p} mode=${(st.mode & 0o777).toString(8)}` });
      const cfg = readJsonSafe<any>(p, {});
      checks.push({ name: "config valid", ok: Object.keys(cfg).length > 0, msg: `${Object.keys(cfg).length} keys` });
    } else {
      checks.push({ name: "config file", ok: false, msg: `${p} não existe - será criado com defaults` });
      saveAntigravityConfigAtomic(DEFAULT_CONFIG ?? { cli_first: true });
      checks.push({ name: "config created", ok: true, msg: "defaults criados" });
    }
  } catch (e) { checks.push({ name: "config file", ok: false, msg: (e as Error).message }); }
  // bypass headers constants
  checks.push({ name: "bypass constants", ok: GEMINI_OAUTH_CLIENT_ID.includes("681255809395"), msg: `client_id=${maskToken(GEMINI_OAUTH_CLIENT_ID)} UA=GeminiCLI/0.35.3 X-Goog=gl-node/22.19.0` });
  // fetch project?
  checks.push({ name: "fallback project", ok: !!FALLBACK_PROJECT_ID, msg: FALLBACK_PROJECT_ID });

  for (const ch of checks) {
    console.log(`  ${ch.ok ? C.green("✔") : C.red("✖")} ${C.bold(ch.name)}: ${ch.msg}`);
  }
  console.log("");
  // sugestões
  console.log(C.dim("Sugestões:"));
  console.log(C.dim("  - Se token expirando: o AccountManager faz refresh automático ao usar, ou rode `login` novamente"));
  console.log(C.dim("  - Se mode !=600: o CLI corrige automaticamente na próxima escrita"));
  console.log(C.dim("  - Para forçar bypass headers: use sempre gl-node/22.19.0 e Client-Metadata IDE_UNSPECIFIED"));
  console.log("");
}

async function cmdVersion(_args: string[]): Promise<void> {
  const jsonFlag = _args.includes("--json");
  try {
    const info = await getVersionInfo();
    const pluginVersion = (() => { try { return (versionMod.PLUGIN_VERSION ?? PLUGIN_VERSION_FALLBACK); } catch { return PLUGIN_VERSION_FALLBACK; } })();
    if (jsonFlag) {
      console.log(JSON.stringify({ plugin: PLUGIN_VERSION_FALLBACK, antigravity: info.version, full: info, client_id: GEMINI_OAUTH_CLIENT_ID, project: FALLBACK_PROJECT_ID, models: ALL_MODELS_2026.length }, null, 2));
      return;
    }
    console.log(C.bold("\n🔖 Versões"));
    console.log(`  Plugin opencode-antigravity-auth: ${C.bold(PLUGIN_VERSION_FALLBACK)}`);
    console.log(`  Antigravity: ${C.bold(info.version)} full=${(info as any).fullVersion ?? "-"} source=${info.source}`);
    console.log(`  ClientID: ${C.dim(maskToken(GEMINI_OAUTH_CLIENT_ID))} (Gemini CLI 0.35.3)`);
    console.log(`  Project fallback: ${FALLBACK_PROJECT_ID}`);
    console.log(`  Models catalog: ${ALL_MODELS_2026.length} (antigravity-first)`);
    console.log(`  BaseDir: ${resolveBaseDir()}`);
  } catch (e) {
    console.log(C.bold(`\n🔖 Versão fallback: ${PLUGIN_VERSION_FALLBACK}`));
    console.log(C.dim(`Erro ao buscar versão remota: ${(e as Error).message}`));
  }
}

// ===========================================================================
// 06. MENU INTERATIVO
// ===========================================================================
async function interactiveMenu(): Promise<void> {
  const rl = readline.createInterface({ input, output });
  let exit = false;
  const mgr = getAccountManager();

  const menu = `
${C.bold("╔════════════════════════════════════════════════════════╗")}
${C.bold("║  Opencode Antigravity Auth - CLI Interativo (Onda 5)  ║")}
${C.bold("╚════════════════════════════════════════════════════════╝")}
${C.dim(`Dir: ${resolveBaseDir()} | Client: GeminiCLI/0.35.3 | gl-node/22.19.0 | project=${FALLBACK_PROJECT_ID}`)}

${C.cyan("1")}  🔐 Login OAuth (PKCE + browser)
${C.cyan("2")}  👥 Listar contas
${C.cyan("3")}  ➕ Adicionar conta manualmente
${C.cyan("4")}  🔄 Set active / estratégia rotação
${C.cyan("5")}  ✅ Enable / Disable conta
${C.cyan("6")}  🗑️  Remover conta
${C.cyan("7")}  📊 Checar quotas (ativa ou todas)
${C.cyan("8")}  ⚙️  Configurar thresholds / catálogo
${C.cyan("9")}  📚 Modelos (catálogo ALL_MODELS_2026)
${C.cyan("10")} 🩺 Status + Doctor
${C.cyan("11")} 🔖 Versão
${C.cyan("0")}  🚪 Sair
`;

  while (!exit) {
    console.log(menu);
    const choice = (await rl.question(`${C.bold("Escolha [0-11]: ")}`)).trim();
    switch (choice) {
      case "1": {
        const noB = (await rl.question("No-browser? (s/N): ")).trim().toLowerCase();
        await cmdLogin(noB === "s" || noB === "sim" ? ["--no-browser"] : []);
        break;
      }
      case "2": {
        await cmdAccounts(["list"]);
        break;
      }
      case "3": {
        const email = (await rl.question("Email: ")).trim();
        const rt = (await rl.question("Refresh token: ")).trim();
        if (!email || !rt) { logWarn("Cancelado"); break; }
        const proj = (await rl.question(`Project ID [${FALLBACK_PROJECT_ID}]: `)).trim() || FALLBACK_PROJECT_ID;
        try { mgr.addAccount({ email, refreshToken: rt, projectId: proj, enabled: true }); logOk(`Adicionada ${email}`); } catch (e) { logErr((e as Error).message); }
        break;
      }
      case "4": {
        await cmdAccounts(["list"]);
        const email = (await rl.question("Email para ativar: ")).trim();
        if (!email) break;
        const sticky = (await rl.question("Modo sticky? (s/N): ")).trim().toLowerCase();
        try { mgr.setActive(email, { sticky: sticky === "s" }); logOk(`Ativa ${email} sticky=${sticky === "s"}`); } catch (e) { logErr((e as Error).message); }
        break;
      }
      case "5": {
        await cmdAccounts(["list"]);
        const email = (await rl.question("Email para toggle enable/disable: ")).trim();
        if (!email) break;
        const act = (await rl.question("Enable (e) / Disable (d)? [e/d]: ")).trim().toLowerCase();
        try {
          if (act === "d") { mgr.disableAccount(email, "manual interactive"); logOk(`Desabilitada ${email}`); }
          else { mgr.enableAccount(email); logOk(`Habilitada ${email}`); }
        } catch (e) { logErr((e as Error).message); }
        break;
      }
      case "6": {
        await cmdAccounts(["list"]);
        const email = (await rl.question("Email para remover: ")).trim();
        if (!email) break;
        const conf = (await rl.question(`Confirma remover ${email}? digite SIM: `)).trim();
        if (conf !== "SIM") { logWarn("Cancelado"); break; }
        const ok = mgr.removeAccount(email);
        if (ok) logOk(`Removida ${email}`); else logErr("Não encontrada");
        break;
      }
      case "7": {
        const all = (await rl.question("Todas contas? (s/N): ")).trim().toLowerCase();
        const json = (await rl.question("Saída JSON? (s/N): ")).trim().toLowerCase();
        const args: string[] = [];
        if (all === "s") args.push("--all");
        if (json === "s") args.push("--json");
        await cmdQuota(args);
        break;
      }
      case "8": {
        await cmdConfig(["list"]);
        const k = (await rl.question("Key para alterar (ou enter p/ voltar): ")).trim();
        if (!k) break;
        const v = (await rl.question(`Novo valor para ${k}: `)).trim();
        if (!v) break;
        await cmdConfig(["set", k, v]);
        break;
      }
      case "9": {
        const api = (await rl.question("Filtrar API (antigravity/gemini-cli/enter todos): ")).trim();
        if (api) await cmdModels(["list", "--api", api]);
        else await cmdModels(["list"]);
        const mid = (await rl.question("Ver info de modelo (id) ou enter p/ voltar: ")).trim();
        if (mid) await cmdModels(["info", mid]);
        break;
      }
      case "10": {
        await cmdStatus([]);
        await cmdDoctor([]);
        break;
      }
      case "11": {
        await cmdVersion([]);
        break;
      }
      case "0":
      case "q":
      case "quit":
      case "exit": {
        exit = true;
        break;
      }
      default:
        logWarn("Opção inválida");
        break;
    }
    if (!exit) {
      await rl.question(C.dim("\n[enter para continuar]"));
    }
  }
  rl.close();
  console.log(C.green("\nAté logo! 👋"));
}

// ===========================================================================
// 07. HELP & MAIN ROUTER
// ===========================================================================
function printHelp(): void {
  console.log(C.bold(`
opencode-antigravity-auth CLI (Onda 5 - Finalização) - produção-ready
Pasta blindada: /mnt/data/auth | Grava em ~/.config/opencode/ (600) atomic
Bypass: client_id 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j / secret GOCSPX-4... / UA GeminiCLI/0.35.3 / gl-node/22.19.0 / Client-Metadata IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI / project rising-fact-p41fc

Uso:
  cli.ts <comando> [subcomando] [flags]

Comandos:
  login [--no-browser] [--timeout <ms>] [--email <email>]
      OAuth PKCE Antigravity via oauth.ts (abre browser local com callback http://127.0.0.1)

  accounts list [--json]
  accounts add --email <email> --refresh-token <token> [--project <id>]
  accounts remove <email>
  accounts enable <email>
  accounts disable <email> [--reason <texto>]
  accounts set-active <email> [--sticky]
  accounts import [--path <arquivo>]

  quota [email] [--all] [--json] [--email <email>]
      Checa quotas via quota.ts (daily-cloudcode-pa + prod) com thresholds de config.ts

  config list [--json]
  config get <key>
  config set <key> <value>
  config reset
      Ajusta thresholds: soft_quota_threshold_percent (0-100), quota_refresh_interval_minutes (1-1440),
      toast_scope, cli_first, quota_fallback, etc. Catálogo modelos ALL_MODELS_2026 de constants.ts.

  models list [--api antigravity|gemini-cli] [--json]
  models info <model-id>

  status
      Resumo contas + config + perms + quota rápida

  doctor
      Diagnóstico de arquivos, perms 600, token expiry, constants

  version [--json]
      Versões plugin + antigravity remote manifest

  help | --help | -h

Sem args => menu interativo (readline/promises) com cores ANSI, zero deps.

Exemplos:
  npx tsx auth/cli.ts login --no-browser
  npx tsx auth/cli.ts accounts list
  npx tsx auth/cli.ts quota --all
  npx tsx auth/cli.ts config set soft_quota_threshold_percent 85
  npx tsx auth/cli.ts models list --api antigravity
  npx tsx auth/cli.ts status
`));
}

async function main(): Promise<void> {
  const argv = process.argv.slice(2);
  const cmd = (argv[0] ?? "").toLowerCase();

  // If no command, interactive
  if (!cmd || cmd === "menu" || cmd === "interactive" || cmd === "i") {
    if (argv.includes("--help") || argv.includes("-h")) { printHelp(); return; }
    // check if TTY; if not TTY and no args, show help
    if (!process.stdout.isTTY && !argv.length) { printHelp(); return; }
    if (!argv.length) { await interactiveMenu(); return; }
  }

  switch (cmd) {
    case "help":
    case "--help":
    case "-h":
      printHelp();
      break;
    case "login":
    case "auth":
    case "signin":
      await cmdLogin(argv.slice(1));
      break;
    case "accounts":
    case "account":
    case "acc":
      await cmdAccounts(argv.slice(1));
      break;
    case "quota":
    case "quotas":
    case "q":
      await cmdQuota(argv.slice(1));
      break;
    case "config":
    case "cfg":
    case "settings":
      await cmdConfig(argv.slice(1));
      break;
    case "models":
    case "model":
    case "m":
      await cmdModels(argv.slice(1));
      break;
    case "status":
    case "st":
      await cmdStatus(argv.slice(1));
      break;
    case "doctor":
    case "doc":
    case "check":
      await cmdDoctor(argv.slice(1));
      break;
    case "version":
    case "ver":
    case "v":
      await cmdVersion(argv.slice(1));
      break;
    default:
      logErr(`Comando desconhecido: ${cmd}`);
      printHelp();
      process.exit(1);
  }
}

// ---------------------------------------------------------------------------
// Entry point (ESM safe)
// ---------------------------------------------------------------------------
if (import.meta.url === `file://${process.argv[1]}` || process.argv[1]?.endsWith("cli.ts") || process.argv[1]?.endsWith("cli.js")) {
  main().catch((e) => {
    logErr(`Fatal: ${(e as Error).message}`);
    console.error(C.dim((e as Error).stack ?? ""));
    process.exit(1);
  });
}

export {
  main as runCLI,
  cmdLogin,
  cmdAccounts,
  cmdQuota,
  cmdConfig,
  cmdModels,
  cmdStatus,
  cmdDoctor,
  cmdVersion,
  interactiveMenu,
  printHelp,
  resolveBaseDir,
  resolveAccountsPath,
  resolveConfigPath,
  atomicWriteFileSecure,
  ANSI,
  C,
};

export default {
  runCLI: main,
  interactiveMenu,
};
