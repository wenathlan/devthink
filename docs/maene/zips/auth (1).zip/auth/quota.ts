/**
 * @fileoverview quota.ts - Gerenciador de Quota completo para opencode-antigravity-auth
 * @module auth/quota
 * @description
 *  Plugin opencode-antigravity-auth com bypass Gemini CLI.
 *  Implementa dual quota Antigravity + Gemini CLI, cache TTL adaptativo,
 *  soft threshold 90%, background refresh, e parsing resiliente do endpoint
 *  cloudcode-pa.googleapis.com v1internal:retrieveUserQuotaSummary.
 *
 *  - Client ID: 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com
 *  - Secret: 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
 *  - User-Agent: GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1
 *  - X-Goog-Api-Client: gl-node/22.19.0
 *  - Client-Metadata: ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 *  - Endpoints: cloudcode-pa.googleapis.com + daily-cloudcode-pa.googleapis.com v1internal
 *  - Project fallback: rising-fact-p41fc
 *  - Models 2026: antigravity-gemini-3-pro, antigravity-gemini-3.1-pro, antigravity-gemini-3-flash,
 *    antigravity-claude-sonnet-4-6, antigravity-claude-opus-4-6-thinking,
 *    gemini-2.5-flash, gemini-2.5-pro, gemini-3-flash-preview, gemini-3-pro-preview,
 *    gemini-3.1-pro-preview, gemini-3.1-pro-preview-customtools
 *
 *  Produção-ready, apenas node:* builtins + fetch global. Zero deps externas.
 *
 * @author ONDA 3 - Módulos Core
 * @license MIT
 * @since 2026
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import * as crypto from "node:crypto";

// =============================================================================
// CONSTANTES BLINDADAS - BYPASS GEMINI CLI
// =============================================================================

export const OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;

export const OAUTH_CLIENT_SECRET = "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" as const;

export const OAUTH_SCOPES = [
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
] as const;

export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;

export const CLOUDCODE_BASE = "https://cloudcode-pa.googleapis.com" as const;
export const CLOUDCODE_DAILY_BASE = "https://daily-cloudcode-pa.googleapis.com" as const;

export const ENDPOINTS = {
  loadCodeAssist: `${CLOUDCODE_BASE}/v1internal:loadCodeAssist`,
  onboardUser: `${CLOUDCODE_BASE}/v1internal:onboardUser`,
  fetchAvailableModels: `${CLOUDCODE_BASE}/v1internal:fetchAvailableModels`,
  generateContent: `${CLOUDCODE_BASE}/v1internal:generateContent`,
  streamGenerateContent: `${CLOUDCODE_BASE}/v1internal:streamGenerateContent`,
  retrieveUserQuotaSummary: `${CLOUDCODE_BASE}/v1internal:retrieveUserQuotaSummary`,
} as const;

export const ENDPOINTS_DAILY = {
  loadCodeAssist: `${CLOUDCODE_DAILY_BASE}/v1internal:loadCodeAssist`,
  retrieveUserQuotaSummary: `${CLOUDCODE_DAILY_BASE}/v1internal:retrieveUserQuotaSummary`,
} as const;

/**
 * Mapeamento dual quota: Antigravity usa daily endpoint (quota real),
 * Gemini CLI usa base endpoint (historicamente retorna 1.0 mas ainda consultado).
 */
export const QUOTA_ENDPOINTS = {
  antigravity: ENDPOINTS_DAILY.retrieveUserQuotaSummary,
  "gemini-cli": ENDPOINTS.retrieveUserQuotaSummary,
} as const;

export type QuotaSource = keyof typeof QUOTA_ENDPOINTS; // 'antigravity' | 'gemini-cli'

export const GEMINI_CLI_USER_AGENT =
  "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1" as const;

export const GEMINI_CLI_USER_AGENT_ANTIGRAVITY =
  "antigravity/1.12.8 (linux; x64; VSCode/1.90.0; Antigravity) google-api-nodejs-client/9.15.1" as const;

export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;

export const CLIENT_METADATA_STRING =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const CLIENT_METADATA_ANTIGRAVITY =
  "ideType=IDE_VSCODE,platform=PLATFORM_UNSPECIFIED,pluginType=ANTIGRAVITY" as const;

export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type Model2026 = (typeof MODELS_2026)[number];

// =============================================================================
// QUOTA GROUPS & TTL CONSTANTS
// =============================================================================

/**
 * Intervalo padrão para refresh de quota (minutos).
 * Pode ser overriden via config ou env QUOTA_REFRESH_INTERVAL_MINUTES.
 */
export const QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT = 15 as const;
export const QUOTA_REFRESH_INTERVAL_MS_DEFAULT = QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT * 60 * 1000;

export const QUOTA_SOFT_THRESHOLD = 0.9 as const; // 90% usado => remaining <10% => soft exhausted
export const QUOTA_SOFT_REMAINING = 1 - QUOTA_SOFT_THRESHOLD; // 0.1

export const QUOTA_HARD_THRESHOLD = 0.98; // 98% usado => remaining 2% => hard exhausted
export const QUOTA_CACHE_TTL_MS_DEFAULT = 15 * 60 * 1000; // 15min default
export const QUOTA_CACHE_TTL_MIN_MS = 2 * 60 * 1000; // 2min quando quase zerado
export const QUOTA_CACHE_TTL_MAX_MS = 30 * 60 * 1000; // 30min quando cheio
export const QUOTA_CACHE_FILE = path.join(
  os.homedir(),
  ".config",
  "opencode",
  "cache",
  "antigravity",
  "quota.json"
);

export const QUOTA_REQUEST_TIMEOUT_MS = 10_000 as const;

// Definição canônica de grupos lógicos internos (usado para resolveQuotaGroup)
export type QuotaGroupId =
  | "gemini-3-pro"
  | "gemini-3.1-pro"
  | "gemini-3-flash"
  | "gemini-2.5-pro"
  | "gemini-2.5-flash"
  | "claude-sonnet"
  | "claude-opus"
  | "gemini" // agrupamento genérico retornado pela API (Gemini Models)
  | "claude-3p" // agrupamento genérico Claude+GPT (3p)
  | "unknown";

export interface QuotaGroupDef {
  id: QuotaGroupId;
  displayNamePattern: RegExp; // regex para casar displayName da API
  models: readonly string[];
  dailyLimit: number;
  rpm: number;
  tpm: number;
}

export const QUOTA_GROUP_DEFS: readonly QuotaGroupDef[] = [
  {
    id: "gemini-3-pro",
    displayNamePattern: /gemini.*3.*pro/i,
    models: ["antigravity-gemini-3-pro", "gemini-3-pro-preview"] as const,
    dailyLimit: 1000,
    rpm: 60,
    tpm: 1_000_000,
  },
  {
    id: "gemini-3.1-pro",
    displayNamePattern: /gemini.*3\.1.*pro/i,
    models: [
      "antigravity-gemini-3.1-pro",
      "gemini-3.1-pro-preview",
      "gemini-3.1-pro-preview-customtools",
    ] as const,
    dailyLimit: 500,
    rpm: 30,
    tpm: 2_000_000,
  },
  {
    id: "gemini-3-flash",
    displayNamePattern: /gemini.*3.*flash|flash/i,
    models: ["antigravity-gemini-3-flash", "gemini-3-flash-preview"] as const,
    dailyLimit: 2000,
    rpm: 120,
    tpm: 1_000_000,
  },
  {
    id: "gemini-2.5-pro",
    displayNamePattern: /gemini.*2\.5.*pro/i,
    models: ["gemini-2.5-pro"] as const,
    dailyLimit: 1500,
    rpm: 60,
    tpm: 1_000_000,
  },
  {
    id: "gemini-2.5-flash",
    displayNamePattern: /gemini.*2\.5.*flash/i,
    models: ["gemini-2.5-flash"] as const,
    dailyLimit: 3000,
    rpm: 240,
    tpm: 1_000_000,
  },
  {
    id: "claude-sonnet",
    displayNamePattern: /claude.*sonnet|3p|third.party/i,
    models: ["antigravity-claude-sonnet-4-6"] as const,
    dailyLimit: 500,
    rpm: 30,
    tpm: 200_000,
  },
  {
    id: "claude-opus",
    displayNamePattern: /claude.*opus/i,
    models: ["antigravity-claude-opus-4-6-thinking"] as const,
    dailyLimit: 250,
    rpm: 15,
    tpm: 200_000,
  },
] as const;

// =============================================================================
// TYPES - QUOTA API RESPONSE
// =============================================================================

export type QuotaWindow = "weekly" | "5h" | "daily" | "hourly" | "monthly" | string;

export interface QuotaBucketRaw {
  bucketId: string; // ex: "gemini-weekly", "gemini-5h", "3p-weekly"
  displayName?: string; // "Weekly Limit", "Five Hour Limit"
  window?: QuotaWindow;
  resetTime?: string; // ISO "2026-07-25T01:43:09Z"
  description?: string;
  remainingFraction?: number; // 0.0 - 1.0
  remaining?: number; // alternativa numérica
  limit?: number;
  used?: number;
}

export interface QuotaGroupRaw {
  displayName?: string; // "Gemini Models", "Claude and GPT models"
  description?: string; // "Models within this group: Gemini Flash, Gemini Pro"
  buckets?: QuotaBucketRaw[];
  quotaGroup?: string; // às vezes backend retorna id
}

export interface QuotaSummaryRaw {
  groups?: QuotaGroupRaw[];
  quotaGroup?: QuotaGroupRaw[]; // fallback variante
  // Alguns payloads retornam diretamente buckets no root
  buckets?: QuotaBucketRaw[];
}

export interface QuotaBucketParsed {
  bucketId: string;
  displayName: string;
  window: QuotaWindow;
  resetTime: string | null; // ISO persistido
  resetTimeMs: number | null; // epoch ms para cálculos
  remainingFraction: number; // normalizado 0..1
  remainingPercent: number; // 0..100
  isExhausted: boolean; // remaining <= 0.02
  isSoftExhausted: boolean; // remaining <= 0.1 (90% threshold)
  description: string;
}

export interface QuotaGroupParsed {
  id: QuotaGroupId; // resolvido via mapping ou unknown
  displayName: string;
  description: string;
  rawDisplayName: string;
  source: QuotaSource;
  buckets: QuotaBucketParsed[];
  // Helpers agregados
  weeklyRemaining: number | null;
  fiveHourRemaining: number | null;
  minRemainingFraction: number; // menor remaining entre buckets (pior caso)
  minBucket: QuotaBucketParsed | null;
  isExhausted: boolean;
  isSoftExhausted: boolean;
}

export interface QuotaSummaryParsed {
  groups: QuotaGroupParsed[];
  fetchedAt: number;
  expiresAt: number;
  ttlMs: number;
  source: QuotaSource;
  projectId: string;
  // agregados globais
  globalMinRemaining: number;
  isAnyExhausted: boolean;
  isAnySoftExhausted: boolean;
}

export interface QuotaCacheEntry {
  summary: QuotaSummaryParsed;
  raw: QuotaSummaryRaw;
  tokenHash: string; // hash do token para invalidação
  cachedAt: number;
  expiresAt: number;
  ttlMs: number;
}

export interface CheckQuotaResult {
  allowed: boolean;
  groupId: QuotaGroupId | null;
  bucketId: string | null;
  remainingFraction: number | null;
  remainingPercent: number | null;
  resetTime: string | null;
  resetTimeMs: number | null;
  reason: string;
  isSoftThreshold: boolean;
  isHardExhausted: boolean;
  shouldSkipAccount: boolean;
  source: QuotaSource;
  group?: QuotaGroupParsed;
  bucket?: QuotaBucketParsed;
}

// =============================================================================
// UTILS
// =============================================================================

function hashToken(token: string): string {
  try {
    return crypto.createHash("sha256").update(token).digest("hex").slice(0, 16);
  } catch {
    // fallback FNV-1a simples
    let h = 2166136261;
    for (let i = 0; i < token.length; i++) {
      h ^= token.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  }
}

function parseIsoToMs(iso?: string | null): number | null {
  if (!iso) return null;
  const ms = Date.parse(iso);
  return Number.isNaN(ms) ? null : ms;
}

function clampFraction(n: unknown): number {
  if (typeof n !== "number" || Number.isNaN(n)) return 1.0;
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

function nowMs(): number {
  return Date.now();
}

/**
 * TTL adaptativo: quanto menor remaining, menor TTL para refresh mais rápido.
 * - <10% => 2min
 * - <20% => 5min
 * - <50% => 10min
 * - >=50% => 15min default, mas respeita resetTime próximo
 */
export function computeAdaptiveTtlMs(
  summary: QuotaSummaryRaw | QuotaSummaryParsed,
  baseTtlMs: number = QUOTA_CACHE_TTL_MS_DEFAULT
): number {
  let minRemaining = 1.0;

  // Extrai menor remainingFraction
  if ("groups" in summary && Array.isArray((summary as any).groups)) {
    const groups = (summary as QuotaGroupParsed[] | QuotaGroupRaw[]).flatMap((g: any) =>
      Array.isArray(g.buckets) ? g.buckets : []
    );
    for (const b of groups) {
      const f = clampFraction((b as any).remainingFraction ?? (b as any).remaining ?? 1);
      if (f < minRemaining) minRemaining = f;
    }
  }

  // Se Parsed já tem globalMin
  if ("globalMinRemaining" in summary) {
    minRemaining = (summary as QuotaSummaryParsed).globalMinRemaining;
  }

  let ttl = baseTtlMs;

  if (minRemaining <= QUOTA_SOFT_REMAINING) {
    ttl = QUOTA_CACHE_TTL_MIN_MS; // 2min
  } else if (minRemaining <= 0.2) {
    ttl = 5 * 60 * 1000;
  } else if (minRemaining <= 0.5) {
    ttl = 10 * 60 * 1000;
  } else {
    ttl = baseTtlMs;
  }

  // Ajusta se houver resetTime muito próximo (ex: < ttl)
  let nearestResetMs: number | null = null;
  if ("groups" in summary) {
    for (const g of (summary as any).groups as QuotaGroupParsed[]) {
      for (const b of g.buckets ?? []) {
        const rt = (b as QuotaBucketParsed).resetTimeMs ?? parseIsoToMs((b as any).resetTime);
        if (rt != null) {
          if (nearestResetMs == null || rt < nearestResetMs) nearestResetMs = rt;
        }
      }
    }
  }

  if (nearestResetMs != null) {
    const msUntilReset = nearestResetMs - nowMs();
    if (msUntilReset > 0 && msUntilReset < ttl) {
      // Se reset é antes do TTL, programa refresh logo após reset + jitter 30s
      ttl = Math.max(QUOTA_CACHE_TTL_MIN_MS, msUntilReset + 30_000);
    }
  }

  return Math.max(QUOTA_CACHE_TTL_MIN_MS, Math.min(ttl, QUOTA_CACHE_TTL_MAX_MS));
}

export function getQuotaRefreshIntervalMs(configMinutes?: number): number {
  const envVal = process.env.QUOTA_REFRESH_INTERVAL_MINUTES ?? process.env.ANTIGRAVITY_QUOTA_REFRESH_MINUTES;
  let minutes = configMinutes ?? QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT;

  if (envVal != null) {
    const parsed = Number.parseInt(envVal, 10);
    if (!Number.isNaN(parsed) && parsed > 0 && parsed <= 120) {
      minutes = parsed;
    }
  }

  if (minutes <= 0) minutes = QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT;
  if (minutes > 120) minutes = 120;

  return minutes * 60 * 1000;
}

// =============================================================================
// MODEL -> GROUP RESOLUTION
// =============================================================================

/**
 * Mapeia modelo string para QuotaGroupId interno.
 * Suporta tanto modelos antigravity-* quanto gemini-* nativos.
 */
const MODEL_TO_GROUP_EXACT: Record<string, QuotaGroupId> = {
  "antigravity-gemini-3-pro": "gemini-3-pro",
  "gemini-3-pro-preview": "gemini-3-pro",
  "antigravity-gemini-3.1-pro": "gemini-3.1-pro",
  "gemini-3.1-pro-preview": "gemini-3.1-pro",
  "gemini-3.1-pro-preview-customtools": "gemini-3.1-pro",
  "antigravity-gemini-3-flash": "gemini-3-flash",
  "gemini-3-flash-preview": "gemini-3-flash",
  "gemini-2.5-pro": "gemini-2.5-pro",
  "gemini-2.5-flash": "gemini-2.5-flash",
  "antigravity-claude-sonnet-4-6": "claude-sonnet",
  "antigravity-claude-opus-4-6-thinking": "claude-opus",

  //Aliases genericos API groups
  "gemini": "gemini",
  "claude": "claude-3p",
  "gpt": "claude-3p",
  "3p": "claude-3p",
  "claude-3p": "claude-3p",
};

export function resolveQuotaGroup(model: string): QuotaGroupId {
  if (!model || typeof model !== "string") return "unknown";

  const lower = model.trim().toLowerCase();

  // Exact
  if (MODEL_TO_GROUP_EXACT[lower]) return MODEL_TO_GROUP_EXACT[lower];
  if (MODEL_TO_GROUP_EXACT[model]) return MODEL_TO_GROUP_EXACT[model];

  // Heurísticas
  if (lower.includes("opus")) return "claude-opus";
  if (lower.includes("sonnet") || lower.includes("claude") || lower.includes("3p") || lower.includes("gpt")) {
    // distingue opus já tratado
    if (lower.includes("sonnet")) return "claude-sonnet";
    return "claude-3p";
  }
  if (lower.includes("3.1") && lower.includes("pro")) return "gemini-3.1-pro";
  if (lower.includes("3") && lower.includes("pro")) return "gemini-3-pro";
  if (lower.includes("2.5") && lower.includes("flash")) return "gemini-2.5-flash";
  if (lower.includes("2.5") && lower.includes("pro")) return "gemini-2.5-pro";
  if (lower.includes("flash")) return "gemini-3-flash";

  // API display names
  if (lower.includes("gemini models") || lower === "gemini") return "gemini";
  if (lower.includes("claude and gpt") || lower.includes("claude")) return "claude-3p";

  return "unknown";
}

/**
 * Retorna definição de grupo para um model ou groupId.
 * Se groupId desconhecido, retorna null.
 */
export function getQuotaGroup(input: string): QuotaGroupDef | null {
  if (!input) return null;
  const gid = resolveQuotaGroup(input);
  if (gid === "unknown") {
    // tenta casar por padrão displayName
    for (const def of QUOTA_GROUP_DEFS) {
      if (def.displayNamePattern.test(input)) return def;
    }
    return null;
  }
  // groupId genérico -> retorna def equivalente mais próximo
  if (gid === "gemini") {
    return QUOTA_GROUP_DEFS.find((d) => d.id === "gemini-3-pro") ?? null;
  }
  if (gid === "claude-3p") {
    return QUOTA_GROUP_DEFS.find((d) => d.id === "claude-sonnet") ?? null;
  }
  return QUOTA_GROUP_DEFS.find((d) => d.id === gid) ?? null;
}

/**
 * Alias listado: todos os grupos disponíveis.
 */
export function listQuotaGroups(): readonly QuotaGroupDef[] {
  return QUOTA_GROUP_DEFS;
}

// =============================================================================
// BUILD HEADERS - BYPASS GEMINI CLI
// =============================================================================

function buildDynamicUserAgent(source: QuotaSource): string {
  const platform = os.platform(); // darwin, linux, win32
  const arch = os.arch(); // x64, arm64

  // Mantém coerência plataforma real local, mas permite override via env
  const envUA = process.env.GEMINI_CLI_USER_AGENT ?? process.env.ANTIGRAVITY_USER_AGENT;
  if (envUA && envUA.length > 10) return envUA;

  if (source === "antigravity") {
    // Usa template antigravity para daily endpoint
    if (platform === "darwin" && arch === "arm64") {
      return "antigravity/1.12.8/gemini-3-pro-preview (darwin; arm64; VSCode/1.90.0) google-api-nodejs-client/9.15.1";
    }
    if (platform === "win32") {
      return "antigravity/1.12.8/gemini-3-pro-preview (win32; x64; VSCode/1.90.0) google-api-nodejs-client/9.15.1";
    }
    return GEMINI_CLI_USER_AGENT_ANTIGRAVITY;
  }

  // gemini-cli source: varia por plataforma real
  if (platform === "darwin" && arch === "arm64") {
    return "GeminiCLI/0.35.3/gemini-3-pro-preview (darwin; arm64; GitHub) google-api-nodejs-client/9.15.1";
  }
  if (platform === "darwin") {
    return "GeminiCLI/0.35.3/gemini-3-pro-preview (darwin; x64; GitHub) google-api-nodejs-client/9.15.1";
  }
  if (platform === "win32") {
    return "GeminiCLI/0.35.3/gemini-3-pro-preview (win32; x64; GitHub) google-api-nodejs-client/9.15.1";
  }
  return GEMINI_CLI_USER_AGENT;
}

export function buildQuotaHeaders(token: string, source: QuotaSource = "antigravity"): Record<string, string> {
  const ua = buildDynamicUserAgent(source);
  const xGoog = process.env.X_GOOG_API_CLIENT ?? X_GOOG_API_CLIENT;
  const clientMeta =
    source === "antigravity" ? CLIENT_METADATA_ANTIGRAVITY : CLIENT_METADATA_STRING;

  return {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
    "X-Goog-Api-Client": xGoog,
    "Client-Metadata": clientMeta,
    Accept: "application/json",
    "Accept-Encoding": "gzip, deflate, br",
  };
}

function getEndpointForSource(source: QuotaSource): string {
  return QUOTA_ENDPOINTS[source] ?? QUOTA_ENDPOINTS.antigravity;
}

// =============================================================================
// PARSE QUOTA RESPONSE - ROBUSTO
// =============================================================================

export function parseQuotaBucket(raw: QuotaBucketRaw, source: QuotaSource): QuotaBucketParsed {
  const bucketId = String(raw.bucketId ?? raw.displayName ?? "unknown").toLowerCase();
  const displayName = String(raw.displayName ?? raw.bucketId ?? "Unknown").trim() || "Unknown";
  const window = (raw.window ?? (bucketId.includes("weekly") ? "weekly" : bucketId.includes("5h") ? "5h" : "unknown")) as QuotaWindow;
  const resetIso = raw.resetTime ?? null;
  const resetMs = parseIsoToMs(resetIso);

  let remainingFraction: number;
  if (typeof raw.remainingFraction === "number") {
    remainingFraction = clampFraction(raw.remainingFraction);
  } else if (typeof raw.remaining === "number" && typeof raw.limit === "number" && raw.limit > 0) {
    remainingFraction = clampFraction(raw.remaining / raw.limit);
  } else if (typeof raw.remaining === "number") {
    // Se remaining já é fração?
    remainingFraction = raw.remaining > 1 ? clampFraction(raw.remaining / 100) : clampFraction(raw.remaining);
  } else if (typeof raw.used === "number" && typeof raw.limit === "number" && raw.limit > 0) {
    remainingFraction = clampFraction(1 - raw.used / raw.limit);
  } else {
    // Fallback: cloudcode-pa retorna sempre 1.0 (bug conhecido) -> trata como 1.0 mas marca warning
    remainingFraction = 1.0;
  }

  const remainingPercent = Math.round(remainingFraction * 10000) / 100; // 2 decimais
  const isExhausted = remainingFraction <= 1 - QUOTA_HARD_THRESHOLD || remainingFraction <= 0.02;
  const isSoftExhausted = remainingFraction <= QUOTA_SOFT_REMAINING;

  return {
    bucketId,
    displayName,
    window,
    resetTime: resetIso,
    resetTimeMs: resetMs,
    remainingFraction,
    remainingPercent,
    isExhausted,
    isSoftExhausted,
    description: String(raw.description ?? "").trim(),
  };
}

export function parseQuotaGroup(raw: QuotaGroupRaw, source: QuotaSource): QuotaGroupParsed {
  const displayNameRaw = String(raw.displayName ?? raw.quotaGroup ?? "Unknown").trim();
  // Resolve id heurístico
  let id: QuotaGroupId = resolveQuotaGroup(displayNameRaw);

  // Se displayName contém "Gemini Models" => gemini genérico
  if (/gemini models/i.test(displayNameRaw)) id = "gemini";
  if (/claude.*gpt|3p/i.test(displayNameRaw)) id = "claude-3p";

  const description = String(raw.description ?? "").trim();
  const bucketsRaw = Array.isArray(raw.buckets) ? raw.buckets : [];

  const buckets = bucketsRaw.map((b) => parseQuotaBucket(b, source)).sort((a, b) => {
    // Ordena: 5h primeiro, depois weekly
    if (a.window === "5h" && b.window !== "5h") return -1;
    if (b.window === "5h" && a.window !== "5h") return 1;
    return 0;
  });

  let weeklyRemaining: number | null = null;
  let fiveHourRemaining: number | null = null;
  let minRemaining = 1.0;
  let minBucket: QuotaBucketParsed | null = null;

  for (const bucket of buckets) {
    if (bucket.window === "weekly" || bucket.bucketId.includes("weekly")) {
      if (weeklyRemaining == null || bucket.remainingFraction < weeklyRemaining) weeklyRemaining = bucket.remainingFraction;
    }
    if (bucket.window === "5h" || bucket.bucketId.includes("5h")) {
      if (fiveHourRemaining == null || bucket.remainingFraction < fiveHourRemaining) fiveHourRemaining = bucket.remainingFraction;
    }
    if (bucket.remainingFraction < minRemaining) {
      minRemaining = bucket.remainingFraction;
      minBucket = bucket;
    }
  }

  if (buckets.length === 0) {
    minRemaining = 1.0;
  }

  const isExhausted = buckets.some((b) => b.isExhausted) || minRemaining <= 0.02;
  const isSoftExhausted = buckets.some((b) => b.isSoftExhausted) || minRemaining <= QUOTA_SOFT_REMAINING;

  return {
    id,
    displayName: displayNameRaw,
    description,
    rawDisplayName: displayNameRaw,
    source,
    buckets,
    weeklyRemaining,
    fiveHourRemaining,
    minRemainingFraction: minRemaining,
    minBucket,
    isExhausted,
    isSoftExhausted,
  };
}

/**
 * Parse principal do payload v1internal:retrieveUserQuotaSummary
 */
export function parseQuotaResponse(
  raw: QuotaSummaryRaw,
  opts?: { source?: QuotaSource; projectId?: string; fetchedAt?: number; baseTtlMs?: number }
): QuotaSummaryParsed {
  const source = opts?.source ?? "antigravity";
  const projectId = opts?.projectId ?? PROJECT_FALLBACK;
  const fetchedAt = opts?.fetchedAt ?? nowMs();
  const baseTtl = opts?.baseTtlMs ?? QUOTA_CACHE_TTL_MS_DEFAULT;

  // Normaliza grupos: pode vir em groups, quotaGroup, ou root buckets
  let rawGroups: QuotaGroupRaw[] = [];
  if (Array.isArray(raw.groups)) rawGroups = raw.groups;
  else if (Array.isArray((raw as any).quotaGroup)) rawGroups = (raw as any).quotaGroup;
  else if (Array.isArray(raw.buckets)) {
    // Agrupa buckets isolados em um grupo genérico Gemini
    rawGroups = [
      {
        displayName: "Gemini Models",
        description: "Fallback grouped from root buckets",
        buckets: raw.buckets,
      },
    ];
  }

  const groups = rawGroups.map((g) => parseQuotaGroup(g, source)).filter((g) => g.buckets.length > 0 || g.displayName !== "Unknown");

  // Se API retornou vazio (cloudcode-pa bug retorna empty), cria grupo fallback healthy para não bloquear
  if (groups.length === 0) {
    // log silencioso, mas cria estrutura que permite allowed=true
    const fallbackGroup: QuotaGroupParsed = {
      id: "gemini",
      displayName: "Gemini Models",
      description: "Fallback empty response - assuming full quota (cloudcode-pa returns 1.0)",
      rawDisplayName: "Gemini Models",
      source,
      buckets: [
        {
          bucketId: "gemini-weekly",
          displayName: "Weekly Limit",
          window: "weekly",
          resetTime: null,
          resetTimeMs: null,
          remainingFraction: 1.0,
          remainingPercent: 100,
          isExhausted: false,
          isSoftExhausted: false,
          description: "Fallback - API returned empty",
        },
      ],
      weeklyRemaining: 1.0,
      fiveHourRemaining: 1.0,
      minRemainingFraction: 1.0,
      minBucket: null,
      isExhausted: false,
      isSoftExhausted: false,
    };
    // Ajusta minBucket para o único bucket
    fallbackGroup.minBucket = fallbackGroup.buckets[0] ?? null;

    const ttl = computeAdaptiveTtlMs({ groups: [fallbackGroup] } as any, baseTtl);

    return {
      groups: [fallbackGroup],
      fetchedAt,
      expiresAt: fetchedAt + ttl,
      ttlMs: ttl,
      source,
      projectId,
      globalMinRemaining: 1.0,
      isAnyExhausted: false,
      isAnySoftExhausted: false,
    };
  }

  let globalMin = 1.0;
  let anyExhausted = false;
  let anySoft = false;

  for (const g of groups) {
    if (g.minRemainingFraction < globalMin) globalMin = g.minRemainingFraction;
    if (g.isExhausted) anyExhausted = true;
    if (g.isSoftExhausted) anySoft = true;
  }

  const ttl = computeAdaptiveTtlMs({ groups } as any, baseTtl);

  return {
    groups,
    fetchedAt,
    expiresAt: fetchedAt + ttl,
    ttlMs: ttl,
    source,
    projectId,
    globalMinRemaining: globalMin,
    isAnyExhausted: anyExhausted,
    isAnySoftExhausted: anySoft,
  };
}

// =============================================================================
// FETCH QUOTA - retrieveUserQuotaSummary
// =============================================================================

export interface RetrieveQuotaOptions {
  source?: QuotaSource; // default antigravity (daily endpoint = quota real)
  timeoutMs?: number;
  retries?: number;
  baseTtlMs?: number;
  signal?: AbortSignal;
}

export class QuotaFetchError extends Error {
  public status?: number;
  public body?: string;
  public source: QuotaSource;
  constructor(message: string, source: QuotaSource, status?: number, body?: string) {
    super(message);
    this.name = "QuotaFetchError";
    this.status = status;
    this.body = body;
    this.source = source;
  }
}

/**
 * Chamada direta ao endpoint v1internal:retrieveUserQuotaSummary
 * POST {"project": "<projectId>"}
 *
 * @param token - OAuth access_token Bearer
 * @param projectId - cloudaicompanionProject id, fallback rising-fact-p41fc
 * @param opts - source antigravity|gemini-cli, timeout, retries
 */
export async function retrieveUserQuotaSummary(
  token: string,
  projectId: string = PROJECT_FALLBACK,
  opts?: RetrieveQuotaOptions
): Promise<QuotaSummaryParsed> {
  if (!token || typeof token !== "string" || token.trim().length < 10) {
    throw new TypeError("retrieveUserQuotaSummary: token inválido");
  }

  const source = opts?.source ?? "antigravity";
  const timeoutMs = opts?.timeoutMs ?? QUOTA_REQUEST_TIMEOUT_MS;
  const retries = opts?.retries ?? 1;
  const baseTtlMs = opts?.baseTtlMs ?? QUOTA_CACHE_TTL_MS_DEFAULT;

  const endpoint = getEndpointForSource(source);
  const sanitizedProject = (projectId ?? PROJECT_FALLBACK).trim() || PROJECT_FALLBACK;

  const headers = buildQuotaHeaders(token, source);
  const body = JSON.stringify({ project: sanitizedProject });

  let lastError: unknown = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    // Se caller passou signal externo, propaga abort
    let externalAbortListener: (() => void) | null = null;
    if (opts?.signal) {
      if (opts.signal.aborted) {
        clearTimeout(timer);
        throw new QuotaFetchError("AbortError: external signal aborted", source, 0);
      }
      externalAbortListener = () => controller.abort();
      opts.signal.addEventListener("abort", externalAbortListener, { once: true });
    }

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers,
        body,
        signal: controller.signal,
      } as RequestInit);

      clearTimeout(timer);
      if (externalAbortListener && opts?.signal) {
        opts.signal.removeEventListener("abort", externalAbortListener);
      }

      if (!res.ok) {
        const text = await res.text().catch(() => "");
        // 403 em cloudcode-pa é esperado para retrieveUserQuotaSummary em OAuth local-only?
        // Tenta fallback: se source antigravity falhar, tenta gemini-cli? Não, mantém erro para caller decidir
        throw new QuotaFetchError(
          `Quota fetch failed ${res.status} ${res.statusText} on ${source}: ${text.slice(0, 500)}`,
          source,
          res.status,
          text
        );
      }

      const json = (await res.json().catch(async () => {
        const txt = await res.text().catch(() => "");
        if (txt) {
          try {
            return JSON.parse(txt);
          } catch {
            // ignora
          }
        }
        return {} as QuotaSummaryRaw;
      })) as QuotaSummaryRaw;

      const parsed = parseQuotaResponse(json, {
        source,
        projectId: sanitizedProject,
        fetchedAt: nowMs(),
        baseTtlMs,
      });

      return parsed;
    } catch (err) {
      clearTimeout(timer);
      if (externalAbortListener && opts?.signal) {
        opts.signal.removeEventListener("abort", externalAbortListener);
      }

      lastError = err;

      // Não retenta em 401/403/400
      if (err instanceof QuotaFetchError) {
        if (err.status === 401 || err.status === 403 || err.status === 400) {
          throw err;
        }
      }

      // Timeout / network - retenta se ainda há tentativas
      if (attempt < retries) {
        const backoff = 200 * Math.pow(2, attempt) + Math.random() * 200;
        await new Promise((r) => setTimeout(r, backoff));
        continue;
      }

      // Esgotou
      if (err instanceof QuotaFetchError) throw err;
      throw new QuotaFetchError(
        `Quota fetch network error on ${source}: ${(err as Error).message}`,
        source,
        0
      );
    }
  }

  throw lastError instanceof Error
    ? lastError
    : new QuotaFetchError(`Unknown quota fetch error on ${source}`, source, 0);
}

/**
 * Dual fetch: tenta antigravity (daily) primeiro, depois gemini-cli como fallback.
 * Retorna merged parsed summary com source primária.
 */
export async function retrieveDualQuota(
  token: string,
  projectId: string = PROJECT_FALLBACK,
  opts?: RetrieveQuotaOptions
): Promise<{ antigravity: QuotaSummaryParsed | null; geminiCli: QuotaSummaryParsed | null; primary: QuotaSummaryParsed }> {
  // antigravity deve ser primary (quota real)
  let antigravity: QuotaSummaryParsed | null = null;
  let geminiCli: QuotaSummaryParsed | null = null;

  // tenta ambos em paralelo, mas antigravity tem prioridade
  const results = await Promise.allSettled([
    retrieveUserQuotaSummary(token, projectId, { ...opts, source: "antigravity" }),
    retrieveUserQuotaSummary(token, projectId, { ...opts, source: "gemini-cli" }),
  ]);

  if (results[0].status === "fulfilled") antigravity = results[0].value;
  if (results[1].status === "fulfilled") geminiCli = results[1].value;

  const primary = antigravity ?? geminiCli;

  if (!primary) {
    // ambos falharam, lança erro do antigravity se disponível
    const err0 = results[0].status === "rejected" ? results[0].reason : null;
    const err1 = results[1].status === "rejected" ? results[1].reason : null;
    throw err0 ?? err1 ?? new QuotaFetchError("Both quota sources failed", "antigravity", 0);
  }

  return { antigravity, geminiCli, primary };
}

// =============================================================================
// CACHE MANAGER - TTL ADAPTATIVO + FILE PERSISTENCE
// =============================================================================

interface FileCachePayload {
  version: 1;
  entries: Record<string, QuotaCacheEntry>; // key = tokenHash+project+source
  savedAt: number;
}

function makeCacheKey(token: string, projectId: string, source: QuotaSource): string {
  const h = hashToken(token);
  const proj = projectId || PROJECT_FALLBACK;
  return `${h}:${proj}:${source}`;
}

function loadFileCacheSync(): Record<string, QuotaCacheEntry> {
  try {
    if (!fs.existsSync(QUOTA_CACHE_FILE)) return {};
    const raw = fs.readFileSync(QUOTA_CACHE_FILE, "utf8");
    const parsed = JSON.parse(raw) as FileCachePayload;
    if (parsed.version !== 1 || !parsed.entries) return {};
    // Filtra expirados antigos (> 24h)
    const now = nowMs();
    const out: Record<string, QuotaCacheEntry> = {};
    for (const [k, v] of Object.entries(parsed.entries)) {
      if (v.expiresAt && v.expiresAt > now - 24 * 60 * 60 * 1000) {
        out[k] = v;
      }
    }
    return out;
  } catch {
    return {};
  }
}

function saveFileCacheSync(entries: Record<string, QuotaCacheEntry>): void {
  try {
    const dir = path.dirname(QUOTA_CACHE_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const payload: FileCachePayload = {
      version: 1,
      entries,
      savedAt: nowMs(),
    };
    const tmp = QUOTA_CACHE_FILE + ".tmp." + crypto.randomBytes(4).toString("hex");
    fs.writeFileSync(tmp, JSON.stringify(payload, null, 2), { encoding: "utf8", mode: 0o600 });
    try {
      fs.chmodSync(tmp, 0o600);
    } catch {}
    fs.renameSync(tmp, QUOTA_CACHE_FILE);
  } catch {
    // silencia erro de cache
  }
}

let _memoryFileCache: Record<string, QuotaCacheEntry> | null = null;
let _inflightFetches: Map<string, Promise<QuotaSummaryParsed>> = new Map();

function getFileCache(): Record<string, QuotaCacheEntry> {
  if (_memoryFileCache) return _memoryFileCache;
  _memoryFileCache = loadFileCacheSync();
  return _memoryFileCache;
}

export class QuotaCacheManager {
  private memory: Map<string, QuotaCacheEntry> = new Map();
  private requestCount: number = 0;
  private lastRefreshAt: number = 0;
  private refreshIntervalMs: number;
  public softThreshold: number; // remaining threshold

  constructor(opts?: { refreshIntervalMinutes?: number; softThreshold?: number }) {
    this.refreshIntervalMs = getQuotaRefreshIntervalMs(opts?.refreshIntervalMinutes);
    this.softThreshold = opts?.softThreshold ?? QUOTA_SOFT_REMAINING; // 0.1 remaining = 90% usado
    // preload file cache into memory
    const file = getFileCache();
    for (const [k, v] of Object.entries(file)) {
      this.memory.set(k, v);
    }
  }

  private getKey(token: string, projectId: string, source: QuotaSource): string {
    return makeCacheKey(token, projectId, source);
  }

  getCached(token: string, projectId: string, source: QuotaSource = "antigravity"): QuotaSummaryParsed | null {
    const key = this.getKey(token, projectId, source);
    const entry = this.memory.get(key);
    if (!entry) return null;

    if (nowMs() > entry.expiresAt) {
      // expirado mas retorna se ainda dentro de grace (50% ttl) para stale-while-revalidate
      const grace = entry.ttlMs * 0.5;
      if (nowMs() > entry.expiresAt + grace) {
        this.memory.delete(key);
        return null;
      }
      // retorna stale
      return entry.summary;
    }

    return entry.summary;
  }

  isCacheExpired(token: string, projectId: string, source: QuotaSource = "antigravity"): boolean {
    const key = this.getKey(token, projectId, source);
    const entry = this.memory.get(key);
    if (!entry) return true;
    return nowMs() > entry.expiresAt;
  }

  setCached(
    token: string,
    projectId: string,
    source: QuotaSource,
    raw: QuotaSummaryRaw,
    parsed: QuotaSummaryParsed
  ): void {
    const key = this.getKey(token, projectId, source);
    const ttl = parsed.ttlMs ?? computeAdaptiveTtlMs(parsed, QUOTA_CACHE_TTL_MS_DEFAULT);

    const entry: QuotaCacheEntry = {
      summary: { ...parsed, ttlMs: ttl, expiresAt: nowMs() + ttl },
      raw,
      tokenHash: hashToken(token),
      cachedAt: nowMs(),
      expiresAt: nowMs() + ttl,
      ttlMs: ttl,
    };

    this.memory.set(key, entry);

    // persiste
    const fileCache = getFileCache();
    fileCache[key] = entry;
    // limita tamanho (max 50 entradas)
    const keys = Object.keys(fileCache);
    if (keys.length > 50) {
      // remove mais antigas
      const sorted = keys.sort((a, b) => (fileCache[a].cachedAt ?? 0) - (fileCache[b].cachedAt ?? 0));
      for (let i = 0; i < sorted.length - 50; i++) delete fileCache[sorted[i]];
    }
    saveFileCacheSync(fileCache);
    _memoryFileCache = fileCache;
  }

  /**
   * Limpa cache para um token/projeto ou tudo.
   */
  clear(token?: string, projectId?: string, source?: QuotaSource): void {
    if (!token) {
      this.memory.clear();
      try {
        fs.unlinkSync(QUOTA_CACHE_FILE);
      } catch {}
      _memoryFileCache = {};
      return;
    }
    const targetProject = projectId ?? PROJECT_FALLBACK;
    if (source) {
      const key = this.getKey(token, targetProject, source);
      this.memory.delete(key);
      const fc = getFileCache();
      delete fc[key];
      saveFileCacheSync(fc);
    } else {
      // clear ambas sources
      for (const src of ["antigravity", "gemini-cli"] as QuotaSource[]) {
        const key = this.getKey(token, targetProject, src);
        this.memory.delete(key);
        const fc = getFileCache();
        delete fc[key];
        saveFileCacheSync(fc);
      }
    }
  }

  /**
   * Refresh em background sem bloquear caller.
   * Deduplica inflight requests por key.
   */
  refreshInBackground(token: string, projectId: string, source: QuotaSource = "antigravity"): void {
    const key = this.getKey(token, projectId, source);

    if (_inflightFetches.has(key)) return; // já em progresso

    const p = retrieveUserQuotaSummary(token, projectId, { source })
      .then((parsed) => {
        // raw fallback vazio pois background não tem raw original
        this.setCached(token, projectId, source, { groups: [] }, parsed);
        this.lastRefreshAt = nowMs();
        return parsed;
      })
      .catch(() => {
        // silencia erro background
        return null as any;
      })
      .finally(() => {
        _inflightFetches.delete(key);
      });

    _inflightFetches.set(key, p);

    // Não bloqueia: fire-and-forget, mas evita unhandled
    p.catch(() => {});
  }

  /**
   * Chamado após cada requisição bem-sucedida para decidir se agenda refresh.
   */
  trackRequestAndMaybeRefresh(token: string, projectId: string, source: QuotaSource = "antigravity"): void {
    this.requestCount++;
    const now = nowMs();
    const sinceLast = now - this.lastRefreshAt;

    // Se passou refresh interval, agenda background
    if (sinceLast > this.refreshIntervalMs) {
      this.refreshInBackground(token, projectId, source);
      return;
    }

    // Heurística: se remaining baixo, precisa refresh mais frequente
    const cached = this.getCached(token, projectId, source);
    if (cached && cached.globalMinRemaining < 0.3) {
      // Se remaining <30% e já se passaram 2min, refresh
      if (sinceLast > QUOTA_CACHE_TTL_MIN_MS) {
        this.refreshInBackground(token, projectId, source);
      }
    }
  }

  getStats(): { size: number; requestCount: number; lastRefreshAt: number; refreshIntervalMs: number } {
    return {
      size: this.memory.size,
      requestCount: this.requestCount,
      lastRefreshAt: this.lastRefreshAt,
      refreshIntervalMs: this.refreshIntervalMs,
    };
  }
}

// Singleton default
let _defaultCacheManager: QuotaCacheManager | null = null;

export function getQuotaCacheManager(opts?: { refreshIntervalMinutes?: number }): QuotaCacheManager {
  if (!_defaultCacheManager) {
    _defaultCacheManager = new QuotaCacheManager({
      refreshIntervalMinutes: opts?.refreshIntervalMinutes ?? getQuotaRefreshIntervalMs() / 60000,
    });
  }
  return _defaultCacheManager;
}

// =============================================================================
// CORE QUOTA CHECK APIs
// =============================================================================

/**
 * Verifica quota para um grupo específico.
 * Retorna allowed boolean + meta.
 *
 * @param token - access token
 * @param projectId - project id
 * @param group - group id ou model string (ex: "gemini-3-pro" ou "antigravity-gemini-3-pro")
 * @param opts - source, softThreshold override, useCache
 */
export async function checkQuota(
  token: string,
  projectId: string = PROJECT_FALLBACK,
  group?: string | null,
  opts?: {
    source?: QuotaSource;
    softThreshold?: number; // remaining threshold (default 0.1)
    useCache?: boolean;
    refreshIntervalMinutes?: number;
  }
): Promise<CheckQuotaResult> {
  const source = opts?.source ?? "antigravity";
  const softRemaining = opts?.softThreshold ?? QUOTA_SOFT_REMAINING;
  const useCache = opts?.useCache ?? true;

  const cacheMgr = getQuotaCacheManager({ refreshIntervalMinutes: opts?.refreshIntervalMinutes });

  let summary: QuotaSummaryParsed | null = null;

  if (useCache) {
    summary = cacheMgr.getCached(token, projectId, source);
  }

  if (!summary) {
    try {
      summary = await retrieveUserQuotaSummary(token, projectId, { source });
      cacheMgr.setCached(token, projectId, source, { groups: [] }, summary);
    } catch (e) {
      // Se falha fetch mas tem cache expirado stale, usa stale como fallback permissivo
      const staleKey = makeCacheKey(token, projectId, source);
      const staleEntry = (getFileCache()[staleKey] ?? null) as QuotaCacheEntry | null;
      if (staleEntry?.summary) {
        summary = staleEntry.summary;
      } else {
        throw e;
      }
    }
  } else {
    // Se cache expirou, dispara background refresh sem bloquear
    if (cacheMgr.isCacheExpired(token, projectId, source)) {
      cacheMgr.refreshInBackground(token, projectId, source);
    }
    // track request para eventual refresh
    cacheMgr.trackRequestAndMaybeRefresh(token, projectId, source);
  }

  if (!summary) {
    // fallback final: allow
    return {
      allowed: true,
      groupId: null,
      bucketId: null,
      remainingFraction: 1,
      remainingPercent: 100,
      resetTime: null,
      resetTimeMs: null,
      reason: "no quota data, assuming allowed",
      isSoftThreshold: false,
      isHardExhausted: false,
      shouldSkipAccount: false,
      source,
    };
  }

  // Resolve target group
  let targetGroups: QuotaGroupParsed[] = summary.groups;

  if (group) {
    const gid = resolveQuotaGroup(group);
    if (gid !== "unknown") {
      // Se group é específico, filtra por id exato ou mapeamento genérico
      if (gid === "gemini") {
        // gemini genérico => pega grupo Gemini Models se existir, senão todos gemini-*
        const geminiModelsGroup = summary.groups.find((g) => g.id === "gemini" || /gemini models/i.test(g.displayName));
        if (geminiModelsGroup) targetGroups = [geminiModelsGroup];
        else targetGroups = summary.groups.filter((g) => g.id.startsWith("gemini"));
      } else if (gid === "claude-3p") {
        const claudeGroup = summary.groups.find((g) => g.id === "claude-3p" || /claude.*gpt|3p/i.test(g.displayName));
        if (claudeGroup) targetGroups = [claudeGroup];
        else targetGroups = summary.groups.filter((g) => g.id.startsWith("claude"));
      } else {
        // tenta match exato
        const exact = summary.groups.filter((g) => g.id === gid);
        if (exact.length > 0) targetGroups = exact;
        else {
          // Se não há mapeamento exato na API (API retorna grupos genéricos), usa minRemaining global mas mantém gid para resposta
          // target fica todos grupos, pois não diferencia por sub-modelo
          targetGroups = summary.groups;
        }
      }
    } else {
      // group desconhecido -> usa todos
      targetGroups = summary.groups;
    }
  }

  // Pior caso entre grupos alvo
  let minRemaining = 1.0;
  let minBucket: QuotaBucketParsed | null = null;
  let minGroup: QuotaGroupParsed | null = null;

  for (const g of targetGroups) {
    if (g.minRemainingFraction < minRemaining) {
      minRemaining = g.minRemainingFraction;
      minBucket = g.minBucket ?? g.buckets[0] ?? null;
      minGroup = g;
    }
  }

  if (targetGroups.length === 0) {
    // Sem grupos alvo, fallback allow
    return {
      allowed: true,
      groupId: group ? resolveQuotaGroup(group) : null,
      bucketId: null,
      remainingFraction: 1,
      remainingPercent: 100,
      resetTime: null,
      resetTimeMs: null,
      reason: "no matching groups, assuming allowed",
      isSoftThreshold: false,
      isHardExhausted: false,
      shouldSkipAccount: false,
      source,
    };
  }

  const isHardExhausted = minRemaining <= 0.02 || minRemaining <= 1 - QUOTA_HARD_THRESHOLD;
  const isSoftThreshold = minRemaining <= softRemaining;

  const shouldSkip = isHardExhausted || (isSoftThreshold && minRemaining <= softRemaining);

  // allowed false apenas em hard exhausted; soft permite mas marca shouldSkip para load balancer decidir
  const allowed = !isHardExhausted;

  const gidResult = group ? resolveQuotaGroup(group) : minGroup?.id ?? null;

  return {
    allowed,
    groupId: gidResult,
    bucketId: minBucket?.bucketId ?? null,
    remainingFraction: minRemaining,
    remainingPercent: Math.round(minRemaining * 10000) / 100,
    resetTime: minBucket?.resetTime ?? null,
    resetTimeMs: minBucket?.resetTimeMs ?? null,
    reason: isHardExhausted
      ? `quota exhausted (${(minRemaining * 100).toFixed(2)}% remaining, bucket ${minBucket?.bucketId})`
      : isSoftThreshold
      ? `soft threshold breached (90% used, ${Math.round(minRemaining * 100)}% remaining)`
      : `quota ok (${Math.round(minRemaining * 100)}% remaining)`,
    isSoftThreshold,
    isHardExhausted,
    shouldSkipAccount: shouldSkip,
    source,
    group: minGroup ?? undefined,
    bucket: minBucket ?? undefined,
  };
}

/**
 * Verifica se quota está esgotada (hard threshold).
 * Wrapper sobre checkQuota para compatibilidade.
 */
export async function isQuotaExhausted(
  token: string,
  projectId: string = PROJECT_FALLBACK,
  group?: string | null,
  opts?: { source?: QuotaSource; useCache?: boolean }
): Promise<boolean> {
  const result = await checkQuota(token, projectId, group, opts);
  return result.isHardExhausted;
}

/**
 * Decide se deve pular account (soft 90% threshold).
 * Usado em rotação multi-account.
 */
export async function shouldSkipAccount(
  token: string,
  projectId: string = PROJECT_FALLBACK,
  group?: string | null,
  opts?: { source?: QuotaSource; softThreshold?: number; useCache?: boolean }
): Promise<boolean> {
  const result = await checkQuota(token, projectId, group, opts);
  return result.shouldSkipAccount;
}

/**
 * Lista grupos parsed atuais (usa cache se disponível, senão fetch).
 */
export async function getQuotaGroups(
  token: string,
  projectId: string = PROJECT_FALLBACK,
  opts?: { source?: QuotaSource; useCache?: boolean }
): Promise<QuotaGroupParsed[]> {
  const source = opts?.source ?? "antigravity";
  const useCache = opts?.useCache ?? true;

  const cacheMgr = getQuotaCacheManager();

  if (useCache) {
    const cached = cacheMgr.getCached(token, projectId, source);
    if (cached) return cached.groups;
  }

  const summary = await retrieveUserQuotaSummary(token, projectId, { source });
  cacheMgr.setCached(token, projectId, source, { groups: [] }, summary);
  return summary.groups;
}

// =============================================================================
// QUOTA MANAGER CLASS - DUAL QUOTA + BACKGROUND REFRESH
// =============================================================================

export interface QuotaManagerOptions {
  refreshIntervalMinutes?: number;
  softThreshold?: number; // remaining fraction (default 0.1)
  hardThreshold?: number; // remaining fraction (default 0.02)
  projectId?: string;
  source?: QuotaSource; // default antigravity
  enableDual?: boolean; // se true, busca ambos antigravity+gemini-cli e mescla
}

export class QuotaManager {
  public readonly projectId: string;
  public readonly source: QuotaSource;
  public readonly refreshIntervalMinutes: number;
  public readonly softThreshold: number; // remaining
  public readonly hardThreshold: number;
  public readonly enableDual: boolean;

  private cacheMgr: QuotaCacheManager;
  private token: string | null = null;
  private lastGroups: QuotaGroupParsed[] = [];

  constructor(opts?: QuotaManagerOptions) {
    this.projectId = opts?.projectId ?? PROJECT_FALLBACK;
    this.source = opts?.source ?? "antigravity";
    this.refreshIntervalMinutes = opts?.refreshIntervalMinutes ?? QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT;
    this.softThreshold = opts?.softThreshold ?? QUOTA_SOFT_REMAINING;
    this.hardThreshold = opts?.hardThreshold ?? 0.02;
    this.enableDual = opts?.enableDual ?? true;

    this.cacheMgr = getQuotaCacheManager({ refreshIntervalMinutes: this.refreshIntervalMinutes });
  }

  setToken(token: string): void {
    if (!token || token.length < 10) throw new TypeError("QuotaManager.setToken: token inválido");
    this.token = token;
  }

  getToken(): string | null {
    return this.token;
  }

  /**
   * Força refresh imediato (primária + secundária se dual).
   */
  async refresh(token?: string, projectId?: string): Promise<QuotaSummaryParsed> {
    const t = token ?? this.token;
    if (!t) throw new Error("QuotaManager.refresh: token não definido. Chame setToken() ou passe token.");

    const pid = projectId ?? this.projectId;

    if (this.enableDual) {
      const dual = await retrieveDualQuota(t, pid, {
        source: this.source,
        baseTtlMs: getQuotaRefreshIntervalMs(this.refreshIntervalMinutes),
      });
      // Cache ambas sources se disponíveis
      if (dual.antigravity) {
        this.cacheMgr.setCached(t, pid, "antigravity", { groups: [] }, dual.antigravity);
      }
      if (dual.geminiCli) {
        this.cacheMgr.setCached(t, pid, "gemini-cli", { groups: [] }, dual.geminiCli);
      }
      this.lastGroups = dual.primary.groups;
      return dual.primary;
    } else {
      const summary = await retrieveUserQuotaSummary(t, pid, {
        source: this.source,
        baseTtlMs: getQuotaRefreshIntervalMs(this.refreshIntervalMinutes),
      });
      this.cacheMgr.setCached(t, pid, this.source, { groups: [] }, summary);
      this.lastGroups = summary.groups;
      return summary;
    }
  }

  /**
   * Background refresh não bloqueante.
   */
  refreshInBackground(token?: string, projectId?: string, source?: QuotaSource): void {
    const t = token ?? this.token;
    if (!t) return;
    const pid = projectId ?? this.projectId;
    const src = source ?? this.source;
    this.cacheMgr.refreshInBackground(t, pid, src);

    if (this.enableDual) {
      const other: QuotaSource = src === "antigravity" ? "gemini-cli" : "antigravity";
      this.cacheMgr.refreshInBackground(t, pid, other);
    }
  }

  /**
   * Chamado após cada requisição de generateContent com sucesso.
   */
  notifyRequestSuccess(token?: string, projectId?: string): void {
    const t = token ?? this.token;
    if (!t) return;
    this.cacheMgr.trackRequestAndMaybeRefresh(t, projectId ?? this.projectId, this.source);
  }

  async checkQuota(group?: string | null, token?: string): Promise<CheckQuotaResult> {
    const t = token ?? this.token;
    if (!t) throw new Error("QuotaManager.checkQuota: token não definido");

    return checkQuota(t, this.projectId, group, {
      source: this.source,
      softThreshold: this.softThreshold,
      refreshIntervalMinutes: this.refreshIntervalMinutes,
    });
  }

  async isQuotaExhausted(group?: string | null, token?: string): Promise<boolean> {
    const t = token ?? this.token;
    if (!t) throw new Error("QuotaManager.isQuotaExhausted: token não definido");
    return isQuotaExhausted(t, this.projectId, group, { source: this.source });
  }

  async shouldSkipAccount(group?: string | null, token?: string): Promise<boolean> {
    const t = token ?? this.token;
    if (!t) throw new Error("QuotaManager.shouldSkipAccount: token não definido");
    return shouldSkipAccount(t, this.projectId, group, {
      source: this.source,
      softThreshold: this.softThreshold,
    });
  }

  async getQuotaGroups(token?: string): Promise<QuotaGroupParsed[]> {
    const t = token ?? this.token;
    if (!t) throw new Error("QuotaManager.getQuotaGroups: token não definido");
    return getQuotaGroups(t, this.projectId, { source: this.source });
  }

  resolveQuotaGroup(model: string): QuotaGroupId {
    return resolveQuotaGroup(model);
  }

  getQuotaGroup(input: string): QuotaGroupDef | null {
    return getQuotaGroup(input);
  }

  getCacheStats() {
    return this.cacheMgr.getStats();
  }

  clearCache(token?: string, source?: QuotaSource): void {
    if (token) {
      this.cacheMgr.clear(token, this.projectId, source);
    } else if (this.token) {
      this.cacheMgr.clear(this.token, this.projectId, source);
    } else {
      this.cacheMgr.clear();
    }
  }
}

// =============================================================================
// SINGLETON HELPERS + EXPORTS DE COMPATIBILIDADE
// =============================================================================

let _defaultQuotaManager: QuotaManager | null = null;

export function getDefaultQuotaManager(opts?: QuotaManagerOptions): QuotaManager {
  if (!_defaultQuotaManager) {
    _defaultQuotaManager = new QuotaManager(opts);
  }
  return _defaultQuotaManager;
}

/**
 * Helper para plugin opencode: verifica quota antes de rotear requisição.
 * Retorna true se pode prosseguir.
 */
export async function canProceedWithRequest(
  token: string,
  model: string,
  projectId: string = PROJECT_FALLBACK,
  opts?: { source?: QuotaSource; refreshIntervalMinutes?: number }
): Promise<{ allowed: boolean; check: CheckQuotaResult }> {
  const group = resolveQuotaGroup(model);
  const check = await checkQuota(token, projectId, group, {
    source: opts?.source ?? "antigravity",
    refreshIntervalMinutes: opts?.refreshIntervalMinutes,
  });
  return { allowed: check.allowed, check };
}

// =============================================================================
// CONFIG RESOLUTION - quota_refresh_interval_minutes
// =============================================================================

export interface QuotaConfig {
  quota_refresh_interval_minutes: number;
  quota_soft_threshold_percent: number; // 90 default
  quota_hard_threshold_percent: number; // 98 default
  quota_source: QuotaSource;
  quota_dual_enabled: boolean;
  quota_cache_ttl_ms_default: number;
  project_fallback: string;
}

export const DEFAULT_QUOTA_CONFIG: QuotaConfig = {
  quota_refresh_interval_minutes: QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT,
  quota_soft_threshold_percent: 90,
  quota_hard_threshold_percent: 98,
  quota_source: "antigravity",
  quota_dual_enabled: true,
  quota_cache_ttl_ms_default: QUOTA_CACHE_TTL_MS_DEFAULT,
  project_fallback: PROJECT_FALLBACK,
};

export function resolveQuotaConfig(partial?: Partial<QuotaConfig>): QuotaConfig {
  const envMinutes = process.env.QUOTA_REFRESH_INTERVAL_MINUTES ?? process.env.ANTIGRAVITY_QUOTA_REFRESH_MINUTES;
  let minutes = partial?.quota_refresh_interval_minutes ?? DEFAULT_QUOTA_CONFIG.quota_refresh_interval_minutes;
  if (envMinutes) {
    const p = Number.parseInt(envMinutes, 10);
    if (!Number.isNaN(p) && p > 0) minutes = p;
  }

  return {
    quota_refresh_interval_minutes: Math.max(1, Math.min(minutes, 120)),
    quota_soft_threshold_percent:
      partial?.quota_soft_threshold_percent ?? DEFAULT_QUOTA_CONFIG.quota_soft_threshold_percent,
    quota_hard_threshold_percent:
      partial?.quota_hard_threshold_percent ?? DEFAULT_QUOTA_CONFIG.quota_hard_threshold_percent,
    quota_source: partial?.quota_source ?? DEFAULT_QUOTA_CONFIG.quota_source,
    quota_dual_enabled: partial?.quota_dual_enabled ?? DEFAULT_QUOTA_CONFIG.quota_dual_enabled,
    quota_cache_ttl_ms_default:
      partial?.quota_cache_ttl_ms_default ?? DEFAULT_QUOTA_CONFIG.quota_cache_ttl_ms_default,
    project_fallback: partial?.project_fallback ?? DEFAULT_QUOTA_CONFIG.project_fallback,
  };
}

// =============================================================================
// EXPORT DEFAULT
// =============================================================================

const quotaModule = {
  // constants
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRET,
  PROJECT_FALLBACK,
  ENDPOINTS,
  ENDPOINTS_DAILY,
  QUOTA_ENDPOINTS,
  MODELS_2026,
  QUOTA_GROUP_DEFS,
  QUOTA_REFRESH_INTERVAL_MINUTES_DEFAULT,
  QUOTA_SOFT_THRESHOLD,
  QUOTA_HARD_THRESHOLD,

  // core functions
  retrieveUserQuotaSummary,
  retrieveDualQuota,
  parseQuotaResponse,
  parseQuotaBucket,
  parseQuotaGroup,
  computeAdaptiveTtlMs,
  getQuotaRefreshIntervalMs,

  // resolution
  resolveQuotaGroup,
  getQuotaGroup,
  listQuotaGroups,

  // checks
  checkQuota,
  isQuotaExhausted,
  shouldSkipAccount,
  getQuotaGroups,
  canProceedWithRequest,

  // cache
  QuotaCacheManager,
  getQuotaCacheManager,

  // manager
  QuotaManager,
  getDefaultQuotaManager,

  // config
  DEFAULT_QUOTA_CONFIG,
  resolveQuotaConfig,

  // headers
  buildQuotaHeaders,
};

export default quotaModule;
