/**
 * @fileoverview streaming.ts - ONDA 4 - Plugin Core - Streaming Transformer
 * @module auth/streaming
 * @description Transformer completo produção-ready para SSE do cloudcode-pa
 *              (Cloud Code Assist v1internal:streamGenerateContent).
 *
 *              Features blindadas:
 *              - Parse incremental tolerante a splits (UTF-8, JSON, SSE framing)
 *              - parseSSEChunk() - função pura requerida pela spec
 *              - normalizePayloads() para payloads heterogêneos (candidates, content, parts)
 *              - Transform para OpenAI / Anthropic compatível com opencode
 *              - Tratamento de blocos thinking intercalados (thought:true)
 *              - Cache LRU multi-turn de assinaturas thinking (Map max 100 entries)
 *              - Preservação de thinking entre chunks (stateful)
 *              - Auto-recovery com retry exponencial + jitter + injeção finish sintético
 *              - Zero deps externas: apenas node:* builtins + fetch global
 *
 *              Contexto bypass Gemini CLI:
 *              - Client ID 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com
 *              - Secret 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
 *              - UA GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1
 *              - X-Goog-Api-Client gl-node/22.19.0
 *              - Client-Metadata ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 *              - Project fallback rising-fact-p41fc
 *              - Models 2026 (antigravity + gemini native + claude)
 *
 * @author ONDA 4 - Plugin Core
 * @license MIT
 * @since 2026
 * @version 1.0.0
 */

import * as crypto from "node:crypto";
import * as os from "node:os";

// ============================================================================
// 00. CONSTANTES CANÔNICAS BYPASS (zero-dep)
// ============================================================================

export const GEMINI_CLI_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;
export const GEMINI_CLI_CLIENT_SECRET = "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" as const;
export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;
export const CLOUDCODE_PA_BASE = "https://cloudcode-pa.googleapis.com" as const;

export const GEMINI_CLI_USER_AGENT =
  "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1" as const;
export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;
export const CLIENT_METADATA_RAW =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type ModelId2026 = (typeof MODELS_2026)[number];

// ============================================================================
// 01. TIPOS CORE - RAW PAYLOAD CLOUDCODE-PA
// ============================================================================

export interface RawPart {
  text?: string;
  thought?: boolean;
  thoughtSignature?: string;
  // Claude interop / function calling dentro do cloudcode-pa
  functionCall?: { name: string; args?: Record<string, unknown> | string; id?: string };
  inlineData?: { mimeType: string; data: string };
  // fallback genérico
  [k: string]: unknown;
}

export interface RawContent {
  role?: string;
  parts?: RawPart[];
  // variação sem parts wrapper
  text?: string;
}

export interface RawCandidate {
  content?: RawContent;
  finishReason?: string; // STOP, MAX_TOKENS, SAFETY, etc
  finishMessage?: string;
  index?: number;
  tokenCount?: number;
  safetyRatings?: unknown[];
  // algumas versões enviam content direto no candidate
  parts?: RawPart[];
  text?: string;
  thought?: boolean;
  thoughtSignature?: string;
}

export interface CloudCodeRawChunk {
  candidates?: RawCandidate[];
  // heterogêneo sem candidates
  content?: RawContent;
  parts?: RawPart[];
  // wrapped variations
  response?: CloudCodeRawChunk;
  // metadata
  usageMetadata?: {
    promptTokenCount?: number;
    candidatesTokenCount?: number;
    totalTokenCount?: number;
    thoughtsTokenCount?: number;
  };
  // model version
  model?: string;
  modelVersion?: string;
  // pensamento top-level (algumas versões)
  thought?: string;
  thoughtSignature?: string;
  // fallback
  [k: string]: unknown;
}

// ============================================================================
// 02. TIPOS NORMALIZADOS
// ============================================================================

export type NormalizedPartKind = "text" | "thinking" | "thought_signature" | "function_call" | "inline_data";

export interface NormalizedPart {
  kind: NormalizedPartKind;
  text: string; // sempre string (pode ser vazia para signatures)
  thought: boolean;
  thoughtSignature?: string;
  // function call se kind=function_call
  functionCall?: { name: string; args: string; id: string };
  // origem
  rawIndex: number;
  candidateIndex: number;
  finishReason?: string;
}

export interface NormalizedPayload {
  parts: NormalizedPart[];
  finishReason?: string;
  usage?: CloudCodeRawChunk["usageMetadata"];
  model?: string;
  isThinkingChunk: boolean;
  hasFinish: boolean;
  raw: CloudCodeRawChunk;
}

// ============================================================================
// 03. TIPOS PARA TRANSFORM OPENAI / ANTHROPIC (opencode-compat)
// ============================================================================

export interface StreamingState {
  /** id da completion */
  completionId: string;
  /** model id enviado */
  model: string;
  /** timestamp created */
  created: number;
  /** first chunk sent? */
  sentRole: boolean;
  /** buffer acumulador de texto para métricas */
  accumulatedText: string;
  /** buffer acumulador thinking */
  accumulatedThinking: string;
  /** last finishReason seen */
  lastFinishReason?: string;
  /** thinking atualmente aberto? */
  insideThinking: boolean;
  /** index de content blocks para Anthropic */
  anthropicBlockIndex: number;
  /** map block_index -> kind */
  anthropicBlockKinds: Map<number, NormalizedPartKind>;
  /** para openai tool call id tracking */
  toolCallIdCounter: number;
  /** signature pendente para flush */
  pendingSignatures: string[];
}

export interface OpenAIChatChunk {
  id: string;
  object: "chat.completion.chunk";
  created: number;
  model: string;
  choices: Array<{
    index: number;
    delta: {
      role?: "assistant";
      content?: string;
      reasoning_content?: string;
      reasoning?: string; // compat
      tool_calls?: Array<{
        index: number;
        id: string;
        type: "function";
        function: { name: string; arguments: string };
      }>;
    };
    finish_reason: string | null;
  }>;
  usage?: {
    prompt_tokens?: number;
    completion_tokens?: number;
    total_tokens?: number;
    completion_tokens_details?: { reasoning_tokens?: number };
  };
}

export interface AnthropicSSEEvent {
  type: string;
  // para compat opencode, envia também como data json
  data?: unknown;
  // raw sse line formatted
  sse?: string;
}

// ============================================================================
// 04. LRU CACHE MULTI-TURN PARA ASSINATURAS DE THINKING
// ============================================================================

/**
 * Cache LRU multi-turn de assinaturas de thinking.
 * - Preserva entre requests (global singleton)
 * - Map com max 100 entries (conforme spec)
 * - Key: hash do thinking text ou id de turno
 * - Value: signature string + timestamp + model
 *
 * Uso: modelos thinking da família gemini-3-pro / claude-opus-thinking
 * retornam thoughtSignature que deve ser reenviado em multi-turn para
 * preservar reasoning (replays).
 */
export interface ThinkingSignatureEntry {
  signature: string;
  thinkingText: string;
  model: string;
  timestamp: number;
  turnId: string;
  tokenCount?: number;
}

export class ThinkingSignatureLRUCache {
  private readonly maxEntries: number;
  private readonly map: Map<string, ThinkingSignatureEntry>;

  constructor(maxEntries = 100) {
    this.maxEntries = maxEntries;
    this.map = new Map();
  }

  private touch(key: string): void {
    const entry = this.map.get(key);
    if (!entry) return;
    // LRU: remove e reinsere no fim (mais recente)
    this.map.delete(key);
    this.map.set(key, entry);
  }

  get(key: string): ThinkingSignatureEntry | undefined {
    const v = this.map.get(key);
    if (v) this.touch(key);
    return v;
  }

  set(key: string, entry: ThinkingSignatureEntry): void {
    if (this.map.has(key)) this.map.delete(key);
    this.map.set(key, entry);
    // evict
    while (this.map.size > this.maxEntries) {
      const oldest = this.map.keys().next().value as string;
      this.map.delete(oldest);
    }
  }

  /**
   * Hash FNV-1a curto para thinking text como key quando turnId não existe
   */
  static hashThinking(text: string): string {
    let h = 0x811c9dc5;
    const buf = Buffer.from(text, "utf8");
    for (let i = 0; i < buf.length; i++) {
      h ^= buf[i]!;
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h.toString(16).padStart(8, "0");
  }

  /**
   * Adiciona entrada a partir de NormalizedPart ou Raw
   */
  addFromPayload(payload: {
    signature: string;
    thinkingText?: string;
    model?: string;
    turnId?: string;
    tokenCount?: number;
  }): string {
    const keyBase = payload.turnId ?? ThinkingSignatureLRUCache.hashThinking(payload.thinkingText ?? payload.signature);
    const entry: ThinkingSignatureEntry = {
      signature: payload.signature,
      thinkingText: payload.thinkingText ?? "",
      model: payload.model ?? "gemini-3-pro-preview",
      timestamp: Date.now(),
      turnId: keyBase,
      tokenCount: payload.tokenCount,
    };
    this.set(keyBase, entry);
    return keyBase;
  }

  /** Busca por prefixo de turno / model */
  findByModel(model: string): ThinkingSignatureEntry[] {
    const out: ThinkingSignatureEntry[] = [];
    for (const e of this.map.values()) {
      if (e.model === model || e.model.includes(model) || model.includes(e.model)) out.push(e);
    }
    return out;
  }

  clear(): void {
    this.map.clear();
  }

  get size(): number {
    return this.map.size;
  }

  entries(): IterableIterator<[string, ThinkingSignatureEntry]> {
    return this.map.entries();
  }

  toJSON(): Record<string, ThinkingSignatureEntry> {
    const obj: Record<string, ThinkingSignatureEntry> = {};
    for (const [k, v] of this.map) obj[k] = v;
    return obj;
  }
}

/** Singleton global - persiste entre chamadas no mesmo processo Node */
export const globalThinkingSignatureCache = new ThinkingSignatureLRUCache(100);

// ============================================================================
// 05. PARSE INCREMENTAL TOLERANTE A SPLITS - SSE
// ============================================================================

export interface ParseSSEChunkResult {
  payloads: CloudCodeRawChunk[];
  remainder: string;
  // informações diagnósticas
  consumedBytes: number;
  errors: string[];
}

function safeJsonParseArray(text: string): { objects: CloudCodeRawChunk[]; remainder: string; errors: string[] } {
  const objects: CloudCodeRawChunk[] = [];
  const errors: string[] = [];
  let remainder = text;

  // Trim BOM
  if (remainder.charCodeAt(0) === 0xfeff) remainder = remainder.slice(1);

  // Estratégia 1: linha a linha tipo SSE data:
  // O cloudcode-pa pode enviar:
  // data: {...}\n\n
  // ou
  // data: {...}\r\n
  // ou múltiplos data em mesma chunk
  // ou plain JSON concatenado {}{}
  // ou JSON array [\n{...},\n{...}\n]
  // Precisa ser tolerante.

  // Buffer para processar
  let buffer = remainder;
  remainder = "";

  // Split mantendo framing mas tolerante a split no meio de JSON
  // Tentamos extrair todos data: {json}\n\n válidos
  // Se json incompleto, deixa no remainder

  const lines = buffer.split(/\r?\n/);
  let jsonAccumulator = "";
  let insideDataBlock = false;
  let dataPrefixFound = false;

  const flushAccumulator = (): { parsed: CloudCodeRawChunk[]; leftover: string } => {
    const trimmed = jsonAccumulator.trim();
    if (!trimmed) return { parsed: [], leftover: "" };
    // Tenta parsear um ou mais objetos concatenados
    const parsed: CloudCodeRawChunk[] = [];
    let leftover = "";

    // Caso seja array JSON [...,]
    if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
      try {
        const arr = JSON.parse(trimmed) as unknown;
        if (Array.isArray(arr)) {
          for (const item of arr) {
            if (item && typeof item === "object") parsed.push(item as CloudCodeRawChunk);
          }
          return { parsed, leftover: "" };
        }
      } catch {
        // array incompleto -> tratar como objeto stream
      }
    }

    // Parse concatenado tipo }{ ou }\n{
    // Usamos parser incremental simples de chaves balanceadas
    let depth = 0;
    let inString = false;
    let escape = false;
    let start = -1;
    for (let i = 0; i < trimmed.length; i++) {
      const ch = trimmed[i]!;
      if (escape) {
        escape = false;
        continue;
      }
      if (ch === "\\" && inString) {
        escape = true;
        continue;
      }
      if (ch === '"' ) {
        inString = !inString;
        continue;
      }
      if (inString) continue;
      if (ch === "{" || ch === "[") {
        if (depth === 0) start = i;
        depth++;
      } else if (ch === "}" || ch === "]") {
        depth--;
        if (depth === 0 && start !== -1) {
          const slice = trimmed.slice(start, i + 1);
          try {
            const obj = JSON.parse(slice);
            if (obj && typeof obj === "object") parsed.push(obj as CloudCodeRawChunk);
          } catch (e) {
            // json invalido neste slice -> guarda como leftover pra retry
            errors.push(`json_parse_slice_failed: ${(e as Error).message} slice=${slice.slice(0,120)}`);
            leftover = trimmed.slice(start);
            // interrompe loop, tenta na próxima chamada
            break;
          }
          start = -1;
        }
      }
    }
    if (depth !== 0 && start !== -1) {
      // incompleto
      leftover = trimmed.slice(start);
    } else if (parsed.length === 0 && trimmed.length > 0 && leftover === "") {
      // não conseguiu parsear, pode ser prefix incompleto
      leftover = trimmed;
    }
    return { parsed, leftover };
  };

  // Processa linha a linha
  for (let li = 0; li < lines.length; li++) {
    const line = lines[li]!;
    const trimmedLine = line.trim();

    // Linhas SSE
    if (trimmedLine.length === 0) {
      // linha vazia indica fim de evento SSE - flush
      if (jsonAccumulator.trim().length > 0) {
        const res = flushAccumulator();
        objects.push(...res.parsed);
        if (res.leftover) {
          // deixa resto no accumulator
          jsonAccumulator = res.leftover;
          // se ainda tem dados balanceados incompletos, break para remainder
          if (li === lines.length - 1 && res.parsed.length === 0) {
            // última linha incompleta
            break;
          }
        } else {
          jsonAccumulator = "";
        }
      }
      insideDataBlock = false;
      dataPrefixFound = false;
      continue;
    }

    // Detecta [DONE] de OpenAI-compat wrapper intermediário
    if (trimmedLine === "data: [DONE]" || trimmedLine === "[DONE]") {
      continue;
    }

    let dataContent = "";
    if (trimmedLine.startsWith("data:")) {
      dataPrefixFound = true;
      insideDataBlock = true;
      dataContent = trimmedLine.slice(5).trimStart(); // após data:
      // dataContent pode ser json ou empty
      if (dataContent.length === 0) {
        // data vazio, mas continuação de multilinha data:
        continue;
      }
    } else if (trimmedLine.startsWith("event:") || trimmedLine.startsWith("id:") || trimmedLine.startsWith(":")) {
      // SSE metadata lines - ignora, mas preserva framing
      continue;
    } else if (insideDataBlock || !dataPrefixFound) {
      // linha sem prefixo mas dentro de bloco data (multiline JSON)
      // ou plain JSON sem SSE wrapper (cloudcode-pa às vezes retorna ndjson)
      dataContent = trimmedLine;
    }

    if (dataContent.length > 0) {
      // append com \n para preservar eventual quebras dentro de string json (escapado)
      if (jsonAccumulator.length > 0) jsonAccumulator += "\n";
      jsonAccumulator += dataContent;
      // Tenta detectar se acumulador já é JSON completo (balanceado) e já tem próximo evento
      // Só flush quando encontra linha vazia ou when buffer looks complete + next data: arrives
      // Para não quebrar splits, only tenta flush se bracket balance zero e não dentro de string
      // Heurística rápida:
      const looksComplete = (() => {
        let d = 0, ins = false, esc = false;
        for (let k = 0; k < jsonAccumulator.length; k++) {
          const c = jsonAccumulator[k]!;
          if (esc) { esc = false; continue; }
          if (c === "\\" && ins) { esc = true; continue; }
          if (c === '"') { ins = !ins; continue; }
          if (ins) continue;
          if (c === "{" || c === "[") d++;
          else if (c === "}" || c === "]") d--;
        }
        return d === 0 && !ins;
      })();
      // Se parece completo e próxima linha será novo data: , vamos flush antecipado para tolerar falta de linha vazia
      const nextLine = lines[li + 1];
      const nextIsData = nextLine?.trim().startsWith("data:") ?? false;
      const nextEmpty = nextLine?.trim().length === 0 ?? false;
      if (looksComplete && (nextIsData || nextEmpty || li === lines.length - 1)) {
        const res = flushAccumulator();
        objects.push(...res.parsed);
        if (res.leftover) {
          jsonAccumulator = res.leftover;
        } else {
          jsonAccumulator = "";
          insideDataBlock = false;
        }
      }
    }
  }

  // Ao final, se ainda há accumulator incompleto, deixa como remainder
  if (jsonAccumulator.trim().length > 0) {
    // tenta mais uma vez para ver se é parseável
    const res = flushAccumulator();
    if (res.parsed.length > 0) {
      objects.push(...res.parsed);
      remainder = res.leftover;
    } else {
      remainder = jsonAccumulator; // mantém
    }
  } else {
    remainder = "";
  }

  return { objects, remainder, errors };
}

/**
 * parseSSEChunk() - Função pura requerida pela spec.
 * Tolerante a splits: recebe chunk string + remainder anterior opcional.
 *
 * @param chunk - novo pedaço bruto de texto vindo do ReadableStream
 * @param previousRemainder - remainder de chamada anterior
 * @returns { payloads, remainder } payloads são CloudCodeRawChunk já parseados
 *
 * @example
 * let remainder = ""
 * for await (const raw of stream) {
 *   const { payloads, remainder: next } = parseSSEChunk(raw, remainder)
 *   remainder = next
 *   for (const p of payloads) handle(p)
 * }
 */
export function parseSSEChunk(
  chunk: string | Uint8Array,
  previousRemainder = ""
): { payloads: CloudCodeRawChunk[]; remainder: string; errors: string[]; consumed: number } {
  let text = "";
  if (typeof chunk === "string") {
    text = chunk;
  } else {
    // Uint8Array - decodifica tolerante
    try {
      text = Buffer.from(chunk).toString("utf8");
    } catch {
      text = new TextDecoder("utf-8", { fatal: false }).decode(chunk);
    }
  }

  const combined = previousRemainder + text;
  const { objects, remainder, errors } = safeJsonParseArray(combined);

  // unwrap wrapper response.candidates etc já aqui? Deixa para normalizePayloads
  // mas já tenta desembrulhar camada response se presente
  const payloads = objects.map((obj) => {
    // Alguns payloads cloudcode-pa vêm embalados em { response: {...} }
    const maybe = (obj as any).response as CloudCodeRawChunk | undefined;
    if (maybe && typeof maybe === "object" && ((maybe as any).candidates || (maybe as any).content || (maybe as any).parts)) {
      return maybe;
    }
    return obj;
  });

  return {
    payloads,
    remainder,
    errors,
    consumed: text.length,
  };
}

// ============================================================================
// 06. NORMALIZEPAYLOADS() - UNIFICA PAYLOADS HETEROGÊNEOS
// ============================================================================

/**
 * normalizePayloads() - unifica payloads heterogêneos em NormalizedPayload[]
 *
 * Lida com variações:
 * - {candidates:[{content:{parts:[{text, thought, thoughtSignature}]}, finishReason}]}
 * - {content:{parts:[...]}}
 * - {parts:[...]}
 * - {candidates:[{text:"..."}]} (formato curto)
 * - {text:"..."} plain
 * - thoughtSignature solto
 *
 * @param rawChunks - array de CloudCodeRawChunk vindos de parseSSEChunk
 * @param opts - opções
 */
export function normalizePayloads(
  rawChunks: CloudCodeRawChunk[],
  opts?: {
    model?: string;
    candidateIndexFallback?: number;
  }
): NormalizedPayload[] {
  const modelFallback = opts?.model ?? "gemini-3-pro-preview";
  const out: NormalizedPayload[] = [];

  let globalIndex = opts?.candidateIndexFallback ?? 0;

  for (let rawIndex = 0; rawIndex < rawChunks.length; rawIndex++) {
    const raw = rawChunks[rawIndex]!;
    if (!raw || typeof raw !== "object") continue;

    // Detecta se já está wrapped? Já unwrapped em parseSSEChunk, mas garante
    const unwrapped: CloudCodeRawChunk = (raw as any).response && typeof (raw as any).response === "object" ? (raw as any).response as CloudCodeRawChunk : raw;

    const candidatesList: RawCandidate[] = [];

    if (Array.isArray(unwrapped.candidates) && unwrapped.candidates.length > 0) {
      candidatesList.push(...unwrapped.candidates);
    } else if (unwrapped.content) {
      // sem candidates, content direto -> cria candidate virtual
      candidatesList.push({ content: unwrapped.content, index: 0 });
    } else if (Array.isArray(unwrapped.parts) && unwrapped.parts.length > 0) {
      candidatesList.push({ content: { parts: unwrapped.parts }, index: 0 });
    } else if (typeof (unwrapped as any).text === "string") {
      candidatesList.push({ content: { parts: [{ text: (unwrapped as any).text as string }] }, index: 0 });
    } else if (typeof (unwrapped as any).thought === "string") {
      // pensamento solto no topo
      candidatesList.push({
        content: {
          parts: [
            {
              text: (unwrapped as any).thought as string,
              thought: true,
              thoughtSignature: (unwrapped as any).thoughtSignature as string | undefined,
            } as RawPart,
          ],
        },
        index: 0,
      });
    } else {
      // objeto desconhecido mas ainda tenta extrair text
      const txt = extractTextFromAny(unwrapped);
      if (txt) {
        candidatesList.push({ content: { parts: [{ text: txt }] }, index: 0 });
      } else {
        continue; // chunk vazio / metadata apenas
      }
    }

    // Para cada candidate, extrai parts normalizadas
    for (let ci = 0; ci < candidatesList.length; ci++) {
      const cand = candidatesList[ci]!;
      const candIndex = typeof cand.index === "number" ? cand.index : ci;
      const finishReasonRaw = (cand.finishReason || (unwrapped as any).finishReason || "") as string;
      const finishReason = normalizeFinishReason(finishReasonRaw);

      let rawParts: RawPart[] = [];

      if (cand.content?.parts && Array.isArray(cand.content.parts)) {
        rawParts = cand.content.parts;
      } else if ((cand as any).parts && Array.isArray((cand as any).parts)) {
        rawParts = (cand as any).parts;
      } else if (typeof cand.text === "string" && cand.text.length > 0) {
        rawParts = [{ text: cand.text, thought: !!(cand as any).thought, thoughtSignature: (cand as any).thoughtSignature }];
      } else if (cand.content?.text && typeof cand.content.text === "string") {
        rawParts = [{ text: cand.content.text }];
      } else if (typeof (cand.content as any)?.text === "string") {
        rawParts = [{ text: (cand.content as any).text as string }];
      }

      const normalizedParts: NormalizedPart[] = [];
      let isThinkingChunk = false;

      for (let pi = 0; pi < rawParts.length; pi++) {
        const rp = rawParts[pi]!;
        if (!rp || typeof rp !== "object") continue;

        const txt = typeof rp.text === "string" ? rp.text : extractTextFromAny(rp);
        const isThought = rp.thought === true || (rp as any).isThought === true;
        const sig = typeof rp.thoughtSignature === "string" ? rp.thoughtSignature : (typeof (rp as any).thought_signature === "string" ? (rp as any).thought_signature as string : undefined);

        if (isThought) isThinkingChunk = true;

        // function call
        if (rp.functionCall && typeof rp.functionCall === "object") {
          const fc = rp.functionCall as { name: string; args?: unknown; id?: string };
          const argsStr = typeof fc.args === "string" ? fc.args : JSON.stringify(fc.args ?? {});
          normalizedParts.push({
            kind: "function_call",
            text: "",
            thought: false,
            thoughtSignature: sig,
            functionCall: {
              name: fc.name || "unknown",
              args: argsStr,
              id: fc.id || `call_${globalIndex}_${ci}_${pi}_${Date.now().toString(36)}`,
            },
            rawIndex,
            candidateIndex: candIndex,
            finishReason,
          });
          continue;
        }

        // inline data (imagem etc) - ignora texto mas registra kind
        if (rp.inlineData) {
          normalizedParts.push({
            kind: "inline_data",
            text: "",
            thought: false,
            thoughtSignature: sig,
            rawIndex,
            candidateIndex: candIndex,
            finishReason,
          });
          continue;
        }

        // thoughtSignature solto sem texto
        if (!txt && sig) {
          normalizedParts.push({
            kind: "thought_signature",
            text: "",
            thought: true,
            thoughtSignature: sig,
            rawIndex,
            candidateIndex: candIndex,
            finishReason,
          });
          continue;
        }

        if (!txt && !sig) continue; // vazio

        normalizedParts.push({
          kind: isThought ? "thinking" : "text",
          text: txt ?? "",
          thought: isThought,
          thoughtSignature: sig,
          rawIndex,
          candidateIndex: candIndex,
          finishReason,
        });
      }

      // Mesmo que não tenha parts, se houver finishReason precisamos emitir payload de finish
      const hasFinish = !!finishReason;

      if (normalizedParts.length === 0 && !hasFinish) {
        // Pode ser usageMetadata apenas
        if (unwrapped.usageMetadata) {
          out.push({
            parts: [],
            finishReason: undefined,
            usage: unwrapped.usageMetadata,
            model: unwrapped.model ?? modelFallback,
            isThinkingChunk: false,
            hasFinish: false,
            raw: unwrapped,
          });
        }
        continue;
      }

      out.push({
        parts: normalizedParts,
        finishReason: finishReason || undefined,
        usage: unwrapped.usageMetadata,
        model: unwrapped.model ?? modelFallback,
        isThinkingChunk,
        hasFinish,
        raw: unwrapped,
      });

      globalIndex++;
    }
  }

  return out;
}

function normalizeFinishReason(raw: string): string | undefined {
  if (!raw) return undefined;
  const upper = raw.toUpperCase();
  // Mapeia para OpenAI style
  if (upper.includes("STOP") || upper === "FINISH_REASON_STOP" || upper === "END") return "stop";
  if (upper.includes("MAX_TOKENS") || upper.includes("LENGTH")) return "length";
  if (upper.includes("SAFETY") || upper.includes("BLOCK")) return "content_filter";
  if (upper.includes("RECITATION")) return "content_filter";
  if (upper.includes("TOOL")) return "tool_calls";
  if (upper.includes("FINISH_REASON_UNSPECIFIED")) return undefined;
  // mantém original se não mapeável, mas normaliza lowercase
  return upper.toLowerCase();
}

function extractTextFromAny(obj: unknown): string | undefined {
  if (!obj) return undefined;
  if (typeof obj === "string") return obj;
  if (typeof obj !== "object") return undefined;
  const o = obj as Record<string, unknown>;
  if (typeof o.text === "string") return o.text;
  if (typeof o.content === "string") return o.content;
  if (typeof o.message === "string") return o.message;
  if (Array.isArray(o.parts)) {
    const txt = (o.parts as any[])
      .map((p) => (typeof p === "string" ? p : (p as any)?.text ?? ""))
      .join("");
    if (txt) return txt;
  }
  return undefined;
}

// ============================================================================
// 07. TRANSFORM PARA OPENAI / ANTHROPIC COMPATÍVEL COM OPENCODE
// ============================================================================

function newCompletionId(): string {
  try {
    const uuid = crypto.randomUUID();
    return `chatcmpl-${uuid.replace(/-/g, "").slice(0, 29)}`;
  } catch {
    return `chatcmpl-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
  }
}

export function createInitialStreamingState(model: string, completionId?: string): StreamingState {
  return {
    completionId: completionId ?? newCompletionId(),
    model,
    created: Math.floor(Date.now() / 1000),
    sentRole: false,
    accumulatedText: "",
    accumulatedThinking: "",
    accumulatedThinkingTrimmed: "" as unknown as string, // placeholder
    lastFinishReason: undefined,
    insideThinking: false,
    anthropicBlockIndex: 0,
    anthropicBlockKinds: new Map(),
    toolCallIdCounter: 0,
    pendingSignatures: [],
  } as StreamingState & { accumulatedThinkingTrimmed: string };
}

/**
 * Transform de NormalizedPayload para chunks OpenAI compatível com opencode
 * - Preservação de thinking entre chunks (state.insideThinking)
 * - Emite reasoning_content para thinking
 * - Tool calls se presentes
 * - Finish injection lógica delegada fora (mas aqui trata)
 */
export function transformToOpenAIChunks(
  payloads: NormalizedPayload[],
  state: StreamingState
): OpenAIChatChunk[] {
  const out: OpenAIChatChunk[] = [];

  for (const p of payloads) {
    if (p.finishReason) state.lastFinishReason = p.finishReason;

    // Se usage apenas sem parts, emite chunk com usage? OpenAI streaming não envia usage no meio por padrão,
    // mas opencode pode aceitar final usage. Guardaremos no state para final flush.
    if (p.parts.length === 0 && p.usage) {
      // nada a emitir agora, guarda?
      continue;
    }

    for (const part of p.parts) {
      // role chunk primeiro
      if (!state.sentRole) {
        out.push({
          id: state.completionId,
          object: "chat.completion.chunk",
          created: state.created,
          model: state.model,
          choices: [
            {
              index: part.candidateIndex,
              delta: { role: "assistant" },
              finish_reason: null,
            },
          ],
        });
        state.sentRole = true;
      }

      // Handle thought signature cache
      if (part.thoughtSignature) {
        // armazena no LRU cache global
        try {
          globalThinkingSignatureCache.addFromPayload({
            signature: part.thoughtSignature,
            thinkingText: part.kind === "thinking" ? part.text : state.accumulatedThinking.slice(-2000),
            model: p.model ?? state.model,
            turnId: `${state.completionId}_${part.candidateIndex}`,
          });
        } catch {
          // ignorar erro de cache
        }
        // guarda para flush eventual
        if (!state.pendingSignatures.includes(part.thoughtSignature)) {
          state.pendingSignatures.push(part.thoughtSignature);
          // evita crescimento infinito
          if (state.pendingSignatures.length > 50) state.pendingSignatures.shift();
        }
      }

      // Tool call
      if (part.kind === "function_call" && part.functionCall) {
        out.push({
          id: state.completionId,
          object: "chat.completion.chunk",
          created: state.created,
          model: state.model,
          choices: [
            {
              index: part.candidateIndex,
              delta: {
                tool_calls: [
                  {
                    index: state.toolCallIdCounter++,
                    id: part.functionCall.id,
                    type: "function",
                    function: {
                      name: part.functionCall.name,
                      arguments: part.functionCall.args,
                    },
                  },
                ],
              },
              finish_reason: null,
            },
          ],
        });
        continue;
      }

      // Text / Thinking intercalados
      if (part.kind === "thinking" || part.thought) {
        // preservação thinking entre chunks: se mudamos de thinking para texto e de volta, marca transição
        if (!state.insideThinking) {
          state.insideThinking = true;
        }
        state.accumulatedThinking += part.text;

        // Emite como reasoning_content (padrão opencode + openrouter compat)
        out.push({
          id: state.completionId,
          object: "chat.completion.chunk",
          created: state.created,
          model: state.model,
          choices: [
            {
              index: part.candidateIndex,
              delta: {
                // opencode usa reasoning_content e reasoning ambos, enviamos ambos
                reasoning_content: part.text,
                reasoning: part.text,
              },
              finish_reason: null,
            },
          ],
        });
      } else if (part.kind === "text") {
        // se estava dentro de thinking antes, agora fecha thinking
        if (state.insideThinking) {
          state.insideThinking = false;
        }
        state.accumulatedText += part.text;

        out.push({
          id: state.completionId,
          object: "chat.completion.chunk",
          created: state.created,
          model: state.model,
          choices: [
            {
              index: part.candidateIndex,
              delta: {
                content: part.text,
              },
              finish_reason: null,
            },
          ],
        });
      } else if (part.kind === "thought_signature") {
        // assinatura sem texto - não emite conteúdo, apenas cache já feito
        continue;
      }
      // inline_data ignorado por enquanto
    }

    // Se payload tem finishReason e parts vazios ou não, não emite ainda aqui, deixa para after loop
    // mas se payload tem finish com parts, precisamos fechar?
    if (p.hasFinish && p.finishReason) {
      // não emite final aqui, será feito em flush sintético depois se necessário
      // mas se já tem finish explicita do server, emitimos stop em seguida
      // guardamos lastFinishReason já feito
    }
  }

  return out;
}

/**
 * Flush final sintético caso stream termine - usado tanto em OpenAI quanto Anthropic
 * Gera chunk de finish com finish_reason
 */
export function createSyntheticFinishChunks(
  state: StreamingState,
  reason: string = "stop",
  usage?: NormalizedPayload["usage"]
): OpenAIChatChunk[] {
  const finish = state.lastFinishReason ?? reason;
  const normalized = normalizeFinishReason(finish) ?? "stop";

  const chunk: OpenAIChatChunk = {
    id: state.completionId,
    object: "chat.completion.chunk",
    created: state.created,
    model: state.model,
    choices: [
      {
        index: 0,
        delta: {},
        finish_reason: normalized,
      },
    ],
  };

  if (usage) {
    (chunk as any).usage = {
      prompt_tokens: usage.promptTokenCount,
      completion_tokens: usage.candidatesTokenCount ?? usage.totalTokenCount,
      total_tokens: usage.totalTokenCount,
      completion_tokens_details: usage.thoughtsTokenCount
        ? { reasoning_tokens: usage.thoughtsTokenCount }
        : undefined,
    };
  }

  // [DONE] será adicionado pelo caller na serialização SSE
  return [chunk];
}

/**
 * Formata OpenAIChunk array para SSE lines (string)
 * Pronto para enviar via Node http / fetch Response
 */
export function serializeOpenAIChunksToSSE(chunks: OpenAIChatChunk[]): string[] {
  const lines: string[] = [];
  for (const c of chunks) {
    lines.push(`data: ${JSON.stringify(c)}\n\n`);
  }
  return lines;
}

/**
 * Transform para Anthropic-compatible (opencode usa ambos)
 * Gera eventos no formato Anthropic Messages streaming:
 * - message_start
 * - content_block_start
 * - content_block_delta
 * - content_block_stop
 * - message_delta (stop_reason)
 * - message_stop
 */
export function transformToAnthropicEvents(
  payloads: NormalizedPayload[],
  state: StreamingState
): string[] {
  const sseLines: string[] = [];

  const emit = (event: string, data: unknown): void => {
    sseLines.push(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  // Se primeiro contato, emite message_start + content_block_start se necessário
  if (state.anthropicBlockIndex === 0 && !state.sentRole) {
    emit("message_start", {
      type: "message_start",
      message: {
        id: state.completionId.replace("chatcmpl-", "msg_"),
        type: "message",
        role: "assistant",
        content: [],
        model: state.model,
        stop_reason: null,
        stop_sequence: null,
        usage: { input_tokens: 0, output_tokens: 0 },
      },
    });
    state.sentRole = true;
  }

  for (const p of payloads) {
    if (p.finishReason) state.lastFinishReason = p.finishReason;

    for (const part of p.parts) {
      if (part.thoughtSignature) {
        try {
          globalThinkingSignatureCache.addFromPayload({
            signature: part.thoughtSignature,
            thinkingText: part.text || state.accumulatedThinking.slice(-2000),
            model: p.model ?? state.model,
            turnId: `${state.completionId}_${part.candidateIndex}`,
          });
        } catch {}
      }

      if (part.kind === "function_call" && part.functionCall) {
        // Anthropic tool_use
        const blockIndex = state.anthropicBlockIndex++;
        state.anthropicBlockKinds.set(blockIndex, "function_call");

        emit("content_block_start", {
          type: "content_block_start",
          index: blockIndex,
          content_block: {
            type: "tool_use",
            id: part.functionCall.id,
            name: part.functionCall.name,
            input: {},
          },
        });

        emit("content_block_delta", {
          type: "content_block_delta",
          index: blockIndex,
          delta: {
            type: "input_json_delta",
            partial_json: part.functionCall.args,
          },
        });

        emit("content_block_stop", {
          type: "content_block_stop",
          index: blockIndex,
        });
        continue;
      }

      // Determine block kind baseado em thought
      const isThinking = part.kind === "thinking" || part.thought;
      const wantedKind: NormalizedPartKind = isThinking ? "thinking" : "text";

      // Se não há bloco aberto ou mudou de kind (thinking intercalado), inicia novo block
      let currentBlockIndex = state.anthropicBlockIndex;
      const currentKind = state.anthropicBlockKinds.get(currentBlockIndex - 1);

      const needNewBlock =
        currentBlockIndex === 0 ||
        (currentKind !== undefined && currentKind !== wantedKind && currentKind !== part.kind) ||
        state.insideThinking !== isThinking; // transição thinking<->text

      if (needNewBlock) {
        if (currentBlockIndex > 0 && currentKind !== undefined) {
          // fecha anterior se mudou de tipo, mas se acumulando mesmo tipo não fecha
          if (currentKind !== wantedKind) {
            emit("content_block_stop", {
              type: "content_block_stop",
              index: currentBlockIndex - 1,
            });
          }
        }

        if (currentKind !== wantedKind || currentBlockIndex === 0) {
          // abre novo
          const idx = state.anthropicBlockIndex;
          state.anthropicBlockKinds.set(idx, wantedKind);
          state.anthropicBlockIndex++;

          if (isThinking) {
            emit("content_block_start", {
              type: "content_block_start",
              index: idx,
              content_block: { type: "thinking", thinking: "" },
            });
            state.insideThinking = true;
          } else {
            emit("content_block_start", {
              type: "content_block_start",
              index: idx,
              content_block: { type: "text", text: "" },
            });
            state.insideThinking = false;
          }
          currentBlockIndex = idx;
        }
      }

      // Atualiza accumulators
      if (isThinking) {
        state.accumulatedThinking += part.text;
        const idx = state.anthropicBlockIndex - 1;
        emit("content_block_delta", {
          type: "content_block_delta",
          index: idx,
          delta: { type: "thinking_delta", thinking: part.text },
        });
      } else if (part.kind === "text") {
        state.accumulatedText += part.text;
        const idx = state.anthropicBlockIndex - 1;
        emit("content_block_delta", {
          type: "content_block_delta",
          index: idx,
          delta: { type: "text_delta", text: part.text },
        });
      }
    }
  }

  return sseLines;
}

export function createAnthropicSyntheticFinish(
  state: StreamingState,
  reason: string = "end_turn",
  usage?: NormalizedPayload["usage"]
): string[] {
  const lines: string[] = [];

  const emit = (event: string, data: unknown) => {
    lines.push(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  // Fecha bloco aberto
  if (state.anthropicBlockIndex > 0) {
    const lastIdx = state.anthropicBlockIndex - 1;
    if (state.anthropicBlockKinds.has(lastIdx)) {
      emit("content_block_stop", { type: "content_block_stop", index: lastIdx });
    }
  }

  emit("message_delta", {
    type: "message_delta",
    delta: {
      stop_reason: state.lastFinishReason ? mapFinishToAnthropic(state.lastFinishReason) : reason,
      stop_sequence: null,
    },
    usage: usage
      ? {
          output_tokens: usage.candidatesTokenCount ?? usage.totalTokenCount ?? 0,
        }
      : { output_tokens: 0 },
  });

  emit("message_stop", { type: "message_stop" });

  return lines;
}

function mapFinishToAnthropic(finish: string): string {
  const n = finish.toLowerCase();
  if (n === "stop" || n.includes("stop")) return "end_turn";
  if (n === "length" || n.includes("max")) return "max_tokens";
  if (n === "tool_calls") return "tool_use";
  if (n === "content_filter") return "end_turn";
  return "end_turn";
}

// ============================================================================
// 08. INCREMENTAL SSE PARSER CLASS (stateful)
// ============================================================================

export class IncrementalSSEParser {
  private buffer: string;
  private readonly decoder: TextDecoder;
  private totalBytes: number;

  constructor() {
    this.buffer = "";
    this.decoder = new TextDecoder("utf-8", { fatal: false });
    this.totalBytes = 0;
  }

  /**
   * Push incremental chunk (string | Uint8Array) tolerante a splits.
   * Retorna payloads parseados até agora.
   */
  push(chunk: string | Uint8Array | Buffer): CloudCodeRawChunk[] {
    let text: string;
    if (typeof chunk === "string") {
      text = chunk;
    } else if (chunk instanceof Uint8Array || Buffer.isBuffer(chunk)) {
      // TextDecoder streaming-friendly
      text = this.decoder.decode(chunk, { stream: true });
    } else {
      text = String(chunk);
    }

    this.totalBytes += text.length;
    const result = parseSSEChunk(text, this.buffer);
    this.buffer = result.remainder;
    // Log errors silenciosamente? Aqui ignora mas poderia emitir
    return result.payloads;
  }

  /**
   * Flush final - tenta parsear remainder
   */
  flush(): CloudCodeRawChunk[] {
    if (!this.buffer.trim()) {
      this.buffer = "";
      return [];
    }
    // Força parse com decode final
    try {
      const finalText = this.decoder.decode(); // flush decoder
      if (finalText) this.buffer += finalText;
    } catch {}
    const result = parseSSEChunk("", this.buffer);
    this.buffer = result.remainder;
    if (result.payloads.length > 0) {
      this.buffer = ""; // se parseou, limpa
    }
    return result.payloads;
  }

  get remainder(): string {
    return this.buffer;
  }

  get bytesReceived(): number {
    return this.totalBytes;
  }

  reset(): void {
    this.buffer = "";
    this.totalBytes = 0;
  }
}

// ============================================================================
// 09. STREAMING TRANSFORMER DE ALTO NÍVEL - OPENCODE-COMPAT
// ============================================================================

export type OutputFormat = "openai" | "anthropic" | "raw";

export interface StreamingTransformerOptions {
  /** Model id alvo */
  model: string;
  /** Output format: openai por padrão (opencode) */
  format?: OutputFormat;
  /** completion id opcional */
  completionId?: string;
  /** cache LRU externo (default global) */
  thinkingCache?: ThinkingSignatureLRUCache;
  /** injetar finish sintético se stream terminar sem finish? default true */
  injectSyntheticFinish?: boolean;
  /** incluir [DONE] no final de OpenAI SSE? default true */
  includeDoneMarker?: boolean;
  /** callback para cada chunk transformado (string SSE) */
  onChunk?: (sseLine: string, state: StreamingState) => void;
}

export class CloudCodeStreamingTransformer {
  private readonly parser: IncrementalSSEParser;
  private readonly state: StreamingState;
  private readonly options: Required<StreamingTransformerOptions>;
  private sentFinished: boolean;
  private lastUsage?: CloudCodeRawChunk["usageMetadata"];

  constructor(opts: StreamingTransformerOptions) {
    this.parser = new IncrementalSSEParser();
    this.state = createInitialStreamingState(opts.model, opts.completionId);
    this.options = {
      model: opts.model,
      format: opts.format ?? "openai",
      completionId: this.state.completionId,
      thinkingCache: opts.thinkingCache ?? globalThinkingSignatureCache,
      injectSyntheticFinish: opts.injectSyntheticFinish ?? true,
      includeDoneMarker: opts.includeDoneMarker ?? true,
      onChunk: opts.onChunk ?? (() => {}),
    } as Required<StreamingTransformerOptions>;
    this.sentFinished = false;
  }

  get streamingState(): StreamingState {
    return this.state;
  }

  /**
   * Transforma chunk bruto em SSE lines já no formato de saída
   */
  transformChunk(rawChunk: string | Uint8Array): string[] {
    const parsed = this.parser.push(rawChunk);
    if (parsed.length === 0) return [];

    // Guarda usage se vier
    for (const r of parsed) {
      if ((r as any).usageMetadata) this.lastUsage = (r as any).usageMetadata;
    }

    const normalized = normalizePayloads(parsed, { model: this.options.model });

    let sseLines: string[] = [];

    if (this.options.format === "openai") {
      const openAIChunks = transformToOpenAIChunks(normalized, this.state);
      sseLines = serializeOpenAIChunksToSSE(openAIChunks);
    } else if (this.options.format === "anthropic") {
      sseLines = transformToAnthropicEvents(normalized, this.state);
    } else {
      // raw - devolve JSON lines data:
      for (const n of normalized) {
        sseLines.push(`data: ${JSON.stringify(n)}\n\n`);
      }
    }

    // Callback
    for (const line of sseLines) {
      try {
        this.options.onChunk(line, this.state);
      } catch {}
    }

    return sseLines;
  }

  /**
   * Flush final + injeção sintética de finish
   */
  flush(): string[] {
    const remainingParsed = this.parser.flush();
    const extraLines: string[] = [];

    if (remainingParsed.length > 0) {
      for (const r of remainingParsed) {
        if ((r as any).usageMetadata) this.lastUsage = (r as any).usageMetadata;
      }
      const normalized = normalizePayloads(remainingParsed, { model: this.options.model });
      if (this.options.format === "openai") {
        const chunks = transformToOpenAIChunks(normalized, this.state);
        extraLines.push(...serializeOpenAIChunksToSSE(chunks));
      } else if (this.options.format === "anthropic") {
        extraLines.push(...transformToAnthropicEvents(normalized, this.state));
      } else {
        for (const n of normalized) extraLines.push(`data: ${JSON.stringify(n)}\n\n`);
      }
    }

    if (!this.sentFinished && this.options.injectSyntheticFinish) {
      const finishLines = this.createFinish();
      extraLines.push(...finishLines);
      this.sentFinished = true;
    }

    if (this.options.format === "openai" && this.options.includeDoneMarker) {
      extraLines.push("data: [DONE]\n\n");
    }

    for (const line of extraLines) {
      try {
        this.options.onChunk(line, this.state);
      } catch {}
    }

    return extraLines;
  }

  private createFinish(): string[] {
    if (this.options.format === "openai") {
      const chunks = createSyntheticFinishChunks(this.state, "stop", this.lastUsage);
      return serializeOpenAIChunksToSSE(chunks);
    } else if (this.options.format === "anthropic") {
      return createAnthropicSyntheticFinish(this.state, "end_turn", this.lastUsage);
    } else {
      return [`data: ${JSON.stringify({ finishReason: this.state.lastFinishReason ?? "stop", usage: this.lastUsage })}\n\n`];
    }
  }

  reset(model?: string): void {
    this.parser.reset();
    this.sentFinished = false;
    this.lastUsage = undefined;
    this.state.accumulatedText = "";
    this.state.accumulatedThinking = "";
    this.state.sentRole = false;
    this.state.insideThinking = false;
    this.state.lastFinishReason = undefined;
    this.state.anthropicBlockIndex = 0;
    this.state.anthropicBlockKinds.clear();
    this.state.toolCallIdCounter = 0;
    this.state.pendingSignatures = [];
    if (model) {
      this.state.model = model;
      (this.options as any).model = model;
    }
    this.state.completionId = newCompletionId();
    this.state.created = Math.floor(Date.now() / 1000);
  }
}

// ============================================================================
// 10. AUTO-RECOVERY COM RETRY EXPONENCIAL + INJEÇÃO FINISH SINTÉTICO
// ============================================================================

export interface ResilientFetchOptions {
  /** tentativas máximas (inclui inicial) */
  maxRetries?: number;
  /** base delay ms */
  baseDelayMs?: number;
  /** max delay ms */
  maxDelayMs?: number;
  /** jitter? */
  jitter?: boolean;
  /** status retryable */
  retryOn?: number[];
  /** abort signal externo */
  signal?: AbortSignal;
  /** timeout por tentativa ms */
  timeoutMs?: number;
}

const DEFAULT_RETRY_ON = [429, 500, 502, 503, 504];

export function isRetryableStatus(status: number, retryOn: number[] = DEFAULT_RETRY_ON): boolean {
  return retryOn.includes(status);
}

export function computeExponentialDelay(attempt: number, base: number, max: number, jitter: boolean): number {
  let delay = base * Math.pow(2, attempt);
  if (delay > max) delay = max;
  if (jitter) {
    // jitter 0-30%
    const jitterFactor = 0.7 + Math.random() * 0.6; // 0.7-1.3
    delay = Math.floor(delay * jitterFactor);
  }
  return delay;
}

/**
 * Helper sleep (node builtin)
 */
function sleepMs(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Cria fetch resiliente para streamGenerateContent com retry exponencial.
 * Mantém headers bypass Gemini CLI.
 *
 * @param url - endpoint streamGenerateContent
 * @param init - RequestInit
 * @param opts - retry opts
 * @returns Response com body stream
 */
export async function resilientFetch(
  url: string,
  init: RequestInit,
  opts: ResilientFetchOptions = {}
): Promise<Response> {
  const maxRetries = opts.maxRetries ?? 3;
  const baseDelay = opts.baseDelayMs ?? 500;
  const maxDelay = opts.maxDelayMs ?? 5000;
  const jitter = opts.jitter ?? true;
  const retryOn = opts.retryOn ?? DEFAULT_RETRY_ON;

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    // timeout por tentativa via AbortController
    const timeoutMs = opts.timeoutMs ?? 120_000;
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);

    // mescla signal externo
    const onAbortExternal = () => ac.abort();
    if (opts.signal) {
      if (opts.signal.aborted) {
        clearTimeout(timer);
        throw new Error("resilientFetch aborted by external signal");
      }
      opts.signal.addEventListener("abort", onAbortExternal, { once: true });
    }

    try {
      const mergedInit: RequestInit = {
        ...init,
        signal: ac.signal,
      };

      const res = await fetch(url, mergedInit);
      clearTimeout(timer);
      if (opts.signal) opts.signal.removeEventListener("abort", onAbortExternal);

      if (res.ok) return res;

      if (isRetryableStatus(res.status, retryOn) && attempt < maxRetries) {
        lastError = new Error(`retryable status ${res.status}`);
        // consome body para liberar socket
        try {
          await res.text();
        } catch {}
        const delay = computeExponentialDelay(attempt, baseDelay, maxDelay, jitter);
        await sleepMs(delay);
        continue;
      }

      // não retryable ou esgotou tentativas
      return res;
    } catch (e) {
      clearTimeout(timer);
      if (opts.signal) opts.signal.removeEventListener("abort", onAbortExternal);
      const err = e as Error & { name?: string };
      lastError = err;

      // AbortError não retrya exceto se for timeout interno
      const isAbortTimeout = err.name === "AbortError";
      if (isAbortTimeout && attempt < maxRetries) {
        const delay = computeExponentialDelay(attempt, baseDelay, maxDelay, jitter);
        await sleepMs(delay);
        continue;
      }

      if (attempt < maxRetries) {
        // network errors retry
        const delay = computeExponentialDelay(attempt, baseDelay, maxDelay, jitter);
        await sleepMs(delay);
        continue;
      }

      throw lastError;
    }
  }

  throw lastError ?? new Error("resilientFetch failed after retries");
}

/**
 * Wrapper de alto nível que consome streamGenerateContent com auto-recovery
 * e transforma para async iterable de SSE strings (OpenAI format por padrão).
 *
 * Tolerante a:
 * - quebras de conexão mid-stream (retry e continuação)
 * - falta de finish (injeção sintética)
 * - splits UTF8 / JSON
 *
 * @example
 * for await (const sseLine of createResilientTransformedStream(url, init, {model, format:"openai"})) {
 *   res.write(sseLine)
 * }
 */
export async function* createResilientTransformedStream(
  url: string,
  init: RequestInit,
  transformerOpts: StreamingTransformerOptions,
  fetchOpts: ResilientFetchOptions = {}
): AsyncGenerator<string, void, unknown> {
  const transformer = new CloudCodeStreamingTransformer(transformerOpts);

  const response = await resilientFetch(url, init, fetchOpts);

  if (!response.ok) {
    // tenta ler erro
    let errBody = "";
    try {
      errBody = await response.text();
    } catch {}
    throw new Error(`cloudcode-pa stream failed ${response.status}: ${errBody.slice(0, 500)}`);
  }

  if (!response.body) {
    // sem body (raro) - inject finish sintético
    yield* transformer.flush();
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: false });

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      // value Uint8Array
      const sseLines = transformer.transformChunk(value);
      for (const line of sseLines) yield line;
    }

    // flush final + synthetic finish
    const finalLines = transformer.flush();
    for (const line of finalLines) yield line;
  } catch (e) {
    // erro mid-stream - tenta injeção recovery + finish sintético
    try {
      const finalLines = transformer.flush();
      for (const line of finalLines) yield line;
    } catch {
      // ignora
    }
    // rethrow opcional? Para opencode, melhor não quebrar mas logar; aqui não rethrow para graceful degradation
    // throw e;
  } finally {
    try {
      await reader.cancel();
    } catch {}
  }
}

// ============================================================================
// 11. HELPERS DE HEADER BYPASS (reutilizáveis no plugin)
// ============================================================================

export interface BypassHeadersOptions {
  model?: string;
  accessToken?: string;
  projectId?: string;
  includeAuth?: boolean;
}

/**
 * Gera headers 100% compatíveis Gemini CLI para bypass cloudcode-pa
 * Usado pelo fetch resiliente acima quando plugin chama direto.
 */
export function buildGeminiCliBypassHeaders(opts: BypassHeadersOptions = {}): Record<string, string> {
  const h: Record<string, string> = {
    "User-Agent": GEMINI_CLI_USER_AGENT,
    "X-Goog-Api-Client": X_GOOG_API_CLIENT,
    "Client-Metadata": CLIENT_METADATA_RAW,
    "Content-Type": "application/json",
    Accept: "text/event-stream, application/json",
    "X-Goog-Request-Params": `project=${opts.projectId ?? PROJECT_FALLBACK}`,
  };

  if (opts.includeAuth && opts.accessToken) {
    h.Authorization = `Bearer ${opts.accessToken}`;
  }

  return h;
}

/**
 * Gera ID determinístico de sessão (FNV-1a) a partir de dir/host
 */
export function buildSessionIdFromDir(directory?: string): string {
  const base = directory ?? `${os.hostname()}|${process.cwd()}|${process.pid}`;
  let hash = 0x811c9dc5;
  const buf = Buffer.from(base, "utf8");
  for (let i = 0; i < buf.length; i++) {
    hash ^= buf[i]!;
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

// ============================================================================
// 12. UTILIDADES EXTRAS - USO NO OPENCODE PLUGIN
// ============================================================================

/**
 * Detecta se payload contém thinking (para roteamento)
 */
export function hasThinkingContent(payloads: NormalizedPayload[]): boolean {
  return payloads.some((p) => p.isThinkingChunk || p.parts.some((pt) => pt.thought));
}

/**
 * Extrai todas signatures de thinking de NormalizedPayload[]
 * Para reuso multi-turn no opencode
 */
export function extractThinkingSignatures(payloads: NormalizedPayload[]): string[] {
  const sigs: string[] = [];
  for (const p of payloads) {
    for (const part of p.parts) {
      if (part.thoughtSignature && !sigs.includes(part.thoughtSignature)) sigs.push(part.thoughtSignature);
    }
  }
  return sigs;
}

/**
 * Exporta estado acumulado para observability (opencode UI)
 */
export function getStreamingSummary(state: StreamingState): {
  completionId: string;
  model: string;
  textChars: number;
  thinkingChars: number;
  finishReason?: string;
  toolCalls: number;
  pendingSignatures: number;
} {
  return {
    completionId: state.completionId,
    model: state.model,
    textChars: state.accumulatedText.length,
    thinkingChars: state.accumulatedThinking.length,
    finishReason: state.lastFinishReason,
    toolCalls: state.toolCallIdCounter,
    pendingSignatures: state.pendingSignatures.length,
  };
}

// ============================================================================
// 13. DEFAULT EXPORT BUNDLE
// ============================================================================

export const Streaming = {
  // classes
  IncrementalSSEParser,
  CloudCodeStreamingTransformer,
  ThinkingSignatureLRUCache,
  globalThinkingSignatureCache,

  // core functions required by spec
  parseSSEChunk,
  normalizePayloads,

  // transforms
  transformToOpenAIChunks,
  transformToAnthropicEvents,
  serializeOpenAIChunksToSSE,
  createSyntheticFinishChunks,
  createAnthropicSyntheticFinish,
  createInitialStreamingState,

  // resilient fetch & stream
  resilientFetch,
  createResilientTransformedStream,
  computeExponentialDelay,
  isRetryableStatus,

  // bypass headers & session
  buildGeminiCliBypassHeaders,
  buildSessionIdFromDir,

  // utils
  hasThinkingContent,
  extractThinkingSignatures,
  getStreamingSummary,

  // constants
  GEMINI_CLI_CLIENT_ID,
  GEMINI_CLI_CLIENT_SECRET,
  GEMINI_CLI_USER_AGENT,
  X_GOOG_API_CLIENT,
  CLIENT_METADATA_RAW,
  PROJECT_FALLBACK,
  MODELS_2026,
} as const;

export default Streaming;
