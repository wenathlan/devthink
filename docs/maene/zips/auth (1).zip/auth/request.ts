/**
 * @fileoverview request.ts - ONDA 4 - Plugin Core
 * @module auth/request
 * @description
 *  Transformação completa de request OpenCode -> Cloud Code Assist / Gemini CLI bypass.
 *  Produção-ready, zero deps externas (apenas node:* builtins + fetch global).
 *
 *  Contexto bypass Gemini CLI:
 *   - Client ID: 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com
 *   - Secret: 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 (público no binário CLI)
 *   - User-Agent: GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1
 *   - X-Goog-Api-Client: gl-node/22.19.0
 *   - Client-Metadata: ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 *   - Project fallback: rising-fact-p41fc
 *   - Models 2026: antigravity-*, gemini-2.5-*, gemini-3-*, claude via bypass
 *
 *  Responsabilidades:
 *   - transformRequest() - core transform OpenCode -> Cloud Code Assist
 *   - buildAntigravityRequest() - wrapper com project, session_id determinístico, user_prompt_id
 *   - buildGeminiCLIRequest() - wrapper específico para bypass Gemini CLI puro
 *   - isGeminiCLIOnlyModel()
 *   - cleanToolSchema(), validateToolNames(), session_id FNV-1a, thinkingBudget mapping
 *
 * @author ONDA 4 - Plugin Core
 * @license MIT
 * @since 2026
 */

import * as os from "node:os";
import * as crypto from "node:crypto";

// ============================================================================
// 00. CONSTANTES CANÔNICAS - BYPASS GEMINI CLI
// ============================================================================

export const GEMINI_CLI_OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;
export const GEMINI_CLI_OAUTH_CLIENT_SECRET =
  "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" as const;

export const GEMINI_CLI_USER_AGENT =
  "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1" as const;

export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;

export const CLIENT_METADATA = {
  ideType: "IDE_UNSPECIFIED",
  platform: "PLATFORM_UNSPECIFIED",
  pluginType: "GEMINI",
} as const;

export const CLIENT_METADATA_STRING =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const FALLBACK_PROJECT_ID = "rising-fact-p41fc" as const;

export const CLOUDCODE_PA_BASE = "https://cloudcode-pa.googleapis.com" as const;
export const CLOUDCODE_DAILY_BASE = "https://daily-cloudcode-pa.googleapis.com" as const;

export const CODE_ASSIST_ENDPOINTS = {
  GENERATE: "/v1internal:generateContent",
  STREAM_GENERATE: "/v1internal:streamGenerateContent",
  LOAD: "/v1internal:loadCodeAssist",
} as const;

// ============================================================================
// 01. MODELS 2026 + THINKING MAPPING
// ============================================================================

export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type Model2026 = (typeof MODELS_2026)[number];

export type ThinkingLevel = "low" | "medium" | "high" | "minimal" | "none";

export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = {
  low: 8192,
  medium: 16384,
  high: 32768,
  minimal: 1024,
  none: 0,
} as const;

/** Mapa curto para Gemini API - thinkingBudget em tokens */
export const THINKING_LEVEL_TO_BUDGET_GEMINI = {
  low: 8192,
  medium: 16384,
  high: 32768,
} as const;

export const THINKING_LEVEL_TO_BUDGET_CLAUDE = {
  low: 8192,
  medium: 16384,
  high: 32768,
} as const;

// ============================================================================
// 02. FNV-1a DETERMINÍSTICO - SESSION_ID + USER_PROMPT_ID
// ============================================================================

const FNV_OFFSET_32 = 0x811c9dc5;
const FNV_PRIME_32 = 0x01000193;

export function fnv1a32(input: string): number {
  let hash = FNV_OFFSET_32;
  const buf = Buffer.from(input, "utf8");
  for (let i = 0; i < buf.length; i++) {
    hash ^= buf[i]!;
    hash = Math.imul(hash, FNV_PRIME_32) >>> 0;
  }
  return hash >>> 0;
}

const FNV_OFFSET_64 = 14695981039346656037n;
const FNV_PRIME_64 = 1099511628211n;

export function fnv1a64(input: string): bigint {
  let hash = FNV_OFFSET_64;
  const buf = Buffer.from(input, "utf8");
  for (let i = 0; i < buf.length; i++) {
    hash ^= BigInt(buf[i]!);
    hash = (hash * FNV_PRIME_64) & 0xffffffffffffffffn;
  }
  return hash;
}

function toHex8(n: number): string {
  return (n >>> 0).toString(16).padStart(8, "0");
}

function toHex16(n: bigint): string {
  return n.toString(16).padStart(16, "0");
}

// ============================================================================
// 03. SESSION_ID + USER_PROMPT_ID - DETERMINÍSTICO POR DIRECTORY
// ============================================================================

export interface BuildPromptIdOptions {
  prefix?: string;
  seed?: string;
  includeTimestamp?: boolean;
  length?: "short" | "long";
}

/**
 * Gera session_id determinístico via FNV-1a do directory.
 * Mesmo diretório => mesmo session_id, essencial para fingerprint estável.
 */
export function buildSessionIdFromDir(directory?: string | null): string {
  let dir = directory?.trim();
  if (!dir) {
    try {
      dir = process.cwd();
    } catch {
      dir = os.homedir() || FALLBACK_PROJECT_ID;
    }
  }
  // normaliza para evitar \ vs / divergência
  dir = dir.replace(/\\/g, "/").replace(/\/+$/, "");
  const h = fnv1a32(dir);
  // formato compatível com observados no Gemini CLI: sess_<hex8>-... ou apenas hex
  return `sess_${toHex8(h)}${toHex8(fnv1a32(dir.split("").reverse().join("")))}`.slice(0, 20);
}

/**
 * Gera user_prompt_id determinístico via FNV-1a.
 * Usado para deduplicação no backend Cloud Code.
 */
export function buildUserPromptId(
  input?: string | object | null | undefined,
  opts?: BuildPromptIdOptions | string,
): string {
  let options: BuildPromptIdOptions = {};
  if (typeof opts === "string") options = { seed: opts };
  else if (opts && typeof opts === "object") options = opts;

  const prefix = options.prefix ?? "agyp_";
  const length = options.length ?? "short";

  let baseStr: string;
  if (input == null) {
    try {
      baseStr = `${os.hostname()}|${process.cwd()}|${process.pid}`;
    } catch {
      baseStr = `fallback|${FALLBACK_PROJECT_ID}`;
    }
  } else if (typeof input === "string") baseStr = input;
  else {
    try {
      baseStr = JSON.stringify(input);
    } catch {
      baseStr = String(input);
    }
  }

  if (options.seed) baseStr = `${baseStr}|${options.seed}`;
  if (options.includeTimestamp) baseStr = `${baseStr}|${Date.now()}`;

  const h32 = fnv1a32(baseStr);
  if (length === "short") return `${prefix}${toHex8(h32)}`;

  const h64 = fnv1a64(baseStr);
  return `${prefix}${toHex8(h32)}-${toHex16(h64).slice(0, 12)}`;
}

/**
 * Alias para compatibilidade com fingerprint.ts
 */
export function buildSessionId(directory?: string): string {
  return buildSessionIdFromDir(directory);
}

// ============================================================================
// 04. TOOL NAME VALIDATION + CLEAN SCHEMA
// ============================================================================

const TOOL_NAME_REGEX = /^[a-zA-Z_][a-zA-Z0-9_]{0,63}$/;
const TOOL_NAME_SANITIZE_REGEX = /[^a-zA-Z0-9_]/g;

/**
 * Sanitiza nome de tool para padrão Gemini: [a-zA-Z_][a-zA-Z0-9_]{0,63}
 * - Remove caracteres inválidos, garante início com letra/underscore, trunca 64
 */
export function sanitizeToolName(raw: string): string {
  if (!raw || typeof raw !== "string") return "tool";
  let s = raw.trim().replace(TOOL_NAME_SANITIZE_REGEX, "_");
  if (!/^[a-zA-Z_]/.test(s)) s = "_" + s;
  if (s.length > 64) s = s.slice(0, 64);
  // evita nomes reservados do protocolo
  if (s === "_" || s.length < 1) return "tool";
  s = s.replace(/__+/g, "_");
  return s;
}

export function isValidToolName(name: string): boolean {
  return TOOL_NAME_REGEX.test(name);
}

export interface ValidateToolNamesResult {
  valid: string[];
  invalid: string[];
  sanitized: Record<string, string>; // original -> sanitized
  duplicates: string[];
}

/**
 * Valida lista de tool names, detecta duplicatas e inválidos
 */
export function validateToolNames(names: string[]): ValidateToolNamesResult {
  const valid: string[] = [];
  const invalid: string[] = [];
  const sanitized: Record<string, string> = {};
  const seen = new Set<string>();
  const duplicates: string[] = [];

  for (const raw of names) {
    if (!raw || typeof raw !== "string") {
      invalid.push(String(raw));
      continue;
    }
    if (seen.has(raw)) duplicates.push(raw);
    seen.add(raw);

    if (isValidToolName(raw)) valid.push(raw);
    else {
      invalid.push(raw);
      sanitized[raw] = sanitizeToolName(raw);
    }
  }
  return { valid, invalid, sanitized, duplicates };
}

// Lista de chaves permitidas em JSON Schema para Gemini Function Declarations
const ALLOWED_SCHEMA_KEYS = new Set([
  "type",
  "description",
  "properties",
  "required",
  "items",
  "enum",
  "format",
  "nullable",
  "anyOf",
  "propertyOrdering",
]);

/**
 * Limpa schema JSON removendo chaves não suportadas pelo Gemini (ex: $schema, $id, additionalProperties)
 * Recursivo, preserva estrutura properties/items.
 */
export function cleanToolSchema(schema: unknown): any {
  if (schema == null) return schema;
  if (typeof schema !== "object") return schema;
  if (Array.isArray(schema)) return schema.map(cleanToolSchema);

  const src = schema as Record<string, unknown>;
  const out: Record<string, unknown> = {};

  for (const [k, v] of Object.entries(src)) {
    if (!ALLOWED_SCHEMA_KEYS.has(k)) {
      // permite recursão em anyOf mas ignora outros como $schema, $ref, additionalProperties, etc
      if (k === "anyOf" || k === "oneOf") {
        // normaliza oneOf -> anyOf para compatibilidade
        const targetKey = "anyOf";
        out[targetKey] = Array.isArray(v) ? (v as unknown[]).map(cleanToolSchema) : cleanToolSchema(v);
      }
      continue;
    }

    if (k === "properties" && v && typeof v === "object" && !Array.isArray(v)) {
      const props = v as Record<string, unknown>;
      const cleanedProps: Record<string, unknown> = {};
      for (const [propName, propSchema] of Object.entries(props)) {
        cleanedProps[propName] = cleanToolSchema(propSchema);
      }
      out[k] = cleanedProps;
    } else if (k === "items" && v && typeof v === "object") {
      out[k] = cleanToolSchema(v);
    } else if (k === "anyOf" && Array.isArray(v)) {
      out[k] = (v as unknown[]).map(cleanToolSchema);
    } else if (k === "required" && Array.isArray(v)) {
      out[k] = (v as string[]).filter((s) => typeof s === "string");
    } else if (k === "enum" && Array.isArray(v)) {
      out[k] = v;
    } else {
      out[k] = v;
    }
  }

  // garante type default object se tem properties mas sem type
  if (out.properties && !out.type) out.type = "object";

  return out;
}

export function cleanToolSchemas(schemas: unknown[]): any[] {
  return schemas.map(cleanToolSchema);
}

// ============================================================================
// 05. isGeminiCLIOnlyModel() - DETECÇÃO DE MODELOS EXCLUSIVOS BYPASS
// ============================================================================

const MODELS_2026_SET = new Set<string>(MODELS_2026 as readonly string[]);

/**
 * Determina se modelo só está disponível via bypass Gemini CLI / Antigravity.
 * Regra: qualquer modelo com prefixo antigravity-, claude, gemini-3*, customtools, preview de 3.x
 * é exclusivo do bypass e não existe em API pública generativelanguage.
 *
 * @example
 * isGeminiCLIOnlyModel("gemini-3-pro-preview") => true
 * isGeminiCLIOnlyModel("gemini-2.5-pro") => false
 * isGeminiCLIOnlyModel("antigravity-claude-opus-4-6-thinking") => true
 */
export function isGeminiCLIOnlyModel(modelId: string): boolean {
  if (!modelId || typeof modelId !== "string") return false;
  const lower = modelId.trim().toLowerCase();

  // prefixo antigravity sempre CLI-only
  if (lower.startsWith("antigravity-")) return true;
  // Claude via antigravity
  if (lower.includes("claude")) return true;
  // customtools é exclusivo do bypass 3.1
  if (lower.includes("customtools")) return true;
  // gemini-3.x family toda preview é CLI-only em 2026
  if (/^gemini-3(\.|\-)/.test(lower)) return true;
  // gemini-3 sem ponto também - cobre gemini-3-pro-preview
  if (lower.startsWith("gemini-3-") || lower.startsWith("gemini-3.1-")) return true;
  // fallback: qualquer preview que não seja 2.5 é considerado CLI-only
  if (lower.includes("preview") && !lower.includes("2.5")) return true;

  // Se está no catalogo 2026 mas não é 2.5, considera CLI-only
  if (MODELS_2026_SET.has(modelId) || MODELS_2026_SET.has(lower)) {
    if (lower.includes("2.5")) return false;
    return true;
  }

  return false;
}

/**
 * Alias legado observado em ONDA 3
 */
export function isLikelyAntigravityOnlyModel(modelId: string): boolean {
  return isGeminiCLIOnlyModel(modelId);
}

// ============================================================================
// 06. TIPOS OPENCODE -> GEMINI
// ============================================================================

export interface OpenCodeTool {
  name: string;
  description?: string;
  input_schema?: unknown;
  parameters?: unknown; // alias para input_schema
  inputSchema?: unknown;
}

export interface OpenCodeContentBlock {
  type?: string;
  text?: string;
  thinking?: string;
  level?: ThinkingLevel | string;
  thought?: string;
  id?: string;
  name?: string;
  input?: unknown;
  args?: unknown;
  tool_use_id?: string;
  tool_call_id?: string;
  content?: unknown;
  source?: { type?: string; media_type?: string; data?: string };
  // Anthropic style tool_result content may be array
  [key: string]: unknown;
}

export interface OpenCodeMessage {
  role: "user" | "assistant" | "system" | "tool" | string;
  content: string | OpenCodeContentBlock[] | unknown;
  name?: string;
  tool_call_id?: string;
  tool_use_id?: string;
  // thinking level pode vir no campo thinking da mensagem
  thinking?: ThinkingLevel | string | { level?: string; budget?: number; type?: string };
  thinkingLevel?: ThinkingLevel | string;
  [key: string]: unknown;
}

export interface OpenCodeRequest {
  model?: string;
  messages?: OpenCodeMessage[];
  tools?: OpenCodeTool[];
  tool_choice?: unknown;
  thinking?: ThinkingLevel | string | { level?: ThinkingLevel | string; budget?: number; type?: string; budget_tokens?: number };
  thinkingLevel?: ThinkingLevel | string;
  thinking_level?: ThinkingLevel | string;
  directory?: string;
  cwd?: string;
  project?: string;
  projectId?: string;
  temperature?: number;
  top_p?: number;
  topP?: number;
  top_k?: number;
  topK?: number;
  max_tokens?: number;
  maxTokens?: number;
  google_search?: boolean;
  enable_google_search?: boolean;
  enableGoogleSearch?: boolean;
  session_id?: string;
  user_prompt_id?: string;
  [key: string]: unknown;
}

export interface GeminiPart {
  text?: string;
  thought?: boolean;
  thoughtSignature?: string;
  functionCall?: { name: string; args: Record<string, unknown> };
  functionResponse?: { name: string; response: Record<string, unknown> };
  inlineData?: { mimeType: string; data: string };
}

export interface GeminiContent {
  role: "user" | "model";
  parts: GeminiPart[];
}

export interface GeminiSystemInstruction {
  role?: "system";
  parts: GeminiPart[];
}

export interface GeminiFunctionDeclaration {
  name: string;
  description?: string;
  parameters?: any;
}

export interface GeminiGenerationConfig {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxOutputTokens?: number;
  candidateCount?: number;
  stopSequences?: string[];
  thinkingConfig?: {
    thinkingLevel?: ThinkingLevel;
    thinkingBudget?: number;
    includeThoughts?: boolean;
  };
  // compat
  thinkingLevel?: ThinkingLevel;
  thinkingBudget?: number;
}

export interface CloudCodeAssistInnerRequest {
  contents: GeminiContent[];
  systemInstruction?: GeminiSystemInstruction;
  tools?: any[];
  toolConfig?: { functionCallingConfig?: { mode: string; allowedFunctionNames?: string[] } };
  generationConfig?: GeminiGenerationConfig;
}

export interface TransformOptions {
  projectId?: string;
  directory?: string;
  enableGoogleSearch?: boolean;
  thinkingLevel?: ThinkingLevel | string;
  model?: string;
  sessionId?: string;
  userPromptId?: string;
  temperature?: number;
  topP?: number;
  topK?: number;
  maxTokens?: number;
}

export interface TransformedRequest {
  model: string;
  project: string;
  request: CloudCodeAssistInnerRequest;
  user_prompt_id: string;
  session_id: string;
  thinkingLevel: ThinkingLevel;
  thinkingBudget: number;
  isGeminiCLIOnly: boolean;
  // debug
  _meta?: {
    sourceDirectory: string;
    promptSeed: string;
  };
}

export interface AntigravityFetchPayload {
  url: string;
  method: "POST";
  headers: Record<string, string>;
  body: {
    model: string;
    project: string;
    request: CloudCodeAssistInnerRequest;
    user_prompt_id: string;
    session_id: string;
    requestId?: string;
  };
  rawBody: string;
  model: string;
  project: string;
  user_prompt_id: string;
  session_id: string;
  isGeminiCLIOnly: boolean;
}

// ============================================================================
// 07. HELPERS DE NORMALIZAÇÃO
// ============================================================================

export function normalizeThinkingLevel(input: unknown): ThinkingLevel {
  if (!input) return "medium";
  let level: string;

  if (typeof input === "string") level = input;
  else if (typeof input === "object" && input !== null) {
    const obj = input as any;
    if (typeof obj.level === "string") level = obj.level;
    else if (typeof obj.thinkingLevel === "string") level = obj.thinkingLevel;
    else if (typeof obj.thinking_level === "string") level = obj.thinking_level;
    else level = "medium";
  } else level = "medium";

  level = level.toLowerCase().trim();
  if (level === "low" || level === "minimal" || level === "none") return level as ThinkingLevel;
  if (level === "high" || level === "medium") return level as ThinkingLevel;
  // mapeia variações
  if (["1", "small", "light"].includes(level)) return "low";
  if (["2", "default", "balanced"].includes(level)) return "medium";
  if (["3", "large", "deep", "max"].includes(level)) return "high";
  return "medium";
}

export function mapThinkingLevelToBudget(level: ThinkingLevel | string): number {
  const norm = normalizeThinkingLevel(level);
  return (THINKING_BUDGET_MAP as any)[norm] ?? THINKING_BUDGET_MAP.medium;
}

function extractFirstUserText(messages?: OpenCodeMessage[]): string {
  if (!messages || messages.length === 0) return "prompt";
  for (const m of messages) {
    if (m.role === "user") {
      if (typeof m.content === "string") return m.content.slice(0, 4000);
      if (Array.isArray(m.content)) {
        const texts = (m.content as OpenCodeContentBlock[])
          .filter((b) => (b.type === "text" || !b.type) && typeof b.text === "string")
          .map((b) => b.text as string)
          .join("\n");
        if (texts) return texts.slice(0, 4000);
      }
    }
  }
  // fallback: pega primeiro texto de qualquer mensagem
  for (const m of messages) {
    if (typeof m.content === "string" && m.content.trim()) return m.content.slice(0, 4000);
  }
  return "prompt";
}

function extractSystemParts(messages: OpenCodeMessage[]): GeminiPart[] {
  const parts: GeminiPart[] = [];
  if (!messages) return parts;

  for (const m of messages) {
    if (m.role !== "system") continue;
    if (typeof m.content === "string") {
      if (m.content.trim()) parts.push({ text: m.content });
    } else if (Array.isArray(m.content)) {
      for (const block of m.content as OpenCodeContentBlock[]) {
        if (typeof block === "string") {
          parts.push({ text: block as unknown as string });
        } else if (block.type === "text" && block.text) {
          parts.push({ text: block.text });
        } else if (block.thinking && typeof block.thinking === "string") {
          // system instruction também pode ter thinking? trata como texto
          parts.push({ text: block.thinking });
        } else if ((block as any).text && typeof (block as any).text === "string") {
          parts.push({ text: (block as any).text });
        }
      }
    } else if (m.content && typeof m.content === "object") {
      const maybe = m.content as any;
      if (typeof maybe.text === "string") parts.push({ text: maybe.text });
    }
  }
  return parts;
}

function coerceArgs(input: unknown): Record<string, unknown> {
  if (!input) return {};
  if (typeof input === "object" && !Array.isArray(input)) return input as Record<string, unknown>;
  if (typeof input === "string") {
    try {
      const parsed = JSON.parse(input);
      if (typeof parsed === "object" && !Array.isArray(parsed)) return parsed as Record<string, unknown>;
      return { value: parsed };
    } catch {
      return { text: input };
    }
  }
  return { value: input as any };
}

function coerceFunctionResponseContent(content: unknown): Record<string, unknown> {
  if (content == null) return { result: "" };
  if (typeof content === "string") return { content };
  if (Array.isArray(content)) {
    // tool_result array pode ser blocos
    const texts = content
      .map((c: any) => {
        if (typeof c === "string") return c;
        if (c?.text) return c.text;
        if (c?.content) return typeof c.content === "string" ? c.content : JSON.stringify(c.content);
        return JSON.stringify(c);
      })
      .join("\n");
    return { content: texts };
  }
  if (typeof content === "object") {
    const obj = content as Record<string, unknown>;
    // se já é objeto pronto
    return obj;
  }
  return { result: String(content) };
}

function buildPartsFromContent(
  content: OpenCodeMessage["content"],
  roleHint: string,
): GeminiPart[] {
  const parts: GeminiPart[] = [];
  if (content == null) return parts;

  if (typeof content === "string") {
    if (content.trim().length > 0) parts.push({ text: content });
    return parts;
  }

  if (!Array.isArray(content)) {
    // objeto único possivelmente { text } ou { type }
    const c = content as any;
    if (typeof c.text === "string") parts.push({ text: c.text });
    else if (typeof c.thinking === "string") parts.push({ text: c.thinking, thought: true });
    else parts.push({ text: JSON.stringify(c) });
    return parts;
  }

  // array de blocos (Anthropic / OpenCode style)
  for (const rawBlock of content as OpenCodeContentBlock[]) {
    if (!rawBlock) continue;
    if (typeof rawBlock === "string") {
      const s = (rawBlock as unknown as string).trim();
      if (s) parts.push({ text: s });
      continue;
    }

    const type = (rawBlock.type || (rawBlock as any).type || "").toLowerCase();

    // text block
    if (type === "text" || (!type && typeof rawBlock.text === "string")) {
      if (rawBlock.text && rawBlock.text.trim()) parts.push({ text: rawBlock.text });
      continue;
    }

    // thinking block - baixa/media/alta
    if (type === "thinking" || type === "reasoning" || (rawBlock as any).thinking) {
      const thinkText = (rawBlock.thinking as string) || (rawBlock.text as string) || (rawBlock as any).thought || "";
      if (thinkText && thinkText.trim()) {
        parts.push({ text: thinkText, thought: true });
      }
      continue;
    }

    // tool_use / function call (assistant side)
    if (
      type === "tool_use" ||
      type === "tool-call" ||
      type === "function_call" ||
      type === "functioncall" ||
      (rawBlock as any).name && ((rawBlock as any).input !== undefined || (rawBlock as any).args !== undefined)
    ) {
      // evita confundir tool_result que também tem name
      if (type === "tool_result" || type === "tool-result" || type === "function_response" || (rawBlock as any).tool_use_id) {
        // trata abaixo
      } else {
        const nameRaw = (rawBlock.name as string) || (rawBlock as any).toolName || (rawBlock as any).id || "tool";
        const name = sanitizeToolName(nameRaw);
        const input = (rawBlock.input ?? (rawBlock as any).args ?? {}) as unknown;
        parts.push({
          functionCall: {
            name,
            args: coerceArgs(input),
          },
        });
        continue;
      }
    }

    // tool_result / function response (user/tool side)
    if (
      type === "tool_result" ||
      type === "tool-result" ||
      type === "function_response" ||
      type === "functionresponse" ||
      type === "tool_return" ||
      (rawBlock as any).tool_use_id ||
      (rawBlock as any).tool_call_id
    ) {
      const nameRaw =
        (rawBlock.name as string) ||
        (rawBlock as any).toolName ||
        (rawBlock as any).tool_use_id ||
        (rawBlock as any).tool_call_id ||
        "tool";
      const name = sanitizeToolName(nameRaw);
      const contentField = (rawBlock.content ?? (rawBlock as any).output ?? (rawBlock as any).result ?? "") as unknown;
      parts.push({
        functionResponse: {
          name,
          response: coerceFunctionResponseContent(contentField),
        },
      });
      continue;
    }

    // image block inline
    if (type === "image" || type === "image_url") {
      const src = rawBlock.source as any;
      if (src?.data && src?.media_type) {
        parts.push({
          inlineData: {
            mimeType: src.media_type,
            data: src.data,
          },
        });
      } else if ((rawBlock as any).image_url?.url) {
        // url - não temos download aqui, mas preserva como texto placeholder
        parts.push({ text: `[image: ${(rawBlock as any).image_url.url}]` });
      }
      continue;
    }

    // fallback: tenta extrair texto
    if (typeof (rawBlock as any).text === "string" && (rawBlock as any).text.trim()) {
      parts.push({ text: (rawBlock as any).text });
    } else {
      // stringify seguro
      try {
        const txt = JSON.stringify(rawBlock);
        if (txt.length < 20000) parts.push({ text: txt });
      } catch {
        // ignore
      }
    }
  }

  return parts;
}

function mergeContents(contents: GeminiContent[]): GeminiContent[] {
  if (contents.length <= 1) return contents;
  const merged: GeminiContent[] = [];
  for (const cur of contents) {
    const last = merged[merged.length - 1];
    if (last && last.role === cur.role) {
      last.parts.push(...cur.parts);
    } else {
      merged.push({ role: cur.role, parts: [...cur.parts] });
    }
  }
  // remove empty parts
  return merged
    .map((c) => ({
      role: c.role,
      parts: c.parts.filter((p) => {
        if (p.text != null && p.text.trim() === "" && !p.thought) return false;
        return true;
      }),
    }))
    .filter((c) => c.parts.length > 0);
}

// ============================================================================
// 08. buildGenerationConfig
// ============================================================================

export function buildGenerationConfig(
  req: OpenCodeRequest,
  opts?: TransformOptions,
  thinkingLevelOverride?: ThinkingLevel,
): GeminiGenerationConfig {
  const thinkingLevel =
    thinkingLevelOverride ||
    normalizeThinkingLevel(
      opts?.thinkingLevel ??
        req.thinkingLevel ??
        req.thinking_level ??
        (req as any).thinking?.level ??
        req.thinking ??
        "medium",
    );

  const thinkingBudget = mapThinkingLevelToBudget(thinkingLevel);

  const temperature = opts?.temperature ?? req.temperature;
  const topP = opts?.topP ?? req.topP ?? req.top_p;
  const topK = opts?.topK ?? req.topK ?? req.top_k;
  const maxTokens = opts?.maxTokens ?? req.max_tokens ?? req.maxTokens;

  const cfg: GeminiGenerationConfig = {};

  if (typeof temperature === "number") cfg.temperature = temperature;
  if (typeof topP === "number") cfg.topP = topP;
  if (typeof topK === "number") cfg.topK = topK;
  if (typeof maxTokens === "number") cfg.maxOutputTokens = maxTokens;

  cfg.thinkingConfig = {
    thinkingLevel,
    thinkingBudget,
    includeThoughts: true,
  };
  // compat: algumas versões do backend esperam campos no topo também
  cfg.thinkingLevel = thinkingLevel;
  cfg.thinkingBudget = thinkingBudget;

  return cfg;
}

export function buildBypassHeaders(token?: string, extra?: Record<string, string>): Record<string, string> {
  const h: Record<string, string> = {
    "User-Agent": GEMINI_CLI_USER_AGENT,
    "X-Goog-Api-Client": X_GOOG_API_CLIENT,
    "Client-Metadata": CLIENT_METADATA_STRING,
    "X-Goog-Client-Metadata": CLIENT_METADATA_STRING,
    "Content-Type": "application/json",
    Accept: "application/json",
    "Accept-Encoding": "gzip",
  };
  if (token && token.trim()) {
    const t = token.trim();
    h["Authorization"] = t.startsWith("Bearer ") ? t : `Bearer ${t}`;
  }
  if (extra) {
    for (const [k, v] of Object.entries(extra)) if (v) h[k] = v;
  }
  return h;
}

// ============================================================================
// 09. transformTools - clean + validate + google_search injection
// ============================================================================

export interface TransformToolsResult {
  tools: any[] | undefined;
  toolConfig?: { functionCallingConfig: { mode: string; allowedFunctionNames?: string[] } };
  sanitizedMap: Record<string, string>;
}

export function transformTools(
  openTools: OpenCodeTool[] | undefined,
  enableGoogleSearch?: boolean,
): TransformToolsResult {
  const sanitizedMap: Record<string, string> = {};
  const functionDeclarations: GeminiFunctionDeclaration[] = [];

  if (openTools && Array.isArray(openTools) && openTools.length > 0) {
    const names: string[] = openTools.map((t) => t.name).filter(Boolean) as string[];
    const validation = validateToolNames(names);

    for (const inv of validation.invalid) {
      sanitizedMap[inv] = validation.sanitized[inv] || sanitizeToolName(inv);
    }

    for (const tool of openTools) {
      if (!tool || !tool.name) continue;
      const originalName = tool.name;
      const name = isValidToolName(originalName)
        ? originalName
        : sanitizedMap[originalName] || sanitizeToolName(originalName);

      // pega schema de qualquer alias
      const rawSchema =
        (tool as any).input_schema ??
        (tool as any).inputSchema ??
        (tool as any).parameters ??
        (tool as any).schema ??
        { type: "object", properties: {} };

      const cleaned = cleanToolSchema(rawSchema);

      functionDeclarations.push({
        name,
        description: tool.description || `Function ${name}`,
        parameters: cleaned,
      });
    }
  }

  const toolsPayload: any[] = [];

  if (functionDeclarations.length > 0) {
    // deduplica por nome - última vence
    const dedup = new Map<string, GeminiFunctionDeclaration>();
    for (const fd of functionDeclarations) dedup.set(fd.name, fd);
    toolsPayload.push({ functionDeclarations: Array.from(dedup.values()) });
  }

  if (enableGoogleSearch) {
    // Gemini 3+ usa { google_search: {} }, legado { google_search_retrieval: {} }
    toolsPayload.push({ google_search: {} });
  }

  const tools = toolsPayload.length > 0 ? toolsPayload : undefined;

  let toolConfig: TransformToolsResult["toolConfig"];
  if (functionDeclarations.length > 0) {
    toolConfig = {
      functionCallingConfig: {
        mode: "AUTO",
        // allowedFunctionNames opcional - quando presente restringe; usamos todas declaradas
        allowedFunctionNames: Array.from(new Set(functionDeclarations.map((f) => f.name))),
      },
    };
  }

  return { tools, toolConfig, sanitizedMap };
}

// ============================================================================
// 10. CORE: transformRequest() - OpenCode -> Cloud Code Assist
// ============================================================================

/**
 * Converte request OpenCode (Anthropic/OpenAI-like) para formato Cloud Code Assist
 * v1internal:streamGenerateContent compatível com bypass Gemini CLI.
 *
 * Tratamento:
 * - system instructions extraídas para systemInstruction
 * - thinking blocks (low/medium/high -> 8192/16384/32768) mapeados para thought parts + thinkingConfig
 * - tool_use -> functionCall, tool_result -> functionResponse
 * - google_search tool injection se enabled
 * - cleanToolSchema + validateToolNames
 * - session_id FNV-1a determinístico do directory
 * - generationConfig com thinkingLevel + thinkingBudget
 * - user_prompt_id determinístico + project fallback
 *
 * @param openCodeReq - Request original OpenCode
 * @param opts - Overrides de project, directory, google_search, thinkingLevel etc
 * @returns TransformedRequest pronto para buildAntigravityRequest / buildGeminiCLIRequest
 */
export function transformRequest(
  openCodeReq: OpenCodeRequest,
  opts?: TransformOptions,
): TransformedRequest {
  if (!openCodeReq || typeof openCodeReq !== "object") {
    throw new TypeError("transformRequest: openCodeReq must be an object");
  }

  const model = (opts?.model || openCodeReq.model || "gemini-3-pro-preview") as string;

  const project =
    (opts?.projectId ||
      openCodeReq.project ||
      openCodeReq.projectId ||
      FALLBACK_PROJECT_ID) as string;

  const directory =
    opts?.directory || openCodeReq.directory || (openCodeReq as any).cwd || process.cwd() || os.homedir();

  const session_id = opts?.sessionId || openCodeReq.session_id || buildSessionIdFromDir(directory);

  const rawPromptForId = extractFirstUserText(openCodeReq.messages);
  const user_prompt_id =
    opts?.userPromptId || openCodeReq.user_prompt_id || buildUserPromptId(`${model}|${rawPromptForId}|${project}`, { seed: session_id });

  // thinking level resolution com prioridade opts > req top-level > req.thinking object > blocos
  let detectedLevel: ThinkingLevel = "medium";
  // tenta detectar de blocos thinking primeiro se opts não override
  if (!opts?.thinkingLevel) {
    if (openCodeReq.messages) {
      for (const m of openCodeReq.messages) {
        if (Array.isArray(m.content)) {
          for (const b of m.content as OpenCodeContentBlock[]) {
            if (b && (b.type === "thinking" || (b as any).thinking) && b.level) {
              detectedLevel = normalizeThinkingLevel(b.level);
              break;
            }
          }
        }
      }
    }
  }

  const finalThinkingLevel = normalizeThinkingLevel(
    opts?.thinkingLevel ??
      openCodeReq.thinkingLevel ??
      openCodeReq.thinking_level ??
      (openCodeReq.thinking as any)?.level ??
      openCodeReq.thinking ??
      detectedLevel,
  );

  const thinkingBudget = mapThinkingLevelToBudget(finalThinkingLevel);

  // systemInstruction
  const systemParts = extractSystemParts(openCodeReq.messages || []);
  const systemInstruction: GeminiSystemInstruction | undefined =
    systemParts.length > 0 ? { parts: systemParts } : undefined;

  // contents
  const rawContents: GeminiContent[] = [];
  const messages = openCodeReq.messages || [];

  for (const msg of messages) {
    if (!msg || !msg.role) continue;
    if (msg.role === "system") continue; // já extraído

    let geminiRole: "user" | "model" = "user";
    if (msg.role === "assistant") geminiRole = "model";
    else if (msg.role === "user" || msg.role === "tool") geminiRole = "user";
    else if (msg.role === "model") geminiRole = "model";
    else geminiRole = "user";

    // tool messages com role "tool" normalmente têm functionResponse
    // se mensagem tem tool_call_id/name -> força user role
    if (msg.role === "tool") geminiRole = "user";

    const parts = buildPartsFromContent(msg.content as any, msg.role);
    if (parts.length === 0) continue;

    rawContents.push({ role: geminiRole, parts });
  }

  const contents = mergeContents(rawContents);

  // Se após merge não tiver contents, cria um fallback com prompt
  if (contents.length === 0) {
    const fallbackText = rawPromptForId || "Hello";
    contents.push({ role: "user", parts: [{ text: fallbackText }] });
  }

  // tools + google_search
  const enableGoogleSearch =
    opts?.enableGoogleSearch ??
    (openCodeReq as any).enableGoogleSearch ??
    (openCodeReq as any).enable_google_search ??
    openCodeReq.google_search ??
    false;

  const { tools, toolConfig } = transformTools(openCodeReq.tools, Boolean(enableGoogleSearch));

  // generationConfig
  const generationConfig = buildGenerationConfig(openCodeReq, opts, finalThinkingLevel);

  const inner: CloudCodeAssistInnerRequest = {
    contents,
    ...(systemInstruction ? { systemInstruction } : {}),
    ...(tools ? { tools } : {}),
    ...(toolConfig ? { toolConfig } : {}),
    generationConfig,
  };

  return {
    model,
    project,
    request: inner,
    user_prompt_id,
    session_id,
    thinkingLevel: finalThinkingLevel,
    thinkingBudget,
    isGeminiCLIOnly: isGeminiCLIOnlyModel(model),
    _meta: {
      sourceDirectory: directory,
      promptSeed: rawPromptForId.slice(0, 80),
    },
  };
}

// ============================================================================
// 11. buildAntigravityRequest() - PAYLOAD COMPLETO ANTIGRAVITY
// ============================================================================

/**
 * Constrói request completo para endpoint Antigravity / Cloud Code Assist.
 * Inclui URL, headers de bypass, body pronto para fetch.
 *
 * @param openCodeReq - Request OpenCode original
 * @param opts - Overrides + token opcional para Authorization
 * @param extra - Config extra: endpoint base, streaming boolean, token
 */
export function buildAntigravityRequest(
  openCodeReq: OpenCodeRequest,
  opts?: TransformOptions & {
    token?: string;
    baseUrl?: string;
    streaming?: boolean;
    requestId?: string;
    extraHeaders?: Record<string, string>;
  },
): AntigravityFetchPayload {
  const transformed = transformRequest(openCodeReq, opts);

  const baseUrl = opts?.baseUrl || CLOUDCODE_PA_BASE;
  const streaming = opts?.streaming ?? true;
  const endpointPath = streaming ? CODE_ASSIST_ENDPOINTS.STREAM_GENERATE : CODE_ASSIST_ENDPOINTS.GENERATE;

  const url = `${baseUrl}${endpointPath}`;

  const headers = buildBypassHeaders(opts?.token, opts?.extraHeaders);

  const requestId =
    opts?.requestId ||
    // deterministico + random: fnv dir + crypto random
    `req_${toHex8(fnv1a32(transformed.user_prompt_id + Date.now().toString()))}${crypto
      .randomBytes(2)
      .toString("hex")}`;

  const body = {
    model: transformed.model,
    project: transformed.project,
    request: transformed.request,
    user_prompt_id: transformed.user_prompt_id,
    session_id: transformed.session_id,
    requestId,
  };

  return {
    url,
    method: "POST",
    headers,
    body,
    rawBody: JSON.stringify(body),
    model: body.model,
    project: body.project,
    user_prompt_id: body.user_prompt_id,
    session_id: body.session_id,
    isGeminiCLIOnly: transformed.isGeminiCLIOnly,
  };
}

// ============================================================================
// 12. buildGeminiCLIRequest() - BYPASS GEMINI CLI PURO (daily + prod fallback)
// ============================================================================

/**
 * Constrói request no formato exato que Gemini CLI oficial envia.
 * Diferença principal para buildAntigravityRequest:
 * - Usa daily base por padrão (canary) mas com fallback para prod
 * - Inclui metadados extras de IDE_UNSPECIFIED no request para garantir bypass
 * - Gera user_prompt_id no formato esperado pelo CLI (curto)
 * - Session_id determinístico via FNV-1a do directory é obrigatório
 *
 * @param openCodeReq - Request OpenCode original
 * @param opts - Overrides + token
 */
export function buildGeminiCLIRequest(
  openCodeReq: OpenCodeRequest,
  opts?: TransformOptions & {
    token?: string;
    baseUrl?: string;
    streaming?: boolean;
    requestId?: string;
    extraHeaders?: Record<string, string>;
  },
): AntigravityFetchPayload {
  // Para GeminiCLI puro, força thinkingLevel high se modelo é gemini-3-pro-preview e não especificado
  const modelHint = opts?.model || openCodeReq.model || "";
  const isProPreview = modelHint.toLowerCase().includes("3-pro-preview") || modelHint.toLowerCase().includes("gemini-3");

  const effectiveOpts: TransformOptions = {
    ...opts,
    thinkingLevel: opts?.thinkingLevel || openCodeReq.thinkingLevel || (isProPreview ? "high" : "medium"),
  };

  const transformed = transformRequest(openCodeReq, effectiveOpts);

  // Gemini CLI oficial usa daily quando disponível, com fallback automático
  const baseUrl = opts?.baseUrl || CLOUDCODE_DAILY_BASE;
  const streaming = opts?.streaming ?? true;
  const endpointPath = streaming ? CODE_ASSIST_ENDPOINTS.STREAM_GENERATE : CODE_ASSIST_ENDPOINTS.GENERATE;

  const url = `${baseUrl}${endpointPath}?alt=sse`;

  // Headers idênticos ao CLI real - inclui Client-Metadata em body além de header
  const headers = buildBypassHeaders(opts?.token, {
    // Gemini CLI envia X-Goog-Request-Params com project
    "X-Goog-Request-Params": `project=${encodeURIComponent(transformed.project)}&model=${encodeURIComponent(transformed.model)}`,
    ...opts?.extraHeaders,
  });

  const requestId =
    opts?.requestId ||
    `gcli_${toHex8(fnv1a32(transformed.session_id))}${Date.now().toString(36)}`;

  // Body no formato exato do Gemini CLI: request contém metadata.clientMetadata
  const body = {
    model: transformed.model,
    project: transformed.project,
    request: {
      ...transformed.request,
      // injeta metadata que o CLI sempre envia dentro do request para bypass
      metadata: {
        ideType: CLIENT_METADATA.ideType,
        platform: CLIENT_METADATA.platform,
        pluginType: CLIENT_METADATA.pluginType,
        // extensão: session_id também dentro de metadata é observado em alguns traces
        sessionId: transformed.session_id,
      },
    },
    user_prompt_id: transformed.user_prompt_id,
    session_id: transformed.session_id,
    requestId,
  };

  return {
    url,
    method: "POST",
    headers,
    body,
    rawBody: JSON.stringify(body),
    model: body.model,
    project: body.project,
    user_prompt_id: body.user_prompt_id,
    session_id: body.session_id,
    isGeminiCLIOnly: transformed.isGeminiCLIOnly,
  };
}

// ============================================================================
// 13. EXPORTS DEFAULT BUNDLE
// ============================================================================

export const RequestTransformer = {
  // constants bypass
  GEMINI_CLI_OAUTH_CLIENT_ID,
  GEMINI_CLI_OAUTH_CLIENT_SECRET,
  GEMINI_CLI_USER_AGENT,
  X_GOOG_API_CLIENT,
  CLIENT_METADATA,
  CLIENT_METADATA_STRING,
  FALLBACK_PROJECT_ID,
  CLOUDCODE_PA_BASE,
  CLOUDCODE_DAILY_BASE,
  CODE_ASSIST_ENDPOINTS,
  MODELS_2026,
  THINKING_BUDGET_MAP,

  // core FNV
  fnv1a32,
  fnv1a64,
  buildSessionIdFromDir,
  buildSessionId,
  buildUserPromptId,

  // tools
  sanitizeToolName,
  isValidToolName,
  validateToolNames,
  cleanToolSchema,
  cleanToolSchemas,
  transformTools,

  // thinking
  normalizeThinkingLevel,
  mapThinkingLevelToBudget,

  // models
  isGeminiCLIOnlyModel,
  isLikelyAntigravityOnlyModel,

  // generation
  buildGenerationConfig,
  buildBypassHeaders,

  // main
  transformRequest,
  buildAntigravityRequest,
  buildGeminiCLIRequest,
} as const;

export default RequestTransformer;
