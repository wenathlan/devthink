/**
 * @fileoverview OAuth PKCE Flow - opencode-antigravity-auth
 * @description Implementação completa de OAuth 2.0 com PKCE para bypass via identificação Gemini CLI.
 *              Production-ready, apenas node:* builtins + fetch global. Sem dependências externas.
 * @module auth/oauth
 * @author ONDA 2 - Arquitetura Core
 * @license MIT
 * @version 2.0.0
 */

import * as crypto from "node:crypto";
import * as http from "node:http";
import * as os from "node:os";
import * as readline from "node:readline";
import { spawn } from "node:child_process";

// =============================================================================
// CONSTANTS - DADOS OBRIGATÓRIOS (NÃO ALTERAR CLIENT CREDENTIALS)
// =============================================================================

/**
 * OAuth Client Credentials - Google Cloud SDK / Gemini CLI masquerade
 * Client ID obtido via Gemini CLI auth flow original.
 */
export const CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com";

export const CLIENT_SECRET = "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";

/**
 * Scopes obrigatórios para Cloud Code + Userinfo + Antigravity
 */
export const SCOPES = [
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
] as const;

/**
 * Endpoints OAuth 2.0 Google
 */
export const OAUTH_AUTHORIZE_URL = "https://accounts.google.com/o/oauth2/v2/auth";
export const OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token";
export const USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo";

/**
 * Endpoints Cloud Code Assist (Antigravity bypass)
 */
export const CLOUDCODE_BASE = "https://cloudcode-pa.googleapis.com";
export const ENDPOINTS = {
  loadCodeAssist: `${CLOUDCODE_BASE}/v1internal:loadCodeAssist`,
  onboardUser: `${CLOUDCODE_BASE}/v1internal:onboardUser`,
  fetchAvailableModels: `${CLOUDCODE_BASE}/v1internal:fetchAvailableModels`,
  generateContent: `${CLOUDCODE_BASE}/v1internal:generateContent`,
  streamGenerateContent: `${CLOUDCODE_BASE}/v1internal:streamGenerateContent`,
  retrieveUserQuotaSummary: `${CLOUDCODE_BASE}/v1internal:retrieveUserQuotaSummary`,
} as const;

/**
 * Project fallback quando não há projeto vinculado no Code Assist
 */
export const PROJECT_FALLBACK = "rising-fact-p41fc";

/**
 * Modelos disponíveis 2026 - Antigravity + Gemini
 */
export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

/**
 * Headers de identificação Gemini CLI para bypass
 * User-Agent variável por plataforma; valores base abaixo.
 */
export const GEMINI_UA_BASE = {
  cliVersion: "0.35.3",
  defaultModel: "gemini-3-pro-preview",
  googleApiClient: "google-api-nodejs-client/9.15.1",
  xGoogApiClient: "gl-node/22.19.0",
  clientMetadata: "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI",
} as const;

// =============================================================================
// TYPES
// =============================================================================

export interface PKCEPair {
  /** Verifier: string aleatória 43-128 chars para prova */
  verifier: string;
  /** Challenge: BASE64URL(SHA256(verifier)) */
  challenge: string;
  /** Método sempre S256 */
  method: "S256";
}

export interface TokenResponse {
  access_token: string;
  refresh_token?: string;
  id_token?: string;
  token_type: string;
  expires_in: number;
  scope: string;
  /** Calculado localmente */
  expires_at: number;
}

export interface UserInfo {
  id: string;
  email: string;
  verified_email: boolean;
  name: string;
  given_name?: string;
  family_name?: string;
  picture?: string;
  locale?: string;
  hd?: string;
}

export interface OAuthServerResult {
  server: http.Server;
  /** URL completa de callback (http://127.0.0.1:PORT/oauth-callback) */
  callbackUrl: string;
  /** Porta efetivamente bindada */
  port: number;
  /** Promise que resolve com o authorization code */
  waitForCode: () => Promise<string>;
  /** Encerra servidor */
  close: () => Promise<void>;
}

export interface AuthOptions {
  /** Se true, não tenta abrir browser automaticamente */
  noBrowser?: boolean;
  /** Timeout para aguardar callback antes de fallback manual (ms). Default 30000 */
  callbackTimeoutMs?: number;
  /** Path customizado para callback; default /oauth-callback */
  callbackPath?: string;
  /** Callback para log - permite integração com logger do opencode */
  onLog?: (level: "info" | "warn" | "error", msg: string) => void;
}

// =============================================================================
// UTILS - BASE64URL & PLATFORM DETECTION
// =============================================================================

/**
 * Codifica Buffer/string para base64url (RFC 7636 - sem padding, -_ em vez de +/)
 */
function base64urlEncode(input: Buffer | string): string {
  const buf = typeof input === "string" ? Buffer.from(input) : input;
  return buf
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

/**
 * Decodifica base64url para Buffer
 */
function base64urlDecode(input: string): Buffer {
  let b64 = input.replace(/-/g, "+").replace(/_/g, "/");
  const pad = b64.length % 4;
  if (pad) b64 += "=".repeat(4 - pad);
  return Buffer.from(b64, "base64");
}

/**
 * Detecta se está rodando dentro de WSL
 */
export function isWSL(): boolean {
  try {
    if (process.env.WSL_DISTRO_NAME || process.env.WSLENV) return true;
    // Checa /proc/version por "microsoft" ou "WSL" - best effort
    // Evita fs import; usa os.release()
    const release = os.release().toLowerCase();
    if (release.includes("microsoft") || release.includes("wsl")) return true;
    return false;
  } catch {
    return false;
  }
}

/**
 * Detecta sessão SSH (sem display local)
 */
export function isSSH(): boolean {
  return !!(process.env.SSH_CLIENT || process.env.SSH_TTY || process.env.SSH_CONNECTION);
}

/**
 * Detecta se tem display gráfico disponível
 */
export function hasDisplay(): boolean {
  if (process.platform === "win32") return true;
  if (process.platform === "darwin") return true;
  // Linux: checa DISPLAY ou WAYLAND_DISPLAY
  return !!(process.env.DISPLAY || process.env.WAYLAND_DISPLAY);
}

/**
 * Constrói User-Agent variável por plataforma - Gemini CLI masquerade
 * Formato: GeminiCLI/<version>/<model> (<platform>; <arch>; GitHub) <google-api-client>
 */
export function buildGeminiUserAgent(): string {
  const platform = os.platform(); // linux, darwin, win32
  const arch = os.arch(); // x64, arm64, etc
  // Normaliza para formato esperado pelo backend Google: linux/darwin/win32 -> linux/darwin/windows
  const platformLabel = platform === "win32" ? "windows" : platform;
  return `GeminiCLI/${GEMINI_UA_BASE.cliVersion}/${GEMINI_UA_BASE.defaultModel} (${platformLabel}; ${arch}; GitHub) ${GEMINI_UA_BASE.googleApiClient}`;
}

/**
 * Headers obrigatórios para bypass - retorna objeto com todos os headers de identificação
 */
export function getGeminiHeaders(): Record<string, string> {
  return {
    "User-Agent": buildGeminiUserAgent(),
    "X-Goog-Api-Client": GEMINI_UA_BASE.xGoogApiClient,
    "Client-Metadata": GEMINI_UA_BASE.clientMetadata,
  };
}

// =============================================================================
// PKCE - RFC 7636
// =============================================================================

/**
 * Gera par PKCE (verifier + challenge) conforme RFC 7636
 * - verifier: 32 bytes random -> base64url = 43 chars (dentro de 43-128)
 * - challenge: BASE64URL(SHA256(verifier))
 * 
 * @returns {PKCEPair} par verifier/challenge
 * @example
 * const { verifier, challenge } = generatePKCE();
 */
export function generatePKCE(): PKCEPair {
  // 32 bytes = 43 chars base64url, 64 bytes = 86 chars - escolhemos 64 para força extra
  const verifierBytes = crypto.randomBytes(64);
  const verifier = base64urlEncode(verifierBytes);
  // Challenge = BASE64URL(SHA256(verifier ASCII))
  const challengeHash = crypto.createHash("sha256").update(verifier).digest();
  const challenge = base64urlEncode(challengeHash);

  return {
    verifier,
    challenge,
    method: "S256",
  };
}

// =============================================================================
// OAUTH URL BUILDER
// =============================================================================

/**
 * Constrói URL de autorização OAuth 2.0 com PKCE
 * 
 * @param pkce - Par PKCE gerado
 * @param redirectUri - URI de redirect (ex: http://127.0.0.1:PORT/oauth-callback)
 * @param opts - Opções extras (state custom, login_hint, etc)
 * @returns URL completa para redirecionar usuário
 */
export function buildAuthUrl(
  pkce: PKCEPair,
  redirectUri: string,
  opts?: {
    state?: string;
    loginHint?: string;
    prompt?: "consent" | "select_account" | "none";
    accessType?: "online" | "offline";
  }
): string {
  const state = opts?.state ?? base64urlEncode(crypto.randomBytes(32));

  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: SCOPES.join(" "),
    code_challenge: pkce.challenge,
    code_challenge_method: pkce.method,
    state,
    access_type: opts?.accessType ?? "offline",
    prompt: opts?.prompt ?? "consent",
  });

  if (opts?.loginHint) {
    params.set("login_hint", opts.loginHint);
  }

  return `${OAUTH_AUTHORIZE_URL}?${params.toString()}`;
}

// =============================================================================
// BROWSER OPENER - CROSS PLATFORM + WSL
// =============================================================================

/**
 * Tenta abrir URL no browser padrão - cross-platform
 * Suporta: darwin (open), win32 (start via cmd), linux (xdg-open), WSL (wslview/powershell)
 * 
 * @param url - URL para abrir
 * @returns true se comando foi spawnado, false se falhou
 */
export async function openBrowser(url: string): Promise<boolean> {
  const platform = os.platform();

  const trySpawn = (cmd: string, args: string[]): Promise<boolean> => {
    return new Promise((resolve) => {
      try {
        const child = spawn(cmd, args, {
          stdio: "ignore",
          detached: true,
          shell: false,
        });
        child.on("error", () => resolve(false));
        child.on("spawn", () => {
          child.unref();
          resolve(true);
        });
        // Fallback se spawn não emitir em 1s
        setTimeout(() => resolve(true), 1000);
      } catch {
        resolve(false);
      }
    });
  };

  // WSL: tenta wslview, depois powershell.exe start
  if (isWSL()) {
    // wslview (wslu)
    if (await trySpawn("wslview", [url])) return true;
    // powershell.exe via cmd
    if (
      await trySpawn("powershell.exe", [
        "-NoProfile",
        "-Command",
        `Start-Process "${url.replace(/"/g, '`"')}"`,
      ])
    )
      return true;
  }

  if (platform === "darwin") {
    return trySpawn("open", [url]);
  }

  if (platform === "win32") {
    // start precisa de shell
    return new Promise<boolean>((resolve) => {
      try {
        const child = spawn("cmd", ["/c", "start", '""', url], {
          stdio: "ignore",
          detached: true,
          shell: false,
        });
        child.on("error", () => resolve(false));
        child.on("spawn", () => {
          child.unref();
          resolve(true);
        });
        setTimeout(() => resolve(true), 1000);
      } catch {
        resolve(false);
      }
    });
  }

  // Linux / fallback: xdg-open
  if (await trySpawn("xdg-open", [url])) return true;
  // Tentativas adicionais Linux
  if (await trySpawn("gio", ["open", url])) return true;
  if (await trySpawn("gnome-open", [url])) return true;
  if (await trySpawn("kde-open", [url])) return true;

  return false;
}

// =============================================================================
// MANUAL INPUT FALLBACK
// =============================================================================

/**
 * Solicita input manual do usuário via stdin
 * Suporta colar URL completa ou apenas código
 * 
 * @param promptMsg - Mensagem exibida
 * @returns código extraído
 */
function askManualInput(promptMsg: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });

    rl.question(promptMsg, (answer) => {
      rl.close();
      const trimmed = answer.trim();
      if (!trimmed) {
        reject(new Error("Input vazio recebido. Autenticação cancelada."));
        return;
      }

      // Usuário pode colar URL completa - extrair param 'code'
      try {
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
          const parsed = new URL(trimmed);
          const codeFromUrl = parsed.searchParams.get("code");
          if (codeFromUrl) {
            resolve(codeFromUrl);
            return;
          }
          // Se URL contém #? (fragment), tentar extrair, alguns fluxos retornam fragment
          if (parsed.hash) {
            const hashParams = new URLSearchParams(parsed.hash.replace(/^#/, ""));
            const codeFromHash = hashParams.get("code");
            if (codeFromHash) {
              resolve(codeFromHash);
              return;
            }
          }
        }
      } catch {
        // Não é URL válida - tratar como código direto
      }

      // Tratar como código direto (pode conter "code=XXXX" colado)
      const match = trimmed.match(/(?:code=)?([A-Za-z0-9\-_]+)/);
      if (match) {
        // Se input era "code=XYZ", pega XYZ; se era só XYZ, pega match
        const maybeCode = trimmed.includes("code=") ? match[1] : trimmed.split(/[&\s]/)[0];
        resolve(maybeCode.trim());
      } else {
        resolve(trimmed);
      }
    });

    // Handle Ctrl+C
    rl.on("SIGINT", () => {
      rl.close();
      reject(new Error("Autenticação interrompida pelo usuário (SIGINT)"));
    });
  });
}

// =============================================================================
// OAUTH LOCAL SERVER
// =============================================================================

/**
 * Cria servidor HTTP local em 127.0.0.1:0 (porta aleatória) para receber callback OAuth
 * Handle /oauth-callback, valida state se fornecido, extrai code
 * 
 * @param options - opções: callbackPath, timeout, logger
 * @returns OAuthServerResult com server, callbackUrl, waitForCode, close
 */
export function createOAuthServer(
  options?: {
    callbackPath?: string;
    onLog?: AuthOptions["onLog"];
    expectedState?: string;
  }
): OAuthServerResult {
  const callbackPath = options?.callbackPath ?? "/oauth-callback";
  const onLog = options?.onLog ?? (() => {});
  const expectedState = options?.expectedState;

  let resolveCode!: (code: string) => void;
  let rejectCode!: (err: Error) => void;
  let codeSettled = false;

  const codePromise = new Promise<string>((resolve, reject) => {
    resolveCode = (c: string) => {
      if (!codeSettled) {
        codeSettled = true;
        resolve(c);
      }
    };
    rejectCode = (e: Error) => {
      if (!codeSettled) {
        codeSettled = true;
        reject(e);
      }
    };
  });

  const server = http.createServer((req, res) => {
    try {
      const host = req.headers.host ?? "127.0.0.1";
      const fullUrl = new URL(req.url ?? "/", `http://${host}`);

      // Healthcheck / root -> info
      if (fullUrl.pathname === "/" && req.method === "GET") {
        res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("opencode-antigravity-auth OAuth callback server running. Awaiting /oauth-callback");
        return;
      }

      if (fullUrl.pathname !== callbackPath) {
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("Not Found. Expected path: " + callbackPath);
        return;
      }

      // Extrair code, state, error
      const code = fullUrl.searchParams.get("code");
      const state = fullUrl.searchParams.get("state");
      const error = fullUrl.searchParams.get("error");
      const errorDesc = fullUrl.searchParams.get("error_description");

      if (error) {
        onLog("error", `OAuth callback retornou erro: ${error} - ${errorDesc ?? ""}`);
        const htmlErr = getHtmlResponse(false, `Erro OAuth: ${escapeHtml(error)} - ${escapeHtml(errorDesc ?? "")}`);
        res.writeHead(400, { "Content-Type": "text/html; charset=utf-8" });
        res.end(htmlErr);
        rejectCode(new Error(`OAuth error: ${error} - ${errorDesc ?? "no description"}`));
        return;
      }

      if (expectedState && state && state !== expectedState) {
        onLog("error", `State mismatch. Esperado ${expectedState}, recebido ${state}`);
        const htmlErr = getHtmlResponse(false, "State inválido - possível CSRF. Tente novamente.");
        res.writeHead(400, { "Content-Type": "text/html; charset=utf-8" });
        res.end(htmlErr);
        rejectCode(new Error(`State mismatch: expected ${expectedState}, got ${state}`));
        return;
      }

      if (!code) {
        res.writeHead(400, { "Content-Type": "text/html; charset=utf-8" });
        res.end(getHtmlResponse(false, "Código de autorização ausente na callback URL."));
        rejectCode(new Error("Authorization code ausente na callback"));
        return;
      }

      // Sucesso
      onLog("info", `Authorization code recebido (${code.substring(0, 10)}...)`);
      const htmlOk = getHtmlResponse(true, "Autenticação concluída! Você pode fechar esta janela e voltar ao terminal.");
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(htmlOk);
      resolveCode(code);
    } catch (err) {
      onLog("error", `Erro no handler do servidor OAuth: ${(err as Error).message}`);
      try {
        res.writeHead(500, { "Content-Type": "text/plain" });
        res.end("Internal server error during OAuth callback");
      } catch {
        // res já enviada
      }
      rejectCode(err as Error);
    }
  });

  // Evitar travamento em testes/CI
  server.on("error", (err) => {
    onLog("error", `Erro servidor OAuth: ${err.message}`);
    rejectCode(err);
  });

  // Bind 127.0.0.1 porta aleatória
  let callbackUrl = "";
  let port = 0;

  const listeningPromise = new Promise<{ port: number; url: string }>((resolve, reject) => {
    server.listen(0, "127.0.0.1", () => {
      const addr = server.address();
      if (addr && typeof addr === "object") {
        port = addr.port;
        callbackUrl = `http://127.0.0.1:${port}${callbackPath}`;
        resolve({ port, url: callbackUrl });
      } else {
        reject(new Error("Falha ao obter endereço do servidor OAuth"));
      }
    });
    server.on("error", reject);
  });

  // Wrapper síncrono para callbackUrl - como listen é async mas queremos expor logo,
  // retornamos promise; mas para compat, expomos getters que aguardam listening.
  // Simplificação: server.listen em 0 é quase instantâneo, mas encapsulamos.
  // Para API limpa, vamos aguardar via top-level? Melhor fazer createOAuthServer async.
  // Mantemos sync com property que será preenchida; consumidor deve aguardar via ready.

  return {
    server,
    get callbackUrl() {
      return callbackUrl;
    },
    get port() {
      return port;
    },
    waitForCode: async () => {
      // Garante que servidor está listening antes de aguardar code
      if (!callbackUrl) {
        const info = await listeningPromise;
        callbackUrl = info.url;
        port = info.port;
      }
      return codePromise;
    },
    close: async () => {
      return new Promise<void>((resolve) => {
        server.close(() => resolve());
        // Força close se não fechar em 1s
        setTimeout(() => {
          try {
            server.closeAllConnections?.();
          } catch {}
          resolve();
        }, 1000);
      });
    },
  };
}

/**
 * Versão async helper que já aguarda servidor estar listening e retorna info completa
 */
export async function createOAuthServerAsync(opts?: {
  callbackPath?: string;
  onLog?: AuthOptions["onLog"];
  expectedState?: string;
}): Promise<OAuthServerResult & { ready: true }> {
  const srv = createOAuthServer(opts);
  // Força listening
  await new Promise<void>((resolve, reject) => {
    // Se já está listening, server.address() já terá port; mas aguardamos tick
    if (srv.port !== 0) {
      resolve();
      return;
    }
    srv.server.once("listening", () => resolve());
    srv.server.once("error", reject);
    // Caso edge onde listen já foi chamado no ctor mas callback ainda não rodou
    setTimeout(() => {
      if (srv.port !== 0) resolve();
    }, 50);
  });

  return { ...srv, ready: true as const };
}

/**
 * HTML de resposta para o browser no callback - UX polida
 */
function getHtmlResponse(success: boolean, message: string): string {
  const bg = success ? "#0a2a12" : "#2a0a0a";
  const accent = success ? "#22c55e" : "#ef4444";
  const icon = success ? "✅" : "❌";
  return `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>${success ? "Autenticado" : "Erro"} - opencode-antigravity-auth</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family: ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:${bg};color:#e5e7eb;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px}
  .card{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:16px;padding:32px 28px;max-width:480px;width:100%;text-align:center;backdrop-filter:blur(8px)}
  .icon{font-size:48px;margin-bottom:12px}
  h1{font-size:20px;font-weight:700;margin-bottom:8px;color:${accent}}
  p{font-size:14px;line-height:1.6;color:#cbd5e1}
  code{background:rgba(0,0,0,0.4);padding:2px 6px;border-radius:6px;font-size:12px}
  .hint{margin-top:16px;font-size:12px;color:#94a3b8}
</style>
</head>
<body>
  <div class="card">
    <div class="icon">${icon}</div>
    <h1>${success ? "Autenticação concluída" : "Falha na autenticação"}</h1>
    <p>${escapeHtml(message)}</p>
    <p class="hint">${success ? "Pode fechar esta aba e voltar ao terminal." : "Volte ao terminal e tente novamente."} <br/>opencode-antigravity-auth • Gemini CLI bypass</p>
  </div>
  <script>setTimeout(()=>{try{window.close()}catch{}}, ${success ? "1200" : "5000"});</script>
</body>
</html>`;
}

function escapeHtml(str: string): string {
  return str.replace(/[&<>"']/g, (m) => {
    switch (m) {
      case "&":
        return "&amp;";
      case "<":
        return "&lt;";
      case ">":
        return "&gt;";
      case '"':
        return "&quot;";
      case "'":
        return "&#39;";
      default:
        return m;
    }
  });
}

// =============================================================================
// TOKEN EXCHANGE & REFRESH
// =============================================================================

/**
 * Troca authorization code por tokens (access_token + refresh_token)
 * POST https://oauth2.googleapis.com/token
 * 
 * @param code - Authorization code recebido
 * @param codeVerifier - PKCE verifier original
 * @param redirectUri - Mesmo redirect_uri usado no buildAuthUrl
 * @returns TokenResponse com expires_at calculado
 */
export async function exchangeCodeForTokens(
  code: string,
  codeVerifier: string,
  redirectUri: string
): Promise<TokenResponse> {
  const body = new URLSearchParams({
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    code,
    code_verifier: codeVerifier,
    grant_type: "authorization_code",
    redirect_uri: redirectUri,
  });

  const res = await fetch(OAUTH_TOKEN_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      ...getGeminiHeaders(),
    },
    body: body.toString(),
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`exchangeCodeForTokens falhou (${res.status}): ${txt || res.statusText}`);
  }

  const data = (await res.json()) as Omit<TokenResponse, "expires_at"> & {
    expires_in: number;
  };

  return {
    ...data,
    expires_at: Date.now() + data.expires_in * 1000,
  };
}

/**
 * Renova access_token usando refresh_token
 * 
 * @param refreshToken - Refresh token válido
 * @returns Novo TokenResponse (pode conter novo refresh_token rotacionado)
 */
export async function refreshAccessToken(refreshToken: string): Promise<TokenResponse> {
  const body = new URLSearchParams({
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  });

  const res = await fetch(OAUTH_TOKEN_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      ...getGeminiHeaders(),
    },
    body: body.toString(),
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`refreshAccessToken falhou (${res.status}): ${txt || res.statusText}`);
  }

  const data = (await res.json()) as Omit<TokenResponse, "expires_at">;

  // Google às vezes não retorna novo refresh_token no refresh - manter original
  return {
    refresh_token: refreshToken,
    ...data,
    refresh_token: (data as any).refresh_token ?? refreshToken,
    expires_at: Date.now() + data.expires_in * 1000,
  };
}

/**
 * Verifica se token está expirado ou prestes a expirar (buffer 60s)
 */
export function isTokenExpired(token: TokenResponse, bufferMs = 60_000): boolean {
  return Date.now() + bufferMs >= token.expires_at;
}

// =============================================================================
// USERINFO
// =============================================================================

/**
 * Obtém informações do usuário autenticado
 * GET https://www.googleapis.com/oauth2/v2/userinfo
 * 
 * @param accessToken - Access token válido
 * @returns UserInfo normalizado
 */
export async function getUserInfo(accessToken: string): Promise<UserInfo> {
  const res = await fetch(USERINFO_URL, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      ...getGeminiHeaders(),
      Accept: "application/json",
    },
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`getUserInfo falhou (${res.status}): ${txt || res.statusText}`);
  }

  const data = (await res.json()) as UserInfo;
  if (!data.email) {
    throw new Error("getUserInfo: resposta sem e-mail - scope userinfo.email ausente?");
  }
  return data;
}

// =============================================================================
// ORQUESTRADOR COMPLETO - AUTHENTICATE
// =============================================================================

/**
 * Fluxo OAuth completo: PKCE + Server + Browser + Exchange + UserInfo
 * Suporta:
 * - detecção WSL/SSH -> não tenta abrir browser se não houver DISPLAY
 * - flag --no-browser via AuthOptions.noBrowser ou env OPENCODE_NO_BROWSER=1 ou args
 * - timeout 30s fallback para input manual de URL/código
 * 
 * @param opts - AuthOptions
 * @returns objeto com tokens e userinfo
 */
export async function authenticate(
  opts: AuthOptions & {
    existingPKCE?: PKCEPair;
  } = {}
): Promise<{
  tokens: TokenResponse;
  userInfo: UserInfo;
  pkce: PKCEPair;
  callbackUrl: string;
}> {
  const log = opts.onLog ?? ((level, msg) => {
    const prefix = level === "error" ? "[antigravity-auth][ERR]" : level === "warn" ? "[antigravity-auth][WARN]" : "[antigravity-auth]";
    // eslint-disable-next-line no-console
    console.log(`${prefix} ${msg}`);
  });

  const callbackPath = opts.callbackPath ?? "/oauth-callback";
  const timeoutMs = opts.callbackTimeoutMs ?? 30_000;

  // Flag --no-browser: checa opts, env, e process.argv
  const noBrowserFlag =
    opts.noBrowser ||
    process.env.OPENCODE_NO_BROWSER === "1" ||
    process.argv.includes("--no-browser") ||
    process.env.NO_BROWSER === "1";

  // PKCE
  const pkce = opts.existingPKCE ?? generatePKCE();
  const state = base64urlEncode(crypto.randomBytes(32));

  // Server
  log("info", "Iniciando servidor OAuth local em 127.0.0.1:0 ...");
  const oauthSrv = createOAuthServer({
    callbackPath,
    onLog: log,
    expectedState: state,
  });

  // Aguardar bind da porta (evento listening ocorre async)
  // Como createOAuthServer já chamou listen(0), aguardar 100ms até port estar disponível
  let attempts = 0;
  while (oauthSrv.port === 0 && attempts < 50) {
    await new Promise((r) => setTimeout(r, 20));
    attempts++;
  }
  if (oauthSrv.port === 0) {
    // fallback mais robusto: aguardar via evento
    await new Promise<void>((resolve, reject) => {
      oauthSrv.server.once("listening", resolve);
      oauthSrv.server.once("error", reject);
    });
  }

  const redirectUri = oauthSrv.callbackUrl;
  log("info", `Callback URL: ${redirectUri}`);

  const authUrl = buildAuthUrl(pkce, redirectUri, { state, accessType: "offline", prompt: "consent" });

  // Decidir se deve abrir browser
  let browserOpened = false;
  const shouldAttemptBrowser = !noBrowserFlag && hasDisplay() && !isSSH() || (isWSL() && !noBrowserFlag);

  if (shouldAttemptBrowser) {
    log("info", "Tentando abrir browser padrão...");
    try {
      browserOpened = await openBrowser(authUrl);
      if (browserOpened) {
        log("info", "Browser aberto. Aguardando autorização no navegador...");
      } else {
        log("warn", "Não foi possível abrir browser automaticamente.");
      }
    } catch (e) {
      log("warn", `openBrowser falhou: ${(e as Error).message}`);
    }
  } else {
    if (noBrowserFlag) log("info", "Flag --no-browser detectada. Pulando abertura automática.");
    else if (isSSH()) log("info", "Sessão SSH detectada - sem display local.");
    else if (!hasDisplay()) log("info", "Nenhum display detectado (DISPLAY/WAYLAND_DISPLAY ausente).");
  }

  if (!browserOpened) {
    // Exibir URL para abertura manual
    log("info", "Abra manualmente a URL abaixo no navegador:\n\n" + authUrl + "\n");
    // eslint-disable-next-line no-console
    console.log("\n\x1b[1m\x1b[36m🔐 Para autenticar, abra esta URL no navegador:\x1b[0m\n");
    // eslint-disable-next-line no-console
    console.log(`\x1b[4m${authUrl}\x1b[0m\n`);
  }

  // Wait com timeout + fallback manual
  let code: string;
  try {
    const codePromise = oauthSrv.waitForCode();

    // Corrida com timeout 30s
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error("TIMEOUT")), timeoutMs);
    });

    try {
      code = await Promise.race([codePromise, timeoutPromise]);
    } catch (err) {
      if ((err as Error).message === "TIMEOUT") {
        log("warn", `Timeout de ${timeoutMs / 1000}s aguardando callback - fallback para input manual.`);
        // eslint-disable-next-line no-console
        console.log("\n\x1b[33m⏱️  Timeout aguardando callback automático.\x1b[0m");
        // eslint-disable-next-line no-console
        console.log("Cole abaixo a URL completa para onde o navegador redirecionou (com ?code=) ou apenas o código:\n");

        try {
          code = await askManualInput("🔑 Código/URL de callback: ");
          log("info", "Código recebido via input manual.");
        } catch (inputErr) {
          await oauthSrv.close().catch(() => {});
          throw inputErr;
        }
      } else {
        throw err;
      }
    }
  } finally {
    // Fecha servidor sempre
    await oauthSrv.close().catch(() => {});
  }

  log("info", `Código obtido. Trocando por tokens em ${OAUTH_TOKEN_URL}...`);
  const tokens = await exchangeCodeForTokens(code, pkce.verifier, redirectUri);
  log("info", `Tokens obtidos. expira em ${tokens.expires_in}s`);

  log("info", "Obtendo informações do usuário...");
  const userInfo = await getUserInfo(tokens.access_token);
  log("info", `Autenticado como ${userInfo.email} (${userInfo.name})`);

  return {
    tokens,
    userInfo,
    pkce,
    callbackUrl: redirectUri,
  };
}

// =============================================================================
// HELPERS ADICIONAIS - STORAGE & VALIDATION
// =============================================================================

/**
 * Valida formato de TokenResponse (útil ao carregar de disco)
 */
export function isValidTokenResponse(obj: any): obj is TokenResponse {
  return (
    obj &&
    typeof obj.access_token === "string" &&
    typeof obj.expires_at === "number" &&
    typeof obj.expires_in === "number"
  );
}

/**
 * Extrai code de uma URL de callback (helper público para manual paste)
 */
export function extractCodeFromUrl(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  try {
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
      const u = new URL(trimmed);
      return u.searchParams.get("code");
    }
  } catch {
    // ignore
  }
  // Tenta regex code=
  const m = trimmed.match(/[?&]code=([^&]+)/);
  if (m) return decodeURIComponent(m[1]);
  // Se parece um code puro (sem espaços, tamanho razoável)
  if (/^[A-Za-z0-9\-_]+$/.test(trimmed) && trimmed.length > 10) return trimmed;
  return null;
}

// =============================================================================
// GEMINI CLI BYPASS HEADERS - READY TO USE FOR CLOUDCODE REQUESTS
// =============================================================================

/**
 * Gera lista de modelos disponíveis filtrando por prefixos válidos
 * Helper para validação client-side antes de chamar fetchAvailableModels
 */
export function getAllModels(): readonly string[] {
  return MODELS_2026;
}

export function isAntigravityModel(model: string): boolean {
  return model.startsWith("antigravity-");
}

/**
 * Export default para interop CJS/ESM
 */
const oauth = {
  CLIENT_ID,
  CLIENT_SECRET,
  SCOPES,
  OAUTH_AUTHORIZE_URL,
  OAUTH_TOKEN_URL,
  USERINFO_URL,
  ENDPOINTS,
  PROJECT_FALLBACK,
  MODELS_2026,
  GEMINI_UA_BASE,
  // funcs
  generatePKCE,
  buildAuthUrl,
  createOAuthServer,
  createOAuthServerAsync,
  openBrowser,
  exchangeCodeForTokens,
  refreshAccessToken,
  getUserInfo,
  authenticate,
  isTokenExpired,
  isValidTokenResponse,
  extractCodeFromUrl,
  isWSL,
  isSSH,
  hasDisplay,
  buildGeminiUserAgent,
  getGeminiHeaders,
  getAllModels,
  isAntigravityModel,
  base64urlEncode,
  base64urlDecode,
};

export default oauth;
