/**
 * @fileoverview fingerprint.ts - Anti-detection fingerprint generator mimicking Gemini CLI
 *              for opencode-antigravity-auth bypass.
 *
 * @description
 * Gera fingerprints 100% compatíveis com Gemini CLI oficial para bypass de
 * detecção de projeto no endpoint cloudcode-pa.googleapis.com.
 * - User-Agent dinâmico com plataforma coerente
 * - X-Goog-Api-Client com gl-node version jitter
 * - Client-Metadata blindado IDE_UNSPECIFIED
 * - session_id determinístico via FNV-1a do directory
 * - jitter anti-rate-limit 0-80ms
 * - anti-ban randomized OS/version pairs
 *
 * @module auth/fingerprint
 * @license MIT - opencode-antigravity-auth
 * @compliance Apenas node:* builtins + fetch global (sem deps externas)
 */

import * as os from 'node:os';
import * as path from 'node:path';
import * as crypto from 'node:crypto';

// ============================================================================
// CONSTANTES OBRIGATÓRIAS - BLINDADO
// ============================================================================

/**
 * OAuth2 Client Credentials do Gemini CLI oficial (Google Cloud Code).
 * Esses valores são públicos no binário do Gemini CLI.
 */
export const OAUTH_CLIENT_ID =
  '681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com' as const;

export const OAUTH_CLIENT_SECRET =
  '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' as const;

/**
 * Scopes exigidos pelo Gemini CLI auth flow.
 */
export const OAUTH_SCOPES = [
  'https://www.googleapis.com/auth/cloud-platform',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
] as const;

/** Project fallback interno usado quando usuário não tem projeto vinculado */
export const PROJECT_FALLBACK = 'rising-fact-p41fc' as const;

/** Base URL para Cloud Code API */
export const CLOUDCODE_BASE_URL = 'https://cloudcode-pa.googleapis.com' as const;

/**
 * Endpoints v1internal usados pelo Gemini CLI.
 * Todos sob POST, requerem auth OAuth2 + fingerprint headers.
 */
export const ENDPOINTS = {
  loadCodeAssist: `${CLOUDCODE_BASE_URL}/v1internal:loadCodeAssist`,
  onboardUser: `${CLOUDCODE_BASE_URL}/v1internal:onboardUser`,
  fetchAvailableModels: `${CLOUDCODE_BASE_URL}/v1internal:fetchAvailableModels`,
  generateContent: `${CLOUDCODE_BASE_URL}/v1internal:generateContent`,
  streamGenerateContent: `${CLOUDCODE_BASE_URL}/v1internal:streamGenerateContent`,
  retrieveUserQuotaSummary: `${CLOUDCODE_BASE_URL}/v1internal:retrieveUserQuotaSummary`,
} as const;

/** Modelos 2026 suportados - inclui família antigravity + gemini nativo */
export const MODELS_2026 = [
  'antigravity-gemini-3-pro',
  'antigravity-gemini-3.1-pro',
  'antigravity-gemini-3-flash',
  'antigravity-claude-sonnet-4-6',
  'antigravity-claude-opus-4-6-thinking',
  'gemini-2.5-flash',
  'gemini-2.5-pro',
  'gemini-3-flash-preview',
  'gemini-3-pro-preview',
  'gemini-3.1-pro-preview',
  'gemini-3.1-pro-preview-customtools',
] as const;

export type ModelId2026 = (typeof MODELS_2026)[number];

// ============================================================================
// TIPOS DE PLATAFORMA - POOL COERENTE ANTI-BAN
// ============================================================================

export type PlatformOS = 'win32' | 'linux' | 'darwin';
export type PlatformArch = 'x64' | 'arm64';
export type FingerprintType = 'gemini-cli' | 'antigravity';

/**
 * Perfil de plataforma coerente para UA.
 * Garante que win32 nunca apareça com arm64 (inconsistente no mundo real)
 * e que darwin prefira arm64 (Apple Silicon dominante).
 */
export interface PlatformProfile {
  /** OS Node.js, exato para `process.platform` */
  os: PlatformOS;
  /** Arquitetura Node.js */
  arch: PlatformArch;
  /** String formatada para dentro do parêntese do UA: "win32; x64" */
  uaSegment: string;
  /** Fonte de distribuição - 90% GitHub para coerência */
  source: string;
  /** Peso para randomização - darwin arm64 mais comum em devs */
  weight: number;
}

/**
 * Pool blindado de plataformas. Total de combinações válidas no mundo real.
 * Coerência: win32 só x64, linux x64 dominante, darwin arm64 dominante.
 */
export const PLATFORM_POOL: readonly PlatformProfile[] = [
  { os: 'linux', arch: 'x64', uaSegment: 'linux; x64', source: 'GitHub', weight: 35 },
  { os: 'darwin', arch: 'arm64', uaSegment: 'darwin; arm64', source: 'GitHub', weight: 40 },
  { os: 'win32', arch: 'x64', uaSegment: 'win32; x64', source: 'GitHub', weight: 25 },
] as const;

/** Pool adicional para jitter - versões secundárias que ainda são vistas no telemetry */
export const PLATFORM_POOL_EXTENDED: readonly PlatformProfile[] = [
  { os: 'linux', arch: 'x64', uaSegment: 'linux; x64', source: 'GitHub', weight: 30 },
  { os: 'darwin', arch: 'arm64', uaSegment: 'darwin; arm64', source: 'GitHub', weight: 35 },
  { os: 'darwin', arch: 'x64', uaSegment: 'darwin; x64', source: 'Homebrew', weight: 10 },
  { os: 'win32', arch: 'x64', uaSegment: 'win32; x64', source: 'GitHub', weight: 20 },
  { os: 'linux', arch: 'arm64', uaSegment: 'linux; arm64', source: 'GitHub', weight: 5 },
] as const;

// ============================================================================
// VERSION POOLS - ANTI-BAN RANDOMIZED OS/VERSION PAIRS
// ============================================================================

/** Versões reais do GeminiCLI vistas em telemetry publica GitHub */
export const GEMINI_CLI_VERSION_POOL = [
  '0.35.3',
  '0.35.2',
  '0.35.1',
  '0.34.0',
  '0.33.0',
  '0.32.1',
] as const;

export const ANTIGRAVITY_VERSION_POOL = [
  '1.12.8',
  '1.12.7',
  '1.12.5',
  '1.11.9',
  '1.11.4',
] as const;

/** google-api-nodejs-client versions - lockstep com GeminiCLI releases */
export const GOOGLE_API_CLIENT_VERSION_POOL = [
  '9.15.1',
  '9.15.0',
  '9.14.1',
  '9.14.0',
  '9.13.0',
] as const;

/** gl-node versions para X-Goog-Api-Client - Node LTS reais */
export const GL_NODE_VERSION_POOL = [
  '22.19.0',
  '22.16.0',
  '22.14.0',
  '20.19.3',
  '20.18.1',
  '20.17.0',
  '20.11.0',
  '18.20.4',
] as const;

/** gax version pool complementar */
export const GAX_VERSION_POOL = ['5.0.4', '5.0.3', '4.3.6'] as const;

// ============================================================================
// UTILITÁRIOS CRIPTO - FNV-1A + RANDOM
// ============================================================================

/**
 * Implementação FNV-1a 32-bit determinística para session_id.
 * Usa directory path como seed para garantir mesmo fingerprint por projeto.
 *
 * @param input - string para hash (ex: cwd)
 * @returns hex string 8 chars (uint32)
 */
export function fnv1a32(input: string): string {
  let hash = 0x811c9dc5; // FNV offset basis 32
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    // FNV prime 16777619 com overflow 32-bit
    hash = Math.imul(hash, 0x01000193);
  }
  // convert to unsigned hex 8 chars
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/**
 * FNV-1a 64-bit para session_id extendido (usando BigInt)
 * Determinístico e rápido, sem crypto overhead.
 *
 * @param input - string seed
 * @returns hex 16 chars
 */
export function fnv1a64(input: string): string {
  let hash = 14695981039346656037n;
  const prime = 1099511628211n;
  for (let i = 0; i < input.length; i++) {
    hash ^= BigInt(input.charCodeAt(i));
    hash = (hash * prime) & 0xffffffffffffffffn;
  }
  return hash.toString(16).padStart(16, '0');
}

/**
 * Gera session_id determinístico baseado no diretório atual.
 * Mesma pasta => mesmo session_id => evita flag de device hopping.
 *
 * @param directory - caminho base (default process.cwd())
 * @returns string ex: "a3f9c112-b7e1-4f9a-9d2c-..." ou hex curto
 */
export function generateSessionId(directory?: string): string {
  const dir = directory ?? process.cwd() ?? os.homedir();
  const normalized = path.resolve(dir).toLowerCase();
  const shortHash = fnv1a32(normalized);
  const longHash = fnv1a64(normalized + '|antigravity');
  // formato pseudo-UUID determinístico mas não reversível
  return `${shortHash.slice(0, 8)}-${longHash.slice(0, 4)}-${longHash.slice(4, 8)}-${longHash.slice(8, 12)}-${longHash.slice(12, 16)}${shortHash.slice(0, 4)}`;
}

/**
 * Random seguro usando crypto.getRandomValues / randomInt.
 * Fallback para Math.random se indisponível (não deve acontecer em Node 20+).
 */
export function secureRandom(): number {
  try {
    // crypto.randomInt é mais seguro que Math.random
    return crypto.randomInt(0, 1_000_000) / 1_000_000;
  } catch {
    return Math.random();
  }
}

/**
 * Escolhe elemento aleatório com peso opcional.
 */
export function pickRandomWeighted<T extends { weight: number }>(pool: readonly T[]): T {
  const total = pool.reduce((s, p) => s + p.weight, 0);
  let r = secureRandom() * total;
  for (const item of pool) {
    if (r < item.weight) return item;
    r -= item.weight;
  }
  return pool[pool.length - 1];
}

export function pickRandom<T>(pool: readonly T[]): T {
  const idx = Math.floor(secureRandom() * pool.length);
  return pool[idx];
}

/**
 * Jitter 0-80ms para anti-rate-limit / anti-ban.
 * Delay assíncrono com variação uniforme.
 */
export async function jitter(minMs = 0, maxMs = 80): Promise<void> {
  const delta = maxMs - minMs;
  const wait = minMs + Math.floor(secureRandom() * (delta + 1));
  if (wait <= 0) return;
  await new Promise<void>((res) => setTimeout(res, wait));
}

/**
 * Jitter síncrono - retorna valor ms para uso em header Retry-After / throttle.
 */
export function getJitterMs(minMs = 0, maxMs = 80): number {
  return minMs + Math.floor(secureRandom() * (maxMs - minMs + 1));
}

// ============================================================================
// CLASSE PRINCIPAL - FingerprintGenerator
// ============================================================================

export interface FingerprintOptions {
  /** Diretório para seed determinístico (default cwd) */
  directory?: string;
  /** Permitir pool extendido com combinacoes raras (default false) */
  allowExtendedPlatforms?: boolean;
  /** Fixar plataforma específica (para testes) */
  fixedPlatform?: PlatformProfile;
  /** Fixar versões específicas (para pinning) */
  fixedCliVersion?: string;
  /** Fixar google-api-client version */
  fixedGoogleApiVersion?: string;
  /** Fixar gl-node version */
  fixedNodeVersion?: string;
}

export interface FullHeadersResult {
  /** User-Agent exato Gemini CLI */
  'User-Agent': string;
  /** X-Goog-Api-Client fingerprint */
  'X-Goog-Api-Client': string;
  /** Client-Metadata blindado */
  'Client-Metadata': string;
  /** Content-Type padrão */
  'Content-Type': string;
  /** Accept */
  Accept: string;
  /** X-Client-Details - opcional para alguns endpoints */
  'X-Client-Details'?: string;
  /** Metadados extras para debug/tracing interno */
  __meta: {
    platform: PlatformProfile;
    cliVersion: string;
    googleApiVersion: string;
    glNodeVersion: string;
    gaxVersion: string;
    sessionId: string;
    model: string;
    type: FingerprintType;
    jitterMs: number;
  };
}

/**
 * Gerador anti-detecção que imita Gemini CLI exatamente.
 *
 * Coerência garantida:
 * - Plataforma escolhida define UA segment de forma consistente
 * - Versões Node / gax / google-api-client são pareadas com release real
 * - session_id é determinístico por diretório (evita device hopping detection)
 *
 * Uso:
 * ```ts
 * const fp = new FingerprintGenerator({ directory: process.cwd() });
 * const headers = fp.getFullHeaders('gemini-3-pro-preview', 'gemini-cli');
 * fetch(ENDPOINTS.loadCodeAssist, { method: 'POST', headers, body: ... })
 * ```
 */
export class FingerprintGenerator {
  private readonly directory: string;
  private readonly allowExtended: boolean;
  private readonly fixedPlatform?: PlatformProfile;
  private readonly fixedCliVersion?: string;
  private readonly fixedGoogleApiVersion?: string;
  private readonly fixedNodeVersion?: string;
  private readonly sessionId: string;

  /** Cache de plataforma escolhida por instância - estabilidade por execução */
  private cachedPlatform: PlatformProfile | null = null;

  constructor(opts: FingerprintOptions = {}) {
    this.directory = opts.directory ? path.resolve(opts.directory) : process.cwd();
    this.allowExtended = opts.allowExtendedPlatforms ?? false;
    this.fixedPlatform = opts.fixedPlatform;
    this.fixedCliVersion = opts.fixedCliVersion;
    this.fixedGoogleApiVersion = opts.fixedGoogleApiVersion;
    this.fixedNodeVersion = opts.fixedNodeVersion;
    this.sessionId = generateSessionId(this.directory);
  }

  // --------------------------------------------------------------------------
  // PLATFORM SELECTION - COERENTE + WEIGHTED
  // --------------------------------------------------------------------------

  /**
   * Retorna plataforma coerente, com cache por instância para estabilidade.
   * Se fixedPlatform foi setado, sempre retorna ele (para testes determinísticos).
   *
   * @param override - força plataforma específica, ignorando cache
   */
  getPlatform(override?: PlatformProfile): PlatformProfile {
    if (override) return override;
    if (this.fixedPlatform) return this.fixedPlatform;
    if (this.cachedPlatform) return this.cachedPlatform;

    const pool = this.allowExtended ? PLATFORM_POOL_EXTENDED : PLATFORM_POOL;
    const chosen = pickRandomWeighted(pool);
    this.cachedPlatform = chosen;
    return chosen;
  }

  /**
   * Força rotação de plataforma (útil para testes anti-ban).
   */
  rotatePlatform(): PlatformProfile {
    const pool = this.allowExtended ? PLATFORM_POOL_EXTENDED : PLATFORM_POOL;
    const chosen = pickRandomWeighted(pool);
    this.cachedPlatform = chosen;
    return chosen;
  }

  // --------------------------------------------------------------------------
  // VERSION PAIRS - ANTI-BAN RANDOMIZED
  // --------------------------------------------------------------------------

  /**
   * Gera par coerente de versões que realmente existiram juntas em um release.
   * Evita combinação impossível que seria flag fácil.
   *
   * GeminiCLI 0.35.3 sempre shipou com google-api 9.15.1 + gl-node 22.19.0
   * mas randomizamos dentro de janela plausível de ±2 minor versions.
   */
  private getCoherentVersionPair(): {
    cliVersion: string;
    googleApiVersion: string;
    glNodeVersion: string;
    gaxVersion: string;
  } {
    if (this.fixedCliVersion || this.fixedGoogleApiVersion || this.fixedNodeVersion) {
      return {
        cliVersion: this.fixedCliVersion ?? pickRandom(GEMINI_CLI_VERSION_POOL),
        googleApiVersion: this.fixedGoogleApiVersion ?? pickRandom(GOOGLE_API_CLIENT_VERSION_POOL),
        glNodeVersion: this.fixedNodeVersion ?? pickRandom(GL_NODE_VERSION_POOL),
        gaxVersion: pickRandom(GAX_VERSION_POOL),
      };
    }

    // Estratégia anti-ban: 70% escolhe versão mais recente (comportamento real de usuário),
    // 30% escolhe versão antiga (long tail real)
    const isRecentUser = secureRandom() < 0.7;

    if (isRecentUser) {
      // recent slice
      return {
        cliVersion: pickRandom(GEMINI_CLI_VERSION_POOL.slice(0, 3)),
        googleApiVersion: pickRandom(GOOGLE_API_CLIENT_VERSION_POOL.slice(0, 2)),
        glNodeVersion: pickRandom(GL_NODE_VERSION_POOL.slice(0, 3)),
        gaxVersion: GAX_VERSION_POOL[0],
      };
    } else {
      // long tail
      return {
        cliVersion: pickRandom(GEMINI_CLI_VERSION_POOL.slice(2)),
        googleApiVersion: pickRandom(GOOGLE_API_CLIENT_VERSION_POOL.slice(2)),
        glNodeVersion: pickRandom(GL_NODE_VERSION_POOL.slice(2)),
        gaxVersion: pickRandom(GAX_VERSION_POOL.slice(1)),
      };
    }
  }

  // --------------------------------------------------------------------------
  // USER-AGENT GENERATORS
  // --------------------------------------------------------------------------

  /**
   * Gera User-Agent idêntico ao Gemini CLI oficial.
   *
   * Formato real:
   * `GeminiCLI/0.35.3/gemini-3-pro-preview (win32; x64; GitHub) google-api-nodejs-client/9.15.1`
   *
   * @param model - model id (ex: gemini-3-pro-preview, antigravity-gemini-3-pro)
   * @param platform - override de plataforma (opcional)
   * @returns UA string 100% compatível
   */
  getGeminiCLIUserAgent(model: string = 'gemini-3-pro-preview', platform?: PlatformProfile): string {
    const plat = this.getPlatform(platform);
    const { cliVersion, googleApiVersion } = this.getCoherentVersionPair();

    // Normaliza model: se vier antigravity-*, strip prefix para UA? GeminiCLI original sempre usa gemini-* no UA.
    // Porém para bypass antigravity mantemos model completo quando for antigravity, pois backend aceita.
    // Estratégia: se model começa com antigravity-, mantém full; senão mantém.
    const modelSegment = model.trim();

    // source já vem do perfil (GitHub/Homebrew)
    return `GeminiCLI/${cliVersion}/${modelSegment} (${plat.uaSegment}; ${plat.source}) google-api-nodejs-client/${googleApiVersion}`;
  }

  /**
   * Gera User-Agent variante Antigravity (usado em fetchAvailableModels e some internal).
   *
   * Formato observado:
   * `Antigravity/1.12.8 (linux; x64) CodeAssist/0.9.2 google-api-nodejs-client/9.15.1 gl-node/22.19.0`
   * Mantém compatibilidade com detecção de CLI interno do Google.
   *
   * @param version - versão Antigravity (default pool)
   * @param platform - override plataforma
   */
  getAntigravityUserAgent(
    version?: string,
    platform?: PlatformProfile,
  ): string {
    const plat = this.getPlatform(platform);
    const coherent = this.getCoherentVersionPair();
    const agVersion = version ?? coherent.cliVersion.replace(/^0\./, '1.') ?? pickRandom(ANTIGRAVITY_VERSION_POOL);
    const googleVer = coherent.googleApiVersion;
    const glNode = coherent.glNodeVersion;

    // Alguns traces reais incluem CodeAssist sub-version
    const codeAssistVersions = ['0.9.2', '0.9.1', '0.8.7'];
    const caVer = pickRandom(codeAssistVersions);

    return `Antigravity/${agVersion} (${plat.uaSegment}) CodeAssist/${caVer} google-api-nodejs-client/${googleVer} gl-node/${glNode}`;
  }

  // --------------------------------------------------------------------------
  // X-GOOG-API-CLIENT + CLIENT-METADATA
  // --------------------------------------------------------------------------

  /**
   * Gera X-Goog-Api-Client header idêntico ao Node.js Google client.
   *
   * Formato real visto:
   * `gl-node/22.19.0 gccl/0.2.0 gax/5.0.4 grpc/1.13.4`
   * ou simplificado: `gl-node/22.19.0`
   *
   * Para bypass usamos formato simplificado que é aceito e menos fingerprintável,
   * mas ocasionalmente enviamos full para parecer real.
   */
  getXGoogApiClient(): string {
    const { glNodeVersion, gaxVersion } = this.getCoherentVersionPair();

    // 80% simplificado (mais comum no GeminiCLI atual), 20% full chain
    const useFull = secureRandom() < 0.2;
    if (!useFull) {
      return `gl-node/${glNodeVersion}`;
    }

    const gcclPool = ['0.2.0', '0.2.1'];
    const grpcPool = ['1.13.4', '1.13.3', '1.10.8'];
    const gccl = pickRandom(gcclPool);
    const grpc = pickRandom(grpcPool);

    return `gl-node/${glNodeVersion} gccl/${gccl} gax/${gaxVersion} grpc/${grpc}`;
  }

  /**
   * Client-Metadata blindado - valor fixo exigido pelo backend.
   * Esse header é validado no onboarding e loadCodeAssist.
   *
   * Sempre deve ser exatamente:
   * `ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI`
   */
  getClientMetadata(): string {
    return 'ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI';
  }

  // --------------------------------------------------------------------------
  // FULL HEADERS - BYPASS PROJECT
  // --------------------------------------------------------------------------

  /**
   * Gera headers completos compatíveis com Gemini CLI para bypass.
   * Inclui User-Agent coerente, X-Goog-Api-Client com gl-node jitter,
   * Client-Metadata blindado, e Content-Type.
   *
   * @param model - Model ID alvo (será sanitizado)
   * @param type - 'gemini-cli' para bypass direto, 'antigravity' para variant
   * @param platformOverride - força plataforma específica
   */
  getFullHeaders(
    model: string = 'gemini-3-pro-preview',
    type: FingerprintType = 'gemini-cli',
    platformOverride?: PlatformProfile,
  ): FullHeadersResult {
    const plat = this.getPlatform(platformOverride);
    const versions = this.getCoherentVersionPair();
    const jitterMs = getJitterMs(0, 80);

    const userAgent =
      type === 'gemini-cli'
        ? this.getGeminiCLIUserAgent(model, plat)
        : this.getAntigravityUserAgent(versions.cliVersion, plat);

    const xGoogClient = this.getXGoogApiClient();

    // Client-Metadata é fixo blindado
    const clientMetadata = this.getClientMetadata();

    // Alguns endpoints exigem X-Client-Details com session_id hash
    const xClientDetails = `session_id=${this.sessionId},platform=${plat.os}`;

    return {
      'User-Agent': userAgent,
      'X-Goog-Api-Client': xGoogClient,
      'Client-Metadata': clientMetadata,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'X-Client-Details': xClientDetails,
      __meta: {
        platform: plat,
        cliVersion: versions.cliVersion,
        googleApiVersion: versions.googleApiVersion,
        glNodeVersion: versions.glNodeVersion,
        gaxVersion: versions.gaxVersion,
        sessionId: this.sessionId,
        model,
        type,
        jitterMs,
      },
    };
  }

  /**
   * Gera Headers nativo (Fetch API) pronto para uso direto em fetch().
   *
   * @param model - model id
   * @param type - tipo de fingerprint
   * @returns Headers instance
   */
  toFetchHeaders(model?: string, type?: FingerprintType): Headers {
    const full = this.getFullHeaders(model, type);
    const h = new Headers();
    h.set('User-Agent', full['User-Agent']);
    h.set('X-Goog-Api-Client', full['X-Goog-Api-Client']);
    h.set('Client-Metadata', full['Client-Metadata']);
    h.set('Content-Type', full['Content-Type']);
    h.set('Accept', full['Accept']);
    if (full['X-Client-Details']) h.set('X-Client-Details', full['X-Client-Details']);
    return h;
  }

  /**
   * Retorna session_id determinístico desta instância.
   */
  getSessionId(): string {
    return this.sessionId;
  }

  /**
   * Retorna OAuth config completo para uso no auth flow.
   */
  getOAuthConfig(): {
    clientId: string;
    clientSecret: string;
    scopes: readonly string[];
    projectFallback: string;
  } {
    return {
      clientId: OAUTH_CLIENT_ID,
      clientSecret: OAUTH_CLIENT_SECRET,
      scopes: OAUTH_SCOPES,
      projectFallback: PROJECT_FALLBACK,
    };
  }

  /**
   * Retorna endpoints mapeados (para não duplicar hardcoded fora).
   */
  getEndpoints(): typeof ENDPOINTS {
    return ENDPOINTS;
  }
}

// ============================================================================
// FUNÇÕES STANDALONE EXPORTADAS - API CURTA BLINDADA
// ============================================================================

/**
 * Instância singleton preguiçosa baseada no cwd atual.
 * Evita múltiplas alocações e mantém session_id consistente por processo.
 */
let _defaultInstance: FingerprintGenerator | null = null;

function getDefaultInstance(): FingerprintGenerator {
  if (!_defaultInstance) {
    _defaultInstance = new FingerprintGenerator();
  }
  return _defaultInstance;
}

/**
 * Gera headers compatíveis com Gemini CLI para bypass de project.
 * Função curta blindada minúscula solicitada pela spec.
 *
 * @param model - model id (default gemini-3-pro-preview)
 * @param type - 'gemini-cli' ou 'antigravity'
 * @param platform - override opcional de plataforma string "win32 x64" etc
 * @returns Record de headers pronto para fetch
 *
 * @example
 * ```ts
 * const headers = generateHeaders('antigravity-gemini-3-pro', 'gemini-cli')
 * await fetch(ENDPOINTS.loadCodeAssist, { method: 'POST', headers, body: JSON.stringify({ project: 'rising-fact-p41fc' }) })
 * ```
 */
export function generateHeaders(
  model: string = 'gemini-3-pro-preview',
  type: FingerprintType = 'gemini-cli',
  platform?: PlatformProfile | `${PlatformOS} ${PlatformArch}` | PlatformOS,
): Record<string, string> {
  const fp = getDefaultInstance();

  let platformProfile: PlatformProfile | undefined;
  if (platform) {
    if (typeof platform === 'object') {
      platformProfile = platform;
    } else if (typeof platform === 'string') {
      // parser curto: "win32 x64" ou "win32"
      const parts = platform.toLowerCase().split(/\s+/);
      const osPart = parts[0] as PlatformOS;
      const archPart = (parts[1] as PlatformArch) ?? (osPart === 'darwin' ? 'arm64' : 'x64');
      const found = PLATFORM_POOL.find((p) => p.os === osPart && p.arch === archPart);
      if (found) platformProfile = found;
    }
  }

  const full = fp.getFullHeaders(model, type, platformProfile);
  // Remove __meta interno antes de retornar - apenas headers http reais
  const { __meta, ...httpHeaders } = full;
  // Anti-ban: injeta jitter async no background não-bloqueante? Não aqui - sync puro.
  return httpHeaders as Record<string, string>;
}

/**
 * Variante que retorna Headers nativo (Fetch API).
 * Compatível com fetch global Node 20+.
 */
export function generateFetchHeaders(
  model?: string,
  type?: FingerprintType,
  platform?: PlatformProfile | `${PlatformOS} ${PlatformArch}`,
): Headers {
  const record = generateHeaders(model, type, platform);
  const h = new Headers();
  for (const [k, v] of Object.entries(record)) {
    if (v) h.set(k, v);
  }
  return h;
}

/**
 * Gera fingerprint completo com metadados para debugging / tracing.
 * Útil para validar bypass em dev mode.
 */
export function generateFullFingerprint(
  model?: string,
  type?: FingerprintType,
  directory?: string,
): FullHeadersResult {
  const fp = directory ? new FingerprintGenerator({ directory }) : getDefaultInstance();
  return fp.getFullHeaders(model, type);
}

/**
 * Helper para criar instância com directory específico (session_id determinístico).
 * Essencial para multi-workspace (cada pasta tem fingerprint estável).
 *
 * @param directory - caminho absoluto
 */
export function createFingerprintForDirectory(directory: string): FingerprintGenerator {
  return new FingerprintGenerator({ directory });
}

/**
 * Bypass helper: gera headers + body base para loadCodeAssist.
 * Já inclui project fallback blindado.
 *
 * @param projectId - project id opcional (default rising-fact-p41fc)
 * @param model - model alvo
 */
export function buildLoadCodeAssistRequest(
  projectId: string = PROJECT_FALLBACK,
  model: string = 'gemini-3-pro-preview',
): { url: string; method: 'POST'; headers: Record<string, string>; body: string; sessionId: string } {
  const fp = getDefaultInstance();
  const headersRec = generateHeaders(model, 'gemini-cli');
  const sessionId = fp.getSessionId();

  return {
    url: ENDPOINTS.loadCodeAssist,
    method: 'POST',
    headers: headersRec,
    body: JSON.stringify({
      cloudaicompanionProject: projectId,
      metadata: {
        ideType: 'IDE_UNSPECIFIED',
        platform: 'PLATFORM_UNSPECIFIED',
        pluginType: 'GEMINI',
      },
      session_id: sessionId,
    }),
    sessionId,
  };
}

// ============================================================================
// RE-EXPORTA TUDO PARA CONSUMO DO PLUGIN
// ============================================================================

export const FingerprintConstants = {
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRET,
  OAUTH_SCOPES,
  PROJECT_FALLBACK,
  CLOUDCODE_BASE_URL,
  ENDPOINTS,
  MODELS_2026,
  PLATFORM_POOL,
  GEMINI_CLI_VERSION_POOL,
  GOOGLE_API_CLIENT_VERSION_POOL,
  GL_NODE_VERSION_POOL,
} as const;

export default FingerprintGenerator;
