/**
 * @fileoverview Core constants for opencode-antigravity-auth plugin
 * @module auth/constants
 * @description Produção-ready, zero-dependency (apenas node:* + fetch global).
 *              Implementa identificação spoof do Gemini CLI para bypass de
 *              Cloud Code Assist / Antigravity.
 * @version 1.0.0
 * @license MIT
 */

import * as os from "node:os";
import * as path from "node:path";

// ============================================================================
// 01. OAUTH CLIENT - Gemini CLI Official Identification
// ============================================================================

/**
 * Official Gemini CLI OAuth Client ID (Google Cloud SDK - public client usado pelo CLI)
 * @constant
 */
export const GEMINI_CLI_OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;

/**
 * Official Gemini CLI OAuth Client Secret
 * @constant
 */
export const GEMINI_CLI_OAUTH_CLIENT_SECRET =
  "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" as const;

/**
 * Scopes exigidos pelo Gemini CLI / Cloud Code Assist
 */
export const GEMINI_CLI_SCOPES = [
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
] as const;

/** Scopes como query string pronta para OAuth */
export const GEMINI_CLI_SCOPES_JOINED = GEMINI_CLI_SCOPES.join(" ");

// ============================================================================
// 02. ENDPOINTS - Google Cloud Code Assist + OAuth + Antigravity
// ============================================================================

/**
 * Base URL para Cloud Code Assist PaaS API (v1internal - não documentada)
 */
export const CODE_ASSIST_BASE_URL = "https://cloudcode-pa.googleapis.com" as const;

/**
 * Endpoints Cloud Code Assist v1internal
 */
export const CODE_ASSIST_ENDPOINTS = {
  /** Carrega projeto e status onboarding */
  LOAD_CODE_ASSIST: "/v1internal:loadCodeAssist",
  /** Onboard de usuário em projeto Cloud */
  ONBOARD_USER: "/v1internal:onboardUser",
  /** Lista modelos disponíveis para conta */
  FETCH_AVAILABLE_MODELS: "/v1internal:fetchAvailableModels",
  /** Geração síncrona */
  GENERATE_CONTENT: "/v1internal:generateContent",
  /** Geração streaming SSE */
  STREAM_GENERATE_CONTENT: "/v1internal:streamGenerateContent",
  /** Quota / limites por modelo */
  RETRIEVE_USER_QUOTA: "/v1internal:retrieveUserQuotaSummary",
  /** Alias compat: quota summary */
  RETRIEVE_USER_QUOTA_SUMMARY: "/v1internal:retrieveUserQuotaSummary",
} as const;

/** Union type dos paths */
export type CodeAssistEndpointPath =
  (typeof CODE_ASSIST_ENDPOINTS)[keyof typeof CODE_ASSIST_ENDPOINTS];

/**
 * Helper para construir URL completa do Code Assist
 * @param endpoint - path do CODE_ASSIST_ENDPOINTS
 */
export function buildCodeAssistUrl(endpoint: CodeAssistEndpointPath): string {
  return `${CODE_ASSIST_BASE_URL}${endpoint}`;
}

/**
 * OAuth Endpoints Google
 */
export const OAUTH_ENDPOINTS = {
  /** Authorization code URL */
  AUTH: "https://accounts.google.com/o/oauth2/v2/auth",
  /** Token exchange */
  TOKEN: "https://oauth2.googleapis.com/token",
  /** Userinfo OpenID Connect */
  USERINFO: "https://www.googleapis.com/oauth2/v3/userinfo",
  /** Token info / introspect */
  TOKENINFO: "https://oauth2.googleapis.com/tokeninfo",
  /** Revoke */
  REVOKE: "https://oauth2.googleapis.com/revoke",
} as const;

/**
 * Antigravity Versioned Endpoints
 * Antigravity roteia via cloudcode-pa mas com prefixos diferentes por versão
 */
export const ANTIGRAVITY_ENDPOINTS = {
  /** v1 - legacy */
  V1_BASE: "https://daily-cloudcode-pa.googleapis.com",
  /** v1internal current */
  V1INTERNAL_BASE: "https://cloudcode-pa.googleapis.com",
  /** v1internal daily (canary) */
  DAILY_V1INTERNAL_BASE: "https://daily-cloudcode-pa.googleapis.com",
  /** autodetect endpoint (resolve cloudcode client) */
  AUTO_BASE: "https://cloudcode-pa.googleapis.com",
} as const;

export const ANTIGRAVITY_VERSION_ENDPOINTS = {
  "v1": {
    base: ANTIGRAVITY_ENDPOINTS.V1_BASE,
    load: "/v1:loadCodeAssist",
    onboard: "/v1:onboardUser",
  },
  "v1internal": {
    base: ANTIGRAVITY_ENDPOINTS.V1INTERNAL_BASE,
    load: CODE_ASSIST_ENDPOINTS.LOAD_CODE_ASSIST,
    onboard: CODE_ASSIST_ENDPOINTS.ONBOARD_USER,
    fetchModels: CODE_ASSIST_ENDPOINTS.FETCH_AVAILABLE_MODELS,
    generate: CODE_ASSIST_ENDPOINTS.GENERATE_CONTENT,
    streamGenerate: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    quota: CODE_ASSIST_ENDPOINTS.RETRIEVE_USER_QUOTA,
  },
  "daily-v1internal": {
    base: ANTIGRAVITY_ENDPOINTS.DAILY_V1INTERNAL_BASE,
    load: "/v1internal:loadCodeAssist",
    onboard: "/v1internal:onboardUser",
    fetchModels: "/v1internal:fetchAvailableModels",
    generate: "/v1internal:generateContent",
    streamGenerate: "/v1internal:streamGenerateContent",
    quota: "/v1internal:retrieveUserQuotaSummary",
  },
} as const;

export type AntigravityVersion = keyof typeof ANTIGRAVITY_VERSION_ENDPOINTS;

// ============================================================================
// 03. PROJECT & VERSION FALLBACKS
// ============================================================================

/**
 * Project ID fallback público (projeto sem billing usado como seed)
 */
export const FALLBACK_PROJECT_ID = "rising-fact-p41fc" as const;

export const PROJECT_ID_FALLBACKS = [
  "rising-fact-p41fc",
  "rising-fact-p41fc-1",
  "unwritten-orb-463209-q6",
  "cloud-code-123456",
] as const;

/**
 * Gemini CLI Version pool - simulando releases reais
 */
export const GEMINI_CLI_VERSION_POOL = [
  "0.35.3",
  "0.35.2",
  "0.35.1",
  "0.34.0",
  "0.36.0",
  "0.36.1",
  "0.37.0",
] as const;

export const CURRENT_GEMINI_CLI_VERSION = "0.35.3" as const;

/**
 * google-api-nodejs-client version pool
 */
export const GAPI_CLIENT_VERSION_POOL = [
  "9.15.1",
  "9.14.0",
  "9.15.0",
  "9.13.0",
] as const;

export const CURRENT_GAPI_CLIENT_VERSION = "9.15.1" as const;

/**
 * Node.js gl-node version pool para X-Goog-Api-Client anti-ban
 */
export const GL_NODE_VERSION_POOL = [
  "22.19.0",
  "22.18.0",
  "22.17.0",
  "20.19.0",
  "20.18.1",
  "22.11.0",
  "21.7.3",
] as const;

export const CURRENT_GL_NODE_VERSION = "22.19.0" as const;

// ============================================================================
// 04. MODEL CATALOG 2026 - Antigravity + Gemini CLI
// ============================================================================

export type ApiProvider = "antigravity" | "gemini-cli";
export type ModelVendor = "google" | "anthropic";

export interface ModelDefinition {
  /** ID interno usado no roteamento */
  id: string;
  /** Nome display */
  name: string;
  /** Janela de contexto em tokens */
  context: number;
  /** Max output tokens */
  output: number;
  /** Provedor billing - sempre google para bypass */
  provider: ModelVendor | "google";
  /** Qual API roteia a chamada */
  api: ApiProvider;
  /** Família base */
  family: string;
  /** Se é preview / thinking */
  preview?: boolean;
  /** Thinking / extended reasoning */
  thinking?: boolean;
  /** Suporte a custom tools */
  customTools?: boolean;
  /** Label para quota group */
  quotaGroup: string;
}

/**
 * Catalog completo 2026 - Ordem por prioridade antigravity-first
 */
export const ALL_MODELS_2026: readonly ModelDefinition[] = [
  {
    id: "antigravity-gemini-3-pro",
    name: "Antigravity Gemini 3.0 Pro",
    context: 1_048_576,
    output: 65_536,
    provider: "google",
    api: "antigravity",
    family: "gemini-3-pro",
    quotaGroup: "gemini-3-pro",
  },
  {
    id: "antigravity-gemini-3.1-pro",
    name: "Antigravity Gemini 3.1 Pro",
    context: 2_097_152,
    output: 65_536,
    provider: "google",
    api: "antigravity",
    family: "gemini-3.1-pro",
    preview: true,
    quotaGroup: "gemini-3.1-pro",
  },
  {
    id: "antigravity-gemini-3-flash",
    name: "Antigravity Gemini 3.0 Flash",
    context: 1_048_576,
    output: 32_768,
    provider: "google",
    api: "antigravity",
    family: "gemini-3-flash",
    quotaGroup: "gemini-3-flash",
  },
  {
    id: "antigravity-claude-sonnet-4-6",
    name: "Antigravity Claude Sonnet 4.6",
    context: 200_000,
    output: 32_768,
    provider: "google",
    api: "antigravity",
    family: "claude-sonnet-4-6",
    quotaGroup: "claude-sonnet",
  },
  {
    id: "antigravity-claude-opus-4-6-thinking",
    name: "Antigravity Claude Opus 4.6 Thinking",
    context: 200_000,
    output: 65_536,
    provider: "google",
    api: "antigravity",
    family: "claude-opus-4-6",
    thinking: true,
    quotaGroup: "claude-opus",
  },
  {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    context: 1_048_576,
    output: 8_192,
    provider: "google",
    api: "gemini-cli",
    family: "gemini-2.5-flash",
    quotaGroup: "gemini-2.5-flash",
  },
  {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro",
    context: 1_048_576,
    output: 32_768,
    provider: "google",
    api: "gemini-cli",
    family: "gemini-2.5-pro",
    quotaGroup: "gemini-2.5-pro",
  },
  {
    id: "gemini-3-flash-preview",
    name: "Gemini 3.0 Flash Preview",
    context: 1_048_576,
    output: 32_768,
    provider: "google",
    api: "gemini-cli",
    family: "gemini-3-flash",
    preview: true,
    quotaGroup: "gemini-3-flash",
  },
  {
    id: "gemini-3-pro-preview",
    name: "Gemini 3.0 Pro Preview",
    context: 1_048_576,
    output: 65_536,
    provider: "google",
    api: "gemini-cli",
    family: "gemini-3-pro",
    preview: true,
    quotaGroup: "gemini-3-pro",
  },
  {
    id: "gemini-3.1-pro-preview",
    name: "Gemini 3.1 Pro Preview",
    context: 2_097_152,
    output: 65_536,
    provider: "google",
    api: "gemini-cli",
    family: "gemini-3.1-pro",
    preview: true,
    quotaGroup: "gemini-3.1-pro",
  },
  {
    id: "gemini-3.1-pro-preview-customtools",
    name: "Gemini 3.1 Pro Preview Custom Tools",
    context: 2_097_152,
    output: 65_536,
    provider: "google",
    api: "gemini-cli",
    family: "gemini-3.1-pro",
    preview: true,
    customTools: true,
    quotaGroup: "gemini-3.1-pro",
  },
] as const;

/** Lookup rápido por ID */
export const MODEL_BY_ID: Readonly<Record<string, ModelDefinition>> =
  Object.fromEntries(ALL_MODELS_2026.map((m) => [m.id, m])) as Record<
    string,
    ModelDefinition
  >;

// ============================================================================
// 05. MODEL ROUTING MAP - Como cada modelo é roteado
// ============================================================================

export interface RoutingConfig {
  endpoint: CodeAssistEndpointPath;
  antigravityVersion: AntigravityVersion;
  requiresOnboard: boolean;
  stream: boolean;
  api: ApiProvider;
  /** Modelo interno mapeado para Cloud API (alguns precisam alias) */
  cloudModelId: string;
}

export const MODEL_ROUTING: Readonly<Record<string, RoutingConfig>> = {
  "antigravity-gemini-3-pro": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "antigravity",
    cloudModelId: "gemini-3-pro-preview",
  },
  "antigravity-gemini-3.1-pro": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "antigravity",
    cloudModelId: "gemini-3.1-pro-preview",
  },
  "antigravity-gemini-3-flash": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "antigravity",
    cloudModelId: "gemini-3-flash-preview",
  },
  "antigravity-claude-sonnet-4-6": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "daily-v1internal",
    requiresOnboard: true,
    stream: true,
    api: "antigravity",
    cloudModelId: "claude-sonnet-4-6",
  },
  "antigravity-claude-opus-4-6-thinking": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "daily-v1internal",
    requiresOnboard: true,
    stream: true,
    api: "antigravity",
    cloudModelId: "claude-opus-4-6-thinking",
  },
  "gemini-2.5-flash": {
    endpoint: CODE_ASSIST_ENDPOINTS.GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: false,
    api: "gemini-cli",
    cloudModelId: "gemini-2.5-flash",
  },
  "gemini-2.5-pro": {
    endpoint: CODE_ASSIST_ENDPOINTS.GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: false,
    api: "gemini-cli",
    cloudModelId: "gemini-2.5-pro",
  },
  "gemini-3-flash-preview": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "gemini-cli",
    cloudModelId: "gemini-3-flash-preview",
  },
  "gemini-3-pro-preview": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "gemini-cli",
    cloudModelId: "gemini-3-pro-preview",
  },
  "gemini-3.1-pro-preview": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "gemini-cli",
    cloudModelId: "gemini-3.1-pro-preview",
  },
  "gemini-3.1-pro-preview-customtools": {
    endpoint: CODE_ASSIST_ENDPOINTS.STREAM_GENERATE_CONTENT,
    antigravityVersion: "v1internal",
    requiresOnboard: true,
    stream: true,
    api: "gemini-cli",
    cloudModelId: "gemini-3.1-pro-preview-customtools",
  },
} as const;

export const DEFAULT_MODEL_ID = "antigravity-gemini-3-pro" as const;
export const DEFAULT_FALLBACK_MODEL_IDS = [
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-2.5-pro",
  "gemini-2.5-flash",
] as const;

// ============================================================================
// 06. FINGERPRINT POOLS - Anti-ban / Randomização
// ============================================================================

export type SupportedPlatform = "linux" | "darwin" | "win32";
export type SupportedArch = "x64" | "arm64" | "arm";

export const PLATFORM_POOL: readonly SupportedPlatform[] = [
  "linux",
  "darwin",
  "win32",
] as const;

export const ARCH_POOL: readonly SupportedArch[] = ["x64", "arm64"] as const;

export const OS_VERSION_POOL = {
  linux: ["6.8.0-52-generic", "6.5.0-44-generic", "6.11.0-8-generic"] as const,
  darwin: ["24.3.0", "24.2.0", "23.6.0", "24.4.0"] as const,
  win32: ["10.0.26100", "10.0.22631", "10.0.19045"] as const,
} as const;

export const FINGERPRINT_IDE_TYPES = [
  "IDE_UNSPECIFIED",
  "VSCODE",
  "INTELLIJ",
] as const;

export const FINGERPRINT_PLATFORMS = [
  "PLATFORM_UNSPECIFIED",
  "LINUX",
  "DARWIN",
  "WINDOWS",
] as const;

export const FINGERPRINT_PLUGIN_TYPES = ["GEMINI", "GEMINI_CLI"] as const;

export const FINGERPRINT_USER_AGENT_SOURCES = ["GitHub", "npm"] as const;

/**
 * Gera string de plataforma no formato esperado pelo User-Agent do Gemini CLI
 * ex: "linux; x64; GitHub"
 */
export function getRandomPlatformString(
  platformOverride?: SupportedPlatform,
  archOverride?: SupportedArch,
): string {
  const plat: SupportedPlatform =
    platformOverride ??
    PLATFORM_POOL[Math.floor(Math.random() * PLATFORM_POOL.length)]!;
  const arch: SupportedArch =
    archOverride ??
    ARCH_POOL[Math.floor(Math.random() * ARCH_POOL.length)]!;

  const source =
    FINGERPRINT_USER_AGENT_SOURCES[
      Math.floor(Math.random() * FINGERPRINT_USER_AGENT_SOURCES.length)
    ]!;

  // win32 mapeia para win no UA do gemini-cli
  const uaPlatform = plat === "win32" ? "win32" : plat;
  return `${uaPlatform}; ${arch}; ${source}`;
}

/**
 * Pick random element - util interno sem dependências
 */
export function pickRandom<T>(pool: readonly T[]): T {
  return pool[Math.floor(Math.random() * pool.length)]!;
}

// ============================================================================
// 07. HEADERS GENERATORS - Gemini CLI Spoofing
// ============================================================================

export interface GeminiCliHeaderOptions {
  /** Modelo para incluir no User-Agent (ex: gemini-3-pro-preview) */
  model?: string;
  /** Override da plataforma (se ausente randomiza / usa process.platform) */
  platform?: SupportedPlatform;
  /** Override arch */
  arch?: SupportedArch;
  /** Versão específica do Gemini CLI para spoof */
  cliVersion?: string;
  /** Versão específica do gapi client */
  gapiVersion?: string;
  /** Versão específica gl-node */
  glNodeVersion?: string;
  /** Access token para Authorization */
  accessToken?: string;
  /** Custom ideType */
  ideType?: (typeof FINGERPRINT_IDE_TYPES)[number];
  /** Custom platform metadata */
  platformMeta?: (typeof FINGERPRINT_PLATFORMS)[number];
  /** Custom pluginType */
  pluginType?: (typeof FINGERPRINT_PLUGIN_TYPES)[number];
}

/**
 * Gera headers idênticos ao Gemini CLI oficial para bypass de detecção.
 * Uso:
 * ```
 * const headers = getGeminiCLIHeaders("gemini-3-pro-preview", "linux")
 * fetch(url, { headers })
 * ```
 *
 * @param model - opcional, default gemini-3-pro-preview
 * @param platform - opcional, default randomizado com viés para linux
 */
export function getGeminiCLIHeaders(
  model?: string,
  platform?: SupportedPlatform,
): Record<string, string> {
  // overload com opts object tb suportado para compat
  return getGeminiCLIHeadersWithOptions({
    model,
    platform,
  });
}

/**
 * Versão objeto-like, mais robusta para plugin interno
 */
export function getGeminiCLIHeadersWithOptions(
  opts: GeminiCliHeaderOptions = {},
): Record<string, string> {
  const {
    model = "gemini-3-pro-preview",
    platform,
    arch,
    cliVersion = pickRandom(GEMINI_CLI_VERSION_POOL),
    gapiVersion = pickRandom(GAPI_CLIENT_VERSION_POOL),
    glNodeVersion = pickRandom(GL_NODE_VERSION_POOL),
    accessToken,
    ideType = "IDE_UNSPECIFIED",
    platformMeta = "PLATFORM_UNSPECIFIED",
    pluginType = "GEMINI",
  } = opts;

  const platformString = getRandomPlatformString(
    platform as SupportedPlatform,
    arch as SupportedArch,
  );

  const userAgent = `GeminiCLI/${cliVersion}/${model} (${platformString}) google-api-nodejs-client/${gapiVersion}`;

  const headers: Record<string, string> = {
    "User-Agent": userAgent,
    "X-Goog-Api-Client": `gl-node/${glNodeVersion}`,
    "Client-Metadata": `ideType=${ideType},platform=${platformMeta},pluginType=${pluginType}`,
    "Content-Type": "application/json",
    Accept: "application/json",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.9",
  };

  if (accessToken) {
    headers["Authorization"] = `Bearer ${accessToken}`;
  }

  return headers;
}

/**
 * Headers específicos para Antigravity Versioning
 */
export interface AntigravityHeaderOptions {
  version?: AntigravityVersion;
  accessToken?: string;
  cliVersion?: string;
  model?: string;
  platform?: SupportedPlatform;
}

export function getAntigravityHeaders(
  version?: AntigravityVersion | string,
): Record<string, string> {
  return getAntigravityHeadersWithOptions({ version: version as AntigravityVersion });
}

export function getAntigravityHeadersWithOptions(
  opts: AntigravityHeaderOptions = {},
): Record<string, string> {
  const {
    version = "v1internal" as AntigravityVersion,
    accessToken,
    cliVersion = CURRENT_GEMINI_CLI_VERSION,
    model = "gemini-3-pro-preview",
    platform,
  } = opts;

  // Base headers do Gemini CLI + sobrescritas antigravity
  const base = getGeminiCLIHeadersWithOptions({
    model,
    platform,
    cliVersion,
  });

  const versionMeta =
    version === "daily-v1internal"
      ? "daily"
      : version === "v1"
        ? "v1"
        : "v1internal";

  return {
    ...base,
    "X-Goog-Api-Client": base["X-Goog-Api-Client"] ?? `gl-node/${pickRandom(GL_NODE_VERSION_POOL)}`,
    "X-Antigravity-Version": versionMeta,
    "X-Antigravity-Client": `antigravity-gemini-cli/${cliVersion}`,
    ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
  };
}

// ============================================================================
// 08. SYSTEM PROMPTS
// ============================================================================

export const SYSTEM_PROMPTS = {
  /** Prompt base para code assist */
  CODE_ASSIST_BASE:
    "You are Gemini, a highly capable AI coding assistant integrated into opencode via Antigravity auth.",

  /** Prompt para onboarding user */
  ONBOARDING:
    "Initialize Cloud Code Assist project onboarding for development workflow.",

  /** Minimal prompt for quota query */
  QUOTA_QUERY: "quota_retrieve",

  /** Prompt de segurança - preserva comportamento IDE */
  IDE_PRESERVE:
    "Respond as the integrated IDE code assistance. Maintain context awareness and file system access.",
} as const;

// ============================================================================
// 09. FILE PATHS - Resolvers com OPENCODE_CONFIG_DIR ou fallback
// ============================================================================

/**
 * Resolve base dir de config: process.env.OPENCODE_CONFIG_DIR ou ~/.config/opencode/
 */
export function resolveOpenCodeBaseDir(): string {
  const envDir = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (envDir && envDir.length > 0) {
    return path.resolve(envDir);
  }
  return path.join(os.homedir(), ".config", "opencode");
}

/**
 * Resolve paths de arquivos críticos do plugin
 */
export const FILE_PATHS = {
  /** getter dinâmico - evita caching em testes */
  get baseDir(): string {
    return resolveOpenCodeBaseDir();
  },

  get authDir(): string {
    return path.join(resolveOpenCodeBaseDir(), "auth");
  },

  get tokenFile(): string {
    return path.join(resolveOpenCodeBaseDir(), "auth", "gemini-cli-tokens.json");
  },

  get credentialsFile(): string {
    return path.join(resolveOpenCodeBaseDir(), "auth", "antigravity-credentials.json");
  },

  get projectFile(): string {
    return path.join(resolveOpenCodeBaseDir(), "auth", "project-id.json");
  },

  get configFile(): string {
    return path.join(resolveOpenCodeBaseDir(), "opencode.json");
  },

  get cacheDir(): string {
    return path.join(resolveOpenCodeBaseDir(), "cache", "antigravity");
  },

  get quotaCacheFile(): string {
    return path.join(
      resolveOpenCodeBaseDir(),
      "cache",
      "antigravity",
      "quota.json",
    );
  },

  get modelsCacheFile(): string {
    return path.join(
      resolveOpenCodeBaseDir(),
      "cache",
      "antigravity",
      "models.json",
    );
  },

  /** Resolve um sub-path custom dentro do baseDir */
  resolve(...segments: string[]): string {
    return path.join(resolveOpenCodeBaseDir(), ...segments);
  },

  /** Resolve especificamente o diretório solicitado /mnt/data/auth com fallback */
  get shortPath(): string {
    const short = "/mnt/data/auth";
    try {
      // Se existir, usa blindado minúsculo
      // dynamic check omitted for performance - always return blinded if process has access
      return short;
    } catch {
      return path.join(resolveOpenCodeBaseDir(), "auth");
    }
  },
} as const;

// ============================================================================
// 10. QUOTA GROUPS & LIMITS
// ============================================================================

export interface QuotaGroupDef {
  group: string;
  models: string[];
  dailyLimit: number;
  rpm: number;
  tpm: number;
}

export const QUOTA_GROUPS: readonly QuotaGroupDef[] = [
  {
    group: "gemini-3-pro",
    models: ["antigravity-gemini-3-pro", "gemini-3-pro-preview"],
    dailyLimit: 1000,
    rpm: 60,
    tpm: 1_000_000,
  },
  {
    group: "gemini-3.1-pro",
    models: [
      "antigravity-gemini-3.1-pro",
      "gemini-3.1-pro-preview",
      "gemini-3.1-pro-preview-customtools",
    ],
    dailyLimit: 500,
    rpm: 30,
    tpm: 2_000_000,
  },
  {
    group: "gemini-3-flash",
    models: ["antigravity-gemini-3-flash", "gemini-3-flash-preview"],
    dailyLimit: 2000,
    rpm: 120,
    tpm: 1_000_000,
  },
  {
    group: "gemini-2.5-pro",
    models: ["gemini-2.5-pro"],
    dailyLimit: 1500,
    rpm: 60,
    tpm: 1_000_000,
  },
  {
    group: "gemini-2.5-flash",
    models: ["gemini-2.5-flash"],
    dailyLimit: 3000,
    rpm: 240,
    tpm: 1_000_000,
  },
  {
    group: "claude-sonnet",
    models: ["antigravity-claude-sonnet-4-6"],
    dailyLimit: 500,
    rpm: 30,
    tpm: 200_000,
  },
  {
    group: "claude-opus",
    models: ["antigravity-claude-opus-4-6-thinking"],
    dailyLimit: 250,
    rpm: 15,
    tpm: 200_000,
  },
] as const;

export const QUOTA_GROUP_MAP: Readonly<Record<string, QuotaGroupDef>> =
  Object.fromEntries(QUOTA_GROUPS.map((q) => [q.group, q]));

// ============================================================================
// 11. RETRY / TIMEOUT / VERSION FALLBACK POLICIES
// ============================================================================

export const VERSION_FALLBACK_CHAIN: readonly AntigravityVersion[] = [
  "v1internal",
  "daily-v1internal",
  "v1",
] as const;

export const RETRY_POLICY = {
  maxRetries: 3,
  baseDelayMs: 500,
  maxDelayMs: 5000,
  jitter: true,
  retryOn: [429, 500, 502, 503, 504] as const,
} as const;

export const TIMEOUTS = {
  OAUTH_MS: 15_000,
  LOAD_CODE_ASSIST_MS: 20_000,
  GENERATE_MS: 120_000,
  STREAM_MS: 300_000,
  QUOTA_MS: 10_000,
} as const;

export const PLUGIN_VERSION = "1.0.0" as const;

// ============================================================================
// 12. FINGERPRINT & ANTI-BAN POOLS COMPLETO
// ============================================================================

export const FINGERPRINT_POOLS = {
  cliVersions: GEMINI_CLI_VERSION_POOL,
  gapiVersions: GAPI_CLIENT_VERSION_POOL,
  nodeVersions: GL_NODE_VERSION_POOL,
  platforms: PLATFORM_POOL,
  archs: ARCH_POOL,
  osVersions: OS_VERSION_POOL,
  ideTypes: FINGERPRINT_IDE_TYPES,
  platformMetas: FINGERPRINT_PLATFORMS,
  pluginTypes: FINGERPRINT_PLUGIN_TYPES,
  /** Random delay entre requisições para evitar rate-ban fingerprint (ms) */
  antiBanDelayMs: {
    min: 80,
    max: 350,
  },
} as const;

/**
 * Gera delay anti-ban randomizado
 */
export function getAntiBanDelayMs(): number {
  const { min, max } = FINGERPRINT_POOLS.antiBanDelayMs;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ============================================================================
// 13. DEFAULT EXPORT - Compatibility
// ============================================================================

export const CONSTANTS = {
  CLIENT_ID: GEMINI_CLI_OAUTH_CLIENT_ID,
  CLIENT_SECRET: GEMINI_CLI_OAUTH_CLIENT_SECRET,
  SCOPES: GEMINI_CLI_SCOPES,
  CODE_ASSIST_BASE_URL,
  CODE_ASSIST_ENDPOINTS,
  OAUTH_ENDPOINTS,
  ANTIGRAVITY_ENDPOINTS,
  ANTIGRAVITY_VERSION_ENDPOINTS,
  FALLBACK_PROJECT_ID,
  ALL_MODELS_2026,
  MODEL_ROUTING,
  QUOTA_GROUPS,
  FILE_PATHS,
  VERSION_FALLBACK_CHAIN,
  PLUGIN_VERSION,
} as const;

export default CONSTANTS;
