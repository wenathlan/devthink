/**
 * @module auth/version
 * @description
 * Fetcher dinâmico de versão Antigravity para o plugin opencode-antigravity-auth.
 * Estratégia resiliente em chain com cache 6h (memória + ~/.config/opencode/antigravity-version.json)
 * Usa apenas node:* builtins + fetch global. Zero dependências.
 *
 * Contexto opencode-antigravity-auth (bypass via Gemini CLI identification):
 * - Client ID: 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com
 * - Client Secret: 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
 * - Scopes: https://www.googleapis.com/auth/cloud-platform https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile
 * - User-Agent Gemini: GeminiCLI/0.35.3/gemini-3-pro-preview (darwin; arm64; GitHub) google-api-nodejs-client/9.15.1
 * - X-Goog-Api-Client: gl-node/22.19.0
 * - Client-Metadata: ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 * - Endpoints: cloudcode-pa.googleapis.com v1internal:loadCodeAssist, :onboardUser, :fetchAvailableModels, :generateContent, :streamGenerateContent, :retrieveUserQuotaSummary
 * - Project fallback: rising-fact-p41fc
 * - Models 2026: antigravity-gemini-3-pro, antigravity-gemini-3.1-pro, antigravity-gemini-3-flash, antigravity-claude-sonnet-4-6, antigravity-claude-opus-4-6-thinking, gemini-2.5-flash, gemini-2.5-pro, gemini-3-flash-preview, gemini-3-pro-preview, gemini-3.1-pro-preview, gemini-3.1-pro-preview-customtools
 *
 * @author ONDA 2 - Arquitetura Core
 * @license MIT
 * @since 2026
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";

// ---------------------------------------------------------------------------
// Constants / Fallbacks
// ---------------------------------------------------------------------------

/**
 * Endpoints oficiais Antigravity auto-updater (mesma infra do Gemini CLI/Antigravity IDE).
 * Ambos retornam JSON com `version` no formato "1.15.8-5724687216017408".
 */
export const REMOTE_MANIFEST_URLS = [
  "https://antigravity-auto-updater-974169037036.us-central1.run.app/manifests/linux_amd64.json",
  "https://antigravity-ide-auto-updater-974169037036.us-central1.run.app/api/update/linux/x64/stable/0",
] as const;

/** URLs de changelog para scrape secundário quando manifests falham */
export const CHANGELOG_URLS = [
  "https://antigravity.google.com/docs/changelog",
  "https://antigravity.google.com/changelog",
  "https://cloud.google.com/antigravity/docs/release-notes",
  "https://antigravity-auto-updater-974169037036.us-central1.run.app/changelog",
] as const;

/** Fallback blindado - última versão conhecida estável (IDE) */
export const FALLBACK_VERSION = "1.15.8" as const;
export const FALLBACK_FULL_VERSION = "1.15.8-5724687216017408" as const;

/** Fallback alternativo - usado para compatibilidade CLI/Antigravity v2 track */
export const FALLBACK_ALTERNATIVE_VERSION = "2.0.11" as const;
export const FALLBACK_ALTERNATIVE_FULL = "2.0.11-0000000000000000" as const;

/** Cache 6 horas em ms */
export const VERSION_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

/** Arquivo de cache em disco - XDG style */
export const VERSION_CACHE_FILE = path.join(
  os.homedir(),
  ".config",
  "opencode",
  "antigravity-version.json"
);

/** Timeout padrão para fetch */
export const FETCH_TIMEOUT_MS = 5_000;

// ---------------------------------------------------------------------------
// Auth constants (referência para integração do plugin, não usado no fetch)
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_AUTH_CONSTANTS = {
  CLIENT_ID:
    "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com",
  CLIENT_SECRET: "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",
  SCOPES: [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
  ],
  /** Template UA - produção deve variar plataforma dinamicamente */
  USER_AGENT_TEMPLATES: {
    darwin_arm64:
      "GeminiCLI/0.35.3/gemini-3-pro-preview (darwin; arm64; GitHub) google-api-nodejs-client/9.15.1",
    darwin_x64:
      "GeminiCLI/0.35.3/gemini-3-pro-preview (darwin; x64; GitHub) google-api-nodejs-client/9.15.1",
    linux_x64:
      "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1",
    win32_x64:
      "GeminiCLI/0.35.3/gemini-3-pro-preview (win32; x64; GitHub) google-api-nodejs-client/9.15.1",
  },
  X_GOOG_API_CLIENT: "gl-node/22.19.0",
  CLIENT_METADATA:
    "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI",
  ENDPOINT_BASE: "https://cloudcode-pa.googleapis.com",
  ENDPOINTS: {
    loadCodeAssist: "/v1internal:loadCodeAssist",
    onboardUser: "/v1internal:onboardUser",
    fetchAvailableModels: "/v1internal:fetchAvailableModels",
    generateContent: "/v1internal:generateContent",
    streamGenerateContent: "/v1internal:streamGenerateContent",
    retrieveUserQuotaSummary: "/v1internal:retrieveUserQuotaSummary",
  },
  PROJECT_FALLBACK: "rising-fact-p41fc",
  MODELS_2026: [
    "antigravity-gemini-3-pro",
    "antigravity-gemini-3.1-pro",
    "antigravity-gemini-3-flash",
    "antigravity-claude-sonnet-4-6",
    "antigravity-claude-opus-4-6-thinking",
    "gemini-2.5-flash",
    "gemini-2.5-pro",
    "gemini-3-flash-preview",
    "gemini-3-pro-preview",
    "gemini-3.1-pro-preview",
    "gemini-3.1-pro-preview-customtools",
  ],
} as const;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type VersionSource =
  | "remote-manifest"
  | "ide-updater"
  | "changelog"
  | "cache-file"
  | "memory-cache"
  | "hardcoded-fallback";

export interface AntigravityVersionInfo {
  /** Versão normalizada sem build metadata, ex: "1.15.8" */
  version: string;
  /** Versão completa original, ex: "1.15.8-5724687216017408" */
  fullVersion: string;
  /** Origem de onde veio */
  source: VersionSource;
  /** Epoch ms */
  fetchedAt: number;
  /** Expiração calculada */
  expiresAt: number;
  /** Opcional - URL que retornou a versão */
  url?: string;
}

/** Formato salvo em disco */
interface CachedFilePayload extends AntigravityVersionInfo {}

// ---------------------------------------------------------------------------
// Internal state (memory cache + dedup)
// ---------------------------------------------------------------------------

let memoryCache: AntigravityVersionInfo | null = null;
let inflightPromise: Promise<AntigravityVersionInfo> | null = null;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Parse "1.15.8-5724687216017408" -> "1.15.8"
 * Mantém fallback seguro se não casar regex.
 */
export function parseAntigravityVersion(raw: string): {
  normalized: string;
  full: string;
} {
  if (!raw || typeof raw !== "string") {
    return { normalized: FALLBACK_VERSION, full: FALLBACK_FULL_VERSION };
  }
  const trimmed = raw.trim();
  // Captura semver no início
  const m = trimmed.match(/(\d+\.\d+\.\d+(?:\.\d+)?)/);
  if (!m) {
    // tenta fallback com raw limpo
    const cleaned = trimmed.replace(/[^0-9.\-]/g, "");
    return {
      normalized: cleaned.split("-")[0] || FALLBACK_VERSION,
      full: trimmed,
    };
  }
  const normalized = m[1];
  return { normalized, full: trimmed };
}

/**
 * fetch com timeout usando AbortController (global fetch disponível Node 18+)
 * @param url URL alvo
 * @param init RequestInit opcional
 * @param timeoutMs default 5000
 */
export async function fetchWithTimeout(
  url: string,
  init: RequestInit = {},
  timeoutMs = FETCH_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...init,
      signal: controller.signal,
      // headers base para bypass similar gemini cli
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "User-Agent": ANTIGRAVITY_AUTH_CONSTANTS.USER_AGENT_TEMPLATES.linux_x64,
        "X-Goog-Api-Client": ANTIGRAVITY_AUTH_CONSTANTS.X_GOOG_API_CLIENT,
        ...(init.headers || {}),
      },
    } as RequestInit);
    return res;
  } finally {
    clearTimeout(timer);
  }
}

/** Garante diretório de cache existe */
function ensureCacheDirSync(): void {
  try {
    const dir = path.dirname(VERSION_CACHE_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    }
  } catch {
    // silencioso - disco pode ser read-only, usaremos apenas memória
  }
}

/** Lê cache de disco sincronamente se válido */
export function readCacheFileSync(): AntigravityVersionInfo | null {
  try {
    if (!fs.existsSync(VERSION_CACHE_FILE)) return null;
    const raw = fs.readFileSync(VERSION_CACHE_FILE, "utf8");
    const parsed = JSON.parse(raw) as CachedFilePayload;
    if (!parsed.version || !parsed.fetchedAt) return null;
    // valida TTL
    if (Date.now() > parsed.expiresAt) return null;
    return parsed;
  } catch {
    return null;
  }
}

/** Lê cache de disco assíncrono */
export async function readCacheFile(): Promise<AntigravityVersionInfo | null> {
  try {
    await fs.promises.access(VERSION_CACHE_FILE, fs.constants.R_OK);
    const raw = await fs.promises.readFile(VERSION_CACHE_FILE, "utf8");
    const parsed = JSON.parse(raw) as CachedFilePayload;
    if (!parsed.version || !parsed.fetchedAt) return null;
    if (Date.now() > parsed.expiresAt) return null;
    return { ...parsed, source: "cache-file" };
  } catch {
    return null;
  }
}

/** Escreve cache em disco (best-effort) */
export async function writeCacheFile(
  info: AntigravityVersionInfo
): Promise<void> {
  try {
    ensureCacheDirSync();
    const payload: CachedFilePayload = {
      ...info,
      // garante não expor url sensível? url é pública, ok manter
    };
    await fs.promises.writeFile(
      VERSION_CACHE_FILE,
      JSON.stringify(payload, null, 2),
      { mode: 0o600 }
    );
  } catch {
    // ignore - memória ainda funciona
  }
}

// ---------------------------------------------------------------------------
// Remote fetchers (chain)
// ---------------------------------------------------------------------------

/**
 * Chain 1a: manifesta linux_amd64.json
 * Formato esperado:
 * {
 *   "version": "1.15.8-5724687216017408",
 *   "manifests": { ... },
 *   "latest": "1.15.8-..."
 * }
 */
async function fetchFromManifest(
  url: string
): Promise<AntigravityVersionInfo | null> {
  try {
    const res = await fetchWithTimeout(url, { method: "GET" });
    if (!res.ok) return null;

    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {
      // resposta pode ser texto puro com versão
      const parsed = parseAntigravityVersion(text);
      if (parsed.normalized !== FALLBACK_VERSION || text.includes(".")) {
        const now = Date.now();
        return {
          version: parsed.normalized,
          fullVersion: parsed.full,
          source: url.includes("ide-auto-updater") ? "ide-updater" : "remote-manifest",
          fetchedAt: now,
          expiresAt: now + VERSION_CACHE_TTL_MS,
          url,
        };
      }
      return null;
    }

    // tenta extrair versão de múltiplas chaves possíveis
    const candidates: (string | undefined)[] = [
      json?.version,
      json?.latestVersion,
      json?.latest,
      json?.stable?.version,
      json?.manifest?.version,
      json?.manifests?.linux_amd64?.version,
      json?.manifests?.["linux/amd64"]?.version,
      json?.data?.version,
      json?.result?.version,
    ];

    // se for array de manifests
    if (Array.isArray(json?.manifests)) {
      for (const m of json.manifests) {
        if (m?.version) candidates.push(m.version);
      }
    }

    // varre objeto por qualquer string que pareça versão
    if (candidates.every((c) => !c)) {
      // busca profunda limitada
      const stack = [json];
      let depth = 0;
      while (stack.length && depth < 20) {
        const cur = stack.pop();
        depth++;
        if (cur && typeof cur === "object") {
          for (const v of Object.values(cur)) {
            if (typeof v === "string" && /^\d+\.\d+\.\d+-?\d*/.test(v)) {
              candidates.push(v);
              break;
            }
            if (v && typeof v === "object") stack.push(v);
          }
        }
        if (candidates.filter(Boolean).length) break;
      }
    }

    const rawVersion = candidates.find((c): c is string => !!c && typeof c === "string");
    if (!rawVersion) return null;

    const { normalized, full } = parseAntigravityVersion(rawVersion);
    if (!normalized) return null;

    const now = Date.now();
    return {
      version: normalized,
      fullVersion: full,
      source: url.includes("ide-auto-updater") ? "ide-updater" : "remote-manifest",
      fetchedAt: now,
      expiresAt: now + VERSION_CACHE_TTL_MS,
      url,
    };
  } catch {
    return null;
  }
}

/**
 * Chain 2: changelog scrape
 * Tenta extrair versão de HTML/texto via regex. Melhor esforço.
 */
async function fetchFromChangelog(): Promise<AntigravityVersionInfo | null> {
  // Regex que captura versões tipo 1.15.8, 1.15.8-5724..., 2.0.11
  const versionRegex =
    /(?:antigravity[^0-9]{0,20}|version[^0-9]{0,10}|release[^0-9]{0,10})?(\d+\.\d+\.\d+(?:-\d+)?)/gi;
  const semverOnly = /(\d+\.\d+\.\d+)/g;

  for (const url of CHANGELOG_URLS) {
    try {
      const res = await fetchWithTimeout(url, { method: "GET" }, 5000);
      if (!res.ok) continue;
      const text = await res.text();
      if (!text || text.length < 10) continue;

      // prioriza busca com contexto antigravity
      let match: RegExpExecArray | null;
      const found: string[] = [];
      while ((match = versionRegex.exec(text)) !== null) {
        if (match[1]) found.push(match[1]);
        if (found.length >= 10) break;
      }

      if (found.length === 0) {
        // fallback genérico sem contexto
        let m2: RegExpExecArray | null;
        while ((m2 = semverOnly.exec(text)) !== null) {
          if (m2[1]) {
            // heurística: ignora versões muito baixas 0.0.x e 1.0.0 genéricas a menos que sejam antigravity
            const parts = m2[1].split(".").map(Number);
            if (parts[0] >= 1) found.push(m2[1]);
          }
          if (found.length >= 20) break;
        }
      }

      if (found.length === 0) continue;

      // pega maior versão (semver compare simples) - última entry geralmente é a mais nova se changelog ordenado decrescente
      // para changelog decrescente, primeira ocorrência é a mais nova
      const raw = found[0];
      const { normalized, full } = parseAntigravityVersion(raw);
      const now = Date.now();
      return {
        version: normalized,
        fullVersion: full.includes("-") ? full : `${normalized}-0000000000000000`,
        source: "changelog",
        fetchedAt: now,
        expiresAt: now + VERSION_CACHE_TTL_MS,
        url,
      };
    } catch {
      continue;
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Fetcher dinâmico principal - chain resiliente:
 * 1. remote manifest linux_amd64.json
 * 2. ide auto-updater api/update/linux/x64/stable/0
 * 3. changelog scrape
 * 4. hardcoded fallback 1.15.8 / 2.0.11
 *
 * @returns AntigravityVersionInfo sempre resolvido (fallback garantido)
 */
export async function fetchAntigravityVersion(): Promise<AntigravityVersionInfo> {
  // 1) remote manifests em paralelo com race saudável
  const manifestPromises = REMOTE_MANIFEST_URLS.map((url) => fetchFromManifest(url));

  // tenta primeiro manifesto em ordem, mas com timeout agregado
  for (const p of manifestPromises) {
    try {
      const result = await p;
      if (result && result.version) {
        // cache em memória e disco
        memoryCache = result;
        await writeCacheFile(result);
        return result;
      }
    } catch {
      // continua chain
    }
  }

  // 2) changelog scrape
  try {
    const changelogResult = await fetchFromChangelog();
    if (changelogResult && changelogResult.version) {
      memoryCache = changelogResult;
      await writeCacheFile(changelogResult);
      return changelogResult;
    }
  } catch {
    // ignora
  }

  // 3) tenta cache de disco mesmo expirado como último recurso antes fallback
  try {
    if (fs.existsSync(VERSION_CACHE_FILE)) {
      const raw = await fs.promises.readFile(VERSION_CACHE_FILE, "utf8");
      const parsed = JSON.parse(raw) as CachedFilePayload;
      if (parsed.version) {
        const now = Date.now();
        const reused: AntigravityVersionInfo = {
          ...parsed,
          fetchedAt: now,
          expiresAt: now + VERSION_CACHE_TTL_MS,
          source: "cache-file",
        };
        memoryCache = reused;
        return reused;
      }
    }
  } catch {
    // ignora
  }

  // 4) hardcoded fallback garantido
  const now = Date.now();
  const fallback: AntigravityVersionInfo = {
    version: FALLBACK_VERSION,
    fullVersion: FALLBACK_FULL_VERSION,
    source: "hardcoded-fallback",
    fetchedAt: now,
    expiresAt: now + VERSION_CACHE_TTL_MS,
  };
  memoryCache = fallback;
  // tenta escrever fallback para não ficar sem arquivo
  await writeCacheFile(fallback);
  return fallback;
}

/**
 * Lazy getter principal - usa memória, depois arquivo, depois fetch.
 * Promise deduplicada: chamadas concorrentes compartilham mesmo inflight.
 *
 * @example
 * const v = await getVersion(); // "1.15.8"
 * const info = await getVersionInfo(); // objeto completo
 */
export async function getVersionInfo(): Promise<AntigravityVersionInfo> {
  // 1) memória válida
  if (memoryCache && Date.now() < memoryCache.expiresAt) {
    return { ...memoryCache, source: memoryCache.source === "hardcoded-fallback" ? memoryCache.source : "memory-cache" as any };
  }

  // 2) se já tem request em andamento, aguarda
  if (inflightPromise) {
    return inflightPromise;
  }

  // 3) arquivo válido
  const fileCache = await readCacheFile();
  if (fileCache) {
    memoryCache = fileCache;
    return fileCache;
  }

  // 4) fetch remoto com dedup
  inflightPromise = fetchAntigravityVersion()
    .finally(() => {
      inflightPromise = null;
    });

  const result = await inflightPromise;
  return result;
}

/**
 * Getter simplificado que retorna apenas string "1.15.8"
 * Lazy + cache 6h
 */
export async function getVersion(): Promise<string> {
  const info = await getVersionInfo();
  return info.version;
}

/**
 * Versão síncrona - tenta memória e disco, senão fallback.
 * Útil para contextos onde async não é possível (ex: inicialização de logger).
 * Não faz network.
 */
export function getVersionSync(): string {
  if (memoryCache && Date.now() < memoryCache.expiresAt) {
    return memoryCache.version;
  }
  const file = readCacheFileSync();
  if (file) {
    memoryCache = file;
    return file.version;
  }
  return FALLBACK_VERSION;
}

/**
 * Retorna info completa síncrona se cache existir, senão fallback object.
 */
export function getVersionInfoSync(): AntigravityVersionInfo {
  if (memoryCache && Date.now() < memoryCache.expiresAt) {
    return memoryCache;
  }
  const file = readCacheFileSync();
  if (file) {
    memoryCache = file;
    return file;
  }
  const now = Date.now();
  return {
    version: FALLBACK_VERSION,
    fullVersion: FALLBACK_FULL_VERSION,
    source: "hardcoded-fallback",
    fetchedAt: now,
    expiresAt: now + VERSION_CACHE_TTL_MS,
  };
}

/** Invalida ambos caches (memória + disco) */
export async function invalidateVersionCache(): Promise<void> {
  memoryCache = null;
  inflightPromise = null;
  try {
    await fs.promises.unlink(VERSION_CACHE_FILE);
  } catch {
    // inexistente ou sem permissão - ignora
  }
}

/** Apenas memória */
export function invalidateMemoryCache(): void {
  memoryCache = null;
  inflightPromise = null;
}

/**
 * Resolve UA dinâmico variando plataforma (darwin/linux/win32) para bypass consistente.
 * Usa versão Antigravity fetchada para compor header Client-Metadata opcional.
 */
export async function getDynamicUserAgent(): Promise<string> {
  const platform = os.platform(); // 'darwin' | 'linux' | 'win32'
  const arch = os.arch(); // 'arm64' | 'x64' ...
  const key = `${platform}_${arch}` as keyof typeof ANTIGRAVITY_AUTH_CONSTANTS.USER_AGENT_TEMPLATES;
  const template =
    ANTIGRAVITY_AUTH_CONSTANTS.USER_AGENT_TEMPLATES[key] ||
    (platform === "darwin"
      ? ANTIGRAVITY_AUTH_CONSTANTS.USER_AGENT_TEMPLATES.darwin_arm64
      : ANTIGRAVITY_AUTH_CONSTANTS.USER_AGENT_TEMPLATES.linux_x64);

  // Mantém compatível com gemini cli fingerprint, mas injeta versão real no comment se necessário
  // Ex: GeminiCLI/0.35.3 + Antigravity/1.15.8
  const ver = await getVersion().catch(() => FALLBACK_VERSION);
  // Não altera base para não quebrar allowlist, apenas comment adicional seguro
  return template.replace(
    "GitHub)",
    `GitHub; Antigravity/${ver})`
  );
}

/**
 * Helper para comparar se precisa atualizar (semver gt)
 */
export function isNewerVersion(a: string, b: string): boolean {
  const toNums = (s: string) => s.split("-")[0].split(".").map((n) => parseInt(n, 10) || 0);
  const A = toNums(a);
  const B = toNums(b);
  for (let i = 0; i < Math.max(A.length, B.length); i++) {
    const av = A[i] || 0;
    const bv = B[i] || 0;
    if (av > bv) return true;
    if (av < bv) return false;
  }
  return false;
}

/** Export padrão para import default opcional */
const versionModule = {
  REMOTE_MANIFEST_URLS,
  CHANGELOG_URLS,
  FALLBACK_VERSION,
  FALLBACK_FULL_VERSION,
  FALLBACK_ALTERNATIVE_VERSION,
  FALLBACK_ALTERNATIVE_FULL,
  VERSION_CACHE_FILE,
  VERSION_CACHE_TTL_MS,
  fetchAntigravityVersion,
  getVersion,
  getVersionInfo,
  getVersionSync,
  getVersionInfoSync,
  parseAntigravityVersion,
  fetchWithTimeout,
  invalidateVersionCache,
  invalidateMemoryCache,
  getDynamicUserAgent,
  isNewerVersion,
  ANTIGRAVITY_AUTH_CONSTANTS,
};

export default versionModule;
