/**
 * @fileoverview request-helpers.ts - ONDA 3 - Módulos Core
 * @module auth/request-helpers
 * @description Helpers de limpeza de schema, normalização de mensagens,
 *              geração de IDs, config de thinking e validação para o plugin
 *              opencode-antigravity-auth com bypass Gemini CLI.
 *
 *              Produção-ready, zero deps externas (apenas node:* builtins + fetch global).
 *              Contexto bypass:
 *                Client ID 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j
 *                Secret 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
 *                UA GeminiCLI/0.35.3 + X-Goog-Api-Client gl-node/22.19.0
 *                Client-Metadata ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 *                Endpoints cloudcode-pa.googleapis.com v1internal
 *                Project fallback rising-fact-p41fc
 *                Models 2026 list (antigravity + gemini native)
 *
 * @author ONDA 3 - Módulos Core
 * @license MIT
 * @since 2026
 */

import * as os from "node:os";
import * as crypto from "node:crypto";

// ============================================================================
// 00. CONSTANTES CANÔNICAS DO BYPASS (duplicadas localmente para zero-dep)
// ============================================================================

export const GEMINI_CLI_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;
export const GEMINI_CLI_CLIENT_SECRET = "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" as const;

export const GEMINI_CLI_USER_AGENT = "GeminiCLI/0.35.3" as const;
export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;
export const CLIENT_METADATA_RAW =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const CLOUDCODE_PA_BASE = "https://cloudcode-pa.googleapis.com" as const;
export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;

// Modelos 2026 oficiais do plugin (antigravity + gemini native)
export const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type ModelId2026 = (typeof MODELS_2026)[number];

// Set rápido para lookup
const MODELS_2026_SET = new Set<string>(MODELS_2026 as readonly string[]);

// ============================================================================
// 01. FNV-1a DETERMINÍSTICO - CORE PARA buildUserPromptId E fingerprint
// ============================================================================

const FNV_OFFSET_32 = 0x811c9dc5; // 2166136261
const FNV_PRIME_32 = 0x01000193; // 16777619

/**
 * FNV-1a 32-bit determinístico sobre UTF-8 bytes.
 * Zero deps, puro JS + Buffer (node builtin).
 */
export function fnv1a32(input: string): number {
  let hash = FNV_OFFSET_32;
  const buf = Buffer.from(input, "utf8");
  for (let i = 0; i < buf.length; i++) {
    hash ^= buf[i]!;
    // Math.imul garante 32-bit mul wrap correto
    hash = Math.imul(hash, FNV_PRIME_32) >>> 0;
  }
  return hash >>> 0;
}

const FNV_OFFSET_64 = 14695981039346656037n;
const FNV_PRIME_64 = 1099511628211n;

export function fnv1a64(input: string): bigint {
  let hash = FNV_OFFSET_64;
  const buf = Buffer.from(input, "utf8");
  for (let i = 0; i < buf.length; i++) {
    hash ^= BigInt(buf[i]!);
    hash = (hash * FNV_PRIME_64) & 0xffffffffffffffffn; // 64-bit wrap
  }
  return hash;
}

function toHex8(n: number): string {
  return (n >>> 0).toString(16).padStart(8, "0");
}
function toHex16(n: bigint): string {
  return n.toString(16).padStart(16, "0");
}

// ============================================================================
// 02. buildUserPromptId() - FNV-1a determinístico
// ============================================================================

export interface BuildPromptIdOptions {
  /** Prefixo custom, default "agyp_" */
  prefix?: string;
  /** Seed extra para desempate - ex: projectId, sessionId */
  seed?: string;
  /** Incluir timestamp? false para determinístico puro */
  includeTimestamp?: boolean;
  /** Tamanho do hash 32 ou 64 chars: 'short' 8 chars, 'long' 16+8 */
  length?: "short" | "long";
}

/**
 * Gera ID determinístico de user prompt via FNV-1a.
 * Mesma entrada => mesmo ID. Sem random.
 *
 * @param input - conteúdo do prompt ou objeto (será JSON.stringify). Se omitido, usa hostname+cwd+pid para estabilidade por workspace
 * @param opts - opções de prefixo/seed
 * @returns string id tipo agyp_1a2b3c4d ou agyp_1a2b3c4d-9f8e7d6c5b4a3921
 *
 * @example
 * buildUserPromptId("hello world") => "agyp_5a79f2cc"
 * buildUserPromptId({role:"user", text:"hi"}, {seed:"rising-fact-p41fc", length:"long"})
 */
export function buildUserPromptId(
  input?: string | object | null | undefined,
  opts?: BuildPromptIdOptions | string,
): string {
  // compat: segundo arg pode ser seed string direto
  let options: BuildPromptIdOptions = {};
  if (typeof opts === "string") {
    options = { seed: opts };
  } else if (opts && typeof opts === "object") {
    options = opts;
  }

  const prefix = options.prefix ?? "agyp_";
  const length = options.length ?? "short";

  let baseStr: string;
  if (input == null) {
    // fallback determinístico por workspace - não usa random, usa hostname + cwd + pid estável
    try {
      baseStr = `${os.hostname()}|${process.cwd()}|${process.pid}`;
    } catch {
      baseStr = `fallback|${PROJECT_FALLBACK}`;
    }
  } else if (typeof input === "string") {
    baseStr = input;
  } else {
    try {
      baseStr = JSON.stringify(input);
    } catch {
      baseStr = String(input);
    }
  }

  if (options.seed) {
    baseStr = `${baseStr}|${options.seed}`;
  }

  // Se includeTimestamp true (não determinístico) - desaconselhado, mas suportado
  if (options.includeTimestamp) {
    baseStr = `${baseStr}|${Date.now()}`;
  }

  const h32 = fnv1a32(baseStr);
  if (length === "short") {
    return `${prefix}${toHex8(h32)}`;
  }

  const h64 = fnv1a64(baseStr);
  return `${prefix}${toHex8(h32)}-${toHex16(h64)}`;
}

/**
 * Helper que gera session_id determinístico por diretório (compat com fingerprint.ts)
 */
export function buildSessionIdFromDir(directory?: string): string {
  const dir = directory ?? process.cwd();
  const normalized = dir.replace(/\\/g, "/").toLowerCase();
  const h32 = fnv1a32(normalized);
  const h64 = fnv1a64(normalized);
  // formato semelhante ao usado no Gemini CLI telemetry
  return `sess_${toHex8(h32)}-${toHex16(h64).slice(0, 12)}`;
}

// ============================================================================
// 03. isLikelyAntigravityOnlyModel()
// ============================================================================

const ANTIGRAVITY_ONLY_EXACT = new Set<string>([
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  "gemini-3.1-pro-preview-customtools",
  "gemini-3.1-pro-preview-customtools-thinking",
  "antigravity-gemini-3-pro-thinking",
  "antigravity-gemini-3.1-pro-thinking",
]);

/**
 * Detecta se modelo só funciona via endpoint Antigravity (cloudcode-pa v1internal)
 * e não via genai público. Heurística baseada em prefixos e sufixos.
 *
 * @param modelId - ID do modelo (ex: "antigravity-claude-opus-4-6-thinking")
 * @returns true se provavelmente só funciona em Antigravity
 *
 * Regras:
 * - qualquer modelo começando com antigravity- => true
 * - contém "claude" => true (Claude só via bypass Antigravity)
 * - contém "customtools" => true (customtools é feature Antigravity 2026)
 * - está no set ANTIGRAVITY_ONLY_EXACT
 * - contém "rising-fact" ou "unwritten-orb" etc? Não, esses são projects, não modelos
 */
export function isLikelyAntigravityOnlyModel(modelId: string): boolean {
  if (!modelId || typeof modelId !== "string") return false;
  const id = modelId.trim().toLowerCase();
  if (!id) return false;

  if (id.startsWith("antigravity-")) return true;
  if (ANTIGRAVITY_ONLY_EXACT.has(id)) return true;
  if (id.includes("claude")) return true;
  if (id.includes("customtools")) return true;
  if (id.includes("antigravity")) return true;
  // modelos 3.1 preview com sufixo custom são Antigravity-only na prática
  if (id.includes("3.1") && id.includes("custom")) return true;
  // modelos com thinking + antigravity family
  if (id.includes("-thinking") && id.includes("gemini-3")) {
    // gemini-3 pro nativo não tem thinking nativo, só via antigravity
    // mas mantém simples: se for preview thinking também é antigravity-only
    if (id.startsWith("antigravity-") || id.includes("preview")) {
      // evita falso positivo para gemini-3-pro-preview que é nativo, então só true se tem thinking
      if (id.includes("thinking")) return true;
    }
  }
  return false;
}

// ============================================================================
// 04. cleanToolSchema() - limpeza de JSON Schema para Gemini
// ============================================================================

const DROP_KEYS = new Set<string>([
  "$schema",
  "$id",
  "$comment",
  "$anchor",
  "$defs",
  "definitions",
  "examples",
  "example",
  "deprecated",
  "const", // Gemini não curte const em alguns ver, convertemos para enum
  "format", // mantém? Gemini aceita alguns formatos, mas por segurança remove se for json-specific
]);

const VALID_JSON_TYPES = new Set<string>([
  "string",
  "number",
  "integer",
  "boolean",
  "object",
  "array",
  "null",
]);

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v) && Object.prototype.toString.call(v) === "[object Object]";
}

/**
 * Normaliza campo `type`: se for array com null, mantém tipo principal
 * Se for array com múltiplos tipos, escolhe primeiro não-null
 */
function normalizeTypeField(typeVal: unknown): string | undefined {
  if (typeof typeVal === "string") {
    const low = typeVal.toLowerCase();
    return VALID_JSON_TYPES.has(low) ? low : undefined;
  }
  if (Array.isArray(typeVal)) {
    const filtered = (typeVal as unknown[])
      .map((t) => (typeof t === "string" ? t.toLowerCase() : ""))
      .filter((t) => t && t !== "null" && VALID_JSON_TYPES.has(t));
    if (filtered.length > 0) return filtered[0];
    // fallback
    if ((typeVal as string[]).includes("string")) return "string";
    return undefined;
  }
  return undefined;
}

export interface CleanToolSchemaOptions {
  maxDepth?: number;
  keepFormat?: boolean;
  keepDescription?: boolean;
}

/**
 * Limpa e normaliza JSON Schema de tool para formato aceito por Gemini / Cloud Code Assist.
 *
 * O que faz:
 * - remove $schema, $id, examples, etc
 * - remove chaves undefined / null vazias
 * - normaliza type para lowercase e singular
 * - converte `const: X` para `enum: [X]`
 * - limpa recursivamente properties, items, anyOf/oneOf/allOf
 * - garante que object com properties tenha type=object
 * - remove propriedades vazias
 * - impede profundidade infinita (>20)
 *
 * @param schema - schema bruto (any)
 * @param opts - opções
 * @returns schema limpo
 */
export function cleanToolSchema(schema: unknown, opts?: CleanToolSchemaOptions, _depth = 0): unknown {
  const maxDepth = opts?.maxDepth ?? 20;
  const depth = _depth;

  if (depth > maxDepth) return schema;
  if (schema == null) return schema;
  if (typeof schema === "boolean") return schema;

  if (Array.isArray(schema)) {
    return (schema as unknown[])
      .map((item) => cleanToolSchema(item, opts, depth + 1))
      .filter((v) => v !== undefined);
  }

  if (!isPlainObject(schema)) {
    return schema;
  }

  const out: Record<string, unknown> = {};

  for (const [rawKey, rawVal] of Object.entries(schema as Record<string, unknown>)) {
    if (rawVal === undefined) continue;
    if (DROP_KEYS.has(rawKey)) {
      // exceção: se keepFormat e key é format, mantém
      if (rawKey === "format" && opts?.keepFormat) {
        // mantém apenas formatos seguros para Gemini
        const fmt = String(rawVal).toLowerCase();
        if (["date-time", "date", "enum", "int32", "int64", "double", "float"].includes(fmt)) {
          out[rawKey] = fmt;
        }
        continue;
      }
      // exceção: description sempre mantém por padrão
      continue;
    }

    if (rawKey === "type") {
      const normalized = normalizeTypeField(rawVal);
      if (normalized) out[rawKey] = normalized;
      // se type array incluía null, Gemini usa nullable via `nullable:true`? No Gemini mais novo usa type sem null, mas aceita null em array?
      // Vamos omitir null e não setar nullable para compat. Se precisar, poderia setar out['nullable']=true.
      continue;
    }

    if (rawKey === "const") {
      // const => enum
      out["enum"] = [rawVal];
      continue;
    }

    if (rawKey === "properties" && isPlainObject(rawVal)) {
      const cleanedProps: Record<string, unknown> = {};
      for (const [propKey, propVal] of Object.entries(rawVal as Record<string, unknown>)) {
        const cleaned = cleanToolSchema(propVal, opts, depth + 1);
        if (cleaned !== undefined) cleanedProps[propKey] = cleaned;
      }
      if (Object.keys(cleanedProps).length > 0) out[rawKey] = cleanedProps;
      continue;
    }

    if (rawKey === "items") {
      out[rawKey] = cleanToolSchema(rawVal, opts, depth + 1);
      continue;
    }

    if (rawKey === "additionalProperties") {
      if (typeof rawVal === "boolean") {
        out[rawKey] = rawVal;
      } else if (isPlainObject(rawVal)) {
        out[rawKey] = cleanToolSchema(rawVal, opts, depth + 1);
      }
      continue;
    }

    if (["anyOf", "oneOf", "allOf"].includes(rawKey) && Array.isArray(rawVal)) {
      const cleanedArr = (rawVal as unknown[])
        .map((v) => cleanToolSchema(v, opts, depth + 1))
        .filter((v) => v !== undefined && v !== null) as unknown[];
      if (cleanedArr.length > 0) out[rawKey] = cleanedArr;
      continue;
    }

    if (rawKey === "enum" && Array.isArray(rawVal)) {
      // filtra enums válidos, remove duplicados
      const uniq = [...new Set((rawVal as unknown[]).filter((x) => x != null))];
      if (uniq.length > 0) out[rawKey] = uniq;
      continue;
    }

    if (rawKey === "required" && Array.isArray(rawVal)) {
      const uniq = [...new Set((rawVal as unknown[]).filter((x) => typeof x === "string" && (x as string).length > 0))] as string[];
      if (uniq.length > 0) out[rawKey] = uniq;
      continue;
    }

    // Recursivo genérico para objetos
    if (isPlainObject(rawVal)) {
      const cleaned = cleanToolSchema(rawVal, opts, depth + 1);
      if (cleaned !== undefined && (typeof cleaned !== "object" || Object.keys(cleaned as object).length > 0 || Array.isArray(cleaned))) {
        out[rawKey] = cleaned;
      }
      continue;
    }

    if (Array.isArray(rawVal)) {
      // para arrays genéricos (ex: enum já tratado, mas outros)
      out[rawKey] = rawVal.map((v) => (isPlainObject(v) ? cleanToolSchema(v, opts, depth + 1) : v)).filter((v) => v !== undefined);
      continue;
    }

    // primitivos: string, number, boolean
    out[rawKey] = rawVal;
  }

  // heurística: se tem properties mas não type, assume object
  if (out["properties"] && !out["type"]) {
    out["type"] = "object";
  }
  // se é object mas properties vazio e não tem additionalProperties, remove properties para evitar schema vazio que Gemini rejeita
  if (out["type"] === "object" && out["properties"] && isPlainObject(out["properties"]) && Object.keys(out["properties"] as object).length === 0) {
    delete out["properties"];
  }

  return out;
}

/**
 * Versão plural que limpa mapa de tools ou array de function declarations
 */
export function cleanToolSchemas(
  tools: unknown,
  opts?: CleanToolSchemaOptions,
): unknown {
  if (Array.isArray(tools)) {
    return tools.map((t) => cleanToolSchema(t, opts)).filter(Boolean);
  }
  if (isPlainObject(tools)) {
    // pode ser { functions: [...] } ou { name: { parameters: schema } }
    const obj = tools as Record<string, unknown>;
    if (obj["parameters"] || obj["properties"] || obj["type"]) {
      return cleanToolSchema(obj, opts);
    }
    const cleaned: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj)) {
      cleaned[k] = cleanToolSchema(v, opts);
    }
    return cleaned;
  }
  return cleanToolSchema(tools, opts);
}

// ============================================================================
// 05. validateToolNames()
// ============================================================================

const TOOL_NAME_REGEX = /^[A-Za-z_][A-Za-z0-9_]*$/;
const MAX_TOOL_NAME_LEN = 64;

export interface InvalidToolName {
  name: string;
  reason: string;
}

export interface SanitizedToolName {
  original: string;
  sanitized: string;
}

export interface ValidateToolNamesResult {
  valid: boolean;
  validNames: string[];
  invalid: InvalidToolName[];
  sanitized: SanitizedToolName[];
  allSanitizedValid: boolean;
}

export function sanitizeToolName(name: string): string {
  if (!name || typeof name !== "string") return "_tool";
  let s = name.trim();
  if (!s) return "_tool";
  // troca caracteres inválidos por _
  s = s.replace(/[^A-Za-z0-9_]/g, "_");
  // se começa com dígito, prefixa _
  if (/^[0-9]/.test(s)) s = `_${s}`;
  // se começa com caractere inválido após replace (ex: __), garante letra/_
  if (!/^[A-Za-z_]/.test(s)) s = `_${s}`;
  // truncates 64
  if (s.length > MAX_TOOL_NAME_LEN) s = s.slice(0, MAX_TOOL_NAME_LEN);
  // se após truncar ficou vazio ou inválido
  if (!TOOL_NAME_REGEX.test(s)) {
    // fallback gera nome determinístico via fnv
    const h = toHex8(fnv1a32(name)).slice(0, 8);
    s = `tool_${h}`;
  }
  // remove múltiplos __? mantém, Gemini aceita
  return s;
}

/**
 * Valida lista de nomes de tools. Gemini exige ^[A-Za-z_][A-Za-z0-9_]*$ e max 64.
 *
 * @param tools - array de string, array de {name}, ou Record<string,any>
 * @returns resultado com valid/invalid/sanitized
 */
export function validateToolNames(
  tools: Array<string | { name: string; [k: string]: unknown }> | Record<string, unknown>,
): ValidateToolNamesResult {
  let names: string[] = [];

  if (Array.isArray(tools)) {
    for (const item of tools) {
      if (typeof item === "string") names.push(item);
      else if (isPlainObject(item) && typeof (item as any).name === "string") names.push((item as any).name);
    }
  } else if (isPlainObject(tools)) {
    // se for Record de toolName -> schema, chaves são nomes
    names = Object.keys(tools as Record<string, unknown>);
  }

  // deduplica mantendo ordem para validação, mas mantém duplicatas para report? Vamos dedup para validNames
  const seen = new Set<string>();
  const uniqueNames: string[] = [];
  for (const n of names) {
    if (!seen.has(n)) {
      seen.add(n);
      uniqueNames.push(n);
    }
  }

  const invalid: InvalidToolName[] = [];
  const validNames: string[] = [];
  const sanitized: SanitizedToolName[] = [];

  for (const name of uniqueNames) {
    if (!name || typeof name !== "string") {
      invalid.push({ name: String(name), reason: "empty or not string" });
      sanitized.push({ original: String(name), sanitized: "_tool" });
      continue;
    }
    if (name.length > MAX_TOOL_NAME_LEN) {
      invalid.push({ name, reason: `exceeds ${MAX_TOOL_NAME_LEN} chars` });
    } else if (!TOOL_NAME_REGEX.test(name)) {
      let reason = "must start with letter or underscore and contain only alphanum + underscore";
      if (/^[0-9]/.test(name)) reason = "must not start with digit";
      else if (/[^A-Za-z0-9_]/.test(name)) reason = "contains invalid characters (only A-Za-z0-9_ allowed)";
      else if (!name.length) reason = "empty";
      invalid.push({ name, reason });
    } else {
      validNames.push(name);
    }

    const s = sanitizeToolName(name);
    // se original inválido, adiciona sanitizado
    if (!TOOL_NAME_REGEX.test(name) || name.length > MAX_TOOL_NAME_LEN) {
      sanitized.push({ original: name, sanitized: s });
    }
  }

  const allSanitized = sanitized.map((s) => s.sanitized).concat(validNames);
  const allSanitizedValid = allSanitized.every((n) => TOOL_NAME_REGEX.test(n) && n.length <= MAX_TOOL_NAME_LEN);

  return {
    valid: invalid.length === 0,
    validNames,
    invalid,
    sanitized,
    allSanitizedValid,
  };
}

// ============================================================================
// 06. filterThinkingBlocks()
// ============================================================================

export interface ThoughtLikePart {
  thought?: boolean;
  thinking?: boolean;
  type?: string;
  text?: string;
  content?: string;
  reasoning?: string;
  [k: string]: unknown;
}

/**
 * Remove blocos de thinking/reasoning de conteúdo.
 * Suporta:
 * - string: remove tags <thinking>...</thinking>, <thought>...</thought>, <think>...</think>
 * - array de parts Gemini (com thought:true) => filtra
 * - array de blocks OpenCode-like
 */

const THINKING_TAG_REGEX = /<(thinking|thought|think|reasoning|Thought|Thinking)[^>]*>[\s\S]*?<\/\1\s*>/gi;
const THINKING_SELF_CLOSED_REGEX = /<(thinking|thought|think)[^>]*\/>/gi;
const THINKING_INLINE_PREFIX = /^(?:Thought:|Thinking:|Reasoning:)\s*/i;

export function filterThinkingBlocks(input: string): string;
export function filterThinkingBlocks<T extends ThoughtLikePart>(input: T[]): T[];
export function filterThinkingBlocks(input: unknown): unknown;
export function filterThinkingBlocks(input: unknown): unknown {
  if (typeof input === "string") {
    let out = input;
    // remove blocos com tags
    out = out.replace(THINKING_TAG_REGEX, "");
    out = out.replace(THINKING_SELF_CLOSED_REGEX, "");
    // remove múltiplas linhas que são só prefixo Thinking:
    // também limpa artefactos "<thinking>" soltos
    out = out.replace(/<\/?thinking[^>]*>/gi, "");
    out = out.replace(/<\/?thought[^>]*>/gi, "");
    out = out.replace(/<\/?think[^>]*>/gi, "");
    out = out.replace(/<\/?reasoning[^>]*>/gi, "");
    // remove linhas que começam com Thought:
    out = out
      .split("\n")
      .filter((line) => {
        const trimmed = line.trim();
        if (!trimmed) return true;
        // se linha inteira é marcador de thinking, remove
        if (/^(Thought|Thinking|Reasoning):\s*$/i.test(trimmed)) return false;
        return true;
      })
      .join("\n");
    // trim excesso de espaços em branco deixados
    out = out.replace(/\n{3,}/g, "\n\n").trim();
    return out;
  }

  if (Array.isArray(input)) {
    return (input as ThoughtLikePart[]).filter((part) => {
      if (!part || typeof part !== "object") return true;
      // Gemini: { thought: true }
      if ((part as any).thought === true) return false;
      if ((part as any).thinking === true) return false;
      const t = (part as any).type?.toLowerCase?.();
      if (t === "thinking" || t === "thought" || t === "reasoning") return false;
      // conteúdo textual que é apenas thinking tag
      const text = (part as any).text ?? (part as any).content ?? (part as any).reasoning;
      if (typeof text === "string") {
        const trimmed = text.trim();
        if (!trimmed) return true;
        // se conteúdo inteiro está envolto em thinking tags, filtra bloco inteiro
        if (/^<(thinking|thought|think|reasoning)[\s\S]*<\/(thinking|thought|think|reasoning)>$/i.test(trimmed)) return false;
        // se contém apenas tag, filtra
        if (/^<\/?(thinking|thought|think|reasoning)[^>]*>$/i.test(trimmed)) return false;
      }
      return true;
    });
  }

  // se objeto único com parts
  if (isPlainObject(input)) {
    const obj = input as Record<string, unknown>;
    if (Array.isArray(obj["parts"])) {
      return {
        ...obj,
        parts: filterThinkingBlocks(obj["parts"] as unknown[]),
      };
    }
    if (Array.isArray(obj["content"])) {
      return {
        ...obj,
        content: filterThinkingBlocks(obj["content"] as unknown[]),
      };
    }
  }

  return input;
}

// ============================================================================
// 07. normalizeMessages() - OpenCode -> Gemini
// ============================================================================

export interface OpenCodeContentPart {
  type?: string; // "text" | "image_url" | "tool_call" etc
  text?: string;
  image_url?: { url: string; detail?: string };
  // tool
  id?: string;
  tool_call_id?: string;
  name?: string;
  // para compat
  function?: { name: string; arguments: string | object };
  [k: string]: unknown;
}

export interface OpenCodeToolCall {
  id: string;
  type: "function";
  function: { name: string; arguments: string | object };
}

export interface OpenCodeMessage {
  role: "user" | "assistant" | "system" | "tool" | string;
  content: string | OpenCodeContentPart[] | null | undefined;
  name?: string; // function name for tool role or assistant function
  tool_calls?: OpenCodeToolCall[];
  tool_call_id?: string;
  // extra
  [k: string]: unknown;
}

export interface GeminiFunctionCall {
  name: string;
  args: Record<string, unknown>;
}

export interface GeminiFunctionResponse {
  name: string;
  response: Record<string, unknown>;
}

export interface GeminiPart {
  text?: string;
  inlineData?: { mimeType: string; data: string };
  fileData?: { mimeType: string; fileUri: string };
  functionCall?: GeminiFunctionCall;
  functionResponse?: GeminiFunctionResponse;
  thought?: boolean;
  // futuro
  [k: string]: unknown;
}

export interface GeminiContent {
  role: "user" | "model";
  parts: GeminiPart[];
}

export interface GeminiSystemInstruction {
  role: "system";
  parts: GeminiPart[];
}

export interface NormalizedMessagesResult {
  systemInstruction?: GeminiSystemInstruction;
  contents: GeminiContent[];
  /** mensagens originais ignoradas por serem vazias */
  droppedCount: number;
}

/**
 * Converte data URL para mime + base64
 */
function parseDataUrl(url: string): { mimeType: string; data: string } | null {
  const m = url.match(/^data:([^;]+);base64,(.*)$/);
  if (!m) return null;
  return { mimeType: m[1]!, data: m[2]! };
}

function safeJsonParse(str: string): Record<string, unknown> | null {
  try {
    const parsed = JSON.parse(str);
    if (isPlainObject(parsed)) return parsed as Record<string, unknown>;
    // se não for objeto, encapsula
    return { result: parsed } as Record<string, unknown>;
  } catch {
    return null;
  }
}

function contentPartsToGeminiParts(
  content: string | OpenCodeContentPart[] | null | undefined,
): GeminiPart[] {
  if (content == null) return [];
  if (typeof content === "string") {
    if (!content.trim()) return [];
    return [{ text: content }];
  }
  if (Array.isArray(content)) {
    const parts: GeminiPart[] = [];
    for (const part of content) {
      if (!part) continue;
      if (typeof part === "string") {
        // fallback caso array contenha string
        if ((part as unknown as string).trim()) parts.push({ text: part as unknown as string });
        continue;
      }
      const p = part as OpenCodeContentPart;
      if (p.type === "text" && p.text) {
        parts.push({ text: p.text });
      } else if (p.type === "image_url" && p.image_url?.url) {
        const url = p.image_url.url;
        const data = parseDataUrl(url);
        if (data) {
          parts.push({ inlineData: data });
        } else {
          // se for https, Gemini prefere fileData, mas mantemos texto referência para evitar falha
          // poderia baixar, mas zero-dep: mantém como fileUri
          // detecta mime via extensão simples
          parts.push({ fileData: { mimeType: "image/jpeg", fileUri: url } });
        }
      } else if ((p.type === "image" || (p as any).inlineData) && (p as any).inlineData) {
        parts.push({ inlineData: (p as any).inlineData });
      } else if (p.text) {
        // fallback generico com text
        parts.push({ text: p.text });
      } else if ((p as any).content && typeof (p as any).content === "string") {
        parts.push({ text: (p as any).content });
      }
    }
    return parts;
  }
  return [];
}

/**
 * Normaliza lista de mensagens OpenCode (OpenAI-like) para formato Gemini
 * Cloud Code Assist v1internal.
 *
 * - system => systemInstruction (combinado)
 * - user => role user
 * - assistant => role model, com functionCall se tiver tool_calls
 * - tool => role user com functionResponse
 * - filtra thinking blocks automaticamente
 * - merge mensagens consecutivas de mesmo role
 *
 * @param messages - mensagens OpenCode
 * @param opts - includeSystemAsUser? Se true, system vai como user prefixado
 */
export function normalizeMessages(
  messages: OpenCodeMessage[],
  opts?: { mergeConsecutive?: boolean; includeSystemAsUser?: boolean; filterThinking?: boolean },
): NormalizedMessagesResult {
  const mergeConsecutive = opts?.mergeConsecutive ?? true;
  const includeSystemAsUser = opts?.includeSystemAsUser ?? false;
  const filterThinking = opts?.filterThinking ?? true;

  if (!Array.isArray(messages)) {
    return { contents: [], droppedCount: 0 };
  }

  const systemParts: GeminiPart[] = [];
  const contents: GeminiContent[] = [];
  let dropped = 0;

  for (const msg of messages) {
    if (!msg || typeof msg !== "object") {
      dropped++;
      continue;
    }
    const roleRaw = (msg.role ?? "user").toLowerCase();

    // SYSTEM
    if (roleRaw === "system") {
      const parts = contentPartsToGeminiParts(msg.content as any);
      if (parts.length === 0) {
        dropped++;
        continue;
      }
      const filtered = filterThinking ? (filterThinkingBlocks(parts) as GeminiPart[]) : parts;
      if (includeSystemAsUser) {
        // quando solicitado, system vira user com prefixo
        if (filtered.length > 0) {
          contents.push({ role: "user", parts: filtered.map((p) => (p.text ? { text: `[System] ${p.text}` } : p)) });
        }
      } else {
        systemParts.push(...filtered);
      }
      continue;
    }

    // TOOL -> functionResponse
    if (roleRaw === "tool") {
      const toolName = msg.name ?? (msg as any).tool_name ?? msg.tool_call_id ?? "unknown_tool";
      let responseContent: string;
      if (typeof msg.content === "string") responseContent = msg.content;
      else if (Array.isArray(msg.content)) {
        responseContent = (msg.content as OpenCodeContentPart[]).map((p) => p.text ?? "").join("\n");
      } else responseContent = String(msg.content ?? "");

      const parsed = safeJsonParse(responseContent);
      const response: Record<string, unknown> = parsed ?? { content: responseContent };

      const part: GeminiPart = {
        functionResponse: {
          name: toolName,
          response,
        },
      };
      // Gemini exige que functionResponse venha em role user
      contents.push({ role: "user", parts: [part] });
      continue;
    }

    // ASSISTANT -> model
    if (roleRaw === "assistant" || roleRaw === "model" || roleRaw === "bot") {
      const parts: GeminiPart[] = [];

      // text content
      const textParts = contentPartsToGeminiParts(msg.content as any);
      parts.push(...textParts);

      // tool_calls -> functionCall
      if (Array.isArray(msg.tool_calls)) {
        for (const tc of msg.tool_calls) {
          if (!tc || !tc.function?.name) continue;
          let args: Record<string, unknown> = {};
          const rawArgs = tc.function.arguments;
          if (typeof rawArgs === "string") {
            const parsed = safeJsonParse(rawArgs);
            args = parsed ?? { _raw: rawArgs };
            // se raw era string pura, tenta manter objeto
            if (!parsed) {
              // tenta parse novamente como objeto genérico
              try {
                args = JSON.parse(rawArgs) as Record<string, unknown>;
              } catch {
                args = { input: rawArgs };
              }
            }
          } else if (isPlainObject(rawArgs)) {
            args = rawArgs as Record<string, unknown>;
          }
          // sanitize function name via nossa validação
          const cleanName = sanitizeToolName(tc.function.name);
          parts.push({ functionCall: { name: cleanName, args } });
        }
      }

      if (parts.length === 0) {
        dropped++;
        continue;
      }
      const filtered = filterThinking ? (filterThinkingBlocks(parts) as GeminiPart[]) : parts;
      if (filtered.length === 0) {
        dropped++;
        continue;
      }
      contents.push({ role: "model", parts: filtered });
      continue;
    }

    // USER (default)
    {
      const parts = contentPartsToGeminiParts(msg.content as any);
      if (parts.length === 0) {
        dropped++;
        continue;
      }
      const filtered = filterThinking ? (filterThinkingBlocks(parts) as GeminiPart[]) : parts;
      if (filtered.length === 0) {
        dropped++;
        continue;
      }
      contents.push({ role: "user", parts: filtered });
    }
  }

  // Merge consecutivo mesmo role
  let finalContents = contents;
  if (mergeConsecutive && contents.length > 1) {
    const merged: GeminiContent[] = [];
    let cur: GeminiContent | null = null;
    for (const c of contents) {
      if (cur && cur.role === c.role) {
        cur.parts.push(...c.parts);
      } else {
        if (cur) merged.push(cur);
        cur = { role: c.role, parts: [...c.parts] };
      }
    }
    if (cur) merged.push(cur);
    finalContents = merged;
  }

  const result: NormalizedMessagesResult = {
    contents: finalContents,
    droppedCount: dropped,
  };

  if (systemParts.length > 0) {
    result.systemInstruction = { role: "system", parts: systemParts };
  }

  return result;
}

// ============================================================================
// 08. buildGenerationConfig() - thinkingLevel -> thinkingBudget
// ============================================================================

export type ThinkingLevel = "minimal" | "low" | "medium" | "high" | "none" | string;

export const THINKING_LEVEL_TO_BUDGET_GEMINI: Record<string, number> = {
  none: 0,
  minimal: 0, // 0 desativa thinking em Gemini nativo
  low: 1024,
  medium: 4096,
  high: 8192,
  ultra: 16384,
};

export const THINKING_LEVEL_TO_BUDGET_CLAUDE: Record<string, number> = {
  none: 0,
  minimal: 1024,
  low: 2048,
  medium: 8192,
  high: 16384,
  ultra: 32768,
};

export interface BuildGenerationConfigOptions {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxTokens?: number; // alias para maxOutputTokens
  maxOutputTokens?: number;
  thinkingLevel?: ThinkingLevel;
  thinkingBudget?: number; // override direto
  includeThoughts?: boolean;
  modelId?: string;
  stopSequences?: string[];
  candidateCount?: number;
  presencePenalty?: number;
  frequencyPenalty?: number;
  // extras Gemini
  responseMimeType?: string;
}

export interface GeminiGenerationConfig {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxOutputTokens?: number;
  stopSequences?: string[];
  candidateCount?: number;
  presencePenalty?: number;
  frequencyPenalty?: number;
  thinkingConfig?: {
    thinkingLevel?: string;
    thinkingBudget?: number;
    includeThoughts?: boolean;
  };
  responseMimeType?: string;
  [k: string]: unknown;
}

/**
 * Constrói GenerationConfig para cloudcode-pa v1internal.
 * Mapeia thinkingLevel (minimal/low/medium/high) para thinkingBudget.
 *
 * - Para modelos Gemini: minimal=0 (desativa), low=1024, medium=4096, high=8192
 * - Para modelos Claude (via Antigravity): budgets maiores
 * - Se thinkingBudget direto fornecido, usa direto
 * - Se thinkingLevel=none/minimal com includeThoughts=false, omite includeThoughts para economia
 *
 * @param opts - opções de geração
 * @returns config compatível com v1internal:generateContent
 */
export function buildGenerationConfig(opts: BuildGenerationConfigOptions = {}): GeminiGenerationConfig {
  const config: GeminiGenerationConfig = {};

  if (typeof opts.temperature === "number" && !Number.isNaN(opts.temperature)) {
    config.temperature = Math.max(0, Math.min(2, opts.temperature));
  }
  if (typeof opts.topP === "number" && !Number.isNaN(opts.topP)) {
    config.topP = Math.max(0, Math.min(1, opts.topP));
  }
  if (typeof opts.topK === "number" && !Number.isNaN(opts.topK)) {
    config.topK = Math.max(1, Math.floor(opts.topK));
  }

  const maxT = opts.maxOutputTokens ?? opts.maxTokens;
  if (typeof maxT === "number" && !Number.isNaN(maxT)) {
    config.maxOutputTokens = Math.max(1, Math.floor(maxT));
  }

  if (Array.isArray(opts.stopSequences) && opts.stopSequences.length > 0) {
    config.stopSequences = opts.stopSequences.filter((s) => typeof s === "string" && s.length > 0).slice(0, 5);
  }

  if (typeof opts.candidateCount === "number") {
    config.candidateCount = Math.max(1, Math.min(8, Math.floor(opts.candidateCount)));
  }

  if (opts.responseMimeType) config.responseMimeType = opts.responseMimeType;

  // Pensamento / thinking
  const modelId = (opts.modelId ?? "").toLowerCase();
  const isClaude = modelId.includes("claude") || modelId.includes("opus") || modelId.includes("sonnet");
  const budgetMap = isClaude ? THINKING_LEVEL_TO_BUDGET_CLAUDE : THINKING_LEVEL_TO_BUDGET_GEMINI;

  let budget: number | undefined;
  let levelNorm: string | undefined;

  if (typeof opts.thinkingBudget === "number" && !Number.isNaN(opts.thinkingBudget)) {
    budget = Math.max(0, Math.floor(opts.thinkingBudget));
    levelNorm = opts.thinkingLevel?.toLowerCase?.() ?? (budget === 0 ? "none" : "custom");
  } else if (opts.thinkingLevel) {
    levelNorm = opts.thinkingLevel.toLowerCase().trim();
    if (levelNorm in budgetMap) {
      budget = budgetMap[levelNorm];
    } else {
      // fallback heurístico: tenta mapear sinônimos
      if (["off", "disable", "disabled", "zero"].includes(levelNorm)) {
        budget = 0;
        levelNorm = "none";
      } else if (["min", "minimum"].includes(levelNorm)) {
        budget = budgetMap["minimal"];
        levelNorm = "minimal";
      } else {
        // default medium se desconhecido
        budget = budgetMap["medium"];
      }
    }
  }

  if (budget !== undefined) {
    config.thinkingConfig = {};
    if (levelNorm) config.thinkingConfig.thinkingLevel = levelNorm;
    config.thinkingConfig.thinkingBudget = budget;

    // includeThoughts: só true se budget >0 ou explicitamente pedido
    // Para minimal/none com budget 0, força false para economizar
    let includeThoughts = opts.includeThoughts;
    if (includeThoughts === undefined) {
      includeThoughts = budget > 0;
    }
    config.thinkingConfig.includeThoughts = includeThoughts;

    // Se for Gemini e budget 0 e includeThoughts false, podemos omitir thinkingConfig
    // mas mantemos para clareza, exceto se for none
    if (budget === 0 && !includeThoughts && (levelNorm === "none" || levelNorm === "minimal")) {
      // Para Gemini nativo, remover thinkingConfig quando desativa é válido, mas para Claude mantém 0
      if (!isClaude) {
        // mantém mesmo assim com budget 0 para explicitar desativação
        // não remove
      }
    }
  }

  // presence/frequency - não são nativas Gemini, mas alguns proxies aceitam; mantemos se vierem
  if (typeof opts.presencePenalty === "number") config.presencePenalty = opts.presencePenalty;
  if (typeof opts.frequencyPenalty === "number") config.frequencyPenalty = opts.frequencyPenalty;

  return config;
}

// ============================================================================
// 09. enhanceAgySdkErrorResponse()
// ============================================================================

export interface EnhancedAgyError {
  message: string;
  code?: string;
  status?: number;
  statusText?: string;
  details?: unknown;
  isRetryable: boolean;
  isAuthError: boolean;
  isQuotaError: boolean;
  isModelError: boolean;
  isThinkingBudgetError: boolean;
  original: unknown;
  suggestion?: string;
  requestId?: string;
  modelId?: string;
}

function extractJsonFromText(text: string): Record<string, unknown> | null {
  try {
    return JSON.parse(text) as Record<string, unknown>;
  } catch {
    // tenta extrair json embebido
    const m = text.match(/\{[\s\S]*\}/);
    if (m) {
      try {
        return JSON.parse(m[0]) as Record<string, unknown>;
      } catch {
        return null;
      }
    }
    return null;
  }
}

/**
 * Enriquece erro vindo do Agentic SDK / Cloud Code Assist.
 * Detecta auth, quota, model not found, thinking budget etc e sugere correção.
 *
 * @param error - erro bruto (Error, Response, objeto, string)
 * @param context - contexto opcional com modelId, requestId etc
 */
export function enhanceAgySdkErrorResponse(
  error: unknown,
  context?: { modelId?: string; requestId?: string },
): EnhancedAgyError {
  let message = "Unknown Agentic SDK error";
  let code: string | undefined;
  let status: number | undefined;
  let statusText: string | undefined;
  let details: unknown = undefined;
  let requestId = context?.requestId;
  let modelId = context?.modelId;

  // Normaliza entrada
  if (typeof error === "string") {
    message = error;
    const parsed = extractJsonFromText(error);
    if (parsed) {
      details = parsed;
      if (typeof (parsed as any).message === "string") message = (parsed as any).message;
      if (typeof (parsed as any).error === "string") message = (parsed as any).error;
      if (typeof (parsed as any).code === "string") code = (parsed as any).code;
      // @ts-ignore
      if ((parsed as any).error?.message) message = (parsed as any).error.message;
      // @ts-ignore
      if ((parsed as any).error?.code) code = (parsed as any).error.code;
      // @ts-ignore
      if ((parsed as any).error?.status) code = (parsed as any).error.status;
    }
  } else if (error instanceof Error) {
    message = error.message || message;
    details = { name: error.name, stack: error.stack?.split("\n").slice(0, 5).join("\n") };
    // tenta extrair status de propriedades comuns
    const anyErr = error as any;
    if (typeof anyErr.status === "number") status = anyErr.status;
    if (typeof anyErr.statusCode === "number") status = anyErr.statusCode;
    if (typeof anyErr.code === "string") code = anyErr.code;
    if (typeof anyErr.requestId === "string") requestId = anyErr.requestId;
  } else if (isPlainObject(error)) {
    const obj = error as Record<string, unknown>;
    if (typeof obj["message"] === "string") message = obj["message"] as string;
    else if (typeof (obj["error"] as any)?.message === "string") message = (obj["error"] as any).message;
    else if (typeof obj["error"] === "string") message = obj["error"] as string;

    if (typeof obj["code"] === "string") code = obj["code"] as string;
    else if (typeof (obj["error"] as any)?.code === "string") code = (obj["error"] as any).code;
    else if (typeof obj["status"] === "string") code = obj["status"] as string;

    if (typeof obj["status"] === "number") status = obj["status"] as number;
    if (typeof obj["statusCode"] === "number") status = obj["statusCode"] as number;
    if (typeof obj["httpStatus"] === "number") status = obj["httpStatus"] as number;

    if (typeof obj["statusText"] === "string") statusText = obj["statusText"] as string;
    if (typeof obj["requestId"] === "string") requestId = obj["requestId"] as string;
    if (typeof obj["modelId"] === "string") modelId = obj["modelId"] as string;

    details = obj;
  } else {
    details = error;
    try {
      message = String(error);
    } catch {
      // keep default
    }
  }

  const lowerMsg = message.toLowerCase();
  const lowerCode = (code ?? "").toLowerCase();

  const isAuthError =
    status === 401 ||
    status === 403 ||
    lowerCode.includes("unauthenticated") ||
    lowerCode.includes("permission_denied") ||
    lowerCode.includes("forbidden") ||
    lowerMsg.includes("unauthenticated") ||
    lowerMsg.includes("permission denied") ||
    lowerMsg.includes("unauthorized") ||
    lowerMsg.includes("invalid authentication") ||
    lowerMsg.includes("requires authentication") ||
    lowerMsg.includes("auth") && lowerMsg.includes("failed");

  const isQuotaError =
    status === 429 ||
    lowerCode.includes("resource_exhausted") ||
    lowerCode.includes("quota") ||
    lowerCode.includes("rate_limit") ||
    lowerMsg.includes("quota") ||
    lowerMsg.includes("rate limit") ||
    lowerMsg.includes("too many requests") ||
    lowerMsg.includes("resource exhausted") ||
    lowerMsg.includes("exceeded");

  const isModelError =
    status === 404 ||
    lowerCode.includes("model_not_found") ||
    lowerCode.includes("not_found") && lowerMsg.includes("model") ||
    lowerMsg.includes("model not found") ||
    lowerMsg.includes("unknown model") ||
    lowerMsg.includes("model not supported") ||
    lowerMsg.includes("invalid model");

  const isThinkingBudgetError =
    lowerMsg.includes("thinking") && (lowerMsg.includes("budget") || lowerMsg.includes("token")) ||
    lowerCode.includes("thinking_budget") ||
    lowerMsg.includes("thinkingBudget");

  const isRetryable =
    status === 408 ||
    status === 429 ||
    status === 500 ||
    status === 502 ||
    status === 503 ||
    status === 504 ||
    lowerCode.includes("unavailable") ||
    lowerCode.includes("deadline_exceeded") ||
    lowerCode.includes("aborted") ||
    lowerCode.includes("internal") ||
    (isQuotaError && status === 429); // quota 429 retryable com backoff

  let suggestion: string | undefined;
  if (isAuthError) {
    suggestion = `Reautentique com OAuth: client ${GEMINI_CLI_CLIENT_ID}. Verifique token expirou, escopos ${"https://www.googleapis.com/auth/cloud-platform"}. Tente limpar cache em ~/.config/opencode/auth/ e rodar auth flow novamente. Headers: User-Agent=${GEMINI_CLI_USER_AGENT}, X-Goog-Api-Client=${X_GOOG_API_CLIENT}`;
  } else if (isQuotaError) {
    suggestion = `Quota excedida. Verifique retrieveUserQuotaSummary em ${CLOUDCODE_PA_BASE}/v1internal:retrieveUserQuotaSummary. Troque para modelo fallback ${PROJECT_FALLBACK} ou aguarde reset. Considere modelo alternativo: ${MODELS_2026.filter((m) => !m.includes("claude")).join(", ")}`;
  } else if (isModelError) {
    suggestion = `Modelo ${modelId ?? "desconhecido"} não encontrado. Modelos válidos 2026: ${MODELS_2026.join(", ")}. Verifique se precisa de prefixo antigravity- e endpoint ${CLOUDCODE_PA_BASE}/v1internal. Para Claude use isLikelyAntigravityOnlyModel() para decidir roteamento.`;
  } else if (isThinkingBudgetError) {
    suggestion = `Thinking budget inválido. Use buildGenerationConfig() com thinkingLevel minimal/low/medium/high. Para Gemini: minimal=0, low=1024, medium=4096, high=8192. Para Claude: minimal=1024, low=2048, medium=8192, high=16384. Verifique modelo suporta thinking (claude-opus thinking ou gemini-3 com thinkingConfig).`;
  } else if (isRetryable) {
    suggestion = `Erro transitório (${status ?? code}). Tente novamente com backoff exponencial (500ms base, jitter). Endpoint: ${CLOUDCODE_PA_BASE}/v1internal. Project fallback: ${PROJECT_FALLBACK}.`;
  }

  // Anonimiza secret em mensagem
  const safeMessage = message.replace(/GOCSPX-[A-Za-z0-9\-_]+/g, "[REDACTED_SECRET]");

  return {
    message: safeMessage,
    code,
    status,
    statusText,
    details,
    isRetryable,
    isAuthError,
    isQuotaError,
    isModelError,
    isThinkingBudgetError,
    original: error,
    suggestion,
    requestId,
    modelId,
  };
}

// ============================================================================
// 10. extractVariants()
// ============================================================================

export interface ExtractVariantsResult {
  input: string;
  base: string;
  isAntigravity: boolean;
  isThinking: boolean;
  isCustomTools: boolean;
  isPreview: boolean;
  family: string;
  variants: string[]; // todas variantes geradas
  candidatesInCatalog: string[]; // filtradas que existem em MODELS_2026
  relatedModels: Array<{ id: string; inCatalog: boolean }>;
}

/**
 * Extrai variantes de um modelId, removendo prefixos/sufixos e gerando candidatos.
 *
 * Ex: "antigravity-claude-opus-4-6-thinking" =>
 *   base: "claude-opus-4-6"
 *   variants: ["antigravity-claude-opus-4-6-thinking", "antigravity-claude-opus-4-6", "claude-opus-4-6-thinking", "claude-opus-4-6", ...]
 */
export function extractVariants(modelId: string): ExtractVariantsResult {
  if (!modelId || typeof modelId !== "string") {
    return {
      input: String(modelId),
      base: String(modelId),
      isAntigravity: false,
      isThinking: false,
      isCustomTools: false,
      isPreview: false,
      family: String(modelId),
      variants: [],
      candidatesInCatalog: [],
      relatedModels: [],
    };
  }

  const original = modelId.trim();
  const lower = original.toLowerCase();

  const isAntigravity = lower.startsWith("antigravity-") || lower.includes("antigravity");
  const isThinking = lower.includes("thinking");
  const isCustomTools = lower.includes("customtools") || lower.includes("custom_tools") || lower.includes("custom-tools");
  const isPreview = lower.includes("preview");

  // Remove prefixo antigravity-
  let base = lower;
  if (base.startsWith("antigravity-")) base = base.slice("antigravity-".length);

  // Remove sufixos iterativamente: -thinking, -customtools, -preview-customtools, -preview, -custom
  const suffixes = [
    "-thinking",
    "-customtools",
    "-custom_tools",
    "-custom-tools",
    "-preview-customtools",
    "-preview",
    "-custom",
  ];
  let changed = true;
  while (changed) {
    changed = false;
    for (const suf of suffixes) {
      if (base.endsWith(suf)) {
        base = base.slice(0, -suf.length);
        changed = true;
        break;
      }
    }
  }

  // base limpo ainda pode ter -preview no meio? Remove novamente
  // family é base + heurística de família (ex: gemini-3-pro)
  const family = base;

  // Gera variantes combinatórias
  const variantSet = new Set<string>();

  const prefixes = ["", "antigravity-"];
  const suffixCombos = [
    "",
    "-preview",
    "-preview-customtools",
    "-customtools",
    "-thinking",
    "-preview-thinking",
  ];

  // Gera todas combinações prefixo + base + sufixo
  for (const pre of prefixes) {
    for (const suf of suffixCombos) {
      variantSet.add(`${pre}${base}${suf}`);
    }
  }

  // Adiciona também variações com base original + antigravity
  variantSet.add(original.toLowerCase());
  variantSet.add(`antigravity-${base}`);
  if (isThinking) {
    variantSet.add(`${base}-thinking`);
    variantSet.add(`antigravity-${base}-thinking`);
  }
  if (isCustomTools) {
    variantSet.add(`${base}-preview-customtools`);
    variantSet.add(`antigravity-${base}-preview-customtools`);
    variantSet.add(`${base}-customtools`);
  }

  // Variantes específicas Claude
  if (base.includes("claude")) {
    variantSet.add(`antigravity-${base}`);
    variantSet.add(`antigravity-${base}-thinking`);
    variantSet.add(`${base}-thinking`);
  }

  // Variantes gemini 2.5/3.x
  if (base.startsWith("gemini-")) {
    variantSet.add(base);
    variantSet.add(`${base}-preview`);
    variantSet.add(`antigravity-${base}`);
    // gemini-3-pro => gemini-3-pro-preview
    if (!base.includes("preview") && base.match(/^gemini-\d/)) {
      variantSet.add(`${base}-preview`);
      variantSet.add(`antigravity-${base}`);
    }
  }

  // Normaliza e deduplica, remove vazios
  const variants = [...variantSet].filter((v) => v && v.length > 2).sort();

  const candidatesInCatalog = variants.filter((v) => MODELS_2026_SET.has(v));
  const relatedModels = variants.map((id) => ({ id, inCatalog: MODELS_2026_SET.has(id) }));

  return {
    input: original,
    base,
    isAntigravity,
    isThinking,
    isCustomTools,
    isPreview,
    family,
    variants,
    candidatesInCatalog,
    relatedModels,
  };
}

/**
 * Helper que extrai variantes de lista ou objeto
 */
export function extractVariantsFromAny(input: unknown): ExtractVariantsResult[] {
  if (typeof input === "string") return [extractVariants(input)];
  if (Array.isArray(input)) {
    const out: ExtractVariantsResult[] = [];
    for (const item of input) {
      if (typeof item === "string") out.push(extractVariants(item));
      else if (isPlainObject(item) && typeof (item as any).id === "string") out.push(extractVariants((item as any).id));
      else if (isPlainObject(item) && typeof (item as any).model === "string") out.push(extractVariants((item as any).model));
    }
    return out;
  }
  if (isPlainObject(input)) {
    const keys = Object.keys(input as object);
    // se chaves parecem model ids
    if (keys.every((k) => k.includes("gemini") || k.includes("claude") || k.includes("antigravity"))) {
      return keys.map((k) => extractVariants(k));
    }
  }
  return [];
}

// ============================================================================
// 11. DEFAULT EXPORT + NAMED EXPORTS BUNDLE
// ============================================================================

export const RequestHelpers = {
  // constants
  GEMINI_CLI_CLIENT_ID,
  GEMINI_CLI_CLIENT_SECRET,
  GEMINI_CLI_USER_AGENT,
  X_GOOG_API_CLIENT,
  CLIENT_METADATA_RAW,
  CLOUDCODE_PA_BASE,
  PROJECT_FALLBACK,
  MODELS_2026,

  // core
  fnv1a32,
  fnv1a64,
  buildUserPromptId,
  buildSessionIdFromDir,
  isLikelyAntigravityOnlyModel,
  cleanToolSchema,
  cleanToolSchemas,
  validateToolNames,
  sanitizeToolName,
  filterThinkingBlocks,
  normalizeMessages,
  buildGenerationConfig,
  enhanceAgySdkErrorResponse,
  extractVariants,
  extractVariantsFromAny,

  // mappings
  THINKING_LEVEL_TO_BUDGET_GEMINI,
  THINKING_LEVEL_TO_BUDGET_CLAUDE,
} as const;

export default RequestHelpers;
