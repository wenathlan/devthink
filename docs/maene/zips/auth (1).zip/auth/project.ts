/**
 * @fileoverview project.ts - Descoberta de Project ID para opencode-antigravity-auth
 * @module auth/project
 * @description
 *  Lógica completa de descoberta de Project ID via Cloud Code Assist.
 *  Produção-ready, apenas node:* builtins + fetch global (zero deps externas).
 *
 *  Contexto bypass Gemini CLI:
 *  - Client ID: 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com
 *  - Secret: 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 (público no binário CLI)
 *  - User-Agent: GeminiCLI/0.35.3
 *  - X-Goog-Api-Client: gl-node/22.19.0
 *  - Client-Metadata: ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 *  - Endpoints: cloudcode-pa.googleapis.com / daily-cloudcode-pa.googleapis.com / staging-cloudcode-pa.googleapis.com v1internal
 *  - Project fallback: rising-fact-p41fc
 *  - Models 2026: antigravity-*, gemini-2.5-*, gemini-3-*, claude family
 *
 *  Fluxo:
 *  1. loadCodeAssist(token) -> POST v1internal:loadCodeAssist com metadata GEMINI
 *  2. se cloudaicompanionProject vazio -> onboardUser(token)
 *  3. fetchAvailableModels(token, projectId) -> GET lista de modelos
 *  4. resolveProjectId(token, account) -> retry com fallback PROD/DAILY/SANDBOX, timeout 10s, cache Map, salva em metadata, fallback com warning
 *
 * @author ONDA 3 - Módulos Core
 * @license MIT
 * @since 2026
 */

import * as crypto from "node:crypto";
import * as os from "node:os";

// ============================================================================
// 01. CONSTANTS - BYPASS IDENTIFICATION
// ============================================================================

export const OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;

export const OAUTH_CLIENT_SECRET =
  "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" as const;

export const GEMINI_CLI_USER_AGENT = "GeminiCLI/0.35.3" as const;

export const GOOGLE_API_NODE_VERSION = "22.19.0" as const;

export const X_GOOG_API_CLIENT = `gl-node/${GOOGLE_API_NODE_VERSION}` as const;

export const CLIENT_METADATA_STRING =
  "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI" as const;

export const CLIENT_METADATA = {
  ideType: "IDE_UNSPECIFIED",
  platform: "PLATFORM_UNSPECIFIED",
  pluginType: "GEMINI",
} as const;

export const FALLBACK_PROJECT_ID = "rising-fact-p41fc" as const;

export const REQUEST_TIMEOUT_MS = 10_000 as const;

export const PROJECT_CACHE_TTL_MS = 60 * 60 * 1000 as const; // 1h

// ============================================================================
// 02. ENDPOINTS - PROD / DAILY / SANDBOX
// ============================================================================

export const ENDPOINT_BASES = [
  {
    name: "PROD" as const,
    base: "https://cloudcode-pa.googleapis.com",
  },
  {
    name: "DAILY" as const,
    base: "https://daily-cloudcode-pa.googleapis.com",
  },
  {
    name: "SANDBOX" as const,
    base: "https://staging-cloudcode-pa.googleapis.com",
  },
  // Extra hardening - preprod observado em telemetry
  {
    name: "PREPROD" as const,
    base: "https://preprod-cloudcode-pa.googleapis.com",
  },
] as const;

export type EndpointName = (typeof ENDPOINT_BASES)[number]["name"];

export interface EndpointDef {
  name: EndpointName;
  base: string;
}

export const CODE_ASSIST_PATHS = {
  LOAD: "/v1internal:loadCodeAssist",
  ONBOARD: "/v1internal:onboardUser",
  FETCH_MODELS: "/v1internal:fetchAvailableModels",
} as const;

function buildUrl(base: string, path: string): string {
  return `${base}${path}`;
}

// ============================================================================
// 03. MODELS 2026
// ============================================================================

export const MODELS_2026 = [
  // Antigravity Custom - Gemini
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  // Antigravity Custom - Claude via bypass
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  // Google Native - 2.5
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  // Google Native - 3.x preview
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type Model2026 = (typeof MODELS_2026)[number];

// ============================================================================
// 04. TYPES
// ============================================================================

export interface Account {
  /** Email do usuário (chave primária para cache) */
  email?: string;
  /** ID interno opencode */
  id?: string;
  /** Project ID já resolvido anteriormente */
  projectId?: string;
  /** Metadata mutável onde salvamos project */
  metadata?: {
    projectId?: string;
    cloudaicompanionProject?: string;
    lastResolvedAt?: number;
    resolvedFrom?: EndpointName | "cache" | "metadata" | "fallback";
    lastModels?: string[];
    [key: string]: unknown;
  };
  [key: string]: unknown;
}

export interface LoadCodeAssistResponse {
  cloudaicompanionProject?: string;
  currentTier?: {
    id?: string;
    name?: string;
  };
  projectId?: string;
  codeAssistProject?: string;
  cloudaicompanionProjectId?: string;
  allowedTiers?: Array<{ id: string; isDefault?: boolean }>;
  currentManagedProject?: string;
  // Formatos alternativos observados
  companionProject?: string;
  project?: {
    id?: string;
    name?: string;
  };
  // payload raw para debug
  _raw?: unknown;
}

export interface OnboardUserResponse {
  cloudaicompanionProject?: string;
  projectId?: string;
  response?: {
    cloudaicompanionProject?: {
      id?: string;
      projectId?: string;
    };
  };
  done?: boolean;
  _raw?: unknown;
}

export interface FetchModelsResponse {
  models?: Array<string | { name: string; displayName?: string; id?: string }>;
  availableModels?: Array<string | { name: string }>;
  // Fallbacks
  modelList?: string[];
  _raw?: unknown;
}

export interface ResolvedProject {
  projectId: string;
  source: EndpointName | "cache" | "metadata" | "fallback";
  fromCache: boolean;
  endpointBase?: string;
  models?: string[];
}

interface CacheEntry {
  projectId: string;
  fetchedAt: number;
  source: EndpointName | "metadata" | "fallback";
  endpointBase?: string;
}

// ============================================================================
// 05. IN-MEMORY CACHE
// ============================================================================

/**
 * Cache em memória de Project ID por account/email/token hash
 * Evita chamadas repetidas a loadCodeAssist
 */
export const projectCache: Map<string, CacheEntry> = new Map();

function getCacheKey(token: string, account?: Account): string {
  if (account?.email) return `email:${account.email.toLowerCase().trim()}`;
  if (account?.id) return `id:${account.id}`;
  // hash do token para não armazenar token em claro como key
  try {
    const hash = crypto.createHash("sha256").update(token).digest("hex").slice(0, 16);
    return `token:${hash}`;
  } catch {
    // fallback sem crypto
    return `token:${token.slice(-12)}`;
  }
}

export function clearProjectCache(): void {
  projectCache.clear();
}

export function getProjectCacheSnapshot(): ReadonlyMap<string, CacheEntry> {
  return projectCache;
}

function isCacheValid(entry: CacheEntry): boolean {
  return Date.now() - entry.fetchedAt < PROJECT_CACHE_TTL_MS;
}

// ============================================================================
// 06. HEADERS & FETCH HELPERS
// ============================================================================

export function buildGeminiHeaders(token: string): Record<string, string> {
  if (!token || typeof token !== "string" || token.trim().length === 0) {
    throw new Error("buildGeminiHeaders: token is required and must be non-empty string");
  }
  return {
    Authorization: `Bearer ${token.trim()}`,
    "Content-Type": "application/json",
    Accept: "application/json",
    "User-Agent": GEMINI_CLI_USER_AGENT,
    "X-Goog-Api-Client": X_GOOG_API_CLIENT,
    "Client-Metadata": CLIENT_METADATA_STRING,
    // Extras para compatibilidade com gaxios / google-api-nodejs-client fingerprint
    "X-Client-Details": `ideType=${CLIENT_METADATA.ideType},platform=${CLIENT_METADATA.platform},pluginType=${CLIENT_METADATA.pluginType}`,
    "X-Goog-User-Project": FALLBACK_PROJECT_ID, // hint inicial, server overwrite com real
  };
}

export async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number = REQUEST_TIMEOUT_MS,
): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, {
      ...init,
      signal: controller.signal,
    });
    return resp;
  } catch (err) {
    if ((err as Error).name === "AbortError") {
      throw new Error(`Timeout after ${timeoutMs}ms for ${url}`);
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

function extractProjectId(payload: unknown): string | null {
  if (!payload || typeof payload !== "object") return null;
  const obj = payload as Record<string, unknown>;

  // 1. campo direto string
  const directCandidates: unknown[] = [
    obj.cloudaicompanionProject,
    obj.cloudaicompanionProjectId,
    obj.projectId,
    obj.codeAssistProject,
    obj.companionProject,
    obj.currentManagedProject,
    (obj.project as Record<string, unknown> | undefined)?.id,
    (obj.response as Record<string, unknown> | undefined)?.cloudaicompanionProject,
  ];

  for (const cand of directCandidates) {
    if (typeof cand === "string" && cand.trim().length > 0) {
      return cand.trim();
    }
    // objeto { id: string } ou { projectId: string }
    if (cand && typeof cand === "object") {
      const c = cand as Record<string, unknown>;
      if (typeof c.id === "string" && c.id.trim()) return c.id.trim();
      if (typeof c.projectId === "string" && c.projectId.trim()) return c.projectId.trim();
    }
  }

  // 2. nested response.response.cloudaicompanionProject.id
  try {
    const resp = obj.response as Record<string, unknown> | undefined;
    if (resp) {
      const inner = resp.cloudaicompanionProject as unknown;
      if (typeof inner === "string" && inner.trim()) return inner.trim();
      if (inner && typeof inner === "object") {
        const i = inner as Record<string, unknown>;
        if (typeof i.id === "string" && i.id.trim()) return i.id.trim();
        if (typeof i.projectId === "string" && i.projectId.trim()) return i.projectId.trim();
      }
      // response.cloudaicompanionProjectId (inner)
      if (typeof (resp as Record<string, unknown>).cloudaicompanionProjectId === "string") {
        const v = (resp as Record<string, unknown>).cloudaicompanionProjectId as string;
        if (v.trim()) return v.trim();
      }
    }
  } catch {
    // ignore
  }

  return null;
}

// ============================================================================
// 07. loadCodeAssist
// ============================================================================

/**
 * Carrega Code Assist para descobrir project ID vinculado à conta.
 * POST https://cloudcode-pa.googleapis.com/v1internal:loadCodeAssist
 * Payload: { metadata: { ideType, platform, pluginType: GEMINI } }
 * Headers: Gemini CLI masquerade
 *
 * @param token - OAuth2 access_token válido
 * @param baseUrl - opcional, endpoint base para retry (default PROD)
 */
export async function loadCodeAssist(
  token: string,
  baseUrl?: string,
): Promise<LoadCodeAssistResponse> {
  if (!token) throw new Error("loadCodeAssist: token required");

  const base = baseUrl ?? ENDPOINT_BASES[0].base;
  const url = buildUrl(base, CODE_ASSIST_PATHS.LOAD);

  const headers = buildGeminiHeaders(token);

  // Body mínima que bypassa WAF - metadata GEMINI é obrigatório
  const body = JSON.stringify({
    metadata: {
      ideType: CLIENT_METADATA.ideType,
      platform: CLIENT_METADATA.platform,
      pluginType: CLIENT_METADATA.pluginType,
    },
  });

  const resp = await fetchWithTimeout(
    url,
    {
      method: "POST",
      headers,
      body,
    },
    REQUEST_TIMEOUT_MS,
  );

  if (!resp.ok) {
    const text = await resp.text().catch(() => "<no body>");
    throw new Error(
      `loadCodeAssist failed [${base}] ${resp.status} ${resp.statusText}: ${text.slice(0, 500)}`,
    );
  }

  let json: unknown;
  try {
    json = await resp.json();
  } catch {
    throw new Error(`loadCodeAssist: invalid JSON response from ${base}`);
  }

  const projectId = extractProjectId(json);
  return {
    ...(json as object),
    cloudaicompanionProject: projectId ?? undefined,
    _raw: json,
  } as LoadCodeAssistResponse;
}

// ============================================================================
// 08. onboardUser
// ============================================================================

/**
 * Onboarding quando loadCodeAssist retorna vazio.
 * POST https://cloudcode-pa.googleapis.com/v1internal:onboardUser
 * Chamado apenas se cloudaicompanionProject estiver vazio.
 *
 * @param token - OAuth2 access_token
 * @param baseUrl - opcional base para retry
 * @param tierId - opcional, default free-tier
 */
export async function onboardUser(
  token: string,
  baseUrl?: string,
  tierId: string = "free-tier",
): Promise<OnboardUserResponse> {
  if (!token) throw new Error("onboardUser: token required");

  const base = baseUrl ?? ENDPOINT_BASES[0].base;
  const url = buildUrl(base, CODE_ASSIST_PATHS.ONBOARD);

  const headers = buildGeminiHeaders(token);

  // Payload observado em Gemini CLI e Antigravity telemetry
  // - tierId é necessário para criar projeto
  // - metadata GEMINI é obrigatório para bypass
  // - cloudaicompanionProject pode ser vazio ou FALLBACK para forçar criação
  const body = JSON.stringify({
    tierId,
    cloudaicompanionProject: FALLBACK_PROJECT_ID,
    metadata: {
      ideType: CLIENT_METADATA.ideType,
      platform: CLIENT_METADATA.platform,
      pluginType: CLIENT_METADATA.pluginType,
      // extras para compatibilidade com Antigravity IDE
      duetProject: FALLBACK_PROJECT_ID,
    },
  });

  const resp = await fetchWithTimeout(
    url,
    {
      method: "POST",
      headers,
      body,
    },
    REQUEST_TIMEOUT_MS,
  );

  if (!resp.ok) {
    const text = await resp.text().catch(() => "<no body>");
    // 409 pode indicar já onboarded - tratamos como não-erro se body contém project
    if (resp.status === 409) {
      try {
        const j = JSON.parse(text) as unknown;
        const pid = extractProjectId(j);
        if (pid) {
          return { cloudaicompanionProject: pid, _raw: j } as OnboardUserResponse;
        }
      } catch {
        // fall through
      }
    }
    throw new Error(
      `onboardUser failed [${base}] ${resp.status} ${resp.statusText}: ${text.slice(0, 500)}`,
    );
  }

  let json: unknown;
  try {
    json = await resp.json();
  } catch {
    // alguns endpoints retornam empty object on success
    return { _raw: {} } as OnboardUserResponse;
  }

  const pid = extractProjectId(json);
  return {
    ...(json as object),
    cloudaicompanionProject: pid ?? undefined,
    _raw: json,
  } as OnboardUserResponse;
}

// ============================================================================
// 09. fetchAvailableModels
// ============================================================================

/**
 * Lista modelos disponíveis para o usuário/projeto.
 * Spec diz GET, mas API real opera via POST com metadata e project.
 * Implementação faz GET por spec, com fallback POST para compatibilidade real.
 *
 * @param token - access_token
 * @param projectId - project ID resolvido (ex: rising-fact-p41fc ou real)
 * @param baseUrl - opcional base para retry
 */
export async function fetchAvailableModels(
  token: string,
  projectId: string,
  baseUrl?: string,
): Promise<string[]> {
  if (!token) throw new Error("fetchAvailableModels: token required");
  if (!projectId) throw new Error("fetchAvailableModels: projectId required");

  const base = baseUrl ?? ENDPOINT_BASES[0].base;
  const urlPost = buildUrl(base, CODE_ASSIST_PATHS.FETCH_MODELS);
  const headers = buildGeminiHeaders(token);

  // Tenta POST primeiro (real-world behavior) -> mais estável
  // Body inclui project e metadata
  const bodyPost = JSON.stringify({
    project: projectId,
    cloudaicompanionProject: projectId,
    metadata: {
      ideType: CLIENT_METADATA.ideType,
      platform: CLIENT_METADATA.platform,
      pluginType: CLIENT_METADATA.pluginType,
    },
  });

  // Helper para extrair array de modelos de resposta variada
  const normalizeModels = (payload: unknown): string[] => {
    if (!payload || typeof payload !== "object") return [];
    const obj = payload as Record<string, unknown>;

    const candidates: unknown[] = [
      obj.models,
      obj.availableModels,
      obj.modelList,
      (obj.response as Record<string, unknown> | undefined)?.models,
    ];

    for (const cand of candidates) {
      if (Array.isArray(cand)) {
        const normalized = cand
          .map((m) => {
            if (typeof m === "string") return m;
            if (m && typeof m === "object") {
              const mm = m as Record<string, unknown>;
              if (typeof mm.name === "string") return mm.name.replace(/^models\//, "");
              if (typeof mm.id === "string") return mm.id;
              if (typeof mm.displayName === "string") return mm.displayName;
            }
            return null;
          })
          .filter((x): x is string => typeof x === "string" && x.length > 0);
        if (normalized.length > 0) return normalized;
      }
    }
    return [];
  };

  // 1) POST attempt
  try {
    const resp = await fetchWithTimeout(
      urlPost,
      {
        method: "POST",
        headers,
        body: bodyPost,
      },
      REQUEST_TIMEOUT_MS,
    );

    if (resp.ok) {
      const json = await resp.json().catch(() => null);
      const models = normalizeModels(json);
      if (models.length > 0) return models;
      // se resposta vazia mas status ok, fallback para lista estática apenas se backend retornou vazio
      // continue para GET attempt antes de retornar fallback
    } else {
      // não throw ainda, tenta GET conforme spec
      const text = await resp.text().catch(() => "");
      if (resp.status >= 400 && resp.status < 500 && resp.status !== 429) {
        // client error - pode ser tier / permission, tenta GET
      } else {
        // server error - ainda tenta GET
      }
      // log muted
      void text;
    }
  } catch {
    // ignora erro de POST, tenta GET
  }

  // 2) GET attempt conforme task spec "GET lista modelos"
  try {
    const urlGet = `${urlPost}?project=${encodeURIComponent(projectId)}&alt=json`;
    const respGet = await fetchWithTimeout(
      urlGet,
      {
        method: "GET",
        headers,
      },
      REQUEST_TIMEOUT_MS,
    );

    if (respGet.ok) {
      const json = await respGet.json().catch(() => null);
      const models = normalizeModels(json);
      if (models.length > 0) return models;
    }
  } catch {
    // ignora e usa fallback estático
  }

  // 3) Fallback estático 2026 list
  return [...MODELS_2026];
}

// ============================================================================
// 10. resolveProjectId (core)
// ============================================================================

/**
 * Resolve Project ID com retry em fallback endpoints PROD -> DAILY -> SANDBOX -> PREPROD
 * Features:
 * - timeout 10s por request (fetchWithTimeout)
 * - cache em memória Map com TTL 1h
 * - salvamento em account metadata (mutation + retorno)
 * - fallback rising-fact-p41fc com warning se todos falharem
 *
 * @param token - OAuth2 access_token válido
 * @param account - Account opcional para cache key e persistência em metadata
 * @returns projectId resolvido (sempre string, nunca vazio graças ao fallback)
 */
export async function resolveProjectId(
  token: string,
  account?: Account,
): Promise<string> {
  if (!token || typeof token !== "string" || token.trim().length === 0) {
    throw new Error("resolveProjectId: valid token is required");
  }

  const cleanToken = token.trim();
  const cacheKey = getCacheKey(cleanToken, account);

  // 1) Verifica cache em memória
  const cached = projectCache.get(cacheKey);
  if (cached && isCacheValid(cached)) {
    // também hidrata account metadata se fornecido
    if (account) {
      try {
        account.metadata = {
          ...(account.metadata ?? {}),
          projectId: cached.projectId,
          cloudaicompanionProject: cached.projectId,
          lastResolvedAt: cached.fetchedAt,
          resolvedFrom: "cache" as const,
        };
        account.projectId = cached.projectId;
      } catch {
        // ignore mutation errors
      }
    }
    return cached.projectId;
  }

  // 2) Verifica metadata preexistente (pode ter sido salvo em disco)
  if (account?.metadata) {
    const metaPid =
      (typeof account.metadata.projectId === "string" && account.metadata.projectId.trim()) ||
      (typeof account.metadata.cloudaicompanionProject === "string" &&
        account.metadata.cloudaicompanionProject.trim()) ||
      null;
    if (metaPid) {
      const pid = metaPid.trim();
      // valida formato básico (não vazio, sem espaços, típico gcp project)
      if (pid.length >= 6) {
        const entry: CacheEntry = {
          projectId: pid,
          fetchedAt: Date.now(),
          source: "metadata",
        };
        projectCache.set(cacheKey, entry);
        // re-hidrata timestamp
        try {
          account.metadata.lastResolvedAt = Date.now();
          account.metadata.resolvedFrom = "metadata";
          account.projectId = pid;
        } catch {
          // ignore
        }
        return pid;
      }
    }
  }

  if (account?.projectId && typeof account.projectId === "string" && account.projectId.trim()) {
    const pid = account.projectId.trim();
    if (pid.length >= 6) {
      const entry: CacheEntry = {
        projectId: pid,
        fetchedAt: Date.now(),
        source: "metadata",
      };
      projectCache.set(cacheKey, entry);
      return pid;
    }
  }

  // 3) Tenta endpoints em chain PROD -> DAILY -> SANDBOX -> PREPROD
  let lastError: Error | null = null;

  for (const endpoint of ENDPOINT_BASES) {
    try {
      // loadCodeAssist
      const loadResp = await loadCodeAssist(cleanToken, endpoint.base);
      let projectId = loadResp.cloudaicompanionProject?.trim() || extractProjectId(loadResp._raw);

      // se vazio, tenta onboard + reload
      if (!projectId) {
        try {
          const onboardResp = await onboardUser(cleanToken, endpoint.base, "free-tier");
          projectId = onboardResp.cloudaicompanionProject?.trim() || extractProjectId(onboardResp._raw) || null;

          // se onboard retornou vazio mas foi 200 (done), tenta reload uma vez
          if (!projectId) {
            const reload = await loadCodeAssist(cleanToken, endpoint.base);
            projectId = reload.cloudaicompanionProject?.trim() || extractProjectId(reload._raw) || null;
          }
        } catch (onboardErr) {
          // onboard pode falhar se já onboarded - não fatal, continua
          const msg = (onboardErr as Error).message;
          if (msg.includes("409") || msg.toLowerCase().includes("already")) {
            // tenta reload mesmo assim
            try {
              const reload = await loadCodeAssist(cleanToken, endpoint.base);
              projectId = reload.cloudaicompanionProject?.trim() || extractProjectId(reload._raw) || null;
            } catch {
              // ignore
            }
          } else {
            // preserva erro para log mas continua chain
            lastError = onboardErr as Error;
          }
        }
      }

      if (projectId && projectId.length >= 6) {
        // sucesso - cache + salva em metadata
        const entry: CacheEntry = {
          projectId,
          fetchedAt: Date.now(),
          source: endpoint.name,
          endpointBase: endpoint.base,
        };
        projectCache.set(cacheKey, entry);

        if (account) {
          try {
            account.metadata = {
              ...(account.metadata ?? {}),
              projectId,
              cloudaicompanionProject: projectId,
              lastResolvedAt: entry.fetchedAt,
              resolvedFrom: endpoint.name,
            };
            account.projectId = projectId;
          } catch {
            // ignore mutation
          }
        }

        // opcional: valida modelos (best-effort, não bloqueia resolução)
        try {
          const models = await fetchAvailableModels(cleanToken, projectId, endpoint.base);
          if (account?.metadata) {
            account.metadata.lastModels = models;
          }
        } catch {
          // ignore - models fetch is non-critical
        }

        return projectId;
      }
    } catch (err) {
      lastError = err as Error;
      // continua para próximo endpoint - retry fallback
      continue;
    }
  }

  // 4) Todos endpoints falharam -> fallback rising-fact-p41fc com warning
  const fallbackMsg = `[opencode-antigravity-auth] WARN: Falha ao resolver Project ID via Cloud Code Assist após tentar ${ENDPOINT_BASES.map((e) => e.name).join(", ")}. Último erro: ${lastError?.message ?? "unknown"}. Usando fallback '${FALLBACK_PROJECT_ID}'. Se a conta nunca fez onboarding, modelos Claude/Gemini 3 podem ter quota limitada.`;

  // Em produção, usa console.warn (evita crash)
  // Também tenta process.emitWarning se disponível
  try {
    console.warn(fallbackMsg);
    if (typeof process !== "undefined" && typeof (process as NodeJS.Process).emitWarning === "function") {
      process.emitWarning(fallbackMsg, { type: "AntigravityProjectFallback" });
    }
  } catch {
    // ignore logging errors
  }

  // cache fallback também (curto TTL? usamos mesmo TTL mas source fallback)
  const fallbackEntry: CacheEntry = {
    projectId: FALLBACK_PROJECT_ID,
    fetchedAt: Date.now(),
    source: "fallback",
  };
  projectCache.set(cacheKey, fallbackEntry);

  // salva em metadata com flag fallback
  if (account) {
    try {
      account.metadata = {
        ...(account.metadata ?? {}),
        projectId: FALLBACK_PROJECT_ID,
        cloudaicompanionProject: FALLBACK_PROJECT_ID,
        lastResolvedAt: Date.now(),
        resolvedFrom: "fallback" as const,
        lastResolveError: lastError?.message,
      };
      account.projectId = FALLBACK_PROJECT_ID;
    } catch {
      // ignore
    }
  }

  return FALLBACK_PROJECT_ID;
}

// ============================================================================
// 11. HELPERS ADICIONAIS - PRODUÇÃO
// ============================================================================

/**
 * Verifica se token parece expirado apenas por heurística local
 * (não substitui validação real via tokeninfo)
 */
export function isLikelyExpiredToken(token: string): boolean {
  if (!token) return true;
  return token.length < 20;
}

/**
 * Utilidade para limpar cache expirado (pode ser chamada periodicamente)
 */
export function pruneExpiredCache(): number {
  let removed = 0;
  const now = Date.now();
  for (const [k, v] of projectCache.entries()) {
    if (now - v.fetchedAt >= PROJECT_CACHE_TTL_MS) {
      projectCache.delete(k);
      removed++;
    }
  }
  return removed;
}

/**
 * Resolve platform tuple para logging/debug - usa apenas node:os
 */
export function getPlatformInfo(): { platform: string; arch: string; release: string; hostname: string } {
  return {
    platform: os.platform(),
    arch: os.arch(),
    release: os.release(),
    hostname: os.hostname(),
  };
}

// ============================================================================
// 12. DEFAULT EXPORT - PLUGIN COMPAT
// ============================================================================

const projectModule = {
  // constants
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRET,
  GEMINI_CLI_USER_AGENT,
  X_GOOG_API_CLIENT,
  CLIENT_METADATA,
  CLIENT_METADATA_STRING,
  FALLBACK_PROJECT_ID,
  REQUEST_TIMEOUT_MS,
  ENDPOINT_BASES,
  CODE_ASSIST_PATHS,
  MODELS_2026,
  // cache
  projectCache,
  clearProjectCache,
  pruneExpiredCache,
  // low-level
  buildGeminiHeaders,
  fetchWithTimeout,
  loadCodeAssist,
  onboardUser,
  fetchAvailableModels,
  // core
  resolveProjectId,
  // utils
  getPlatformInfo,
};

export default projectModule;
