/**
 * opencode-antigravity-auth — debug.ts
 * ONDA 3 - Módulos Core
 *
 * Sistema de logging completo production-ready.
 * Contexto bypass Gemini CLI:
 * - Client ID: 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j
 * - Client Secret: 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
 * - User-Agent: GeminiCLI/0.35.3
 * - X-Goog-Api-Client: gl-node/22.19.0
 * - Client-Metadata: ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI
 * - Endpoints: cloudcode-pa.googleapis.com v1internal
 * - Project fallback: rising-fact-p41fc
 *
 * Requisitos ONDA 3:
 * - log para ~/.config/opencode/antigravity-logs/ com rotação 10MB e limpeza 7 dias
 * - painel TUI buffer circular 1000 linhas
 * - níveis debug/info/warn/error controlados por env OPENCODE_ANTIGRAVITY_DEBUG e OPENCODE_ANTIGRAVITY_DEBUG_TUI
 * - quiet_mode suprime toast notifications
 * - redação de segredos (remove tokens)
 * - API singleton DebugLogger com métodos debug/info/warn/error, helpers exportados
 * - apenas node:* builtins
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

// ---------------------------------------------------------------------------
// Constantes do contexto (documentação, não usado diretamente no logger)
// ---------------------------------------------------------------------------
export const GEMINI_CLI_CONTEXT = {
  clientId: "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j",
  clientSecret: "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",
  userAgent: "GeminiCLI/0.35.3",
  xGoogApiClient: "gl-node/22.19.0",
  xClientMetadata: "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI",
  endpoints: {
    loadCode: "https://cloudcode-pa.googleapis.com/v1internal:loadCode",
    onboarding: "https://cloudcode-pa.googleapis.com/v1internal:fetchOnboardingData",
    userTier: "https://cloudcode-pa.googleapis.com/v1internal:fetchUserTier",
    // padrão usado pelo Gemini CLI
    base: "https://cloudcode-pa.googleapis.com",
  },
  projectFallback: "rising-fact-p41fc",
  models2026: [
    "gemini-3-pro-preview",
    "gemini-2.5-pro",
    "gemini-2.5-flash",
    "gemini-2.0-flash-thinking-exp",
    "gemini-antigravity-preview",
  ],
} as const;

// ---------------------------------------------------------------------------
// Configuração de filesystem
// ---------------------------------------------------------------------------
const PLUGIN_DIR_NAME = "opencode";
const LOG_SUBDIR = "antigravity-logs";
const LOG_FILE_NAME = "antigravity.log";
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB
const MAX_FILE_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 dias
const TUI_BUFFER_CAPACITY = 1000;

function getDefaultLogDir(): string {
  return path.join(os.homedir(), ".config", PLUGIN_DIR_NAME, LOG_SUBDIR);
}

function getLogFilePath(logDir: string): string {
  return path.join(logDir, LOG_FILE_NAME);
}

// ---------------------------------------------------------------------------
// Níveis
// ---------------------------------------------------------------------------
export type LogLevelName = "debug" | "info" | "warn" | "error" | "silent";

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  SILENT = 99,
}

const LEVEL_NAME_TO_ENUM: Record<string, LogLevel> = {
  debug: LogLevel.DEBUG,
  info: LogLevel.INFO,
  warn: LogLevel.WARN,
  error: LogLevel.ERROR,
  silent: LogLevel.SILENT,
};

const LEVEL_ENUM_TO_NAME: Record<LogLevel, string> = {
  [LogLevel.DEBUG]: "DEBUG",
  [LogLevel.INFO]: "INFO",
  [LogLevel.WARN]: "WARN",
  [LogLevel.ERROR]: "ERROR",
  [LogLevel.SILENT]: "SILENT",
};

function parseLogLevel(value: string | undefined, defaultLevel: LogLevel): LogLevel {
  if (!value) return defaultLevel;
  const v = value.trim().toLowerCase();
  if (v === "true" || v === "1" || v === "yes" || v === "") {
    return LogLevel.DEBUG;
  }
  if (v === "false" || v === "0" || v === "no") {
    return LogLevel.SILENT;
  }
  if (v in LEVEL_NAME_TO_ENUM) {
    return LEVEL_NAME_TO_ENUM[v];
  }
  // tenta número
  const num = Number(v);
  if (!Number.isNaN(num) && num >= 0 && num <= 3) {
    return num as LogLevel;
  }
  return defaultLevel;
}

function parseBooleanEnv(value: string | undefined, defaultValue: boolean): boolean {
  if (value === undefined) return defaultValue;
  const v = value.trim().toLowerCase();
  if (["1", "true", "yes", "on", "enabled"].includes(v)) return true;
  if (["0", "false", "no", "off", "disabled"].includes(v)) return false;
  return defaultValue;
}

// ---------------------------------------------------------------------------
// Redação de segredos
// ---------------------------------------------------------------------------

/**
 * Lista de padrões sensíveis a serem redatados.
 * Cobre OAuth tokens, GOCSPX client secret, API keys genéricas, Authorization headers, etc.
 */
const SECRET_PATTERNS: Array<{ regex: RegExp; replacement: string }> = [
  // GOCSPX client secret completo
  { regex: /GOCSPX-[A-Za-z0-9_\-]{20,}/g, replacement: "GOCSPX-***REDACTED***" },
  // Client ID pattern (para evitar vazamento completo em logs)
  { regex: /681255809395-[a-z0-9]{20,}\.apps\.googleusercontent\.com/gi, replacement: "***CLIENT_ID_REDACTED***" },
  { regex: /\b681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j\b/g, replacement: "***CLIENT_ID_REDACTED***" },

  // Bearer tokens — captura header ou valor direto
  { regex: /(Bearer\s+)[A-Za-z0-9\-_\.=]+/gi, replacement: "$1***REDACTED***" },
  { regex: /(Authorization['"]?\s*[:=]\s*['"]?)(Bearer\s+)?[A-Za-z0-9\-_\.]+/gi, replacement: "$1***REDACTED***" },

  // OAuth fields genéricos
  { regex: /("?(?:access_token|refresh_token|id_token|client_secret|api_key|apikey|idToken|accessToken|refreshToken)"?\s*[:=]\s*["']?)([^"'\s,}\]]+)/gi, replacement: "$1***REDACTED***" },

  // access_token como query param
  { regex: /([?&](?:access_token|id_token|refresh_token|api_key|key)=)([^&\s]+)/gi, replacement: "$1***REDACTED***" },

  // JWT-like tokens (3 partes base64)
  { regex: /\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b/g, replacement: "***JWT_REDACTED***" },

  // Long random tokens (32+ chars alphanumeric + dash/underscore) que parecem secretos
  { regex: /\b(ya29\.[A-Za-z0-9_\-]+)\b/g, replacement: "ya29.***REDACTED***" },

  // X-Goog headers com tokens
  { regex: /(X-Goog-[A-Za-z\-]+:\s*)(.+)/gi, replacement: "$1***REDACTED***" },
];

export function redactSecrets(input: string): string {
  let out = input;
  for (const { regex, replacement } of SECRET_PATTERNS) {
    // reset lastIndex para regex global reutilizado em loop
    regex.lastIndex = 0;
    out = out.replace(regex, replacement);
  }
  return out;
}

export function redactObject<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === "string") {
    return redactSecrets(obj) as unknown as T;
  }
  if (typeof obj !== "object") return obj;
  if (Array.isArray(obj)) {
    return (obj as unknown as Array<unknown>).map(redactObject) as unknown as T;
  }
  // Objeto: clona raso e redige chaves sensíveis
  const sensitiveKeys = new Set([
    "access_token",
    "refresh_token",
    "id_token",
    "client_secret",
    "clientSecret",
    "accessToken",
    "refreshToken",
    "idToken",
    "api_key",
    "apikey",
    "token",
    "authorization",
    "cookie",
    "set-cookie",
    "x-goog-api-key",
  ]);
  const copy: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
    if (sensitiveKeys.has(k.toLowerCase()) || sensitiveKeys.has(k)) {
      copy[k] = "***REDACTED***";
    } else if (typeof v === "string") {
      copy[k] = redactSecrets(v);
    } else if (typeof v === "object" && v !== null) {
      copy[k] = redactObject(v);
    } else {
      copy[k] = v;
    }
  }
  return copy as unknown as T;
}

// ---------------------------------------------------------------------------
// Buffer circular TUI
// ---------------------------------------------------------------------------
export interface LogEntry {
  timestamp: string; // ISO string
  level: LogLevel;
  levelName: string;
  message: string;
  data?: unknown;
  scope?: string;
}

export class CircularBuffer<T> {
  private buf: (T | undefined)[];
  private head = 0;
  private count = 0;

  constructor(public readonly capacity: number) {
    this.buf = new Array<T | undefined>(capacity);
  }

  push(item: T): void {
    this.buf[this.head] = item;
    this.head = (this.head + 1) % this.capacity;
    if (this.count < this.capacity) this.count++;
  }

  toArray(): T[] {
    const result: T[] = [];
    const start = this.count < this.capacity ? 0 : this.head;
    for (let i = 0; i < this.count; i++) {
      const idx = (start + i) % this.capacity;
      const val = this.buf[idx];
      if (val !== undefined) result.push(val);
    }
    return result;
  }

  clear(): void {
    this.buf = new Array<T | undefined>(this.capacity);
    this.head = 0;
    this.count = 0;
  }

  get size(): number {
    return this.count;
  }

  getRecent(n: number): T[] {
    const all = this.toArray();
    return all.slice(-n);
  }
}

// ---------------------------------------------------------------------------
// Logger principal — Singleton
// ---------------------------------------------------------------------------
export interface DebugLoggerOptions {
  logDir?: string;
  level?: LogLevel | LogLevelName;
  tuiEnabled?: boolean;
  tuiCapacity?: number;
  quietMode?: boolean;
  enableFileLogging?: boolean;
  // permite injetar env para testes
  env?: NodeJS.ProcessEnv;
}

export class DebugLogger {
  private static _instance: DebugLogger | null = null;

  public readonly logDir: string;
  public readonly logFile: string;
  private level: LogLevel;
  private tuiEnabled: boolean;
  private quietMode: boolean;
  private fileLoggingEnabled: boolean;
  private buffer: CircularBuffer<LogEntry>;
  private dirEnsured = false;
  private lastCleanup = 0;
  private readonly CLEANUP_INTERVAL_MS = 60 * 60 * 1000; // 1h

  // Para evitar recursão se logger falhar durante logging do erro de fs
  private isWriting = false;

  private constructor(opts: DebugLoggerOptions = {}) {
    const env = opts.env ?? process.env;

    this.logDir = opts.logDir ?? getDefaultLogDir();
    this.logFile = getLogFilePath(this.logDir);

    // Nível controlado por env OPENCODE_ANTIGRAVITY_DEBUG
    const envLevelRaw = env["OPENCODE_ANTIGRAVITY_DEBUG"];
    if (opts.level !== undefined) {
      this.level =
        typeof opts.level === "string"
          ? parseLogLevel(opts.level, LogLevel.INFO)
          : opts.level;
    } else {
      // default INFO, mas se env for true => DEBUG
      this.level = parseLogLevel(envLevelRaw, LogLevel.INFO);
    }

    // TUI habilitado por env OPENCODE_ANTIGRAVITY_DEBUG_TUI
    // Se DEBUG env habilitado, TUI default true. Caso contrário também true mas respeita flag.
    const envTuiRaw = env["OPENCODE_ANTIGRAVITY_DEBUG_TUI"];
    if (opts.tuiEnabled !== undefined) {
      this.tuiEnabled = opts.tuiEnabled;
    } else if (envTuiRaw !== undefined) {
      this.tuiEnabled = parseBooleanEnv(envTuiRaw, true);
    } else {
      // Default: TUI ativo quando debug ativo, inativo caso silent
      this.tuiEnabled = this.level !== LogLevel.SILENT;
    }

    // Quiet mode suprime toast notifications
    const envQuietRaw =
      env["OPENCODE_ANTIGRAVITY_QUIET_MODE"] ??
      env["OPENCODE_ANTIGRAVITY_QUIET"] ??
      env["OPENCODE_ANTIGRAVITY_SUPPRESS_TOAST"];
    if (opts.quietMode !== undefined) {
      this.quietMode = opts.quietMode;
    } else {
      this.quietMode = parseBooleanEnv(envQuietRaw, false);
    }

    this.fileLoggingEnabled = opts.enableFileLogging ?? true;

    const capacity = opts.tuiCapacity ?? TUI_BUFFER_CAPACITY;
    this.buffer = new CircularBuffer<LogEntry>(capacity);

    // Inicialização lazy de dir cria no primeiro log, mas tentamos garantir agora sem quebrar
    try {
      this.ensureLogDir();
      this.cleanupOldLogs();
    } catch {
      // noop — não quebra app se fs falhar no boot
    }

    // Bind para uso como callback
    this.debug = this.debug.bind(this);
    this.info = this.info.bind(this);
    this.warn = this.warn.bind(this);
    this.error = this.error.bind(this);
  }

  // -------------------------------------------------------------------------
  // Singleton access
  // -------------------------------------------------------------------------
  public static getInstance(opts?: DebugLoggerOptions): DebugLogger {
    if (!DebugLogger._instance) {
      DebugLogger._instance = new DebugLogger(opts);
    } else if (opts && Object.keys(opts).length > 0) {
      // Se já existe mas opts traz overrides explícitos, aplica
      DebugLogger._instance.applyOptions(opts);
    }
    return DebugLogger._instance;
  }

  /** Para testes — reseta singleton */
  public static _resetForTests(): void {
    DebugLogger._instance = null;
  }

  private applyOptions(opts: DebugLoggerOptions): void {
    if (opts.level !== undefined) {
      this.level =
        typeof opts.level === "string"
          ? parseLogLevel(opts.level, this.level)
          : opts.level;
    }
    if (opts.tuiEnabled !== undefined) this.tuiEnabled = opts.tuiEnabled;
    if (opts.quietMode !== undefined) this.quietMode = opts.quietMode;
    if (opts.enableFileLogging !== undefined) this.fileLoggingEnabled = opts.enableFileLogging;
  }

  // -------------------------------------------------------------------------
  // Getters / setters públicos
  // -------------------------------------------------------------------------
  public getLevel(): LogLevel {
    return this.level;
  }

  public getLevelName(): LogLevelName {
    const name = LEVEL_ENUM_TO_NAME[this.level]?.toLowerCase();
    return (name as LogLevelName) ?? "info";
  }

  public setLevel(level: LogLevel | LogLevelName): void {
    this.level = typeof level === "string" ? parseLogLevel(level, this.level) : level;
  }

  public isTuiEnabled(): boolean {
    return this.tuiEnabled;
  }

  public setTuiEnabled(enabled: boolean): void {
    this.tuiEnabled = enabled;
  }

  public isQuietMode(): boolean {
    return this.quietMode;
  }

  public setQuietMode(quiet: boolean): void {
    this.quietMode = quiet;
  }

  /**
   * Indica se toast notifications devem ser mostradas.
   * Em quiet_mode, suprime toasts.
   */
  public shouldShowToast(): boolean {
    return !this.quietMode;
  }

  public isDebugEnabled(): boolean {
    return this.level <= LogLevel.DEBUG;
  }

  public getLogDir(): string {
    return this.logDir;
  }

  public getLogFilePath(): string {
    return this.logFile;
  }

  // -------------------------------------------------------------------------
  // Filesystem — dir, rotação, limpeza
  // -------------------------------------------------------------------------
  private ensureLogDir(): void {
    if (this.dirEnsured) return;
    try {
      fs.mkdirSync(this.logDir, { recursive: true });
      this.dirEnsured = true;
    } catch {
      // não propaga — logging não pode quebrar app
      this.dirEnsured = false;
    }
  }

  private getFileSize(): number {
    try {
      const stat = fs.statSync(this.logFile);
      return stat.size;
    } catch {
      return 0;
    }
  }

  private rotateIfNeeded(): void {
    if (!this.fileLoggingEnabled) return;
    try {
      const size = this.getFileSize();
      if (size < MAX_FILE_SIZE_BYTES) return;

      const timestamp = new Date()
        .toISOString()
        .replace(/[:.]/g, "-")
        .replace("T", "_")
        .replace("Z", "");
      const rotatedName = `antigravity-${timestamp}.log`;
      const rotatedPath = path.join(this.logDir, rotatedName);

      try {
        fs.renameSync(this.logFile, rotatedPath);
      } catch {
        // se falhar rename (ex. arquivo aberto), trunca
        try {
          fs.truncateSync(this.logFile, 0);
        } catch {
          // ignore
        }
      }

      // após rotação, tenta limpeza
      this.cleanupOldLogs(true);
    } catch {
      // ignore rotation errors
    }
  }

  /**
   * Remove logs mais antigos que 7 dias.
   * Chamado no boot e após rotação, com intervalo mínimo de 1h.
   */
  private cleanupOldLogs(force = false): void {
    const now = Date.now();
    if (!force && now - this.lastCleanup < this.CLEANUP_INTERVAL_MS) return;
    this.lastCleanup = now;

    if (!this.fileLoggingEnabled) return;
    try {
      this.ensureLogDir();
      const files = fs.readdirSync(this.logDir);
      for (const file of files) {
        // apenas arquivos do nosso padrão
        if (!file.startsWith("antigravity") || !file.endsWith(".log")) continue;
        // preserva arquivo atual
        if (file === LOG_FILE_NAME) continue;

        const fullPath = path.join(this.logDir, file);
        try {
          const stat = fs.statSync(fullPath);
          const age = now - stat.mtimeMs;
          if (age > MAX_FILE_AGE_MS) {
            fs.unlinkSync(fullPath);
          }
        } catch {
          // ignora arquivo individual
        }
      }
      // também verifica arquivo atual muito antigo? não deletamos, apenas rotacionamos por tamanho,
      // mas se muito antigo e grande, rotação já cuida. Opcional: se arquivo atual >7 dias e vazio não necessário.
    } catch {
      // ignore
    }
  }

  // -------------------------------------------------------------------------
  // Core logging
  // -------------------------------------------------------------------------
  private shouldLog(incomingLevel: LogLevel): boolean {
    if (this.level === LogLevel.SILENT) return false;
    return incomingLevel >= this.level;
  }

  private formatEntry(entry: LogEntry): string {
    const redactedMessage = redactSecrets(entry.message);
    let line = `${entry.timestamp} [${entry.levelName}]`;
    if (entry.scope) {
      line += ` [${redactSecrets(entry.scope)}]`;
    }
    line += ` ${redactedMessage}`;
    if (entry.data !== undefined) {
      try {
        const json = JSON.stringify(redactObject(entry.data));
        line += ` ${json}`;
      } catch {
        line += ` [unserializable data]`;
      }
    }
    return line + "\n";
  }

  private writeToFile(formatted: string): void {
    if (!this.fileLoggingEnabled) return;
    if (this.isWriting) return; // evita recursão
    this.isWriting = true;
    try {
      this.ensureLogDir();
      this.rotateIfNeeded();
      fs.appendFileSync(this.logFile, formatted, { encoding: "utf8" });
    } catch {
      // logging failure não quebra
    } finally {
      this.isWriting = false;
    }
  }

  private pushToTui(entry: LogEntry): void {
    if (!this.tuiEnabled) return;
    try {
      this.buffer.push(entry);
    } catch {
      // ignore
    }
  }

  private log(level: LogLevel, message: string, data?: unknown, scope?: string): LogEntry | null {
    if (!this.shouldLog(level)) return null;

    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      levelName: LEVEL_ENUM_TO_NAME[level] ?? "INFO",
      message: String(message),
      data,
      scope,
    };

    // TUI buffer — sempre com mensagem original redatada apenas na exibição,
    // mas armazenamos já redatado por segurança
    const redactedForStorage: LogEntry = {
      ...entry,
      message: redactSecrets(entry.message),
      data: data !== undefined ? redactObject(data) : undefined,
      scope: scope ? redactSecrets(scope) : undefined,
    };

    this.pushToTui(redactedForStorage);

    // File log — linha formatada
    const formatted = this.formatEntry(entry);
    this.writeToFile(formatted);

    // Também console em debug? Respeita nivel, mas não polui stdout por padrão.
    // Apenas quando OPENCODE_ANTIGRAVITY_DEBUG está ativo e não em quiet mode, envia para stderr
    // para não interferir com TUI opencode.
    // Mantemos silencioso: não usamos console.log para evitar spam, só em DEBUG env força stderr.
    if (this.level <= LogLevel.DEBUG) {
      try {
        // Usa process.stderr.write para não quebrar se console foi mockado
        if (typeof process !== "undefined" && process.stderr && !this.quietMode) {
          // Evita duplicar file log em console a menos que seja warn/error ou debug explicitamente
          if (level >= LogLevel.WARN) {
            process.stderr.write(formatted);
          }
        }
      } catch {
        // ignore
      }
    }

    return redactedForStorage;
  }

  // -------------------------------------------------------------------------
  // Métodos públicos de nível
  // -------------------------------------------------------------------------
  public debug(message: string, data?: unknown, scope?: string): LogEntry | null {
    return this.log(LogLevel.DEBUG, message, data, scope);
  }

  public info(message: string, data?: unknown, scope?: string): LogEntry | null {
    return this.log(LogLevel.INFO, message, data, scope);
  }

  public warn(message: string, data?: unknown, scope?: string): LogEntry | null {
    return this.log(LogLevel.WARN, message, data, scope);
  }

  public error(message: string, data?: unknown, scope?: string): LogEntry | null {
    return this.log(LogLevel.ERROR, message, data, scope);
  }

  /**
   * Log com escopo custom (útil para child loggers)
   */
  public withScope(scope: string): ScopedLogger {
    return new ScopedLogger(this, scope);
  }

  // -------------------------------------------------------------------------
  // TUI API
  // -------------------------------------------------------------------------
  public getTuiBuffer(): LogEntry[] {
    return this.buffer.toArray();
  }

  public getRecentLogs(count: number): LogEntry[] {
    return this.buffer.getRecent(count);
  }

  public getTuiBufferAsString(maxLines?: number): string {
    const entries = maxLines ? this.buffer.getRecent(maxLines) : this.buffer.toArray();
    return entries
      .map((e) => {
        const scopePart = e.scope ? ` [${e.scope}]` : "";
        const dataPart = e.data !== undefined ? ` ${JSON.stringify(e.data)}` : "";
        return `${e.timestamp} [${e.levelName}]${scopePart} ${e.message}${dataPart}`;
      })
      .join("\n");
  }

  public clearTuiBuffer(): void {
    this.buffer.clear();
  }

  public getTuiBufferSize(): number {
    return this.buffer.size;
  }

  public getTuiCapacity(): number {
    return this.buffer.capacity;
  }
}

// ---------------------------------------------------------------------------
// Scoped logger — para módulos (ex. auth:refresh)
// ---------------------------------------------------------------------------
export class ScopedLogger {
  constructor(private readonly parent: DebugLogger, private readonly scope: string) {}

  debug(message: string, data?: unknown): LogEntry | null {
    return this.parent.debug(message, data, this.scope);
  }
  info(message: string, data?: unknown): LogEntry | null {
    return this.parent.info(message, data, this.scope);
  }
  warn(message: string, data?: unknown): LogEntry | null {
    return this.parent.warn(message, data, this.scope);
  }
  error(message: string, data?: unknown): LogEntry | null {
    return this.parent.error(message, data, this.scope);
  }

  withScope(childScope: string): ScopedLogger {
    return new ScopedLogger(this.parent, `${this.scope}:${childScope}`);
  }

  get parentLogger(): DebugLogger {
    return this.parent;
  }
}

// ---------------------------------------------------------------------------
// Singleton default + helpers exportados
// ---------------------------------------------------------------------------
function getLogger(): DebugLogger {
  return DebugLogger.getInstance();
}

export const logger: DebugLogger = DebugLogger.getInstance();

/**
 * Helpers funcionais — para import direto:
 *   import { debug, info } from "./debug"
 */
export function debug(message: string, data?: unknown, scope?: string): LogEntry | null {
  return getLogger().debug(message, data, scope);
}
export function info(message: string, data?: unknown, scope?: string): LogEntry | null {
  return getLogger().info(message, data, scope);
}
export function warn(message: string, data?: unknown, scope?: string): LogEntry | null {
  return getLogger().warn(message, data, scope);
}
export function error(message: string, data?: unknown, scope?: string): LogEntry | null {
  return getLogger().error(message, data, scope);
}

/**
 * Cria logger com escopo (ex. "auth:gemini", "plugin:load")
 */
export function createScopedLogger(scope: string): ScopedLogger {
  return getLogger().withScope(scope);
}

/**
 * Alias para compatibilidade: createDebugLogger
 */
export function createDebugLogger(scope: string): ScopedLogger {
  return createScopedLogger(scope);
}

/**
 * Helpers de estado — controlados por env
 */
export function isDebugEnabled(): boolean {
  return getLogger().isDebugEnabled();
}
export function isTuiEnabled(): boolean {
  return getLogger().isTuiEnabled();
}
export function isQuietMode(): boolean {
  return getLogger().isQuietMode();
}
export function shouldShowToast(): boolean {
  return getLogger().shouldShowToast();
}

/**
 * Acesso ao buffer TUI
 */
export function getTuiBuffer(): LogEntry[] {
  return getLogger().getTuiBuffer();
}
export function getRecentLogs(n: number): LogEntry[] {
  return getLogger().getRecentLogs(n);
}
export function getTuiBufferAsString(maxLines?: number): string {
  return getLogger().getTuiBufferAsString(maxLines);
}
export function clearTuiBuffer(): void {
  return getLogger().clearTuiBuffer();
}

/**
 * Informações de log filesystem
 */
export function getLogDir(): string {
  return getLogger().getLogDir();
}
export function getLogFilePathExport(): string {
  return getLogger().getLogFilePath();
}

/**
 * Ajuste dinâmico (útil para TUI commander)
 */
export function setLogLevel(level: LogLevel | LogLevelName): void {
  getLogger().setLevel(level);
}
export function setQuietMode(enabled: boolean): void {
  getLogger().setQuietMode(enabled);
}
export function setTuiEnabled(enabled: boolean): void {
  getLogger().setTuiEnabled(enabled);
}

// ---------------------------------------------------------------------------
// Default export — singleton
// ---------------------------------------------------------------------------
export default DebugLogger;
