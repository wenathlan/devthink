import * as fs from "node:fs";
import * as path from "node:path";

const required = ["plugin.ts","constants.ts","oauth.ts","accounts.ts","project.ts","quota.ts","request.ts","streaming.ts","recovery.ts","config.ts","debug.ts","version.ts","fingerprint.ts","cli.ts","index.ts","package.json","tsconfig.json","README.md","LICENSE"];
console.log("Validating /mnt/data/auth ...");
for (const f of required) {
  const p = path.join("/mnt/data/auth", f);
  if (!fs.existsSync(p)) console.error(`MISSING ${f}`);
  else {
    const s = fs.statSync(p);
    console.log(`OK ${f} ${s.size} bytes`);
  }
}
console.log("Validation done");
