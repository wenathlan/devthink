/**
 * index.ts - Public exports for opencode-antigravity-auth-next
 * Date: 2026-08-25
 */
export { default as plugin } from "./plugin.ts";
export { default } from "./plugin.ts";
export * from "./constants.ts";
export * from "./config.ts";
export * from "./version.ts";
export * from "./fingerprint.ts";
export * from "./oauth.ts";
export * from "./accounts.ts";
export * from "./project.ts";
export * from "./quota.ts";
export * from "./debug.ts";
export * from "./request-helpers.ts";
export * from "./request.ts";
export * from "./streaming.ts";
export * from "./recovery.ts";

// Re-export ALL_MODELS
export { ALL_MODELS_2026, MODEL_BY_ID, MODEL_ROUTING } from "./constants.ts";

// Bypass constants
export const GEMINI_CLI_BYPASS = {
  clientId: "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com",
  clientSecret: "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",
  userAgent: "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1",
  xGoogApiClient: "gl-node/22.19.0",
  clientMetadata: "ideType=IDE_UNSPECIFIED,platform=PLATFORM_UNSPECIFIED,pluginType=GEMINI",
  fallbackProject: "rising-fact-p41fc",
  endpoints: {
    loadCodeAssist: "https://cloudcode-pa.googleapis.com/v1internal:loadCodeAssist",
    generateContent: "https://cloudcode-pa.googleapis.com/v1internal:generateContent",
    streamGenerateContent: "https://cloudcode-pa.googleapis.com/v1internal:streamGenerateContent",
  },
  isolatedDir: "/mnt/data/auth",
};
