/**
 * @fileoverview Configuração blindada para plugin opencode-antigravity-auth
 * @module auth/config
 * @description
 *  Schema completo para `~/.config/opencode/antigravity.json` + constantes de bypass
 *  Gemini CLI. Produção-ready, zero deps externas (apenas node:* builtins + fetch global).
 *
 *  Pasta blindada minúscula: /mnt/data/auth
 *  Arquivo alvo: ~/.config/opencode/antigravity.json (0o600)
 *
 * @author ONDA 2 - Arquitetura Core
 * @since 2026
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";

// =============================================================================
// CONSTANTES DE BYPASS - GEMINI CLI IDENTIFICATION
// =============================================================================

/**
 * OAuth2 Client ID do Gemini CLI (Google Cloud Code)
 * @readonly
 */
export const OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com" as const;

/**
 * OAuth2 Client Secret do Gemini CLI
 * @readonly
 * @security Este secret é público no binário do Gemini CLI; não é segredo privado
 */
export const OAUTH_CLIENT_SECRET =
  "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" as const;

/**
 * Escopos OAuth exigidos para Cloud Code + identidade
 * @readonly
 */
export const OAUTH_SCOPES = [
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
] as const;

/**
 * OAuth scopes como string space-separated para token request
 */
export const OAUTH_SCOPE_STRING = OAUTH_SCOPES.join(" ");

/**
 * User-Agent canônico do Gemini CLI.
 * Formato: GeminiCLI/<version>/<default-model> (<platform>; <arch>; GitHub) google-api-nodejs-client/<gaxios-ver>
 * Observação: plataforma varia para evitar fingerprinting estático.
 * @readonly
 */
export const GEMINI_CLI_USER_AGENT_BASE =
  "GeminiCLI/0.35.3/gemini-3-pro-preview (linux; x64; GitHub) google-api-nodejs-client/9.15.1" as const;

/**
 * Versão do google-api-nodejs-client fingerprintada
 */
export const GOOGLE_API_CLIENT_VERSION = "9.15.1" as const;

/**
 * Versão do GeminiCLI fingerprintada
 */
export const GEMINI_CLI_VERSION = "0.35.3" as const;

/**
 * Modelo padrão anunciado no UA
 */
export const GEMINI_CLI_DEFAULT_MODEL = "gemini-3-pro-preview" as const;

/**
 * X-Goog-Api-Client header (Node.js runtime fingerprint)
 * @readonly
 */
export const X_GOOG_API_CLIENT = "gl-node/22.19.0" as const;

/**
 * Client metadata para bypass (IDE unspecified = CLI puro)
 * @readonly
 */
export const CLIENT_METADATA = {
  ideType: "IDE_UNSPECIFIED",
  platform: "PLATFORM_UNSPECIFIED",
  pluginType: "GEMINI",
} as const;

/**
 * Client-Metadata serializado como string de header `X-Goog-Client-Metadata` / payload
 */
export const CLIENT_METADATA_STRING = `ideType=${CLIENT_METADATA.ideType},platform=${CLIENT_METADATA.platform},pluginType=${CLIENT_METADATA.pluginType}` as const;

/**
 * Project fallback quando cloud project não resolvido via loadCodeAssist
 * @readonly
 */
export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;

/**
 * Endpoints base Cloud Code Assist PA (Playground API)
 */
export const CLOUDCODE_BASE_URL = "https://cloudcode-pa.googleapis.com" as const;

export const CLOUDCODE_ENDPOINTS = {
  base: CLOUDCODE_BASE_URL,
  /** Carrega projeto Cloud Code e vincula licença */
  loadCodeAssist: `${CLOUDCODE_BASE_URL}/v1internal:loadCodeAssist`,
  /** Onboarding inicial do usuário */
  onboardUser: `${CLOUDCODE_BASE_URL}/v1internal:onboardUser`,
  /** Lista modelos disponíveis para o usuário */
  fetchAvailableModels: `${CLOUDCODE_BASE_URL}/v1internal:fetchAvailableModels`,
  /** Geração não-streaming */
  generateContent: `${CLOUDCODE_BASE_URL}/v1internal:generateContent`,
  /** Geração streaming SSE */
  streamGenerateContent: `${CLOUDCODE_BASE_URL}/v1internal:streamGenerateContent`,
  /** Resumo de quota por modelo */
  retrieveUserQuotaSummary: `${CLOUDCODE_BASE_URL}/v1internal:retrieveUserQuotaSummary`,
} as const;

/**
 * Modelos disponíveis 2026 (antigravity custom + Google nativos)
 * @readonly
 */
export const MODELS_2026 = [
  // Antigravity Custom - Gemini family
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  // Antigravity Custom - Claude family via bypass
  "antigravity-claude-sonnet-4-6",
  "antigravity-claude-opus-4-6-thinking",
  // Google Native - 2.5 series
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  // Google Native - 3.x preview
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
] as const;

export type Model2026 = (typeof MODELS_2026)[number];

// =============================================================================
// HELPERS DE USER-AGENT DINÂMICO (variação de plataforma)
// =============================================================================

/**
 * Plataforma normalizada para fingerprint UA.
 * Converte Node os.platform()/arch() para string esperada pelo Google.
 */
export type PlatformTuple = {
  platform: string;
  arch: string;
};

/**
 * Retorna tupla plataforma/arch no formato usado pelo UA oficial.
 * Ex: linux -> linux, darwin -> darwin, win32 -> win32
 * @returns {PlatformTuple}
 */
export function getPlatformTuple(): PlatformTuple {
  const p = os.platform(); // linux, darwin, win32
  const a = os.arch(); // x64, arm64, etc.

  // Normaliza arch para o que o Gemini CLI anuncia
  let archNormalized = a;
  if (a === "x64") archNormalized = "x64";
  else if (a === "arm64") archNormalized = "arm64";
  else if (a === "arm") archNormalized = "arm";
  // mantém outros como estão

  // Platform já vem normalizada, só garante lower-case
  const platformNormalized = p.toLowerCase();

  return { platform: platformNormalized, arch: archNormalized };
}

/**
 * Gera User-Agent do GeminiCLI dinamicamente variando plataforma.
 * Evita fingerprint estático em WAF.
 *
 * Template: GeminiCLI/<cliVersion>/<model> (<platform>; <arch>; GitHub) google-api-nodejs-client/<gclientVersion>
 *
 * @param overrides - Sobrescrita opcional de plataforma/cliVersion/model
 * @returns User-Agent string pronta para header `User-Agent`
 */
export function buildGeminiUserAgent(overrides?: {
  cliVersion?: string;
  model?: string;
  platform?: string;
  arch?: string;
  gclientVersion?: string;
}): string {
  const tuple = getPlatformTuple();
  const cliVersion = overrides?.cliVersion ?? GEMINI_CLI_VERSION;
  const model = overrides?.model ?? GEMINI_CLI_DEFAULT_MODEL;
  const platform = overrides?.platform ?? tuple.platform;
  const arch = overrides?.arch ?? tuple.arch;
  const gclientVersion =
    overrides?.gclientVersion ?? GOOGLE_API_CLIENT_VERSION;

  // Formato exato do Gemini CLI real
  return `GeminiCLI/${cliVersion}/${model} (${platform}; ${arch}; GitHub) google-api-nodejs-client/${gclientVersion}`;
}

/**
 * Gera X-Goog-Api-Client header dinâmico baseado na versão Node atual,
 * caindo para fallback se process.versions indisponível.
 */
export function buildXGoogApiClient(): string {
  try {
    const nodeVer =
      typeof process !== "undefined" && process.versions?.node
        ? process.versions.node
        : "22.19.0";
    return `gl-node/${nodeVer}`;
  } catch {
    return X_GOOG_API_CLIENT;
  }
}

/**
 * Headers completos de identificação para bypass
 */
export function getBypassHeaders(): Record<string, string> {
  return {
    "User-Agent": buildGeminiUserAgent(),
    "X-Goog-Api-Client": buildXGoogApiClient(),
    "Client-Metadata": CLIENT_METADATA_STRING,
    "X-Goog-Client-Metadata": CLIENT_METADATA_STRING,
  };
}

// =============================================================================
// SCHEMA DE CONFIGURAÇÃO - ~/.config/opencode/antigravity.json
// =============================================================================

/**
 * Escopo de notificações toast/opencode
 */
export type ToastScope = "all" | "project" | "minimal" | "none";

/**
 * Modo de fallback de quota.
 * - true: habilita fallback automático para modelo reserva
 * - false: desabilita fallback, falha dura em 429
 * - "auto": sistema escolhe melhor modelo com quota
 * - string: nome do modelo específico para fallback
 */
export type QuotaFallback = boolean | "auto" | string;

/**
 * Configuração principal do plugin antigravity.
 * Persistida em ~/.config/opencode/antigravity.json com chmod 0o600.
 */
export interface AntigravityConfig {
  /**
   * Se true, tenta autenticação via `gemini` CLI local antes de OAuth próprio.
   * Útil quando usuário já está logado no Gemini CLI.
   * @default true
   */
  cli_first: boolean;

  /**
   * Escopo de exibição de toasts/notificações no opencode
   * @default "all"
   */
  toast_scope: ToastScope;

  /**
   * Percentual de quota a partir do qual inicia aviso/fallback suave
   * @default 90 (90%)
   * @range 0-100
   */
  soft_quota_threshold_percent: number;

  /**
   * Estratégia de fallback quando quota atinge threshold
   * @default "auto"
   */
  quota_fallback: QuotaFallback;

  /**
   * Intervalo em minutos para refresh de quota summary
   * @default 15
   * @range 1-1440
   */
  quota_refresh_interval_minutes: number;

  /**
   * TTL do cache de soft quota em minutos
   * @default 5
   * @range 1-1440
   */
  soft_quota_cache_ttl_minutes: number;

  /**
   * Se true, aplica offset no PID para evitar detecção de automação
   * @default true
   */
  pid_offset_enabled: boolean;

  /**
   * Habilita busca groundada do Google (google_search tool)
   * @default false
   */
  google_search_enabled: boolean;

  /**
   * Modo debug com logs verbosos
   * @default false
   */
  debug: boolean;

  /**
   * TTL do cache de versão/verificação de update em minutos
   * @default 60
   * @range 1-10080 (1 semana max)
   */
  version_cache_ttl: number;
}

/**
 * Configuração padrão imutável.
 */
export const DEFAULT_CONFIG: Readonly<AntigravityConfig> = {
  cli_first: true,
  toast_scope: "all",
  soft_quota_threshold_percent: 90,
  quota_fallback: "auto",
  quota_refresh_interval_minutes: 15,
  soft_quota_cache_ttl_minutes: 5,
  pid_offset_enabled: true,
  google_search_enabled: false,
  debug: false,
  version_cache_ttl: 60,
} as const;

const CONFIG_DIR_NAME = "opencode" as const;
const CONFIG_FILE_NAME = "antigravity.json" as const;

// =============================================================================
// CACHE EM MEMÓRIA
// =============================================================================

type MemoryCacheEntry = {
  config: AntigravityConfig;
  mtimeMs: number;
  path: string;
  loadedAtMs: number;
};

let _memoryCache: MemoryCacheEntry | null = null;

// =============================================================================
// VALIDADORES MANUAIS (SEM ZOD)
// =============================================================================

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function isBoolean(v: unknown): v is boolean {
  return typeof v === "boolean";
}

function isNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

function isString(v: unknown): v is string {
  return typeof v === "string";
}

function isValidToastScope(v: unknown): v is ToastScope {
  return v === "all" || v === "project" || v === "minimal" || v === "none";
}

function isValidQuotaFallback(v: unknown): v is QuotaFallback {
  if (isBoolean(v)) return true;
  if (v === "auto") return true;
  if (isString(v)) {
    // aceita qualquer string não vazia (nome de modelo) ou modelo conhecido
    return v.trim().length > 0;
  }
  return false;
}

/**
 * Erro de validação de config
 */
export class ConfigValidationError extends Error {
  public readonly errors: string[];
  constructor(errors: string[]) {
    super(`Invalid antigravity config: ${errors.join("; ")}`);
    this.name = "ConfigValidationError";
    this.errors = errors;
  }
}

/**
 * Valida campo numérico em range e retorna valor ou erro.
 */
function validateNumberInRange(
  key: string,
  value: unknown,
  min: number,
  max: number,
  defaultValue: number,
  errors: string[]
): number {
  if (value === undefined) return defaultValue;
  if (!isNumber(value)) {
    errors.push(`${key} must be a number`);
    return defaultValue;
  }
  if (value < min || value > max) {
    errors.push(`${key} must be between ${min} and ${max} (got ${value})`);
    // clamp em vez de falhar hard para robustez
    return Math.min(Math.max(value, min), max);
  }
  return value;
}

/**
 * Valida e normaliza objeto parcial de config, mesclando com defaults.
 * Não usa zod - validação manual para zero deps.
 *
 * @param raw - Objeto cru lido do JSON
 * @param strict - Se true, lança ConfigValidationError em erros; se false, usa defaults e acumula warnings
 * @returns Config sanitizada
 */
export function parseAndValidateConfig(
  raw: unknown,
  opts?: { strict?: boolean }
): AntigravityConfig {
  const strict = opts?.strict ?? false;
  const errors: string[] = [];

  if (!isObject(raw)) {
    if (raw === null || raw === undefined) {
      // arquivo vazio/null => usa defaults
      return { ...DEFAULT_CONFIG };
    }
    errors.push("config root must be an object");
    if (strict) throw new ConfigValidationError(errors);
    return { ...DEFAULT_CONFIG };
  }

  // Começa com defaults como base
  const result: AntigravityConfig = { ...DEFAULT_CONFIG };

  // cli_first
  if ("cli_first" in raw) {
    if (!isBoolean(raw.cli_first)) {
      errors.push("cli_first must be boolean");
    } else {
      result.cli_first = raw.cli_first;
    }
  }

  // toast_scope
  if ("toast_scope" in raw) {
    if (!isValidToastScope(raw.toast_scope)) {
      errors.push(
        `toast_scope must be one of all|project|minimal|none (got ${String(
          raw.toast_scope
        )})`
      );
    } else {
      result.toast_scope = raw.toast_scope;
    }
  }

  // soft_quota_threshold_percent (default 90)
  result.soft_quota_threshold_percent = validateNumberInRange(
    "soft_quota_threshold_percent",
    (raw as Record<string, unknown>).soft_quota_threshold_percent,
    0,
    100,
    DEFAULT_CONFIG.soft_quota_threshold_percent,
    errors
  );

  // quota_fallback
  if ("quota_fallback" in raw) {
    if (!isValidQuotaFallback(raw.quota_fallback)) {
      errors.push(
        `quota_fallback must be boolean | "auto" | modelName (got ${String(
          raw.quota_fallback
        )})`
      );
    } else {
      result.quota_fallback = raw.quota_fallback as QuotaFallback;
    }
  }

  // quota_refresh_interval_minutes (default 15)
  result.quota_refresh_interval_minutes = validateNumberInRange(
    "quota_refresh_interval_minutes",
    (raw as Record<string, unknown>).quota_refresh_interval_minutes,
    1,
    1440,
    DEFAULT_CONFIG.quota_refresh_interval_minutes,
    errors
  );

  // soft_quota_cache_ttl_minutes
  result.soft_quota_cache_ttl_minutes = validateNumberInRange(
    "soft_quota_cache_ttl_minutes",
    (raw as Record<string, unknown>).soft_quota_cache_ttl_minutes,
    1,
    1440,
    DEFAULT_CONFIG.soft_quota_cache_ttl_minutes,
    errors
  );

  // pid_offset_enabled
  if ("pid_offset_enabled" in raw) {
    if (!isBoolean(raw.pid_offset_enabled)) {
      errors.push("pid_offset_enabled must be boolean");
    } else {
      result.pid_offset_enabled = raw.pid_offset_enabled;
    }
  }

  // google_search_enabled
  if ("google_search_enabled" in raw) {
    if (!isBoolean(raw.google_search_enabled)) {
      errors.push("google_search_enabled must be boolean");
    } else {
      result.google_search_enabled = raw.google_search_enabled;
    }
  }

  // debug
  if ("debug" in raw) {
    if (!isBoolean(raw.debug)) {
      errors.push("debug must be boolean");
    } else {
      result.debug = raw.debug;
    }
  }

  // version_cache_ttl
  result.version_cache_ttl = validateNumberInRange(
    "version_cache_ttl",
    (raw as Record<string, unknown>).version_cache_ttl,
    1,
    10080,
    DEFAULT_CONFIG.version_cache_ttl,
    errors
  );

  if (strict && errors.length > 0) {
    throw new ConfigValidationError(errors);
  }

  // Em modo não-estrito, loga warnings se debug ativo (sem console.error agressivo)
  // O consumidor pode decidir logar errors retornados via segunda API se quiser.

  return result;
}

/**
 * Validação leve que retorna lista de erros sem throw, útil para diagnóstico.
 */
export function validateConfigRaw(raw: unknown): {
  valid: boolean;
  errors: string[];
  config: AntigravityConfig;
} {
  const errors: string[] = [];
  let config: AntigravityConfig;
  try {
    // tenta strict para capturar tudo
    config = parseAndValidateConfig(raw, { strict: false });
    // re-valida manualmente para coletar todos os erros (parse já coleta internamente mas não expõe)
    // Para expor erros, replicamos coleta simples:
    if (!isObject(raw) && raw != null) {
      errors.push("config root must be an object");
    } else if (isObject(raw)) {
      if ("cli_first" in raw && !isBoolean(raw.cli_first))
        errors.push("cli_first must be boolean");
      if ("toast_scope" in raw && !isValidToastScope(raw.toast_scope))
        errors.push("toast_scope invalid");
      if ("quota_fallback" in raw && !isValidQuotaFallback(raw.quota_fallback))
        errors.push("quota_fallback invalid");
      if ("pid_offset_enabled" in raw && !isBoolean(raw.pid_offset_enabled))
        errors.push("pid_offset_enabled must be boolean");
      if ("google_search_enabled" in raw && !isBoolean(raw.google_search_enabled))
        errors.push("google_search_enabled must be boolean");
      if ("debug" in raw && !isBoolean(raw.debug))
        errors.push("debug must be boolean");

      const numFields: Array<[string, number, number]> = [
        ["soft_quota_threshold_percent", 0, 100],
        ["quota_refresh_interval_minutes", 1, 1440],
        ["soft_quota_cache_ttl_minutes", 1, 1440],
        ["version_cache_ttl", 1, 10080],
      ];
      for (const [k, min, max] of numFields) {
        const v = (raw as Record<string, unknown>)[k];
        if (v !== undefined) {
          if (!isNumber(v)) errors.push(`${k} must be a number`);
          else if (v < min || v > max)
            errors.push(`${k} must be between ${min} and ${max}`);
        }
      }
    }
  } catch (e) {
    if (e instanceof ConfigValidationError) {
      return { valid: false, errors: e.errors, config: { ...DEFAULT_CONFIG } };
    }
    errors.push((e as Error).message);
    config = { ...DEFAULT_CONFIG };
  }

  return { valid: errors.length === 0, errors, config: config! };
}

// =============================================================================
// HELPERS DE PATH / IO
// =============================================================================

/**
 * Retorna caminho absoluto do arquivo de config.
 * `~/.config/opencode/antigravity.json` no OS atual.
 * Respeita XDG_CONFIG_HOME em Linux se definido.
 *
 * @returns caminho absoluto
 */
export function getConfigPath(): string {
  // XDG override (Linux standard)
  const xdg = process.env.XDG_CONFIG_HOME;
  if (xdg && xdg.trim().length > 0) {
    return path.join(xdg, CONFIG_DIR_NAME, CONFIG_FILE_NAME);
  }

  const home = os.homedir();

  // Fallback robusto se homedir falhar (raro)
  if (!home || home.trim().length === 0) {
    // tenta HOME env
    const envHome = process.env.HOME || process.env.USERPROFILE || "";
    if (envHome) {
      return path.join(envHome, ".config", CONFIG_DIR_NAME, CONFIG_FILE_NAME);
    }
    // último fallback relativo (não ideal mas evita throw)
    return path.join(
      process.cwd(),
      ".config",
      CONFIG_DIR_NAME,
      CONFIG_FILE_NAME
    );
  }

  return path.join(home, ".config", CONFIG_DIR_NAME, CONFIG_FILE_NAME);
}

/**
 * Garante que diretório da config existe (mkdir -p)
 */
function ensureConfigDirExists(configPath: string): void {
  const dir = path.dirname(configPath);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
}

/**
 * Escrita atômica com chmod 0o600.
 * - Escreve em arquivo temporário no mesmo dir
 * - chmod 0o600
 * - rename atômico
 *
 * @param filePath destino final
 * @param data string JSON
 */
function atomicWriteFile(filePath: string, data: string): void {
  ensureConfigDirExists(filePath);

  const dir = path.dirname(filePath);
  const tmpName = `${path.basename(
    filePath
  )}.tmp.${process.pid}.${Date.now()}.${Math.random()
    .toString(36)
    .slice(2, 8)}`;
  const tmpPath = path.join(dir, tmpName);

  try {
    // Escreve temp
    fs.writeFileSync(tmpPath, data, { encoding: "utf8", mode: 0o600 });

    // Garante permissão 0o600 mesmo se umask interferiu
    try {
      fs.chmodSync(tmpPath, 0o600);
    } catch {
      // chmod pode falhar no Windows; ignora mas continua
    }

    // fsync do arquivo para durabilidade (best-effort)
    try {
      const fd = fs.openSync(tmpPath, "r");
      try {
        fs.fsyncSync(fd);
      } finally {
        fs.closeSync(fd);
      }
    } catch {
      // fsync opcional
    }

    // Rename atômico
    fs.renameSync(tmpPath, filePath);

    // Garante 0o600 no destino final também
    try {
      fs.chmodSync(filePath, 0o600);
    } catch {
      // ignora em Windows
    }
  } finally {
    // Cleanup temp se ainda existir
    try {
      if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    } catch {
      // ignore
    }
  }
}

// =============================================================================
// API PÚBLICA: load / save / update + cache memória
// =============================================================================

/**
 * Limpa cache em memória (útil para testes ou quando arquivo mudou externamente).
 */
export function clearConfigCache(): void {
  _memoryCache = null;
}

/**
 * Carrega configuração de disco com cache em memória baseado em mtime.
 * - Se arquivo não existe, retorna defaults.
 * - Se JSON inválido, retorna defaults + loga warning se debug.
 * - Atualiza cache em memória.
 *
 * @param opts - force: se true ignora cache memória
 * @returns AntigravityConfig sanitizada
 */
export function loadConfig(opts?: { force?: boolean }): AntigravityConfig {
  const configPath = getConfigPath();
  const force = opts?.force ?? false;

  // Checa cache memória se mtime ainda válido
  if (!force && _memoryCache && _memoryCache.path === configPath) {
    try {
      const stat = fs.statSync(configPath);
      if (stat.mtimeMs === _memoryCache.mtimeMs) {
        return { ..._memoryCache.config };
      }
    } catch {
      // arquivo pode ter sido deletado; se cache existe, retorna cache ou defaults?
      // Se arquivo não existe, mantém cache? Melhor invalidar e retornar defaults
      // mas vamos continuar fluxo para recarregar defaults
      if (!fs.existsSync(configPath)) {
        // Se arquivo sumiu, retorna defaults mas mantém cache? Não - limpa e retorna defaults
        clearConfigCache();
        return { ...DEFAULT_CONFIG };
      }
      // erro de stat mas arquivo existe: retorna cache como fallback
      return { ..._memoryCache.config };
    }
  }

  // Lê disco
  let rawContent: string | null = null;
  let mtimeMs = 0;

  try {
    const stat = fs.statSync(configPath);
    mtimeMs = stat.mtimeMs;
    rawContent = fs.readFileSync(configPath, { encoding: "utf8" });
  } catch (err) {
    // Arquivo não existe => retorna defaults
    if (
      (err as NodeJS.ErrnoException).code === "ENOENT" ||
      !fs.existsSync(configPath)
    ) {
      const cfg = { ...DEFAULT_CONFIG };
      _memoryCache = {
        config: cfg,
        mtimeMs: 0,
        path: configPath,
        loadedAtMs: Date.now(),
      };
      return { ...cfg };
    }
    // Outros erros de leitura => defaults e limpa cache
    clearConfigCache();
    return { ...DEFAULT_CONFIG };
  }

  let parsed: unknown;
  try {
    parsed = rawContent ? JSON.parse(rawContent) : null;
  } catch {
    // JSON inválido => defaults
    const cfg = { ...DEFAULT_CONFIG };
    _memoryCache = {
      config: cfg,
      mtimeMs,
      path: configPath,
      loadedAtMs: Date.now(),
    };
    return { ...cfg };
  }

  const cfg = parseAndValidateConfig(parsed, { strict: false });

  _memoryCache = {
    config: cfg,
    mtimeMs,
    path: configPath,
    loadedAtMs: Date.now(),
  };

  return { ...cfg };
}

/**
 * Salva configuração completa em disco de forma atômica com chmod 0o600.
 * Atualiza cache em memória.
 *
 * @param config - Objeto config completo (validado)
 * @returns config salva (clone)
 */
export function saveConfig(config: AntigravityConfig): AntigravityConfig {
  // Valida antes de salvar (non-strict para sanitizar)
  const sanitized = parseAndValidateConfig(config, { strict: false });

  const configPath = getConfigPath();
  const json = JSON.stringify(sanitized, null, 2) + "\n";

  atomicWriteFile(configPath, json);

  // Atualiza cache com novo mtime
  let mtimeMs = Date.now();
  try {
    const stat = fs.statSync(configPath);
    mtimeMs = stat.mtimeMs;
  } catch {
    // ignora
  }

  _memoryCache = {
    config: sanitized,
    mtimeMs,
    path: configPath,
    loadedAtMs: Date.now(),
  };

  return { ...sanitized };
}

/**
 * Atualiza parcialmente a config: merge shallow + salva atômico.
 * Thread-safe o suficiente para uso single-process; para multi-processo depende de rename atômico.
 *
 * @param partial - Campos a atualizar
 * @returns config atualizada completa
 *
 * @example
 * updateConfig({ debug: true, toast_scope: "minimal" })
 */
export function updateConfig(
  partial: Partial<AntigravityConfig>
): AntigravityConfig {
  if (!isObject(partial)) {
    throw new TypeError("updateConfig: partial must be an object");
  }

  // load atual (usa cache se válido)
  const current = loadConfig();

  // Merge shallow: apenas chaves conhecidas são aceitas
  const mergedRaw: Record<string, unknown> = { ...current };

  for (const key of Object.keys(partial) as Array<keyof AntigravityConfig>) {
    if (key in DEFAULT_CONFIG) {
      (mergedRaw as Record<string, unknown>)[key] = (
        partial as Record<string, unknown>
      )[key];
    }
  }

  // Valida merged
  const validated = parseAndValidateConfig(mergedRaw, { strict: false });

  return saveConfig(validated);
}

/**
 * Versão assíncrona de loadConfig (wrapper sobre sync para compatibilidade)
 * Usa fs.promises mas mantém mesma semântica de cache.
 */
export async function loadConfigAsync(opts?: {
  force?: boolean;
}): Promise<AntigravityConfig> {
  // Mantém simples, chama sync dentro de Promise - evita duplicar lógica
  return loadConfig(opts);
}

/**
 * Versão assíncrona de saveConfig
 */
export async function saveConfigAsync(
  config: AntigravityConfig
): Promise<AntigravityConfig> {
  return saveConfig(config);
}

/**
 * Versão assíncrona de updateConfig
 */
export async function updateConfigAsync(
  partial: Partial<AntigravityConfig>
): Promise<AntigravityConfig> {
  return updateConfig(partial);
}

// =============================================================================
// EXPORT INFO BUNDLE (opcional para debugging seguro - nunca loga secret)
// =============================================================================

/**
 * Info segura de debug (sem secret). Uso em logs com debug enabled.
 */
export function getSafeDebugInfo() {
  const cfgPath = getConfigPath();
  const tuple = getPlatformTuple();
  return {
    configPath: cfgPath,
    clientId: OAUTH_CLIENT_ID,
    projectFallback: PROJECT_FALLBACK,
    endpoints: CLOUDCODE_ENDPOINTS,
    modelsCount: MODELS_2026.length,
    platform: tuple.platform,
    arch: tuple.arch,
    userAgent: buildGeminiUserAgent(),
    xGoog: buildXGoogApiClient(),
    clientMetadata: CLIENT_METADATA_STRING,
  } as const;
}
