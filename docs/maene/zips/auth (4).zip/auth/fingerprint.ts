/**
 * fingerprint.ts — FingerprintGenerator for opencode-antigravity-auth-next
 * @module fingerprint
 * @version 2.0.0
 * @date 2026-08-25
 *
 * Third-person observer architecture:
 * - Library-first export, root-first (no src/ nested)
 * - Zero external dependencies, only node:* builtins + global fetch
 * - Direct cloudcode-pa.googleapis.com usage (no localhost v1 base)
 * - Supports 2026 models: gemini-3-pro-preview, gemini-3-flash-preview,
 *   gemini-3.1-pro-preview, gemini-2.5, claude-opus-4-6-thinking, claude-sonnet-4-6
 *
 * Responsibilities:
 * - Coherent platform pools: windows/amd64, darwin/arm64, linux/x64
 * - Deterministic FNV-1a hashing for session_id and user_prompt_id
 * - Jitter 0-80ms anti-rate-limit
 * - User-Agent antigravity/{version} {os}/{arch}
 * - X-Goog-Api-Client only for gemini-cli mode
 * - Client-Metadata generation
 * - Explicitly omits X-Goog-QuotaUser and X-Client-Device-Id (AM does not send in content)
 */

import * as os from "node:os";
import { randomInt, randomUUID } from "node:crypto";

/* -------------------------------------------------------------------------- */
/* Types                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Supported header generation styles.
 * - antigravity: emulates Antigravity Manager content requests
 * - gemini-cli: emulates Gemini CLI pool (includes X-Goog-Api-Client)
 */
export type HeaderStyle = "antigravity" | "gemini-cli";

/** OS name normalized for fingerprint pools */
export type OsName = "windows" | "darwin" | "linux";

/** Architecture name normalized for fingerprint pools */
export type ArchName = "amd64" | "arm64" | "x64";

/**
 * Coherent platform pool entry.
 * The pool guarantees OS/arch consistency for fingerprinting.
 */
export interface PlatformPool {
  /** Logical key e.g. windows/amd64 */
  readonly key: string;
  /** Normalized OS name used in User-Agent */
  readonly os: OsName;
  /** Normalized arch name used in User-Agent */
  readonly arch: ArchName;
  /** Node.js platform identifier */
  readonly nodePlatform: NodeJS.Platform;
  /** Node.js arch identifier */
  readonly nodeArch: string;
  /** Electron/Chrome OS fragment if needed */
  readonly displayOs: string;
}

/**
 * Map of all known pools
 */
export type PoolMap = Record<string, PlatformPool>;

/* -------------------------------------------------------------------------- */
/* Constants — pools coerentes                                                */
/* -------------------------------------------------------------------------- */

/**
 * Blinded short-name compatible pools.
 * Windows uses amd64 naming (Go convention) to match AM traffic,
 * darwin uses arm64 (Apple Silicon primary for 2026), linux uses x64.
 */
export const PLATFORM_POOLS: PoolMap = {
  "windows/amd64": {
    key: "windows/amd64",
    os: "windows",
    arch: "amd64",
    nodePlatform: "win32",
    nodeArch: "x64",
    displayOs: "Windows_NT",
  },
  "darwin/arm64": {
    key: "darwin/arm64",
    os: "darwin",
    arch: "arm64",
    nodePlatform: "darwin",
    nodeArch: "arm64",
    displayOs: "Darwin",
  },
  "linux/x64": {
    key: "linux/x64",
    os: "linux",
    arch: "x64",
    nodePlatform: "linux",
    nodeArch: "x64",
    displayOs: "Linux",
  },
} as const;

/** Fallback Antigravity version when remote fetch fails — governance requires 1.19.2 */
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2";

/** Preferred plugin version for new installs */
export const PLUGIN_VERSION_FALLBACK = "2.0.0";

/* -------------------------------------------------------------------------- */
/* FNV-1a implementation                                                      */
/* -------------------------------------------------------------------------- */

/** FNV-1a 32-bit constants */
const FNV32_OFFSET_BASIS = 0x811c9dc5;
const FNV32_PRIME = 0x01000193;

/** FNV-1a 64-bit constants for longer IDs */
const FNV64_OFFSET_BASIS = 14695981039346656037n;
const FNV64_PRIME = 1099511628211n;
const FNV64_MASK = (1n << 64n) - 1n;

/* -------------------------------------------------------------------------- */
/* Class                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Generates coherent fingerprints for Antigravity requests.
 *
 * The generator follows third-person observer pattern:
 * it does not mutate global state, only observes current runtime
 * and produces deterministic outputs when a seed is supplied.
 */
export class FingerprintGenerator {
  /** Antigravity app version used in User-Agent */
  private readonly version: string;
  /** Cached pool for current process */
  private poolCache: PlatformPool | null = null;

  /**
   * @param antigravityVersion - Version string to embed in User-Agent.
   *   Expected format semver like 1.19.2 or 2.0.0. Falls back to 1.19.2 if invalid.
   */
  constructor(antigravityVersion?: string) {
    const v = (antigravityVersion ?? "").trim();
    if (v && /^\d+\.\d+\.\d+/.test(v)) {
      this.version = v;
    } else if (v && /^antigravity\//.test(v)) {
      // Allow passing full UA string — extracts version part
      const m = v.match(/antigravity\/([0-9]+\.[0-9]+\.[0-9]+[^\s]*)/i);
      this.version = m ? m[1] : ANTIGRAVITY_VERSION_FALLBACK;
    } else {
      this.version = ANTIGRAVITY_VERSION_FALLBACK;
    }
  }

  /* ---------------------------- hashing ---------------------------- */

  /**
   * Computes FNV-1a 32-bit hash (deterministic, fast, no crypto dependency).
   * @param input string to hash
   * @returns unsigned 32-bit integer
   */
  private fnv1a32(input: string): number {
    if (typeof input !== "string") {
      throw new TypeError("fnv1a32 input must be string");
    }
    let hash = FNV32_OFFSET_BASIS;
    for (let i = 0; i < input.length; i++) {
      hash ^= input.charCodeAt(i);
      hash = Math.imul(hash, FNV32_PRIME);
    }
    return hash >>> 0;
  }

  /**
   * Computes FNV-1a 64-bit hash for longer session identifiers.
   * @param input string to hash
   * @returns 64-bit bigint
   */
  private fnv1a64(input: string): bigint {
    if (typeof input !== "string") {
      throw new TypeError("fnv1a64 input must be string");
    }
    let hash = FNV64_OFFSET_BASIS;
    for (let i = 0; i < input.length; i++) {
      hash ^= BigInt(input.charCodeAt(i));
      hash = (hash * FNV64_PRIME) & FNV64_MASK;
    }
    return hash;
  }

  /**
   * Returns hex representation of FNV-1a 32-bit hash, padded to 8 chars.
   */
  public fnv1aHex(input: string): string {
    const h = this.fnv1a32(input);
    return h.toString(16).padStart(8, "0");
  }

  /**
   * Generates a deterministic session_id from a seed.
   *
   * The implementation uses FNV-1a 64-bit to remain deterministic:
   * same seed → same ID across processes. When no seed is supplied,
   * it falls back to randomUUID + hostname + timestamp, still hashed.
   *
   * Format: sess_<16-hex>-<36-base time fragment> or sess_<16-hex> when seeded.
   *
   * @param seed optional deterministic seed (e.g., projectId + userId + conversation hash)
   * @returns session identifier string
   */
  public generateSessionId(seed?: string): string {
    try {
      if (seed && typeof seed === "string" && seed.length > 0) {
        const h = this.fnv1a64(seed);
        const hex = h.toString(16).padStart(16, "0");
        // Second round for extra entropy while staying deterministic
        const h2 = this.fnv1a32(`${seed}:sess`);
        const suffix = h2.toString(16).padStart(8, "0");
        return `sess_${hex}${suffix}`;
      }
      // Non-deterministic path: random base still hashed via FNV for uniform format
      const randomBase = `${randomUUID()}:${os.hostname()}:${Date.now()}`;
      const h = this.fnv1a64(randomBase);
      const timeFrag = Date.now().toString(36);
      return `sess_${h.toString(16).padStart(16, "0")}_${timeFrag}`;
    } catch (err) {
      // Fallback never throws — guarantees session_id always present
      const fallback = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
      return `sess_${this.fnv1aHex(fallback)}_${Date.now().toString(36)}`;
    }
  }

  /**
   * Generates a deterministic user_prompt_id from a seed.
   *
   * Mirrors Antigravity Manager behavior where prompt IDs are stable per request content.
   *
   * @param seed optional deterministic seed (e.g., message content or tool-call hash)
   * @returns user prompt identifier
   */
  public generateUserPromptId(seed?: string): string {
    try {
      if (seed && typeof seed === "string" && seed.length > 0) {
        const h = this.fnv1a64(seed);
        const hex = h.toString(16).padStart(16, "0");
        const h2 = this.fnv1a32(`${seed}:up`);
        return `up_${hex}${h2.toString(16).padStart(8, "0")}`;
      }
      const randomBase = `${randomUUID()}:${os.hostname()}:${process.pid}`;
      const h = this.fnv1a64(randomBase);
      return `up_${h.toString(16).padStart(16, "0")}_${Date.now().toString(36)}`;
    } catch {
      const fallback = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
      return `up_${this.fnv1aHex(fallback)}`;
    }
  }

  /* ---------------------------- platform ---------------------------- */

  /**
   * Returns the coherent platform pool for the current runtime.
   *
   * Detection order:
   * - win32 → windows/amd64
   * - darwin → darwin/arm64 (Apple Silicon primary, coherent for 2026)
   * - otherwise → linux/x64
   *
   * The result is cached after first detection.
   */
  public getPlatformPool(): PlatformPool {
    if (this.poolCache) {
      return this.poolCache;
    }

    const plat = os.platform();
    let key: string;

    if (plat === "win32") {
      key = "windows/amd64";
    } else if (plat === "darwin") {
      // Coherence: even if node reports x64 on Rosetta, prefers arm64 pool
      key = "darwin/arm64";
    } else {
      key = "linux/x64";
    }

    const pool = PLATFORM_POOLS[key];
    if (!pool) {
      // Defensive: should never happen due to constants above
      this.poolCache = PLATFORM_POOLS["linux/x64"];
    } else {
      this.poolCache = pool;
    }
    return this.poolCache;
  }

  /**
   * Static accessor for all pools — useful for testing and CLI listing.
   */
  public static getPlatformPools(): PoolMap {
    return { ...PLATFORM_POOLS };
  }

  /**
   * Returns the current pool key string, e.g., "darwin/arm64".
   */
  public getCurrentPoolKey(): string {
    return this.getPlatformPool().key;
  }

  /* ---------------------------- jitter ---------------------------- */

  /**
   * Generates jitter delay in milliseconds, inclusive range 0-80ms.
   *
   * Uses node:crypto.randomInt for cryptographically strong randomness,
   * falls back to Math.random if not available.
   *
   * @returns integer 0..80
   */
  public getJitterMs(): number {
    try {
      // randomInt is synchronous when no callback supplied (Node >=18)
      const v = randomInt(0, 81);
      if (typeof v === "number" && Number.isFinite(v)) {
        return v;
      }
    } catch {
      // fallback below
    }
    return Math.floor(Math.random() * 81);
  }

  /**
   * Applies jitter asynchronously — awaits 0-80ms.
   * Useful before retry or before quota-sensitive requests.
   *
   * @returns promise that resolves after jitter delay
   */
  public async applyJitter(): Promise<void> {
    const ms = this.getJitterMs();
    if (ms <= 0) return;
    await new Promise<void>((resolve) => setTimeout(resolve, ms));
  }

  /* ---------------------------- metadata ---------------------------- */

  /**
   * Builds Client-Metadata header value.
   *
   * Antigravity Manager observed traffic sends a structured value.
   * Format chosen to match AM: JSON stringified with ideType, platform, arch, version, node.
   * Keeps it human-readable for debuggability; server tolerates JSON.
   *
   * @param pool optional pool override, defaults to current runtime pool
   */
  private buildClientMetadata(pool?: PlatformPool): string {
    const p = pool ?? this.getPlatformPool();
    try {
      const nodeVer = process.version;
      const payload = {
        ideType: "ANTIGRAVITY",
        ideVersion: this.version,
        platform: p.os.toUpperCase(),
        arch: p.arch.toUpperCase(),
        pluginVersion: PLUGIN_VERSION_FALLBACK,
        nodeVersion: nodeVer,
        osDisplay: p.displayOs,
      };
      // AM uses key=value pairs in some builds; JSON is accepted by cloudcode-pa.
      // Returns compact JSON to stay compatible with googleapis client metadata parsing.
      return JSON.stringify(payload);
    } catch {
      // Minimal fallback never throws
      return `ideType=antigravity,platform=${p.os},arch=${p.arch},version=${this.version}`;
    }
  }

  /**
   * Builds X-Goog-Api-Client header value — only for gemini-cli mode.
   *
   * Format: gl-node/<nodeVersion> antigravity/<version> gccl/<clientVersion>
   * Mirrors Gemini CLI telemetry observed 2025-2026.
   */
  private buildApiClient(): string {
    try {
      const nodeVer = process.version.replace(/^v/, "");
      // gccl = google cloud code library version marker; gb = antigravity
      return `gl-node/${nodeVer} antigravity/${this.version} gccl/1.0.0`;
    } catch {
      return `antigravity/${this.version}`;
    }
  }

  /* ---------------------------- headers ---------------------------- */

  /**
   * Generates fingerprint headers for cloudcode-pa.googleapis.com requests.
   *
   * Requirements enforced:
   * - User-Agent: antigravity/{version} {os}/{arch}  (coherent pool)
   * - Client-Metadata: always included (AM observed)
   * - X-Goog-Api-Client: ONLY when headerStyle === 'gemini-cli'
   * - Never includes X-Goog-QuotaUser nor X-Client-Device-Id (AM does not send in content)
   *
   * @param headerStyle 'antigravity' for default content path, 'gemini-cli' for CLI quota pool
   * @returns record of headers ready to spread into fetch init
   */
  public getFingerprintHeaders(
    headerStyle: HeaderStyle = "antigravity"
  ): Record<string, string> {
    if (headerStyle !== "antigravity" && headerStyle !== "gemini-cli") {
      throw new TypeError(
        `headerStyle must be 'antigravity' or 'gemini-cli', got ${String(headerStyle)}`
      );
    }

    const pool = this.getPlatformPool();

    // Coherent User-Agent — critical: original plugin failed due to outdated 1.11.5
    const userAgent = `antigravity/${this.version} ${pool.os}/${pool.arch}`;

    const headers: Record<string, string> = {
      "User-Agent": userAgent,
      "Content-Type": "application/json",
      "Client-Metadata": this.buildClientMetadata(pool),
      // Accept header improves compatibility with cloudcode-pa
      Accept: "application/json",
    };

    if (headerStyle === "gemini-cli") {
      // Only for Gemini CLI quota pool — matches daily-cloudcode-pa production behavior
      headers["X-Goog-Api-Client"] = this.buildApiClient();
    }

    // Explicitly ensure banned headers are not present (defensive)
    // AM traffic analysis shows these are absent in content requests
    // delete headers["X-Goog-QuotaUser"];
    // delete headers["X-Client-Device-Id"];
    // delete headers["X-Goog-Request-Reason"];

    return headers;
  }

  /**
   * Returns version currently used for fingerprinting.
   */
  public getVersion(): string {
    return this.version;
  }
}

/* -------------------------------------------------------------------------- */
/* Singleton helper for library-first usage                                   */
/* -------------------------------------------------------------------------- */

/**
 * Default shared generator — uses fallback version until version.ts resolves remote.
 * Consumers may create own instances with dynamic version from version.ts.
 */
export const defaultFingerprintGenerator = new FingerprintGenerator(
  ANTIGRAVITY_VERSION_FALLBACK
);

/**
 * Convenience wrapper matching original plugin export names.
 */
export function getFingerprintHeaders(
  style: HeaderStyle = "antigravity",
  version?: string
): Record<string, string> {
  if (version) {
    return new FingerprintGenerator(version).getFingerprintHeaders(style);
  }
  return defaultFingerprintGenerator.getFingerprintHeaders(style);
}

/* -------------------------------------------------------------------------- */
/* Exports — library-first barrel compatible                                 */
/* -------------------------------------------------------------------------- */

export default FingerprintGenerator;
