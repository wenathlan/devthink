/**
 * @file cli.ts
 * @module opencode-antigravity-auth-next/cli
 * @description
 *  Third-person observer: the library watches how Antigravity Manager and
 *  Gemini CLI expose authentication UX and reproduces it as a standalone
 *  CLI without external dependencies. The observer never leaks secrets,
 *  enforces chmod 600 on disk, uses only node:* builtins + global fetch,
 *  and talks directly to cloudcode-pa.googleapis.com without any localhost
 *  v1 base-url proxy. OAuth callback still uses 127.0.0.1 random port locked
 *  by kernel (port 0) — 100% user choice, host fixed to loopback, no fixed
 *  port, no 0.0.0.0, compatible with spec governance.
 *
 *  Layout: library-first, root-first — file lives in /mnt/data/auth/cli.ts
 *  Runtime: only node:* builtins (node:fs, node:path, node:os, node:readline,
 *           node:crypto) + global fetch (Node >=18). Zero external deps.
 *  Date governance: 25/08/2026 — Canto do Buriti, PI, BR — v2.0.0
 *
 *  Capabilities:
 *   - Interactive menu (readline) + non-interactive subcommands
 *   - login: PKCE S256 OAuth flow via ./oauth.ts startOAuthFlow direct cloudcode-pa
 *   - logout: remove account, --all flag
 *   - list accounts: human table, healthy count, disabled/quota state
 *   - check quotas: direct v1internal:retrieveUserQuotaSummary cascade PROD/DAILY/SANDBOX
 *   - manage accounts enable/disable sticky/round-robin aware
 *   - configure models: writes plugin model definitions direct to opencode.json
 *     with atomic tmp+chmod 600+rename, merging existing file safely
 *   - diagnostics: paths, version, endpoint reachability, token expiry
 *
 *  Atomicity:
 *   - All writes use tmp file in same dir, random suffix, chmod 600, rename.
 *   - Accounts file is delegated to AccountManager which already does chmod 600.
 *   - opencode.json write is done here with same guarantees.
 *
 *  Models 2026 awareness:
 *   - gemini-3-pro-preview, gemini-3-flash-preview, gemini-3.1-pro-preview,
 *     gemini-3.1-pro-preview-customtools, gemini-2.5-pro/flash,
 *     claude-opus-4-6-thinking (low,max), claude-sonnet-4-6,
 *     plus antigravity-* prefixed variants.
 *
 *  Bypass notes documented:
 *   EN: Antigravity bypass relies on mimicking antigravity/{ver} {os}/{arch} UA
 *       and bypassing x-goog-user-project stripping, endpoint cascade 403/404/5xx.
 *       This CLI reproduces fingerprint via FingerprintGenerator + dynamic UA.
 *   PT-BR: Bypass Antigravity depende de imitar UA antigravity/{ver} {os}/{arch}
 *       e remover x-goog-user-project, cascata de endpoints em 403/404/5xx.
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
import * as readline from "node:readline";

// ---------------------------------------------------------------------------
// Local library imports — ESM .js extension for tsx + tsc compatibility
// Observer keeps root-first imports, no src/ nesting.
// ---------------------------------------------------------------------------

import { AccountManager } from "./accounts.js";
import { startOAuthFlow, SUPPORTED_MODELS_2026 as OAUTH_SUPPORTED_MODELS } from "./oauth.js";
import { resolveProjectId, FALLBACK_PROJECT_ID, CODE_ASSIST_ENDPOINTS } from "./project.js";
import { QuotaManager, ANTIGRAVITY_VERSION_FALLBACK as QUOTA_VERSION_FALLBACK, getDynamicUserAgent } from "./quota.js";
import { ANTIGRAVITY_VERSION_FALLBACK, ANTIGRAVITY_USER_AGENT_FALLBACK } from "./constants.js";

// ---------------------------------------------------------------------------
// Constants — observer enforces secure perms, no external deps
// ---------------------------------------------------------------------------

const FILE_MODE = 0o600 as const;
const DIR_MODE = 0o755 as const;
const CLI_VERSION = "2.0.0" as const;

const CLOUDCODE_ENDPOINTS_DIRECT = [
  "https://cloudcode-pa.googleapis.com",
  "https://daily-cloudcode-pa.googleapis.com",
  "https://daily-cloudcode-pa.sandbox.googleapis.com",
] as const;

// ---------------------------------------------------------------------------
// ANSI helpers — zero deps, best-effort (disable if NO_COLOR)
// ---------------------------------------------------------------------------

const NO_COLOR = !!process.env.NO_COLOR || process.env.TERM === "dumb";
function ansi(code: string, txt: string): string {
  if (NO_COLOR) return txt;
  return `\x1b[${code}m${txt}\x1b[0m`;
}
const c = {
  bold: (s: string) => ansi("1", s),
  dim: (s: string) => ansi("2", s),
  red: (s: string) => ansi("31", s),
  green: (s: string) => ansi("32", s),
  yellow: (s: string) => ansi("33", s),
  cyan: (s: string) => ansi("36", s),
  magenta: (s: string) => ansi("35", s),
  gray: (s: string) => ansi("90", s),
};

// ---------------------------------------------------------------------------
// Atomic file helpers — third-person observer, production hardened
// ---------------------------------------------------------------------------

async function ensureDir(dir: string): Promise<void> {
  try {
    await fsp.mkdir(dir, { recursive: true, mode: DIR_MODE });
  } catch {}
  try {
    await fsp.chmod(dir, DIR_MODE);
  } catch {}
}

function ensureDirSync(dir: string): void {
  try {
    fs.mkdirSync(dir, { recursive: true, mode: DIR_MODE });
  } catch {}
  try {
    fs.chmodSync(dir, DIR_MODE);
  } catch {}
}

async function atomicWriteFileAtomic(filePath: string, content: string, mode = FILE_MODE): Promise<void> {
  const dir = path.dirname(filePath);
  await ensureDir(dir);
  const rand = crypto.randomBytes(6).toString("hex");
  const tmp = path.join(dir, `.${path.basename(filePath)}.${process.pid}.${rand}.tmp`);
  try {
    await fsp.writeFile(tmp, content, { encoding: "utf8", mode });
    try {
      await fsp.chmod(tmp, mode);
    } catch {}
    await fsp.rename(tmp, filePath);
    try {
      await fsp.chmod(filePath, mode);
    } catch {}
  } finally {
    try {
      await fsp.unlink(tmp);
    } catch {}
  }
}

function atomicWriteFileSync(filePath: string, content: string, mode = FILE_MODE): void {
  const dir = path.dirname(filePath);
  ensureDirSync(dir);
  const rand = crypto.randomBytes(6).toString("hex");
  const tmp = path.join(dir, `.${path.basename(filePath)}.${process.pid}.${rand}.tmp`);
  try {
    fs.writeFileSync(tmp, content, { encoding: "utf8", mode });
    try {
      fs.chmodSync(tmp, mode);
    } catch {}
    fs.renameSync(tmp, filePath);
    try {
      fs.chmodSync(filePath, mode);
    } catch {}
  } finally {
    try {
      fs.unlinkSync(tmp);
    } catch {}
  }
}

// ---------------------------------------------------------------------------
// Path resolvers — honoring OPENCODE_CONFIG_DIR, XDG, homedir
// ---------------------------------------------------------------------------

function resolveConfigDir(): string {
  const envDir = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (envDir) return path.resolve(envDir);
  return path.join(os.homedir(), ".config", "opencode");
}

function resolveAccountsFilePath(custom?: string): string {
  if (custom) return path.resolve(custom);
  return path.join(resolveConfigDir(), "antigravity-accounts.json");
}

function resolveAntigravityJsonPath(custom?: string): string {
  if (custom) return path.resolve(custom);
  return path.join(resolveConfigDir(), "antigravity.json");
}

interface OpenCodeJsonLocation {
  path: string;
  exists: boolean;
  source: "cwd" | "global" | "env" | "custom";
}

function resolveOpenCodeJsonCandidates(): string[] {
  const candidates: string[] = [];
  const envDir = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (envDir) {
    candidates.push(path.join(path.resolve(envDir), "opencode.json"));
  }
  candidates.push(path.join(process.cwd(), "opencode.json"));
  candidates.push(path.join(process.cwd(), ".opencode", "opencode.json"));
  candidates.push(path.join(os.homedir(), ".config", "opencode", "opencode.json"));
  candidates.push(path.join(os.homedir(), ".opencode", "opencode.json"));
  // dedup preserve order
  return [...new Set(candidates)];
}

async function locateOpenCodeJson(customPath?: string, preferGlobal = false): Promise<OpenCodeJsonLocation> {
  if (customPath) {
    const abs = path.resolve(customPath);
    try {
      await fsp.access(abs, fs.constants.F_OK);
      return { path: abs, exists: true, source: "custom" };
    } catch {
      return { path: abs, exists: false, source: "custom" };
    }
  }

  const candidates = resolveOpenCodeJsonCandidates();
  const ordered = preferGlobal ? [...candidates].reverse() : candidates;

  for (const cand of ordered) {
    try {
      await fsp.access(cand, fs.constants.F_OK);
      const src: OpenCodeJsonLocation["source"] =
        cand.includes(process.cwd()) ? "cwd" : cand.includes(os.homedir()) && cand.includes(".config") ? "global" : cand === path.join(path.resolve(process.env.OPENCODE_CONFIG_DIR ?? ""), "opencode.json") ? "env" : "global";
      return { path: cand, exists: true, source: src };
    } catch {}
  }

  // none exists — default to cwd or global based on flag
  if (preferGlobal) {
    return { path: path.join(resolveConfigDir(), "opencode.json"), exists: false, source: "global" };
  }
  return { path: path.join(process.cwd(), "opencode.json"), exists: false, source: "cwd" };
}

function readJsonSafeSync(filePath: string): any {
  try {
    const txt = fs.readFileSync(filePath, "utf8");
    if (!txt.trim()) return {};
    return JSON.parse(txt);
  } catch {
    return null;
  }
}

async function readJsonSafe(filePath: string): Promise<any | null> {
  try {
    const txt = await fsp.readFile(filePath, "utf8");
    if (!txt.trim()) return {};
    return JSON.parse(txt);
  } catch (e: any) {
    if (e?.code === "ENOENT") return null;
    return null;
  }
}

// ---------------------------------------------------------------------------
// Model definitions 2026 — observer documents bypass via UA + endpoint cascade
// ---------------------------------------------------------------------------

interface ModelCatalogEntry {
  id: string;
  name: string;
  provider: "antigravity";
  family: "gemini" | "claude";
  context: number;
  output: number;
  thinking: boolean;
  variants: string[];
  aliases: string[];
}

const MODELS_2026_CATALOG: ModelCatalogEntry[] = [
  {
    id: "gemini-3-pro-preview",
    name: "Gemini 3 Pro Preview (Antigravity)",
    provider: "antigravity",
    family: "gemini",
    context: 1_048_576,
    output: 65_535,
    thinking: true,
    variants: ["antigravity-gemini-3-pro-preview", "antigravity-gemini-3-pro"],
    aliases: ["gemini-3-pro", "antigravity-gemini-3-pro"],
  },
  {
    id: "gemini-3-flash-preview",
    name: "Gemini 3 Flash Preview (Antigravity)",
    provider: "antigravity",
    family: "gemini",
    context: 1_048_576,
    output: 65_535,
    thinking: false,
    variants: ["antigravity-gemini-3-flash-preview", "antigravity-gemini-3-flash"],
    aliases: ["gemini-3-flash", "antigravity-gemini-3-flash"],
  },
  {
    id: "gemini-3.1-pro-preview",
    name: "Gemini 3.1 Pro Preview (Antigravity)",
    provider: "antigravity",
    family: "gemini",
    context: 1_048_576,
    output: 65_535,
    thinking: true,
    variants: ["antigravity-gemini-3.1-pro-preview", "antigravity-gemini-3.1-pro"],
    aliases: ["gemini-3.1-pro-preview", "gemini-3.1-pro", "antigravity-gemini-3.1-pro"],
  },
  {
    id: "gemini-3.1-pro-preview-customtools",
    name: "Gemini 3.1 Pro Preview CustomTools (Antigravity)",
    provider: "antigravity",
    family: "gemini",
    context: 1_048_576,
    output: 65_535,
    thinking: true,
    variants: [],
    aliases: [],
  },
  {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro (Antigravity)",
    provider: "antigravity",
    family: "gemini",
    context: 1_048_576,
    output: 65_535,
    thinking: true,
    variants: ["antigravity-gemini-2.5-pro"],
    aliases: ["gemini-2.5", "gemini-2.5-pro-preview"],
  },
  {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash (Antigravity)",
    provider: "antigravity",
    family: "gemini",
    context: 1_048_576,
    output: 65_535,
    thinking: false,
    variants: ["antigravity-gemini-2.5-flash"],
    aliases: ["gemini-2.5-flash-preview"],
  },
  {
    id: "claude-opus-4-6-thinking",
    name: "Claude Opus 4.6 Thinking (Antigravity)",
    provider: "antigravity",
    family: "claude",
    context: 200_000,
    output: 64_000,
    thinking: true,
    variants: ["antigravity-claude-opus-4-6-thinking", "claude-opus-4-6-thinking-low", "claude-opus-4-6-thinking-max"],
    aliases: ["claude-opus-4-6", "antigravity-claude-opus-4-6"],
  },
  {
    id: "claude-sonnet-4-6",
    name: "Claude Sonnet 4.6 (Antigravity)",
    provider: "antigravity",
    family: "claude",
    context: 200_000,
    output: 64_000,
    thinking: false,
    variants: ["antigravity-claude-sonnet-4-6", "claude-sonnet-4-6-thinking"],
    aliases: ["claude-sonnet-4-6", "antigravity-claude-sonnet-4-6"],
  },
];

const PLUGIN_NAME = "opencode-antigravity-auth-next" as const;

// ---------------------------------------------------------------------------
// Readline helpers — only node:readline builtin
// ---------------------------------------------------------------------------

function createRl(): readline.Interface {
  return readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: true,
  });
}

function question(rl: readline.Interface, prompt: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(prompt, (ans) => resolve(ans.trim()));
  });
}

async function confirm(rl: readline.Interface, prompt: string, defaultYes = false): Promise<boolean> {
  const suffix = defaultYes ? " [Y/n] " : " [y/N] ";
  const ans = await question(rl, prompt + suffix);
  if (!ans) return defaultYes;
  return /^y(es)?$/i.test(ans);
}

// ---------------------------------------------------------------------------
// Pretty printers — table, duration, size, redaction
// ---------------------------------------------------------------------------

function fmtDuration(ms: number): string {
  if (ms <= 0) return "now";
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${s % 60}s`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ${m % 60}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

function redactEmail(email: string): string {
  // keep domain, redact local part partially for logs? CLI shows full for UX, but we keep full for operator.
  return email;
}

function printHeader(): void {
  console.log(
    c.bold(c.cyan(`\n┌─────────────────────────────────────────────────────────┐`)) +
      `\n${c.bold(c.cyan("│"))}  ${c.bold("opencode-antigravity-auth-next")} ${c.dim(`v${CLI_VERSION}`)} — third-person observer  ${c.bold(c.cyan("│"))}` +
      `\n${c.bold(c.cyan("│"))}  ${c.dim("direct cloudcode-pa.googleapis.com, no localhost v1")}        ${c.bold(c.cyan("│"))}` +
      `\n${c.bold(c.cyan("└─────────────────────────────────────────────────────────┘"))}\n`
  );
}

function printHelp(): void {
  printHeader();
  console.log(
    `${c.bold("Usage:")} npx tsx /mnt/data/auth/cli.ts <command> [options]\n` +
      `${c.bold("   or:")} node --import tsx /mnt/data/auth/cli.ts <command>\n\n` +
      `${c.bold("Commands:")}\n` +
      `  ${c.cyan("login")}                         OAuth PKCE login, add account\n` +
      `  ${c.cyan("logout")} [email] [--all]         Remove account(s)\n` +
      `  ${c.cyan("list")} | ls | accounts           List all accounts\n` +
      `  ${c.cyan("quotas")} | quota | check          Check quotas direct cloudcode-pa\n` +
      `  ${c.cyan("enable")} <email>                 Enable account\n` +
      `  ${c.cyan("disable")} <email>                Disable account\n` +
      `  ${c.cyan("configure")} [--global] [--path p] Write model definitions to opencode.json\n` +
      `  ${c.cyan("config")} | doctor | diagnostics  Show paths, version, endpoints\n` +
      `  ${c.cyan("help")}                           Show this help\n\n` +
      `${c.bold("Interactive:")}\n` +
      `  No args → menu interativo via ${c.dim("node:readline")}\n\n` +
      `${c.bold("Env:")}\n` +
      `  OPENCODE_CONFIG_DIR   Override ~/.config/opencode\n` +
      `  ANTIGRAVITY_DEBUG     Debug logging (1/true/debug)\n` +
      `  NO_COLOR              Disable ANSI colors\n\n` +
      `${c.bold("Security:")}\n` +
      `  • Atomic writes tmp+chmod 600+rename for antigravity-accounts.json & opencode.json\n` +
      `  • Direct PROD/DAILY/SANDBOX cascade 403/404/5xx, strip x-goog-user-project to avoid 403\n` +
      `  • UA ${c.dim(ANTIGRAVITY_USER_AGENT_FALLBACK)} coherent {os}/{arch}\n` +
      `  • Models 2026: ${OAUTH_SUPPORTED_MODELS.join(", ")}\n`
  );
}

// ---------------------------------------------------------------------------
// Account operations — library-first, observer pattern
// ---------------------------------------------------------------------------

async function initAccountManager(): Promise<AccountManager> {
  const mgr = new AccountManager({ disableBackground: true });
  await mgr.init();
  return mgr;
}

async function loginFlow(opts?: { noBrowser?: boolean }): Promise<void> {
  printHeader();
  console.log(c.bold("→ Login Antigravity — OAuth PKCE S256 direct cloudcode-pa\n"));

  const mgr = await initAccountManager();

  console.log(c.dim(`  Config dir: ${resolveConfigDir()}`));
  console.log(c.dim(`  Accounts file: ${resolveAccountsFilePath()} (chmod 600)`));
  console.log(c.dim(`  CloudCode base direct: ${CODE_ASSIST_ENDPOINTS.PROD}`));
  console.log(c.dim(`  UA fallback: ${ANTIGRAVITY_USER_AGENT_FALLBACK} / dynamic ${getDynamicUserAgent()}`));
  console.log("");

  // openBrowser override if --no-browser
  const openBrowserFn = opts?.noBrowser
    ? (url: string) => {
        console.log(c.yellow("\n[no-browser] Abra manualmente:\n") + url + "\n");
      }
    : undefined;

  let result: Awaited<ReturnType<typeof startOAuthFlow>>;
  try {
    result = await startOAuthFlow({
      openBrowserFn: openBrowserFn as any,
      timeoutMs: 5 * 60 * 1000,
    });
  } catch (e: any) {
    console.error(c.red(`\n✗ OAuth flow falhou: ${e?.message ?? String(e)}`));
    if (e?.cause) console.error(c.dim(`  cause: ${e.cause}`));
    process.exitCode = 1;
    return;
  }

  const email = result.userInfo.email.toLowerCase().trim();
  console.log(c.green(`\n✓ OAuth OK — ${email} (${result.userInfo.name ?? "no name"})`));
  console.log(c.dim(`  access_token expires_in ${result.tokens.expires_in}s, refresh_token ${result.tokens.refresh_token ? "present" : "absent (preserved?)"}`));

  const refreshToken = result.tokens.refresh_token;
  if (!refreshToken) {
    console.error(c.red("✗ Google não retornou refresh_token — tente login com prompt=consent ou remova acesso em https://myaccount.google.com/permissions"));
    process.exitCode = 1;
    return;
  }

  // Resolve project id direct cloudcode-pa cascade PROD → DAILY → SANDBOX, 10s timeout, no localhost v1
  console.log(c.dim("\n  Resolvendo projectId via loadCodeAssist/onboardUser cascade..."));
  let projectId = FALLBACK_PROJECT_ID;
  try {
    const resolved = await resolveProjectId({
      accessToken: result.tokens.access_token,
      email,
      metadataSaver: async (pid) => {
        // optimistic saver — will be persisted again via addAccount
        projectId = pid;
      },
    });
    projectId = resolved.projectId;
    console.log(
      resolved.isFallback
        ? c.yellow(`  ⚠ Fallback projectId ${projectId} (all endpoints failed, works Antigravity but 403 Gemini CLI)`)
        : c.green(`  ✓ ProjectId ${projectId} via ${resolved.endpointUsed ?? "cache"} modelsChecked=${resolved.modelsChecked ?? "n/a"}`)
    );
  } catch (e: any) {
    console.log(c.yellow(`  ⚠ resolveProjectId falhou, usando fallback ${FALLBACK_PROJECT_ID}: ${e?.message ?? String(e)}`));
    projectId = FALLBACK_PROJECT_ID;
  }

  // Add to manager — atomic chmod 600 via manager.save()
  try {
    const now = Date.now();
    const added = await mgr.addAccount({
      email,
      refreshToken,
      accessToken: result.tokens.access_token,
      expiry: now + result.tokens.expires_in * 1000,
      projectId,
      displayName: result.userInfo.name,
    } as any);

    // Try update displayName if manager doesn't set
    if (result.userInfo.name) {
      await mgr.updateAccount(email, { displayName: result.userInfo.name });
    }

    console.log(c.green(`\n✓ Conta adicionada/ atualizada: ${added.email}`));
    console.log(c.dim(`  ID: ${added.id}`));
    console.log(c.dim(`  Project: ${added.projectId}`));
    console.log(c.dim(`  File: ${mgr.filePath}`));
    console.log(`\n${c.bold("Próximos passos:")} ${c.cyan("opencode-antigravity-auth-next configure")} para escrever models em ${c.dim("opencode.json")}`);
  } catch (e: any) {
    console.error(c.red(`\n✗ Falha ao salvar conta: ${e?.message ?? String(e)}`));
    process.exitCode = 1;
  } finally {
    await mgr.dispose().catch(() => {});
  }
}

async function logoutFlow(emailArg?: string, all = false): Promise<void> {
  printHeader();
  const mgr = await initAccountManager();
  const accounts = mgr.listAll();

  if (accounts.length === 0) {
    console.log(c.yellow("Nenhuma conta cadastrada."));
    await mgr.dispose();
    return;
  }

  if (all) {
    console.log(c.bold(`→ Logout --all: removendo ${accounts.length} conta(s)`));
    const rl = createRl();
    const ok = await confirm(rl, c.red(`Confirmar remoção de TODAS ${accounts.length} contas?`), false);
    rl.close();
    if (!ok) {
      console.log(c.dim("Cancelado."));
      await mgr.dispose();
      return;
    }
    for (const acc of accounts) {
      await mgr.removeAccount(acc.email);
      console.log(c.dim(`  removido ${acc.email}`));
    }
    console.log(c.green(`\n✓ Todas contas removidas. File: ${mgr.filePath}`));
    await mgr.dispose();
    return;
  }

  let targetEmail = emailArg?.toLowerCase().trim();

  if (!targetEmail) {
    if (accounts.length === 1) {
      targetEmail = accounts[0].email;
    } else {
      // interactive choose
      console.log(c.bold("→ Logout — escolha conta para remover:\n"));
      accounts.forEach((acc, i) => {
        console.log(`  ${c.cyan(String(i + 1))}. ${acc.email} ${acc.disabled ? c.red("[disabled]") : c.green("[active]")} project=${acc.projectId ?? FALLBACK_PROJECT_ID}`);
      });
      const rl = createRl();
      const ans = await question(rl, `\nDigite número (1-${accounts.length}) ou email: `);
      rl.close();
      const num = Number(ans);
      if (Number.isFinite(num) && num >= 1 && num <= accounts.length) {
        targetEmail = accounts[num - 1].email;
      } else if (ans.includes("@")) {
        targetEmail = ans.toLowerCase();
      } else {
        console.log(c.yellow("Entrada inválida, cancelado."));
        await mgr.dispose();
        return;
      }
    }
  }

  if (!targetEmail) {
    console.log(c.yellow("Email não informado, cancelado."));
    await mgr.dispose();
    return;
  }

  const existing = mgr.getByEmail(targetEmail);
  if (!existing) {
    console.error(c.red(`Conta não encontrada: ${targetEmail}`));
    console.log(c.dim(`Contas existentes: ${accounts.map((a) => a.email).join(", ")}`));
    await mgr.dispose();
    process.exitCode = 1;
    return;
  }

  const rl2 = createRl();
  const ok2 = await confirm(rl2, `Remover conta ${c.bold(existing.email)}?`, false);
  rl2.close();
  if (!ok2) {
    console.log(c.dim("Cancelado."));
    await mgr.dispose();
    return;
  }

  const removed = await mgr.removeAccount(targetEmail);
  if (removed) {
    console.log(c.green(`\n✓ Conta removida: ${targetEmail}`));
  } else {
    console.log(c.red(`\n✗ Falha ao remover: ${targetEmail}`));
    process.exitCode = 1;
  }
  await mgr.dispose();
}

async function listAccountsFlow(): Promise<void> {
  printHeader();
  console.log(c.bold("→ List Accounts\n"));

  const mgr = await initAccountManager();
  const all = mgr.listAll();

  if (all.length === 0) {
    console.log(c.yellow("Nenhuma conta cadastrada."));
    console.log(c.dim(`File: ${mgr.filePath} (vazio ou inexistente)`));
    console.log(c.dim(`Dica: ${c.cyan("login")} para adicionar.`));
    await mgr.dispose();
    return;
  }

  console.log(c.dim(`File: ${mgr.filePath} (chmod 600, ${all.length} conta(s))`));
  console.log(c.dim(`Config dir: ${resolveConfigDir()}\n`));

  const now = Date.now();
  const healthy = all.filter((a) => !a.disabled && !(a.quotaExhaustedUntil && now < a.quotaExhaustedUntil));

  console.log(c.bold(`Resumo: ${all.length} total, ${c.green(String(healthy.length) + " healthy")}, ${c.red(String(all.length - healthy.length) + " skipped")}\n`));

  // Table header
  const header = [
    "EMAIL".padEnd(32),
    "STATUS".padEnd(18),
    "PROJECT".padEnd(24),
    "EXPIRY".padEnd(12),
    "LAST USED".padEnd(12),
  ].join(" | ");
  console.log(c.dim(header));
  console.log(c.dim("-".repeat(header.length)));

  for (const acc of all) {
    const statusParts: string[] = [];
    if (acc.disabled) statusParts.push(c.red("disabled"));
    else statusParts.push(c.green("active"));

    if (acc.quotaExhaustedUntil && now < acc.quotaExhaustedUntil) {
      const left = acc.quotaExhaustedUntil - now;
      statusParts.push(c.yellow(`quota ${fmtDuration(left)}`));
    }

    if (!acc.accessToken || (acc.expiry && acc.expiry - now < 5 * 60 * 1000)) {
      statusParts.push(c.yellow("token expiring"));
    }

    const expiryStr = acc.expiry ? fmtDuration(acc.expiry - now) : "unknown";
    const lastUsedStr = acc.lastUsed ? fmtDuration(now - acc.lastUsed) + " ago" : "never";

    const line =
      `${redactEmail(acc.email).padEnd(32)} | ` +
      `${statusParts.join(", ").padEnd(18)} | ` +
      `${(acc.projectId ?? FALLBACK_PROJECT_ID).slice(0, 22).padEnd(24)} | ` +
      `${expiryStr.padEnd(12)} | ` +
      `${lastUsedStr.padEnd(12)}`;

    console.log(line);
    if (acc.displayName) {
      console.log(c.dim(`  └─ ${acc.displayName} id=${acc.id?.slice(0, 12) ?? "no-id"}`));
    }
  }

  console.log("");
  await mgr.dispose();
}

async function checkQuotasFlow(): Promise<void> {
  printHeader();
  console.log(c.bold("→ Check Quotas — direct cloudcode-pa.googleapis.com cascade\n"));

  const mgr = await initAccountManager();
  const accounts = mgr.listAll();

  if (accounts.length === 0) {
    console.log(c.yellow("Nenhuma conta para verificar."));
    await mgr.dispose();
    return;
  }

  console.log(c.dim(`Accounts: ${accounts.length}, endpoints: ${CLOUDCODE_ENDPOINTS_DIRECT.join(", ")}`));
  console.log(c.dim(`UA: ${getDynamicUserAgent(QUOTA_VERSION_FALLBACK)}`));
  console.log("");

  const quotaMgr = new QuotaManager({ disableBackground: true, disableFileCache: true });

  let okCount = 0;
  let failCount = 0;

  for (const acc of accounts) {
    const label = `${acc.email} ${acc.disabled ? c.red("[disabled]") : ""}`;
    process.stdout.write(`${c.cyan("•")} ${label} — refreshing token... `);

    let freshAcc = acc;
    try {
      freshAcc = await mgr.refreshIfNeeded(acc.email);
      process.stdout.write(c.green("token ok") + " — fetching quota... ");
    } catch (e: any) {
      process.stdout.write(c.yellow(`token refresh falhou: ${e?.message?.slice(0, 80) ?? String(e).slice(0, 80)}`) + " — trying stale token... ");
    }

    const token = freshAcc.accessToken;
    if (!token) {
      console.log(c.red("no access_token, skip"));
      failCount++;
      continue;
    }

    try {
      const summary = await quotaMgr.fetchQuota(token, freshAcc.projectId);
      okCount++;

      const exhausted = summary.exhaustedGroups.length > 0 ? c.red(`EXHAUSTED ${summary.exhaustedGroups.join(",")}`) : c.green("OK");
      console.log(
        `${exhausted} groups=${summary.groups.length} remaining=${summary.groups
          .map((g) => `${g.group}:${g.remainingPerMinute ?? "n/a"}%`)
          .join(",")}`
      );

      // detailed per model if available
      if (summary.groups.length > 0) {
        for (const g of summary.groups) {
          const pct = g.remainingPercent !== undefined ? `${(g.remainingPercent * 100).toFixed(1)}%` : "unknown";
          console.log(c.dim(`    ${g.group} → ${pct} reset=${g.resetAt ? new Date(g.resetAt).toISOString() : "n/a"} limit=${g.limit ?? "?"}`));
        }
      }
    } catch (e: any) {
      failCount++;
      console.log(c.red(`quota fetch failed: ${e?.message?.slice(0, 200) ?? String(e).slice(0, 200)} status=${e?.status ?? "?"}`));
      // if 429, mark exhausted
      const txt = e?.body ?? e?.message ?? "";
      if (String(txt).toLowerCase().includes("quota") || e?.status === 429) {
        console.log(c.yellow(`    marking quota exhausted for 20m`));
        try {
          await mgr.markQuotaExhausted(acc.email, { durationMs: 20 * 60 * 1000 });
        } catch {}
      }
    }
  }

  console.log(`\n${c.bold("Resultado:")} ${c.green(`${okCount} ok`)} ${failCount > 0 ? c.red(`${failCount} falhas`) : ""}`);

  await quotaMgr.dispose().catch(() => {});
  await mgr.dispose().catch(() => {});
}

async function enableAccountFlow(email: string): Promise<void> {
  printHeader();
  const mgr = await initAccountManager();
  const ok = await mgr.enable(email);
  if (ok) {
    console.log(c.green(`✓ Account enabled: ${email}`));
  } else {
    console.error(c.red(`✗ Account not found: ${email}`));
    process.exitCode = 1;
  }
  await mgr.dispose();
}

async function disableAccountFlow(email: string): Promise<void> {
  printHeader();
  const mgr = await initAccountManager();
  const ok = await mgr.disable(email);
  if (ok) {
    console.log(c.yellow(`✓ Account disabled: ${email} (skipped in rotation)`));
  } else {
    console.error(c.red(`✗ Account not found: ${email}`));
    process.exitCode = 1;
  }
  await mgr.dispose();
}

// ---------------------------------------------------------------------------
// Configure models — writes plugin model definitions direct to opencode.json
// atomic chmod 600, merging safe, library-first
// ---------------------------------------------------------------------------

function buildOpenCodeModelDefinitions(): {
  pluginList: string[];
  providerModels: Record<string, any>;
  topLevelModels: Record<string, any>;
} {
  const pluginList = [PLUGIN_NAME];

  const providerModels: Record<string, any> = {};
  const topLevelModels: Record<string, any> = {};

  for (const entry of MODELS_2026_CATALOG) {
    const baseId = entry.id;

    // Provider-level definition — rich metadata for plugin
    const richDef = {
      id: baseId,
      name: entry.name,
      provider: entry.provider,
      family: entry.family,
      contextWindow: entry.context,
      outputLimit: entry.output,
      thinking: entry.thinking
        ? {
            supported: true,
            budget: entry.family === "claude" ? 32_768 : 16_384,
            max: entry.family === "claude" ? 64_000 : 32_768,
            levels: ["minimal", "low", "medium", "high", "max"],
          }
        : { supported: false },
      modalities: { input: ["text", "image", "pdf"], output: ["text"] },
      // Bypass metadata — documents how UA / header works
      antigravity: {
        bypass: {
          userAgent: `${ANTIGRAVITY_USER_AGENT_FALLBACK} {os}/{arch}`,
          stripHeaders: ["x-goog-user-project", "x-goog-quota-user"],
          endpoints: [...CLOUDCODE_ENDPOINTS_DIRECT],
          cascade: "403/404/5xx",
          versionFallback: ANTIGRAVITY_VERSION_FALLBACK ?? QUOTA_VERSION_FALLBACK,
        },
        endpoint: CODE_ASSIST_ENDPOINTS.PROD,
        projectFallback: FALLBACK_PROJECT_ID,
      },
      googleSearch: entry.family === "gemini" ? { enabled: true, model: "gemini-3-flash-preview" } : undefined,
    };

    providerModels[baseId] = richDef;

    // Also register variants as separate provider models and top-level shortcuts
    const allIds = [baseId, ...entry.variants, ...entry.aliases];
    const uniqIds = [...new Set(allIds)];

    for (const vid of uniqIds) {
      // Provide minimal top-level alias for opencode compatibility
      topLevelModels[vid] = {
        provider: "antigravity",
        model: baseId,
        name: entry.name,
        limit: { context: entry.context, output: entry.output },
      };
      // Also ensure providerModels contains variant mapping if not already
      if (!providerModels[vid]) {
        providerModels[vid] = {
          ...richDef,
          id: vid,
          aliasOf: baseId,
          name: `${entry.name} (alias ${vid})`,
        };
      }
    }

    // Add antagravity/ slash prefixed shortcuts for OpenCode provider routing (e.g. antigravity/gemini-3-pro-preview)
    const slashKey = `antigravity/${baseId}`;
    topLevelModels[slashKey] = {
      provider: "antigravity",
      model: baseId,
      name: entry.name,
    };
  }

  // Also add OAuth supported list from oauth.ts as fallback
  for (const m of OAUTH_SUPPORTED_MODELS) {
    const mid = String(m);
    if (!providerModels[mid]) {
      providerModels[mid] = {
        id: mid,
        name: `${mid} (Antigravity 2026)`,
        provider: "antigravity",
        family: mid.includes("claude") ? "claude" : "gemini",
        contextWindow: mid.includes("claude") ? 200_000 : 1_048_576,
        outputLimit: mid.includes("claude") ? 64_000 : 65_535,
        thinking: { supported: true },
        aliasOf: undefined,
      };
    }
    if (!topLevelModels[mid]) {
      topLevelModels[mid] = { provider: "antigravity", model: mid };
    }
  }

  return { pluginList, providerModels, topLevelModels };
}

async function configureModelsFlow(opts: { global?: boolean; customPath?: string } = {}): Promise<void> {
  printHeader();
  console.log(c.bold("→ Configure Models — escrever plugin model definitions direto em opencode.json\n"));

  const loc = await locateOpenCodeJson(opts.customPath, !!opts.global);
  console.log(c.dim(`Target candidate: ${loc.path} (exists=${loc.exists}, source=${loc.source})`));
  console.log(c.dim(`Config dir global: ${resolveConfigDir()}`));
  console.log("");

  let existing: any = {};
  if (loc.exists) {
    const parsed = await readJsonSafe(loc.path);
    if (parsed) {
      existing = parsed;
      console.log(c.green(`  ✓ opencode.json existente carregado (${Object.keys(parsed).length} top-level keys)`));
    } else {
      console.log(c.yellow(`  ⚠ opencode.json existente mas inválido JSON — será feito backup e sobrescrito`));
      // backup
      try {
        const backupPath = `${loc.path}.backup-${Date.now()}.json`;
        await fsp.copyFile(loc.path, backupPath);
        console.log(c.dim(`  backup → ${backupPath}`));
      } catch {}
      existing = {};
    }
  } else {
    console.log(c.dim(`  opencode.json não existe — será criado novo`));
  }

  const { pluginList, providerModels, topLevelModels } = buildOpenCodeModelDefinitions();

  // Merge strategy — observer preserves user keys, adds ours
  // - plugin: array merge unique
  // - provider.antigravity.models: merge our models into existing, preserving user custom if not colliding with ours? We overwrite ours to guarantee 2026 updates.
  // - models (top-level): merge
  const merged: any = { ...existing };

  // Ensure $schema
  if (!merged.$schema) {
    merged.$schema = "https://opencode.ai/config.json";
  }

  // Plugin list
  const existingPlugins = Array.isArray(merged.plugin) ? merged.plugin : merged.plugins ? merged.plugins : [];
  const pluginsSet = new Set<string>([...existingPlugins.map((p: any) => String(p)), ...pluginList]);
  merged.plugin = Array.from(pluginsSet);

  // provider.antigravity
  if (!merged.provider || typeof merged.provider !== "object") merged.provider = {};
  if (!merged.provider.antigravity || typeof merged.provider.antigravity !== "object") merged.provider.antigravity = {};
  if (!merged.provider.antigravity.models || typeof merged.provider.antigravity.models !== "object") merged.provider.antigravity.models = {};

  // Preserve existing provider.antigravity.options if present
  const existingProviderModels = merged.provider.antigravity.models as Record<string, any>;
  const newProviderModels = { ...existingProviderModels };

  // Overwrite with our latest 2026 definitions for our ids, keep other user models
  for (const [k, v] of Object.entries(providerModels)) {
    newProviderModels[k] = v;
  }

  merged.provider.antigravity.models = newProviderModels;
  // Also add minimal options hint
  if (!merged.provider.antigravity.options) {
    merged.provider.antigravity.options = {
      __comment: "antigravity auth next — direct cloudcode-pa, chmod 600 accounts",
      apiKey: "use-oauth",
      baseUrl: CODE_ASSIST_ENDPOINTS.PROD,
      versionFallback: ANTIGRAVITY_VERSION_FALLBACK ?? QUOTA_VERSION_FALLBACK,
      bypass: `strip x-goog-user-project, UA ${ANTIGRAVITY_USER_AGENT_FALLBACK} {os}/{arch}, cascade 403/404/5xx`,
    };
  }

  // top-level models map — OpenCode also supports top-level models: { "model-id": { provider, model } }
  if (!merged.models || typeof merged.models !== "object") merged.models = {};
  const existingTopModels = merged.models as Record<string, any>;
  for (const [k, v] of Object.entries(topLevelModels)) {
    if (!existingTopModels[k]) {
      existingTopModels[k] = v;
    } else {
      // merge preserving existing but ensuring provider/model present
      existingTopModels[k] = { ...v, ...existingTopModels[k], provider: "antigravity", model: (existingTopModels[k] as any).model ?? v.model };
    }
  }
  merged.models = existingTopModels;

  // Write atomically chmod 600 — requirement
  const content = JSON.stringify(merged, null, 2) + "\n";
  try {
    await atomicWriteFileAtomic(loc.path, content, FILE_MODE);
    console.log(c.green(`\n✓ opencode.json escrito atomically (chmod 600) → ${loc.path}`));
    console.log(c.dim(`  plugin: ${JSON.stringify(merged.plugin)}`));
    console.log(c.dim(`  provider.antigravity.models: ${Object.keys(newProviderModels).length} definitions`));
    console.log(c.dim(`  top-level models: ${Object.keys(existingTopModels).length} entries`));
    console.log(c.dim(`  models 2026 core: ${MODELS_2026_CATALOG.map((e) => e.id).join(", ")}`));
    console.log(`\n${c.bold("Verificação:")} ${c.cyan(`cat ${loc.path} | head -n 100`)}`);
  } catch (e: any) {
    console.error(c.red(`\n✗ Falha ao escrever opencode.json: ${e?.message ?? String(e)}`));
    process.exitCode = 1;
  }
}

async function diagnosticsFlow(): Promise<void> {
  printHeader();
  console.log(c.bold("→ Diagnostics — third-person observer state\n"));

  const cfgDir = resolveConfigDir();
  const accPath = resolveAccountsFilePath();
  const antPath = resolveAntigravityJsonPath();
  const openCodeLoc = await locateOpenCodeJson();

  console.log(`${c.bold("Paths:")}`);
  console.log(`  ${c.dim("config dir:")} ${cfgDir}`);
  console.log(`  ${c.dim("accounts:")} ${accPath} ${fs.existsSync(accPath) ? c.green("exists") : c.yellow("not found")}`);
  try {
    const stat = fs.statSync(accPath);
    console.log(`    ${c.dim(`mode ${(stat.mode & 0o777).toString(8)} size ${stat.size} mtime ${new Date(stat.mtimeMs).toISOString()}`)}`);
  } catch {}
  console.log(`  ${c.dim("antigravity.json:")} ${antPath} ${fs.existsSync(antPath) ? c.green("exists") : c.yellow("not found")}`);
  console.log(`  ${c.dim("opencode.json:")} ${openCodeLoc.path} ${openCodeLoc.exists ? c.green(`exists (${openCodeLoc.source})`) : c.yellow(`not found, would create at ${openCodeLoc.path} (${openCodeLoc.source})`)}`);

  console.log(`\n${c.bold("Versions & UA:")}`);
  console.log(`  cli: ${CLI_VERSION}`);
  console.log(`  fallback: ${ANTIGRAVITY_VERSION_FALLBACK ?? QUOTA_VERSION_FALLBACK}`);
  console.log(`  UA fallback: ${ANTIGRAVITY_USER_AGENT_FALLBACK}`);
  console.log(`  dynamic UA: ${getDynamicUserAgent()}`);
  console.log(`  node: ${process.version} platform=${os.platform()} arch=${os.arch()} release=${os.release()}`);

  console.log(`\n${c.bold("Endpoints direct (no localhost v1):")}`);
  for (const ep of CLOUDCODE_ENDPOINTS_DIRECT) {
    console.log(`  ${ep}`);
  }

  console.log(`\n${c.bold("Models 2026:")}`);
  console.log(`  ${MODELS_2026_CATALOG.map((m) => m.id).join(", ")}`);
  console.log(`  OAuth list: ${OAUTH_SUPPORTED_MODELS.join(", ")}`);

  console.log(`\n${c.bold("Accounts:")}`);
  const mgr = await initAccountManager();
  const all = mgr.listAll();
  console.log(`  total=${all.length} healthy=${mgr.list(false).length}`);
  if (all.length > 0) {
    all.slice(0, 5).forEach((a) => {
      console.log(`    ${a.email} project=${a.projectId ?? FALLBACK_PROJECT_ID} disabled=${!!a.disabled}`);
    });
    if (all.length > 5) console.log(c.dim(`    ... +${all.length - 5} more`));
  }
  await mgr.dispose();

  console.log(`\n${c.bold("Env:")}`);
  console.log(`  OPENCODE_CONFIG_DIR=${process.env.OPENCODE_CONFIG_DIR ?? "(not set)"}`);
  console.log(`  ANTIGRAVITY_DEBUG=${process.env.ANTIGRAVITY_DEBUG ?? "(not set)"}`);
  console.log(`  NO_COLOR=${process.env.NO_COLOR ?? "(not set)"}`);

  console.log(`\n${c.bold("Security:")}`);
  console.log(`  atomic writes chmod 600, Map cache in-memory hashed tokens, no secret in logs`);
  console.log(`  fetch global only, node:* builtins, direct cloudcode-pa sans localhost proxy`);
}

// ---------------------------------------------------------------------------
// Interactive menu — only node:readline builtin
// ---------------------------------------------------------------------------

async function interactiveMenu(): Promise<void> {
  printHeader();

  const rl = createRl();

  while (true) {
    console.log(
      `${c.bold("\nMenu Interativo — escolha ação:")}\n` +
        `  ${c.cyan("1")}  Login — adicionar nova conta (OAuth PKCE)\n` +
        `  ${c.cyan("2")}  List accounts\n` +
        `  ${c.cyan("3")}  Check quotas (direct cloudcode-pa)\n` +
        `  ${c.cyan("4")}  Enable account\n` +
        `  ${c.cyan("5")}  Disable account\n` +
        `  ${c.cyan("6")}  Logout — remover conta\n` +
        `  ${c.cyan("7")}  Configure models → opencode.json (atomic chmod 600)\n` +
        `  ${c.cyan("8")}  Diagnostics / paths / version\n` +
        `  ${c.cyan("9")}  Help\n` +
        `  ${c.cyan("0")}  Exit\n`
    );

    const choice = await question(rl, `${c.bold("→ Escolha [0-9]: ")} `);

    switch (choice.trim()) {
      case "1":
      case "login":
        rl.close();
        await loginFlow();
        return;
      case "2":
      case "list":
      case "ls":
      case "accounts":
        await listAccountsFlow();
        break;
      case "3":
      case "quotas":
      case "quota":
      case "check":
        await checkQuotasFlow();
        break;
      case "4":
      case "enable": {
        const email = await question(rl, "Email para habilitar: ");
        if (email) await enableAccountFlow(email);
        break;
      }
      case "5":
      case "disable": {
        const email = await question(rl, "Email para desabilitar: ");
        if (email) await disableAccountFlow(email);
        break;
      }
      case "6":
      case "logout":
        await logoutFlow();
        break;
      case "7":
      case "configure":
      case "models": {
        const globalFlag = await confirm(rl, "Usar config global (~/.config/opencode/opencode.json) em vez de cwd/opencode.json?", false);
        await configureModelsFlow({ global: globalFlag });
        break;
      }
      case "8":
      case "diagnostics":
      case "doctor":
      case "config":
        await diagnosticsFlow();
        break;
      case "9":
      case "help":
        printHelp();
        break;
      case "0":
      case "exit":
      case "quit":
      case "q":
        console.log(c.dim("\nSaindo — observer third-person finalizado.\n"));
        rl.close();
        return;
      default:
        console.log(c.yellow(`Opção desconhecida: ${choice}`));
        break;
    }
  }
}

// ---------------------------------------------------------------------------
// Main arg parser — non-interactive + interactive fallback
// ---------------------------------------------------------------------------

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const cmd = (args[0] ?? "").toLowerCase();
  const rest = args.slice(1);

  // Flags
  const hasFlag = (name: string) => args.includes(`--${name}`) || args.includes(`-${name[0]}`);
  const getFlagValue = (name: string): string | undefined => {
    const idx = args.findIndex((a) => a === `--${name}` || a.startsWith(`--${name}=`));
    if (idx === -1) return undefined;
    const arg = args[idx];
    if (arg.includes("=")) return arg.split("=").slice(1).join("=").trim();
    return args[idx + 1]?.trim();
  };

  const globalFlag = hasFlag("global") || hasFlag("g");
  const noBrowser = hasFlag("no-browser");
  const allFlag = hasFlag("all");

  if (args.length === 0) {
    await interactiveMenu();
    return;
  }

  switch (cmd) {
    case "login": {
      await loginFlow({ noBrowser });
      break;
    }
    case "logout": {
      const email = rest.find((a) => a.includes("@"));
      await logoutFlow(email, allFlag);
      break;
    }
    case "list":
    case "ls":
    case "list-accounts":
    case "accounts": {
      await listAccountsFlow();
      break;
    }
    case "quotas":
    case "quota":
    case "check-quotas":
    case "check": {
      await checkQuotasFlow();
      break;
    }
    case "enable": {
      const email = rest.find((a) => a.includes("@")) ?? getFlagValue("email");
      if (!email) {
        console.error(c.red("enable requires email: enable <email>"));
        process.exitCode = 2;
        break;
      }
      await enableAccountFlow(email);
      break;
    }
    case "disable": {
      const email = rest.find((a) => a.includes("@")) ?? getFlagValue("email");
      if (!email) {
        console.error(c.red("disable requires email: disable <email>"));
        process.exitCode = 2;
        break;
      }
      await disableAccountFlow(email);
      break;
    }
    case "configure":
    case "configure-models":
    case "config-models":
    case "models":
    case "setup": {
      const customPath = getFlagValue("path") ?? getFlagValue("file") ?? rest.find((a) => a.endsWith(".json"));
      await configureModelsFlow({ global: globalFlag, customPath });
      break;
    }
    case "config":
    case "diagnostics":
    case "doctor":
    case "path":
    case "paths": {
      await diagnosticsFlow();
      break;
    }
    case "help":
    case "--help":
    case "-h":
    case "-help": {
      printHelp();
      break;
    }
    default: {
      console.log(c.yellow(`Comando desconhecido: ${cmd}`));
      printHelp();
      process.exitCode = 1;
    }
  }
}

// ---------------------------------------------------------------------------
// ESM entry — library-first export + direct execution
// ---------------------------------------------------------------------------

export const CLI = {
  version: CLI_VERSION,
  login: loginFlow,
  logout: logoutFlow,
  list: listAccountsFlow,
  quotas: checkQuotasFlow,
  enable: enableAccountFlow,
  disable: disableAccountFlow,
  configureModels: configureModelsFlow,
  diagnostics: diagnosticsFlow,
  interactive: interactiveMenu,
  modelsCatalog: MODELS_2026_CATALOG,
  buildDefinitions: buildOpenCodeModelDefinitions,
  resolveConfigDir,
  resolveAccountsFilePath,
  atomicWriteFileAtomic,
  atomicWriteFileSync,
};

// Only auto-run when executed directly, not when imported as library (library-first)
const isMainModule = (() => {
  try {
    const thisFile = new URL(import.meta.url).pathname;
    const entry = process.argv[1] ? path.resolve(process.argv[1]) : "";
    return entry && (thisFile === entry || thisFile.endsWith("/cli.ts") || thisFile.endsWith("/cli.js"));
  } catch {
    return true;
  }
})();

if (isMainModule) {
  main().catch((e) => {
    console.error(c.red(`\n✗ CLI fatal error: ${e?.message ?? String(e)}`));
    if (e?.stack) console.error(c.dim(e.stack.slice(0, 2000)));
    process.exitCode = 1;
  });
}

export default CLI;
