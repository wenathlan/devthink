/**
 * @fileoverview project.ts — descoberta e resolução de Project ID do Cloud Code
 * @description
 * O observador percebe que este módulo é responsável por transformar um
 * access_token OAuth em um cloudaicompanionProject utilizável. Ele observa
 * três comportamentos distintos do lado do servidor (PROD, DAILY, SANDBOX) e
 * decide qual project id persistir. Quando tudo falha, o observador recorre
 * ao fallback blindado `rising-fact-p41fc` com aviso explícito.
 *
 * Arquitetura: third-person observer, library-first, root-first.
 * Dependências: apenas `node:*` builtins + fetch global (Node >= 18).
 * Timeouts: 10s por chamada, retry em 403/404/5xx entre endpoints.
 *
 * Modelos suportados 2026 validados via fetchAvailableModels:
 * - gemini-3-pro-preview, gemini-3-flash-preview, gemini-3.1-pro-preview,
 *   gemini-2.5, claude-opus-4-6-thinking, claude-sonnet-4-6.
 *
 * @version 2.0.0 — opencode-antigravity-auth-next
 * @license MIT
 */

import { createHash } from "node:crypto";
import { platform, arch } from "node:os";

// ---------------------------------------------------------------------------
// Constantes blindadas — root-first, sem src/
// ---------------------------------------------------------------------------

/**
 * O observador registra que o endpoint PROD é autoritativo;
 * DAILY e SANDBOX são fallbacks para rollout gradual e testes canário.
 */
export const CODE_ASSIST_ENDPOINTS = {
  PROD: "https://cloudcode-pa.googleapis.com",
  DAILY: "https://daily-cloudcode-pa.googleapis.com",
  SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  AUTOPUSH: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
} as const;

/**
 * Ordem de tentativa observada em produção — PROD primeiro,
 * depois DAILY, depois SANDBOX. AUTOPUSH é opcional e só usado
 * quando o usuário força via env ou em debug.
 */
export const ENDPOINT_ORDER: readonly string[] = [
  CODE_ASSIST_ENDPOINTS.PROD,
  CODE_ASSIST_ENDPOINTS.DAILY,
  CODE_ASSIST_ENDPOINTS.SANDBOX,
];

/** Timeout por request — 10s conforme requisito. */
export const FETCH_TIMEOUT_MS = 10_000;

/** Projeto fallback blindado — funciona para Antigravity, falha para Gemini CLI com 403 documentado. */
export const FALLBACK_PROJECT_ID = "rising-fact-p41fc";

/** User-Agent dinâmico — fallback estável 1.19.2 quando version.ts não responde. */
export const ANTIGRAVITY_USER_AGENT_FALLBACK = "antigravity/1.19.2";

/**
 * O observador constrói a string completa de UA com SO/arch para
 * minimizar detecção de bot — coerente com FingerprintGenerator.
 */
function buildDefaultUserAgent(): string {
  try {
    const os = platform(); // darwin | linux | win32
    const cpu = arch(); // arm64 | x64
    const mappedOs = os === "darwin" ? "darwin" : os === "win32" ? "win32" : "linux";
    const mappedArch = cpu === "arm64" ? "arm64" : "x64";
    return `${ANTIGRAVITY_USER_AGENT_FALLBACK} ${mappedOs}/${mappedArch}`;
  } catch {
    return ANTIGRAVITY_USER_AGENT_FALLBACK;
  }
}

/** Modelos 2026 que o observador espera ver em fetchAvailableModels. */
export const MODELS_2026 = [
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-2.5",
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "claude-opus-4-6-thinking",
  "claude-sonnet-4-6",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3.1-pro",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-sonnet-4-6",
] as const;

// ---------------------------------------------------------------------------
// Cache em memória — Map blindado
// ---------------------------------------------------------------------------

interface CacheEntry {
  projectId: string;
  timestamp: number;
  email?: string;
}

const CACHE_TTL_MS = 60 * 60 * 1000; // 1h

/**
 * O observador mantém um Map in-memory para evitar round-trips repetidos
 * durante rotação multi-account. A chave é um hash SHA-256 truncado do
 * access token para não reter segredo em plaintext no heap snapshot.
 */
const projectIdCache = new Map<string, CacheEntry>();

function hashToken(token: string): string {
  try {
    return createHash("sha256").update(token).digest("hex").slice(0, 32);
  } catch {
    // fallback FNV-1a se crypto indisponível (ambiente restrito)
    return fnv1a32(token).toString(16);
  }
}

/**
 * FNV-1a 32-bit — usado para session_id determinístico e fallback de hash.
 * O observador nota que 0-80ms jitter em outros módulos usa este hash como semente.
 */
export function fnv1a32(str: string): number {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = (hash * 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

export function getCachedProjectId(accessToken: string): string | null {
  const key = hashToken(accessToken);
  const entry = projectIdCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > CACHE_TTL_MS) {
    projectIdCache.delete(key);
    return null;
  }
  return entry.projectId;
}

export function setCachedProjectId(accessToken: string, projectId: string, email?: string): void {
  const key = hashToken(accessToken);
  projectIdCache.set(key, { projectId, timestamp: Date.now(), email });
}

export function clearProjectIdCache(): void {
  projectIdCache.clear();
}

export function getCacheStats(): { size: number; entries: Array<{ email?: string; ageMs: number }> } {
  const now = Date.now();
  return {
    size: projectIdCache.size,
    entries: Array.from(projectIdCache.values()).map((e) => ({
      email: e.email,
      ageMs: now - e.timestamp,
    })),
  };
}

// ---------------------------------------------------------------------------
// Helpers — timeout, retry, headers antagravity
// ---------------------------------------------------------------------------

/**
 * Determina se o observador deve tentar o próximo endpoint.
 * 403/404 indicam rollout ou IAM divergente; 5xx indicam instabilidade.
 */
export function isRetryable(status: number): boolean {
  return status === 403 || status === 404 || status >= 500;
}

export interface AntigravityHeadersOptions {
  userAgent?: string;
  extra?: Record<string, string>;
}

/**
 * O observador constrói os headers mínimos que o Antigravity Manager
 * realmente envia em content requests — apenas User-Agent + Authorization.
 * X-Goog-Api-Client e Client-Metadata são omitidos no AM para reduzir
 * superfície de fingerprint (issue #310), mas mantidos opcionais para
 * compatibilidade com endpoints DAILY.
 */
export function buildAntagravityHeaders(
  accessToken: string,
  opts: AntigravityHeadersOptions = {}
): Record<string, string> {
  const ua = opts.userAgent ?? buildDefaultUserAgent();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${accessToken}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
  };
  // Compat layer — alguns proxies e DAILY esperam X-Goog-Api-Client, mas AM não envia.
  // O observador decide enviar de forma condicional apenas quando solicitado via extra.
  if (opts.extra) {
    for (const [k, v] of Object.entries(opts.extra)) {
      headers[k] = v;
    }
  }
  return headers;
}

export class ProjectDiscoveryError extends Error {
  public status?: number;
  public endpoint?: string;
  public retryable: boolean;

  constructor(message: string, status?: number, endpoint?: string) {
    super(message);
    this.name = "ProjectDiscoveryError";
    this.status = status;
    this.endpoint = endpoint;
    this.retryable = status !== undefined ? isRetryable(status) : true;
  }
}

/**
 * Fetch com timeout de 10s usando AbortController nativo.
 * O observador garante que nenhum request fique pendurado além do SLA.
 */
export async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = FETCH_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const signal = controller.signal;

  // Merge sinais externos se existirem
  const mergedInit: RequestInit = { ...init, signal };

  if (init.signal) {
    // Se o chamador já tem um signal, propaga abort do timeout para ele via wrapper
    const externalSignal = init.signal as AbortSignal;
    if (externalSignal.aborted) {
      clearTimeout(timeoutId);
      controller.abort();
    } else {
      externalSignal.addEventListener("abort", () => controller.abort(), { once: true });
    }
  }

  try {
    const response = await fetch(url, mergedInit);
    return response;
  } catch (err: any) {
    if (err?.name === "AbortError") {
      throw new ProjectDiscoveryError(`timeout after ${timeoutMs}ms for ${url}`, 408, url);
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

// ---------------------------------------------------------------------------
// Tipos de resposta Cloud Code
// ---------------------------------------------------------------------------

export interface CodeAssistMetadata {
  ideType: string;
  platform: string;
  pluginType: string;
}

function defaultMetadata(): CodeAssistMetadata {
  return {
    ideType: "ANTIGRAVITY",
    platform: "PLATFORM_UNSPECIFIED",
    pluginType: "GEMINI",
  };
}

export interface LoadCodeAssistResponse {
  cloudaicompanionProject?: string | { id: string; name?: string } | null;
  currentTier?: { id?: string; name?: string } | null;
  cloudaicompanionProjectId?: string | null;
  // Formas alternativas observadas em diferentes rollouts
  projectId?: string | null;
  tierId?: string | null;
  [key: string]: unknown;
}

export interface OnboardUserResponse {
  done?: boolean;
  name?: string;
  response?: {
    cloudaicompanionProject?: { id: string } | string;
    projectId?: string;
  };
  cloudaicompanionProject?: { id: string } | string;
  [key: string]: unknown;
}

export interface AvailableModel {
  name: string;
  displayName?: string;
  supportedMethods?: string[];
}

export interface FetchAvailableModelsResponse {
  models?: AvailableModel[];
  availableModels?: AvailableModel[];
  [key: string]: unknown;
}

// ---------------------------------------------------------------------------
// loadCodeAssist — descobre project id existente
// ---------------------------------------------------------------------------

export interface LoadCodeAssistOptions {
  accessToken: string;
  endpoint: string;
  projectId?: string;
  userAgent?: string;
}

/**
 * O observador chama loadCodeAssist. Se o usuário já tem um projeto
 * provisionado, o servidor retorna cloudaicompanionProject. Se não,
 * retorna null/vazio indicando necessidade de onboarding.
 *
 * Endpoint: POST {endpoint}/v1internal:loadCodeAssist
 */
export async function loadCodeAssist(opts: LoadCodeAssistOptions): Promise<string | null> {
  const { accessToken, endpoint, projectId, userAgent } = opts;

  const url = `${endpoint.replace(/\/+$/, "")}/v1internal:loadCodeAssist`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  const body: Record<string, unknown> = {
    metadata: defaultMetadata(),
  };

  // Se o chamador já tem um projectId cacheado, envia para validação.
  if (projectId && projectId !== FALLBACK_PROJECT_ID) {
    // Duas formas observadas: string direta e objeto com id
    body.cloudaicompanionProject = projectId;
  }

  let res: Response;
  try {
    res = await fetchWithTimeout(
      url,
      {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      },
      FETCH_TIMEOUT_MS
    );
  } catch (e: any) {
    throw new ProjectDiscoveryError(
      `loadCodeAssist network failed at ${endpoint}: ${e.message}`,
      e.status ?? 0,
      endpoint
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    const err = new ProjectDiscoveryError(
      `loadCodeAssist failed ${res.status} at ${endpoint}: ${text.slice(0, 500)}`,
      res.status,
      endpoint
    );
    throw err;
  }

  let data: LoadCodeAssistResponse;
  try {
    data = (await res.json()) as LoadCodeAssistResponse;
  } catch {
    throw new ProjectDiscoveryError(`loadCodeAssist invalid JSON at ${endpoint}`, 500, endpoint);
  }

  // Normalização de resposta — múltiplos formatos observados
  const rawProject = (data as any).cloudaicompanionProject ?? data.cloudaicompanionProjectId ?? data.projectId;

  if (!rawProject) {
    // Sem projeto — precisa onboard
    return null;
  }

  if (typeof rawProject === "string") {
    // Pode vir "projects/xyz" ou "xyz" ou "projects/xyz/locations/global"
    const parts = rawProject.split("/");
    if (parts.includes("projects")) {
      const idx = parts.indexOf("projects");
      return parts[idx + 1] ?? rawProject;
    }
    return rawProject;
  }

  if (typeof rawProject === "object" && rawProject !== null) {
    const obj = rawProject as { id?: string; name?: string };
    if (obj.id) {
      const parts = obj.id.split("/");
      if (parts.includes("projects")) {
        const idx = parts.indexOf("projects");
        return parts[idx + 1] ?? obj.id;
      }
      return obj.id;
    }
    if (obj.name) return obj.name.split("/").pop() ?? obj.name;
  }

  return null;
}

// ---------------------------------------------------------------------------
// onboardUser — provisiona projeto para contas FREE
// ---------------------------------------------------------------------------

export interface OnboardUserOptions {
  accessToken: string;
  endpoint: string;
  tierId?: string;
  userAgent?: string;
}

/**
 * O observador chama onboardUser quando loadCodeAssist retorna vazio.
 * Para tier FREE, cria o projeto gerenciado pelo Google.
 * A resposta pode ser LRO (long-running operation) que requer polling.
 *
 * Endpoint: POST {endpoint}/v1internal:onboardUser
 */
export async function onboardUser(opts: OnboardUserOptions): Promise<string | null> {
  const { accessToken, endpoint, tierId = "FREE", userAgent } = opts;

  const url = `${endpoint.replace(/\/+$/, "")}/v1internal:onboardUser`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  // Payload mínimo observado em OpenClaw e gemini-cli
  const body = {
    tierId,
    metadata: defaultMetadata(),
  };

  let res: Response;
  try {
    res = await fetchWithTimeout(
      url,
      {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      },
      FETCH_TIMEOUT_MS
    );
  } catch (e: any) {
    throw new ProjectDiscoveryError(
      `onboardUser network failed at ${endpoint}: ${e.message}`,
      e.status ?? 0,
      endpoint
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new ProjectDiscoveryError(
      `onboardUser failed ${res.status} at ${endpoint}: ${text.slice(0, 500)}`,
      res.status,
      endpoint
    );
  }

  let data: OnboardUserResponse;
  try {
    data = (await res.json()) as OnboardUserResponse;
  } catch {
    throw new ProjectDiscoveryError(`onboardUser invalid JSON at ${endpoint}`, 500, endpoint);
  }

  // Resposta direta
  const direct =
    (data as any).cloudaicompanionProject ??
    (data as any).response?.cloudaicompanionProject ??
    (data as any).response?.projectId;

  if (direct) {
    if (typeof direct === "string") {
      const parts = direct.split("/");
      return parts.includes("projects") ? direct.split("/")[1 + direct.split("/").indexOf("projects")] ?? direct : direct;
    }
    if (typeof direct === "object" && (direct as any).id) {
      const id = (direct as any).id as string;
      const parts = id.split("/");
      return parts.includes("projects") ? parts[parts.indexOf("projects") + 1] ?? id : id;
    }
  }

  // LRO polling — quando name existe e done=false
  if (data.name && data.done === false) {
    const polled = await pollOperation({
      accessToken,
      endpoint,
      operationName: data.name,
      userAgent,
    });
    if (polled) return polled;
  }

  if (data.done && data.response) {
    const proj = (data.response as any).cloudaicompanionProject ?? (data.response as any).projectId;
    if (proj) {
      if (typeof proj === "string") return proj.split("/").pop() ?? proj;
      if (typeof proj === "object" && (proj as any).id) return (proj as any).id.split("/").pop() ?? (proj as any).id;
    }
  }

  // Se onboard não retornou projeto mas não errou, retorna null para que
  // o chamador tente loadCodeAssist novamente (padrão observado no gemini-cli)
  return null;
}

interface PollOperationOptions {
  accessToken: string;
  endpoint: string;
  operationName: string;
  userAgent?: string;
  maxAttempts?: number;
}

/**
 * Polling de LRO — o observador nota que onboardUser às vezes retorna
 * operação assíncrona; ele espera com backoff até 5 tentativas.
 */
async function pollOperation(opts: PollOperationOptions): Promise<string | null> {
  const { accessToken, endpoint, operationName, userAgent, maxAttempts = 5 } = opts;

  // operationName pode ser "v1internal/operations/xxx" ou nome curto
  const base = endpoint.replace(/\/+$/, "");
  const opPath = operationName.startsWith("v1internal/") ? operationName : `v1internal/${operationName}`;
  const url = `${base}/${opPath.includes("operations/") ? opPath : `operations/${operationName}`}`;

  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    // backoff 500ms, 1s, 2s, 4s, 8s — jitter implícito via event loop
    if (attempt > 0) {
      const delayMs = Math.min(500 * 2 ** (attempt - 1), 8000);
      await new Promise((r) => setTimeout(r, delayMs));
    }

    try {
      const res = await fetchWithTimeout(
        url,
        {
          method: "GET",
          headers,
        },
        FETCH_TIMEOUT_MS
      );

      if (!res.ok) continue;

      const data = (await res.json()) as OnboardUserResponse;
      if (data.done) {
        const proj =
          (data as any).response?.cloudaicompanionProject ??
          (data as any).response?.projectId ??
          (data as any).cloudaicompanionProject;
        if (proj) {
          if (typeof proj === "string") return proj.split("/").pop() ?? proj;
          if (typeof proj === "object" && (proj as any).id) return (proj as any).id.split("/").pop() ?? (proj as any).id;
        }
        return null;
      }
    } catch {
      // continua polling em erro transitório
      continue;
    }
  }

  return null;
}

// ---------------------------------------------------------------------------
// fetchAvailableModels — valida projeto e lista modelos 2026
// ---------------------------------------------------------------------------

export interface FetchModelsOptions {
  accessToken: string;
  endpoint: string;
  projectId: string;
  userAgent?: string;
}

/**
 * O observador valida se o projectId resolve modelos.
 * Quando fetchAvailableModels retorna 200, o projeto é considerado saudável.
 * Também detecta suporte aos modelos novos de 2026; falta deles não falha,
 * apenas loga para debug.
 *
 * Endpoint: POST {endpoint}/v1internal:fetchAvailableModels
 */
export async function fetchAvailableModels(opts: FetchModelsOptions): Promise<AvailableModel[]> {
  const { accessToken, endpoint, projectId, userAgent } = opts;

  if (!projectId) throw new ProjectDiscoveryError("fetchAvailableModels requires projectId", 400, endpoint);

  const url = `${endpoint.replace(/\/+$/, "")}/v1internal:fetchAvailableModels`;
  const headers = buildAntagravityHeaders(accessToken, { userAgent });

  const body = {
    cloudaicompanionProject: projectId,
    metadata: defaultMetadata(),
  };

  let res: Response;
  try {
    res = await fetchWithTimeout(
      url,
      {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      },
      FETCH_TIMEOUT_MS
    );
  } catch (e: any) {
    throw new ProjectDiscoveryError(
      `fetchAvailableModels network failed at ${endpoint}: ${e.message}`,
      e.status ?? 0,
      endpoint
    );
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new ProjectDiscoveryError(
      `fetchAvailableModels failed ${res.status} at ${endpoint}: ${text.slice(0, 500)}`,
      res.status,
      endpoint
    );
  }

  let data: FetchAvailableModelsResponse;
  try {
    data = (await res.json()) as FetchAvailableModelsResponse;
  } catch {
    throw new ProjectDiscoveryError(`fetchAvailableModels invalid JSON at ${endpoint}`, 500, endpoint);
  }

  const rawModels = (data as any).models ?? (data as any).availableModels ?? [];
  const models: AvailableModel[] = Array.isArray(rawModels) ? rawModels : [];

  // O observador verifica se pelo menos um dos modelos 2026 está presente;
  // não falha se não estiver, pois rollout é gradual.
  const found2026 = models.filter((m) => (MODELS_2026 as readonly string[]).some((needle) => m.name?.includes(needle)));
  if (found2026.length === 0 && models.length > 0) {
    // Silencioso em prod — apenas para debug interno
    // console.debug(`[project] no 2026 models found at ${endpoint}, got ${models.length}`)
  }

  return models;
}

// ---------------------------------------------------------------------------
// resolveProjectId — orquestrador principal com retry PROD/DAILY/SANDBOX
// ---------------------------------------------------------------------------

export interface AccountMetadataSaver {
  (projectId: string): Promise<void> | void;
}

export interface ResolveProjectIdOptions {
  /** Bearer token OAuth — obrigatório */
  accessToken: string;
  /** Project id já salvo no disco — opcional, tenta validar primeiro */
  cachedProjectId?: string;
  /** Email da conta para cache/log — opcional */
  email?: string;
  /** Callback para persistir em account metadata (accounts.ts) */
  metadataSaver?: AccountMetadataSaver;
  /** User-Agent override — se não fornecido usa fallback dinâmico */
  userAgent?: string;
  /** Ordem de endpoints override — default ENDPOINT_ORDER */
  endpoints?: readonly string[];
  /** Se true, inclui AUTOPUSH como último fallback antes do fallback blindado */
  includeAutopush?: boolean;
}

export interface ResolveResult {
  projectId: string;
  fromCache: boolean;
  endpointUsed?: string;
  isFallback: boolean;
  modelsChecked?: number;
}

/**
 * Resolve o project id com retry entre endpoints.
 *
 * Fluxo observado:
 * 1. Checa cache Map memória.
 * 2. Se cachedProjectId fornecido, tenta loadCodeAssist com ele em cada endpoint.
 * 3. Se load retorna null, tenta onboardUser + load novamente.
 * 4. Se sucesso, valida opcionalmente com fetchAvailableModels (best-effort).
 * 5. Salva em cache e chama metadataSaver para persistir em account metadata.
 * 6. Se todos endpoints falham com isRetryable, usa FALLBACK com warning.
 *
 * O observador nota que 403 com `rising-fact-p41fc` é esperado para Gemini CLI
 * models — daí o warning explícito.
 */
export async function resolveProjectId(opts: ResolveProjectIdOptions): Promise<ResolveResult> {
  const {
    accessToken,
    cachedProjectId,
    email,
    metadataSaver,
    userAgent = buildDefaultUserAgent(),
    endpoints = ENDPOINT_ORDER,
    includeAutopush = false,
  } = opts;

  if (!accessToken) {
    throw new ProjectDiscoveryError("resolveProjectId requires accessToken");
  }

  // 1. Cache rápido
  const cached = getCachedProjectId(accessToken);
  if (cached) {
    return { projectId: cached, fromCache: true, isFallback: cached === FALLBACK_PROJECT_ID };
  }

  if (cachedProjectId && cachedProjectId !== FALLBACK_PROJECT_ID) {
    const cachedDirect = getCachedProjectId(cachedProjectId); // se alguém cacheou pelo id
    if (cachedDirect) {
      return { projectId: cachedDirect, fromCache: true, isFallback: false };
    }
  }

  const allEndpoints = includeAutopush ? [...endpoints, CODE_ASSIST_ENDPOINTS.AUTOPUSH] : endpoints;

  let lastError: ProjectDiscoveryError | null = null;
  let attemptedEndpoints = 0;

  // 2. Tentativa por endpoint
  for (const endpoint of allEndpoints) {
    attemptedEndpoints++;
    try {
      // a) tenta load direto com cachedProjectId se existir
      let discoveredProjectId: string | null = null;

      if (cachedProjectId && cachedProjectId !== FALLBACK_PROJECT_ID) {
        try {
          const validated = await loadCodeAssist({
            accessToken,
            endpoint,
            projectId: cachedProjectId,
            userAgent,
          });
          if (validated) {
            discoveredProjectId = validated;
          } else {
            // cacheado mas não retornou nada — tenta load sem id para obter o correto
            discoveredProjectId = await loadCodeAssist({
              accessToken,
              endpoint,
              userAgent,
            });
          }
        } catch (e: any) {
          if (e instanceof ProjectDiscoveryError && !e.retryable) throw e;
          // se load com id falhou com retryable, tenta load sem id no mesmo endpoint
          try {
            discoveredProjectId = await loadCodeAssist({ accessToken, endpoint, userAgent });
          } catch (inner: any) {
            if (inner instanceof ProjectDiscoveryError) {
              lastError = inner;
              if (!isRetryable(inner.status ?? 0)) throw inner;
              continue; // próximo endpoint
            }
            lastError = inner;
            continue;
          }
        }
      } else {
        // sem cache — load puro
        discoveredProjectId = await loadCodeAssist({ accessToken, endpoint, userAgent });
      }

      // b) se load retornou null, tenta onboard + load novamente
      if (!discoveredProjectId) {
        try {
          const onboarded = await onboardUser({ accessToken, endpoint, tierId: "FREE", userAgent });
          if (onboarded) {
            discoveredProjectId = onboarded;
          } else {
            // padrão observado: onboard sem retorno, mas load seguinte funciona
            discoveredProjectId = await loadCodeAssist({ accessToken, endpoint, userAgent });
          }
        } catch (onboardErr: any) {
          if (onboardErr instanceof ProjectDiscoveryError) {
            lastError = onboardErr;
            if (!isRetryable(onboardErr.status ?? 0)) throw onboardErr;
            continue;
          }
          lastError = onboardErr;
          continue;
        }
      }

      if (!discoveredProjectId) {
        // este endpoint não conseguiu projetar id — tenta próximo se retryable
        lastError = new ProjectDiscoveryError(`no project id from ${endpoint}`, 404, endpoint);
        continue;
      }

      // c) best-effort validação com fetchAvailableModels — não falha se 404/403
      let modelsCount: number | undefined;
      try {
        const models = await fetchAvailableModels({
          accessToken,
          endpoint,
          projectId: discoveredProjectId,
          userAgent,
        });
        modelsCount = models.length;
      } catch (validateErr: any) {
        if (validateErr instanceof ProjectDiscoveryError) {
          // se validação falhar com 403/404, considera projectId ainda válido se veio de loadCodeAssist
          // (caso observado quando Gemini CLI models ainda não propagaram)
          if (!isRetryable(validateErr.status ?? 0)) {
            // erro não retryable na validação — aborta completamente
            throw validateErr;
          }
          // retryable — mas ainda aceita project id
        }
      }

      // sucesso — salva cache e metadata
      setCachedProjectId(accessToken, discoveredProjectId, email);

      if (metadataSaver) {
        try {
          await metadataSaver(discoveredProjectId);
        } catch (saveErr) {
          // falha de salvamento não deve quebrar resolução — apenas avisa
          console.warn(
            `[antigravity-auth] failed to save projectId metadata for ${email ?? "unknown"}: ${(saveErr as Error).message}`
          );
        }
      }

      return {
        projectId: discoveredProjectId,
        fromCache: false,
        endpointUsed: endpoint,
        isFallback: false,
        modelsChecked: modelsCount,
      };
    } catch (err: any) {
      if (err instanceof ProjectDiscoveryError) {
        lastError = err;
        if (err.retryable) {
          // continua para próximo endpoint
          continue;
        } else {
          // 401, 400 etc — não adianta trocar endpoint
          throw err;
        }
      }
      // erro desconhecido — trata como retryable para tentar próximo endpoint
      lastError = new ProjectDiscoveryError(
        `unexpected error at ${endpoint}: ${err?.message ?? String(err)}`,
        500,
        endpoint
      );
      continue;
    }
  }

  // 3. Todos endpoints falharam — fallback blindado com warning
  console.warn(
    `[antigravity-auth] WARNING: all ${attemptedEndpoints} endpoints failed` +
      `${lastError ? ` (last: ${lastError.status} ${lastError.message.slice(0, 200)})` : ""}.` +
      ` Falling back to blinded project ${FALLBACK_PROJECT_ID}.` +
      ` This works for Antigravity but will 403 for Gemini CLI models. ` +
      `Check https://github.com/NoeFabris/opencode-antigravity-auth#403-permission-denied`
  );

  setCachedProjectId(accessToken, FALLBACK_PROJECT_ID, email);

  if (metadataSaver) {
    try {
      await metadataSaver(FALLBACK_PROJECT_ID);
    } catch {
      // ignora falha de save no fallback
    }
  }

  return {
    projectId: FALLBACK_PROJECT_ID,
    fromCache: false,
    endpointUsed: undefined,
    isFallback: true,
  };
}

/**
 * Wrapper de conveniência que o observador usa quando só tem email.
 * Mantém compatibilidade com AccountManager V3 que salva projectId em
 * `~/.config/opencode/antigravity-accounts.json` com chmod 600.
 */
export async function resolveAndSaveProjectId(
  accessToken: string,
  account: { email?: string; projectId?: string; save?: AccountMetadataSaver },
  opts: Omit<ResolveProjectIdOptions, "accessToken" | "cachedProjectId" | "email" | "metadataSaver"> = {}
): Promise<ResolveResult> {
  return resolveProjectId({
    accessToken,
    cachedProjectId: account.projectId,
    email: account.email,
    metadataSaver: account.save,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Exports de compatibilidade e default
// ---------------------------------------------------------------------------

export const projectIdCacheForTesting = projectIdCache;

const projectModule = {
  CODE_ASSIST_ENDPOINTS,
  ENDPOINT_ORDER,
  FETCH_TIMEOUT_MS,
  FALLBACK_PROJECT_ID,
  MODELS_2026,
  isRetryable,
  buildAntagravityHeaders,
  fetchWithTimeout,
  loadCodeAssist,
  onboardUser,
  fetchAvailableModels,
  resolveProjectId,
  resolveAndSaveProjectId,
  getCachedProjectId,
  setCachedProjectId,
  clearProjectIdCache,
  getCacheStats,
  fnv1a32,
  ProjectDiscoveryError,
};

export default projectModule;
