/**
 * @file accounts.ts
 * @module opencode-antigravity-auth-next/accounts
 * @description AccountManager V3 — third-person observer, library-first.
 * Manages multi-account persistence, atomic save, round-robin/sticky rotation,
 * double-checked locking refresh, 429/quota detection, background refresh,
 * and import from antigravity-manager.
 *
 * Standards: Node >=18, ESM, node:* builtins only + global fetch.
 * Path: ~/.config/opencode/antigravity-accounts.json with fallback OPENCODE_CONFIG_DIR.
 * Models 2026 aware via quota metadata, but storage is model-agnostic.
 *
 * @version 2.0.0 — 2026-08-25
 * @license MIT
 */

import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";

// ---------------------------------------------------------------------------
// Constants — OAuth credentials (public client, override via env)
// ---------------------------------------------------------------------------

/** google oauth token endpoint */
const TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";

/** public antigravity oauth client — 9Router / NoeFabris variant (public, not secret alone) */
const DEFAULT_CLIENT_ID =
  "1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com";
const DEFAULT_CLIENT_SECRET = "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";

/** secondary fallback — official antagravity / gemini cli client id prefix 681255809395- */
const SECONDARY_CLIENT_ID_FALLBACK =
  "681255809395-oo8ft2oq6bda7b6t5a2prl1saaq1hhs.apps.googleusercontent.com";

/** fallback project id used when onboarding not yet done */
const FALLBACK_PROJECT_ID = "rising-fact-p41fc";

/** token refresh buffer: refresh if expiry within 5 minutes */
const REFRESH_BUFFER_MS = 5 * 60 * 1000;

/** background refresh interval default 10 min */
const BACKGROUND_INTERVAL_MS = 10 * 60 * 1000;

/** default quota exhausted cooldown */
const DEFAULT_QUOTA_COOLDOWN_MS = 20 * 60 * 1000; // 20 min
const QUOTA_429_COOLDOWN_MS = 60 * 60 * 1000; // 1h for explicit 429

/** file permissions */
const FILE_MODE = 0o600;
const DIR_MODE = 0o755;

// ---------------------------------------------------------------------------
// Types V3
// ---------------------------------------------------------------------------

/**
 * Quota snapshot per account, mirrors v1internal:retrieveUserQuotaSummary
 * but kept lightweight in storage.
 */
export interface QuotaInfo {
  /** remaining percentage or tokens, optional */
  remaining?: number;
  /** limit */
  limit?: number;
  /** reset timestamp ms */
  resetAt?: number;
  /** true when exhausted */
  exhausted?: boolean;
  /** raw group mapped from model→group, e.g. antigravity, gemini-cli */
  group?: string;
  /** last check ms */
  lastChecked?: number;
  /** per-model counters when dual pool */
  pools?: Record<string, { remaining?: number; resetAt?: number }>;
}

/**
 * V3 Account — canonical storage format for opencode-antigravity-auth-next.
 * Compatible with antigravity-manager flat export {email, refresh_token}
 */
export interface Account {
  /** unique email, lowercased */
  email: string;
  /** google oauth refresh token (1//...) */
  refreshToken: string;
  /** cached bearer access token */
  accessToken?: string;
  /** expiry epoch ms (Date.now() + expires_in*1000) */
  expiry?: number;
  /** cloud project id resolved via loadCodeAssist / onboardUser */
  projectId?: string;
  /** soft disabled flag — user can toggle */
  disabled?: boolean;
  /** quota exhausted until epoch ms — skip in rotation */
  quotaExhaustedUntil?: number;
  /** last usage epoch ms */
  lastUsed?: number;
  /** creation epoch ms */
  createdAt?: number;
  /** update epoch ms */
  updatedAt?: number;
  /** cached quota snapshot */
  quota?: QuotaInfo;
  /** optional stable id (uuid) */
  id?: string;
  /** account pool type */
  type?: "antigravity" | "gemini-cli" | "auto" | string;
  /** display name from userinfo */
  displayName?: string;
  /** optional metadata — not persisted critically */
  metadata?: Record<string, unknown>;
}

/** File wrapper — versioned for forward migration */
export interface AccountsFileV3 {
  version: 3;
  accounts: Account[];
  lastRotationIndex?: number;
  lastStickyEmail?: string | null;
  updatedAt?: number;
  /** optional fallback project cache */
  fallbackProjectId?: string;
}

/** legacy shapes for import tolerance */
type LegacyFile =
  | AccountsFileV3
  | { accounts: Account[] }
  | { accounts: Record<string, Account> }
  | Account[]
  | { version?: number; [k: string]: unknown };

/** rotation strategies */
export type RotationStrategy = "round-robin" | "sticky";

/** result of token refresh */
export interface RefreshResult {
  accessToken: string;
  expiry: number; // epoch ms
  projectId?: string;
  raw?: Record<string, unknown>;
}

/** options for manager */
export interface AccountManagerOptions {
  /** override file path — for tests */
  filePath?: string;
  /** default rotation strategy */
  defaultStrategy?: RotationStrategy;
  /** disable background refresh */
  disableBackground?: boolean;
  /** background interval */
  backgroundIntervalMs?: number;
  /** custom fetcher for refresh (DI) */
  refreshFn?: (refreshToken: string) => Promise<RefreshResult>;
}

/** quota exhausted mark options */
export interface QuotaExhaustedOptions {
  durationMs?: number;
  reason?: string;
  group?: string;
  model?: string;
}

// ---------------------------------------------------------------------------
// Path resolution — third-person observer: resolves without side-effects
// ---------------------------------------------------------------------------

/**
 * Resolves config directory honoring OPENCODE_CONFIG_DIR env fallback.
 * observer only — no fs writes here.
 */
export function resolveConfigDir(): string {
  const envDir = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (envDir && envDir.length > 0) {
    return path.resolve(envDir);
  }
  return path.join(os.homedir(), ".config", "opencode");
}

/**
 * Resolves full accounts file path.
 */
export function resolveAccountsPath(custom?: string): string {
  if (custom && custom.trim().length > 0) return path.resolve(custom);
  const dir = resolveConfigDir();
  return path.join(dir, "antigravity-accounts.json");
}

/**
 * Candidate paths for antigravity-manager import.
 */
export function resolveAntagravityManagerCandidates(): string[] {
  const home = os.homedir();
  const custom = process.env.ANTIGRAVITY_MANAGER_ACCOUNTS_PATH?.trim();
  const list: string[] = [];
  if (custom) list.push(path.resolve(custom));
  list.push(
    path.join(home, ".config", "antigravity-manager", "accounts.json"),
    path.join(home, ".config", "antigravity-manager", "credentials.json"),
    path.join(home, ".antigravity-manager", "accounts.json"),
    path.join(home, ".antigravity-manager", "credentials.json"),
    path.join(home, "Library", "Application Support", "antigravity-manager", "accounts.json"),
    path.join(home, ".config", "zerogravity", "accounts.json"),
    path.join(home, ".config", "opencode", "antigravity-accounts.json.bak"),
  );
  // windows AppData
  if (process.env.APPDATA) {
    list.push(
      path.join(process.env.APPDATA, "antigravity-manager", "accounts.json"),
      path.join(process.env.APPDATA, "antigravity-manager", "credentials.json"),
    );
  }
  return list;
}

// ---------------------------------------------------------------------------
// Helpers — atomic IO, parsing
// ---------------------------------------------------------------------------

/**
 * Ensures dir exists with 0755, tolerant to race.
 */
async function ensureDir(dir: string): Promise<void> {
  try {
    await fsp.mkdir(dir, { recursive: true, mode: DIR_MODE });
  } catch (err) {
    // best-effort chmod even if exists
    try {
      await fsp.chmod(dir, DIR_MODE);
    } catch {
      // ignore
    }
    if ((err as NodeJS.ErrnoException).code !== "EEXIST") {
      // if mkdir failed for other reason, rethrow only if dir doesn't exist
      try {
        await fsp.stat(dir);
      } catch {
        throw err;
      }
    }
  }
}

/**
 * Writes file atomically: temp + rename + chmod 600.
 * Third-person observer safe — no partial file exposure.
 */
async function atomicWriteFileAtomic(targetPath: string, data: string): Promise<void> {
  const dir = path.dirname(targetPath);
  await ensureDir(dir);

  const rand = crypto.randomBytes(6).toString("hex");
  const tmpName = `.antigravity-accounts.tmp-${process.pid}-${rand}.json`;
  const tmpPath = path.join(dir, tmpName);

  // write temp
  await fsp.writeFile(tmpPath, data, { encoding: "utf8", mode: FILE_MODE });
  try {
    await fsp.chmod(tmpPath, FILE_MODE);
  } catch {
    // ignore on windows
  }
  // rename atomic
  await fsp.rename(tmpPath, targetPath);
  try {
    await fsp.chmod(targetPath, FILE_MODE);
  } catch {
    // windows may not support chmod 600
  }
}

/**
 * Parses legacy file formats into normalized accounts array.
 */
function normalizeFileContent(raw: unknown): { accounts: Account[]; rotationIndex: number; stickyEmail: string | null } {
  const now = Date.now();
  let accounts: Account[] = [];
  let rotationIndex = 0;
  let stickyEmail: string | null = null;

  if (!raw) return { accounts, rotationIndex, stickyEmail };

  // flat array — antigravity-manager export
  if (Array.isArray(raw)) {
    accounts = raw
      .map((item: any) => {
        if (!item) return null;
        const email = (item.email ?? item.email_address ?? item.id ?? "").toString().toLowerCase().trim();
        const rt = (item.refresh_token ?? item.refreshToken ?? item.refreshTokenEncrypted ?? "").toString().trim();
        if (!email || !rt) return null;
        const acc: Account = {
          email,
          refreshToken: rt,
          accessToken: item.access_token ?? item.accessToken,
          expiry: item.expiry ?? item.expires_at ?? undefined,
          projectId: item.projectId ?? item.project_id ?? FALLBACK_PROJECT_ID,
          disabled: !!item.disabled,
          createdAt: item.createdAt ?? now,
          updatedAt: now,
          id: item.id ?? crypto.randomUUID?.() ?? `${email}-${now}`,
          type: item.type ?? "antigravity",
        };
        // normalize expiry if seconds
        if (acc.expiry && acc.expiry < 1e12) {
          // seconds -> ms if looks like seconds
          if (acc.expiry > 1e9 && acc.expiry < 1e12) acc.expiry = acc.expiry * 1000;
        }
        return acc;
      })
      .filter(Boolean) as Account[];
    return { accounts, rotationIndex, stickyEmail };
  }

  if (typeof raw === "object") {
    const obj = raw as any;
    // AccountsFileV3
    if (Array.isArray(obj.accounts)) {
      accounts = obj.accounts
        .map((a: any) => {
          if (!a?.email || !a?.refreshToken && !a?.refresh_token) return null;
          const email = a.email.toString().toLowerCase().trim();
          const rt = (a.refreshToken ?? a.refresh_token ?? "").toString().trim();
          if (!email || !rt) return null;
          return {
            ...a,
            email,
            refreshToken: rt,
            id: a.id ?? crypto.randomUUID?.() ?? `${email}-${now}`,
            createdAt: a.createdAt ?? now,
            updatedAt: a.updatedAt ?? now,
          } as Account;
        })
        .filter(Boolean) as Account[];
      rotationIndex = Number.isFinite(obj.lastRotationIndex) ? obj.lastRotationIndex : 0;
      stickyEmail = obj.lastStickyEmail ?? null;
      return { accounts, rotationIndex, stickyEmail };
    }
    // map form {accounts: {email: {...}}}
    if (obj.accounts && typeof obj.accounts === "object" && !Array.isArray(obj.accounts)) {
      const map = obj.accounts as Record<string, any>;
      accounts = Object.entries(map)
        .map(([emailKey, val]: [string, any]) => {
          const email = (val?.email ?? emailKey).toString().toLowerCase().trim();
          const rt = (val?.refreshToken ?? val?.refresh_token ?? "").toString().trim();
          if (!email || !rt) return null;
          return {
            email,
            refreshToken: rt,
            accessToken: val.accessToken ?? val.access_token,
            expiry: val.expiry,
            projectId: val.projectId ?? FALLBACK_PROJECT_ID,
            disabled: !!val.disabled,
            createdAt: val.createdAt ?? now,
            updatedAt: now,
            id: val.id ?? crypto.randomUUID?.() ?? `${email}-${now}`,
            type: val.type ?? "antigravity",
          } as Account;
        })
        .filter(Boolean) as Account[];
      return { accounts, rotationIndex, stickyEmail };
    }
    // single account object?
    if (obj.email && (obj.refreshToken || obj.refresh_token)) {
      const email = obj.email.toString().toLowerCase().trim();
      const rt = (obj.refreshToken ?? obj.refresh_token).toString().trim();
      if (email && rt) {
        accounts = [
          {
            email,
            refreshToken: rt,
            accessToken: obj.accessToken,
            expiry: obj.expiry,
            projectId: obj.projectId,
            createdAt: now,
            updatedAt: now,
            id: crypto.randomUUID?.() ?? `${email}-${now}`,
          },
        ];
      }
    }
  }

  return { accounts, rotationIndex, stickyEmail };
}

/**
 * Sanitizes account for persistence — strips undefined, normalizes email.
 */
function sanitizeAccount(acc: Account): Account {
  const now = Date.now();
  const email = acc.email.toLowerCase().trim();
  return {
    email,
    refreshToken: acc.refreshToken.trim(),
    accessToken: acc.accessToken?.trim() || undefined,
    expiry: acc.expiry,
    projectId: acc.projectId?.trim() || FALLBACK_PROJECT_ID,
    disabled: !!acc.disabled,
    quotaExhaustedUntil: acc.quotaExhaustedUntil,
    lastUsed: acc.lastUsed,
    createdAt: acc.createdAt ?? now,
    updatedAt: now,
    quota: acc.quota,
    id: acc.id ?? crypto.randomUUID?.() ?? `${email}-${now}`,
    type: acc.type ?? "antigravity",
    displayName: acc.displayName,
    metadata: acc.metadata,
  };
}

// ---------------------------------------------------------------------------
// OAuth refresh — uses fetch global, no external deps
// ---------------------------------------------------------------------------

/**
 * Resolves OAuth client credentials honoring env overrides.
 */
function resolveOAuthCredentials(): { clientId: string; clientSecret: string } {
  const envId = process.env.ANTIGRAVITY_CLIENT_ID?.trim() || process.env.GOOGLE_CLIENT_ID?.trim();
  const envSecret = process.env.ANTIGRAVITY_CLIENT_SECRET?.trim() || process.env.GOOGLE_OAUTH_CLIENT_SECRET?.trim();
  return {
    clientId: envId && envId.length > 10 ? envId : DEFAULT_CLIENT_ID,
    clientSecret: envSecret && envSecret.length > 10 ? envSecret : DEFAULT_CLIENT_SECRET,
  };
}

/**
 * Default refresh implementation.
 * Observes third-party response without leaking secrets to logs.
 */
async function defaultRefreshFn(refreshToken: string): Promise<RefreshResult> {
  const { clientId, clientSecret } = resolveOAuthCredentials();

  const body = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  });

  const res = await fetch(TOKEN_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      // dynamic UA blinded — matches constants.ts behavior
      "User-Agent": `antigravity/${process.env.ANTIGRAVITY_VERSION ?? "1.19.2"} ${os.type()}/${os.arch()}`,
    },
    body: body.toString(),
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    // try secondary client fallback on invalid_client
    const isInvalidClient = res.status === 400 || res.status === 401;
    const containsInvalid = txt.toLowerCase().includes("invalid_client") || txt.toLowerCase().includes("unauthorized_client");
    if (isInvalidClient && containsInvalid && clientId === DEFAULT_CLIENT_ID) {
      // retry with secondary client id but same secret shape may differ — attempt with same secret
      // if env not overriding, this attempts official client
      try {
        const retryBody = new URLSearchParams({
          client_id: SECONDARY_CLIENT_ID_FALLBACK,
          client_secret: clientSecret,
          refresh_token: refreshToken,
          grant_type: "refresh_token",
        });
        const retryRes = await fetch(TOKEN_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: retryBody.toString(),
        });
        if (retryRes.ok) {
          const retryJson = (await retryRes.json()) as any;
          const expiresIn = Number(retryJson.expires_in ?? 3600);
          return {
            accessToken: retryJson.access_token,
            expiry: Date.now() + expiresIn * 1000,
            raw: retryJson,
          };
        }
      } catch {
        // fall through to throw original error
      }
    }
    const err: any = new Error(`token refresh failed ${res.status}: ${txt.slice(0, 500)}`);
    err.status = res.status;
    err.body = txt;
    throw err;
  }

  const json = (await res.json()) as any;
  if (!json.access_token) {
    throw new Error(`refresh response missing access_token: ${JSON.stringify(json).slice(0, 500)}`);
  }
  const expiresIn = Number(json.expires_in ?? 3600);
  return {
    accessToken: json.access_token,
    expiry: Date.now() + expiresIn * 1000,
    raw: json,
  };
}

// ---------------------------------------------------------------------------
// AccountManager — core
// ---------------------------------------------------------------------------

/**
 * AccountManager V3 — third-person observer pattern.
 * The manager observes accounts from file, never mutates caller objects directly
 * without atomic persistence. Library-first: pure functions, no opencode SDK dep.
 */
export class AccountManager {
  /** file path resolved */
  public readonly filePath: string;

  private accounts: Account[] = [];
  private rotationIndex = 0;
  private stickyEmail: string | null = null;

  /** double-checked locking map: email -> refresh promise */
  private refreshLocks: Map<string, Promise<Account>> = new Map();

  /** save serialization queue */
  private saveQueue: Promise<void> = Promise.resolve();

  /** background timer */
  private backgroundTimer: NodeJS.Timeout | null = null;

  private options: Required<Omit<AccountManagerOptions, "filePath" | "refreshFn">> & {
    filePath?: string;
    refreshFn?: AccountManagerOptions["refreshFn"];
  };

  private initialized = false;

  // -----------------------------------------------------------------------
  // ctor
  // -----------------------------------------------------------------------

  constructor(opts: AccountManagerOptions = {}) {
    const fp = resolveAccountsPath(opts.filePath);
    this.filePath = fp;
    this.options = {
      defaultStrategy: opts.defaultStrategy ?? "round-robin",
      disableBackground: opts.disableBackground ?? false,
      backgroundIntervalMs: opts.backgroundIntervalMs ?? BACKGROUND_INTERVAL_MS,
      filePath: fp,
      refreshFn: opts.refreshFn,
    } as any;
  }

  // -----------------------------------------------------------------------
  // lifecycle
  // -----------------------------------------------------------------------

  /**
   * Initializes manager — loads from disk, tolerant to missing file.
   */
  async init(): Promise<void> {
    if (this.initialized) return;
    await this.load();
    this.initialized = true;
    if (!this.options.disableBackground) {
      this.startBackgroundRefresh(this.options.backgroundIntervalMs);
    }
  }

  /**
   * Loads accounts from disk atomically, merges legacy formats.
   * Public for explicit reload.
   */
  async load(): Promise<Account[]> {
    try {
      const content = await fsp.readFile(this.filePath, "utf8");
      const parsed: LegacyFile = JSON.parse(content);
      const { accounts, rotationIndex, stickyEmail } = normalizeFileContent(parsed);
      this.accounts = accounts.map(sanitizeAccount);
      this.rotationIndex = Number.isFinite(rotationIndex) ? (rotationIndex as number) : 0;
      this.stickyEmail = stickyEmail ? stickyEmail.toLowerCase() : null;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code === "ENOENT") {
        this.accounts = [];
        this.rotationIndex = 0;
        this.stickyEmail = null;
        // ensure dir exists for future saves
        await ensureDir(path.dirname(this.filePath)).catch(() => {});
      } else if (err instanceof SyntaxError) {
        // corrupted file — backup and reset, preserve backup
        try {
          const dir = path.dirname(this.filePath);
          const backup = path.join(dir, `antigravity-accounts.corrupt-${Date.now()}.json`);
          await fsp.copyFile(this.filePath, backup).catch(() => {});
        } catch {}
        this.accounts = [];
        this.rotationIndex = 0;
        this.stickyEmail = null;
      } else {
        // rethrow unexpected
        throw err;
      }
    }
    return this.listAll();
  }

  /**
   * Saves accounts atomically with chmod 600 and save-queue serialization.
   */
  async save(): Promise<void> {
    const payload: AccountsFileV3 = {
      version: 3,
      accounts: this.accounts.map(sanitizeAccount),
      lastRotationIndex: this.rotationIndex,
      lastStickyEmail: this.stickyEmail,
      updatedAt: Date.now(),
      fallbackProjectId: FALLBACK_PROJECT_ID,
    };

    const data = JSON.stringify(payload, null, 2);

    // chain saves to avoid race
    const task = async () => {
      await atomicWriteFileAtomic(this.filePath, data);
    };

    // enqueue
    this.saveQueue = this.saveQueue.then(task, task);
    await this.saveQueue;
  }

  // -----------------------------------------------------------------------
  // read helpers — observer never mutates without copy
  // -----------------------------------------------------------------------

  /** Returns deep copy of all accounts (including disabled) */
  listAll(): Account[] {
    return this.accounts.map((a) => ({ ...a, quota: a.quota ? { ...a.quota } : undefined }));
  }

  /**
   * Lists accounts — by default only active (not disabled, not quota exhausted).
   * @param includeDisabled when true returns all.
   */
  list(includeDisabled = false): Account[] {
    if (includeDisabled) return this.listAll();
    const now = Date.now();
    return this.accounts
      .filter((a) => !a.disabled && !this.isQuotaExhaustedInternal(a, now))
      .map((a) => ({ ...a }));
  }

  /** active accounts snapshot */
  listActive(): Account[] {
    return this.list(false);
  }

  /** find by email lowercased */
  getByEmail(email: string): Account | null {
    const key = email.toLowerCase().trim();
    const found = this.accounts.find((a) => a.email.toLowerCase() === key);
    return found ? { ...found } : null;
  }

  /** internal mutable ref — only manager uses */
  private getMutableByEmail(email: string): Account | undefined {
    const key = email.toLowerCase().trim();
    return this.accounts.find((a) => a.email.toLowerCase() === key);
  }

  /** checks token expiry buffer */
  private isTokenExpiredInternal(acc: Account, now = Date.now()): boolean {
    if (!acc.accessToken) return true;
    if (!acc.expiry) return true;
    return acc.expiry - now < REFRESH_BUFFER_MS;
  }

  /** public token expiry check */
  isTokenExpired(acc: Account): boolean {
    return this.isTokenExpiredInternal(acc, Date.now());
  }

  /** checks quota exhausted */
  private isQuotaExhaustedInternal(acc: Account, now = Date.now()): boolean {
    if (!acc.quotaExhaustedUntil) return false;
    return now < acc.quotaExhaustedUntil;
  }

  /** public quota check */
  isQuotaExhausted(email: string): boolean {
    const acc = this.getMutableByEmail(email);
    if (!acc) return false;
    return this.isQuotaExhaustedInternal(acc, Date.now());
  }

  /**
   * Detects 429 / quota error from response.
   * Used by plugin fetch interceptor to call markQuotaExhausted.
   */
  static isQuotaError(status: number, bodyText?: string): boolean {
    if (status === 429) return true;
    if (status === 403) {
      const txt = (bodyText ?? "").toLowerCase();
      return (
        txt.includes("quota") ||
        txt.includes("rate limit") ||
        txt.includes("rate_limit") ||
        txt.includes("resource exhausted") ||
        txt.includes("too many requests") ||
        txt.includes("billing") ||
        txt.includes("exhausted")
      );
    }
    return false;
  }

  // -----------------------------------------------------------------------
  // rotation — round-robin / sticky
  // -----------------------------------------------------------------------

  /**
   * Returns next usable account per strategy, skipping disabled/quota.
   * Updates lastUsed and rotation state, persists sticky in background (non-blocking).
   *
   * Double-checked for quota after selection.
   *
   * @param strategy rotation mode
   * @returns account copy or null if none usable
   */
  getNextAccount(strategy: RotationStrategy = this.options.defaultStrategy): Account | null {
    const now = Date.now();
    const active = this.accounts.filter((a) => !a.disabled && !this.isQuotaExhaustedInternal(a, now));

    if (active.length === 0) return null;

    let chosen: Account | undefined;

    if (strategy === "sticky" && this.stickyEmail) {
      chosen = active.find((a) => a.email.toLowerCase() === this.stickyEmail?.toLowerCase());
    }

    if (!chosen) {
      // round-robin
      if (this.rotationIndex >= active.length || this.rotationIndex < 0) this.rotationIndex = 0;
      chosen = active[this.rotationIndex % active.length];
      this.rotationIndex = (this.rotationIndex + 1) % active.length;
      this.stickyEmail = chosen.email.toLowerCase();
      // background persist rotation — fire and forget, queued
      this.save().catch(() => {});
    }

    if (!chosen) return null;

    // update lastUsed mutable then async save
    const mutable = this.getMutableByEmail(chosen.email);
    if (mutable) {
      mutable.lastUsed = now;
      mutable.updatedAt = now;
      // non-blocking save for lastUsed to avoid slowing request path
      this.save().catch(() => {});
    }

    return { ...chosen };
  }

  /**
   * Async variant that also refreshes token if needed via double-checked locking.
   * Preferred for production request path.
   */
  async getNextAccountWithRefresh(
    strategy: RotationStrategy = this.options.defaultStrategy,
  ): Promise<Account | null> {
    const acc = this.getNextAccount(strategy);
    if (!acc) return null;
    try {
      const refreshed = await this.refreshIfNeeded(acc);
      return refreshed;
    } catch {
      // refresh failed → mark disabled? no, return original and let caller fallback
      return acc;
    }
  }

  // -----------------------------------------------------------------------
  // quota handling
  // -----------------------------------------------------------------------

  /**
   * Marks account quota exhausted for duration.
   * @param email account email
   * @param opts duration and reason
   */
  async markQuotaExhausted(email: string, opts: QuotaExhaustedOptions | number = {}): Promise<void> {
    const durationOpts = typeof opts === "number" ? { durationMs: opts } : opts;
    const durationMs = durationOpts.durationMs ?? DEFAULT_QUOTA_COOLDOWN_MS;
    const key = email.toLowerCase().trim();
    const acc = this.getMutableByEmail(key);
    if (!acc) return;
    const now = Date.now();
    acc.quotaExhaustedUntil = now + durationMs;
    acc.updatedAt = now;
    acc.quota = {
      ...(acc.quota ?? {}),
      exhausted: true,
      lastChecked: now,
      group: durationOpts.group ?? acc.quota?.group,
    };
    // if sticky was this account, clear sticky so next call rotates
    if (this.stickyEmail?.toLowerCase() === key) {
      this.stickyEmail = null;
      // rotation remains, next getNextAccount will pick next
    }
    await this.save();
  }

  /**
   * Clears quota exhausted flag — used when quota resets or manual enable.
   */
  async clearQuotaExhausted(email: string): Promise<void> {
    const acc = this.getMutableByEmail(email.toLowerCase().trim());
    if (!acc) return;
    acc.quotaExhaustedUntil = undefined;
    if (acc.quota) acc.quota.exhausted = false;
    acc.updatedAt = Date.now();
    await this.save();
  }

  /**
   * Checks if should skip account due to quota — mirrors quota.ts shouldSkipAccount.
   */
  shouldSkipAccount(email: string): boolean {
    return this.isQuotaExhausted(email);
  }

  // -----------------------------------------------------------------------
  // enable / disable / add / remove
  // -----------------------------------------------------------------------

  async enable(email: string): Promise<boolean> {
    const acc = this.getMutableByEmail(email);
    if (!acc) return false;
    acc.disabled = false;
    acc.quotaExhaustedUntil = undefined;
    if (acc.quota) acc.quota.exhausted = false;
    acc.updatedAt = Date.now();
    await this.save();
    return true;
  }

  async disable(email: string): Promise<boolean> {
    const acc = this.getMutableByEmail(email);
    if (!acc) return false;
    acc.disabled = true;
    acc.updatedAt = Date.now();
    if (this.stickyEmail?.toLowerCase() === email.toLowerCase().trim()) {
      this.stickyEmail = null;
    }
    await this.save();
    return true;
  }

  async addAccount(input: Account | { email: string; refreshToken: string; projectId?: string }): Promise<Account> {
    const email = input.email.toLowerCase().trim();
    if (!email) throw new Error("email required");
    const rt = (input as any).refreshToken ?? (input as any).refresh_token;
    if (!rt) throw new Error("refreshToken required");

    const existing = this.getMutableByEmail(email);
    if (existing) {
      // update refresh token, keep other fields
      existing.refreshToken = rt.trim();
      if ((input as Account).projectId) existing.projectId = (input as Account).projectId;
      existing.disabled = false;
      existing.quotaExhaustedUntil = undefined;
      existing.updatedAt = Date.now();
      await this.save();
      return { ...existing };
    }

    const now = Date.now();
    const acc: Account = sanitizeAccount({
      email,
      refreshToken: rt.trim(),
      accessToken: (input as Account).accessToken,
      expiry: (input as Account).expiry,
      projectId: (input as Account).projectId ?? FALLBACK_PROJECT_ID,
      disabled: false,
      createdAt: now,
      updatedAt: now,
      id: (input as Account).id ?? crypto.randomUUID?.() ?? `${email}-${now}`,
      type: (input as Account).type ?? "antigravity",
      displayName: (input as Account).displayName,
    });

    this.accounts.push(acc);
    await this.save();
    return { ...acc };
  }

  async removeAccount(email: string): Promise<boolean> {
    const key = email.toLowerCase().trim();
    const idx = this.accounts.findIndex((a) => a.email.toLowerCase() === key);
    if (idx === -1) return false;
    this.accounts.splice(idx, 1);
    if (this.stickyEmail?.toLowerCase() === key) this.stickyEmail = null;
    if (this.rotationIndex >= this.accounts.length) this.rotationIndex = 0;
    await this.save();
    return true;
  }

  async updateAccount(email: string, patch: Partial<Account>): Promise<Account | null> {
    const acc = this.getMutableByEmail(email);
    if (!acc) return null;
    if (patch.refreshToken) acc.refreshToken = patch.refreshToken.trim();
    if (patch.accessToken !== undefined) acc.accessToken = patch.accessToken?.trim();
    if (patch.expiry !== undefined) acc.expiry = patch.expiry;
    if (patch.projectId !== undefined) acc.projectId = patch.projectId;
    if (patch.disabled !== undefined) acc.disabled = patch.disabled;
    if (patch.quota !== undefined) acc.quota = patch.quota;
    if (patch.displayName !== undefined) acc.displayName = patch.displayName;
    acc.updatedAt = Date.now();
    await this.save();
    return { ...acc };
  }

  // -----------------------------------------------------------------------
  // refresh — double-checked locking
  // -----------------------------------------------------------------------

  /**
   * Refreshes token if needed, with double-checked locking per email.
   * Ensures only one in-flight refresh per account.
   *
   * @param account account copy or email
   * @param force force refresh even if not expired
   */
  async refreshIfNeeded(account: Account | string, force = false): Promise<Account> {
    const emailKey =
      typeof account === "string" ? account.toLowerCase().trim() : account.email.toLowerCase().trim();

    const mutable = this.getMutableByEmail(emailKey);
    if (!mutable) throw new Error(`account not found: ${emailKey}`);

    const now = Date.now();
    const needsRefresh = force || this.isTokenExpiredInternal(mutable, now);

    if (!needsRefresh) {
      return { ...mutable };
    }

    // first check lock map
    const existingLock = this.refreshLocks.get(emailKey);
    if (existingLock) {
      // await existing and double-check
      const result = await existingLock;
      return { ...result };
    }

    // create new refresh promise
    const refreshPromise = (async (): Promise<Account> => {
      try {
        // double-checked after acquiring lock intention
        const afterLockNow = Date.now();
        const stillNeeds = force || this.isTokenExpiredInternal(mutable, afterLockNow);
        if (!stillNeeds) {
          return { ...mutable };
        }

        const refresher = this.options.refreshFn ?? defaultRefreshFn;
        const res = await refresher(mutable.refreshToken);

        mutable.accessToken = res.accessToken;
        mutable.expiry = res.expiry;
        if (res.projectId) mutable.projectId = res.projectId;
        mutable.updatedAt = Date.now();

        await this.save();
        return { ...mutable };
      } finally {
        // release lock
        this.refreshLocks.delete(emailKey);
      }
    })();

    this.refreshLocks.set(emailKey, refreshPromise);
    return refreshPromise;
  }

  /**
   * Forces refresh for all accounts that will expire within window.
   * Used by background refresher.
   */
  async refreshExpiringSoon(windowMs = 10 * 60 * 1000): Promise<void> {
    const now = Date.now();
    const toRefresh = this.accounts.filter(
      (a) => !a.disabled && a.refreshToken && a.expiry && a.expiry - now < windowMs,
    );

    for (const acc of toRefresh) {
      try {
        await this.refreshIfNeeded(acc.email, false);
      } catch (err) {
        // log but continue — observer should not crash
        // do not mark disabled on refresh failure; token may be revoked separately
        // eslint-disable-next-line no-console
        console.warn(`[accounts] background refresh failed for ${acc.email}: ${(err as Error).message}`);
      }
    }
  }

  // -----------------------------------------------------------------------
  // background refresh
  // -----------------------------------------------------------------------

  /**
   * Starts background refresh timer — refreshes tokens expiring soon.
   */
  startBackgroundRefresh(intervalMs = this.options.backgroundIntervalMs): void {
    this.stopBackgroundRefresh();
    this.backgroundTimer = setInterval(() => {
      this.refreshExpiringSoon(BACKGROUND_INTERVAL_MS + REFRESH_BUFFER_MS).catch(() => {});
      // also clean expired quota flags
      const now = Date.now();
      let dirty = false;
      for (const a of this.accounts) {
        if (a.quotaExhaustedUntil && now >= a.quotaExhaustedUntil) {
          a.quotaExhaustedUntil = undefined;
          if (a.quota) a.quota.exhausted = false;
          a.updatedAt = now;
          dirty = true;
        }
      }
      if (dirty) this.save().catch(() => {});
    }, intervalMs) as unknown as NodeJS.Timeout;

    // unref so process can exit
    if (this.backgroundTimer && typeof (this.backgroundTimer as any).unref === "function") {
      (this.backgroundTimer as any).unref();
    }
  }

  stopBackgroundRefresh(): void {
    if (this.backgroundTimer) {
      clearInterval(this.backgroundTimer as unknown as NodeJS.Timeout);
      this.backgroundTimer = null;
    }
  }

  // -----------------------------------------------------------------------
  // import — antigravity-manager
  // -----------------------------------------------------------------------

  /**
   * Imports accounts from antigravity-manager flat array format.
   * Tolerates both flat array and wrapped schemas.
   *
   * @param customPath optional explicit path
   * @returns number of imported / merged accounts
   */
  async importFromAntagravityManager(customPath?: string): Promise<number> {
    const candidates = customPath ? [path.resolve(customPath)] : resolveAntagravityManagerCandidates();
    let imported = 0;

    for (const cand of candidates) {
      try {
        const content = await fsp.readFile(cand, "utf8");
        if (!content.trim()) continue;
        const parsed = JSON.parse(content);
        const { accounts } = normalizeFileContent(parsed);
        if (accounts.length === 0) continue;

        for (const acc of accounts) {
          const existing = this.getMutableByEmail(acc.email);
          if (existing) {
            // merge — prefer existing refreshToken unless empty? update if differs
            if (acc.refreshToken && acc.refreshToken !== existing.refreshToken) {
              // keep newest token by checking if file is newer? simple overwrite if provided
              existing.refreshToken = acc.refreshToken;
              existing.updatedAt = Date.now();
            }
          } else {
            this.accounts.push(sanitizeAccount(acc));
            imported++;
          }
        }
        // if we found at least one valid file, break after first successful import
        // to avoid duplicate counting from multiple legacy paths
        if (accounts.length > 0) {
          // continue scanning to collect max? spec says import file singular — break after first non-empty
          break;
        }
      } catch (err) {
        const code = (err as NodeJS.ErrnoException).code;
        if (code === "ENOENT") continue;
        // corrupted file — skip
        continue;
      }
    }

    if (imported > 0) {
      await this.save();
    }
    return imported;
  }

  // -----------------------------------------------------------------------
  // utils for plugin integration
  // -----------------------------------------------------------------------

  /**
   * Marks quota exhausted based on HTTP response, convenience wrapper.
   * Returns true if marked.
   */
  async markFromResponse(
    email: string,
    status: number,
    bodyText?: string,
    opts: QuotaExhaustedOptions = {},
  ): Promise<boolean> {
    if (!AccountManager.isQuotaError(status, bodyText)) return false;
    const duration = status === 429 ? QUOTA_429_COOLDOWN_MS : opts.durationMs ?? DEFAULT_QUOTA_COOLDOWN_MS;
    await this.markQuotaExhausted(email, { ...opts, durationMs: duration });
    return true;
  }

  /**
   * Gets healthy account count.
   */
  healthyCount(): number {
    const now = Date.now();
    return this.accounts.filter((a) => !a.disabled && !this.isQuotaExhaustedInternal(a, now)).length;
  }

  /**
   * Disposes manager — stops timers and flushes save queue.
   */
  async dispose(): Promise<void> {
    this.stopBackgroundRefresh();
    await this.saveQueue.catch(() => {});
    this.refreshLocks.clear();
  }

  // -----------------------------------------------------------------------
  // static factories — observer entry points
  // -----------------------------------------------------------------------

  /**
   * Factory that auto-inits from default path.
   */
  static async create(opts: AccountManagerOptions = {}): Promise<AccountManager> {
    const mgr = new AccountManager(opts);
    await mgr.init();
    return mgr;
  }

  /**
   * Synchronous path helper — does not touch fs.
   */
  static resolvePath(custom?: string): string {
    return resolveAccountsPath(custom);
  }
}

// ---------------------------------------------------------------------------
// Default export + named compatibility
// ---------------------------------------------------------------------------

export default AccountManager;

/**
 * Helper to ensure accounts file exists with safe perms, idempotent.
 */
export async function ensureAccountsFile(filePath?: string): Promise<string> {
  const fp = resolveAccountsPath(filePath);
  await ensureDir(path.dirname(fp));
  try {
    await fsp.access(fp, fs.constants.F_OK);
    try {
      await fsp.chmod(fp, FILE_MODE);
    } catch {}
  } catch {
    // create empty v3 file
    const empty: AccountsFileV3 = {
      version: 3,
      accounts: [],
      lastRotationIndex: 0,
      lastStickyEmail: null,
      updatedAt: Date.now(),
      fallbackProjectId: FALLBACK_PROJECT_ID,
    };
    await atomicWriteFileAtomic(fp, JSON.stringify(empty, null, 2));
  }
  return fp;
}

/**
 * Quick utility — reads accounts without manager instance.
 */
export async function loadAccountsSnapshot(filePath?: string): Promise<Account[]> {
  const fp = resolveAccountsPath(filePath);
  try {
    const content = await fsp.readFile(fp, "utf8");
    const { accounts } = normalizeFileContent(JSON.parse(content));
    return accounts.map(sanitizeAccount);
  } catch {
    return [];
  }
}
