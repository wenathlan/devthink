/**
 * @file recovery.ts
 * @description Auto-recovery engine LRU signature, detectors, strategies, withAutoRecovery backoff.
 * observer third-person, node:* only + fetch, direct cloudcode-pa.
 */
import { randomInt } from "node:crypto";

export type RecoveryStrategy = "continue" | "undo_guidance" | "keep_thinking" | "inject_preserved";

export type RecoveryErrorType =
  | "invalid_thinking_signature"
  | "tool_use_without_thinking"
  | "session_boundary"
  | "tool_failure"
  | "tool_result_missing"
  | "thinking_block_order"
  | "thinking_disabled_violation"
  | "unknown";

export type RecoveryContext = {
  errorType: RecoveryErrorType;
  message: string;
  lastThinking?: { text: string; signature?: string };
  toolUseId?: string;
  sessionId?: string;
};

const LRU_MAX = 100;

class LRUCache<K, V> extends Map<K, V> {
  constructor(private max: number = LRU_MAX) { super(); }
  override set(k: K, v: V): this {
    if (this.has(k)) this.delete(k);
    super.set(k, v);
    if (this.size > this.max) {
      const first = this.keys().next().value;
      if (first !== undefined) this.delete(first);
    }
    return this;
  }
}

const signatureCache = new LRUCache<string, string>(LRU_MAX);

function fnv1a32(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export function detectErrorType(err: any, lastPayload?: any): RecoveryErrorType {
  const msg = String(err?.message ?? err ?? "").toLowerCase();
  if (msg.includes("thinking") && msg.includes("signature")) return "invalid_thinking_signature";
  if (msg.includes("tool_use") && msg.includes("thinking") || msg.includes("tool_use without")) return "tool_use_without_thinking";
  if (msg.includes("session") && msg.includes("boundary")) return "session_boundary";
  if (msg.includes("tool_result") && msg.includes("missing")) return "tool_result_missing";
  if (msg.includes("thinking_block") && msg.includes("order")) return "thinking_block_order";
  if (msg.includes("thinking") && msg.includes("disabled")) return "thinking_disabled_violation";
  if (msg.includes("tool") && (msg.includes("failed") || msg.includes("error"))) return "tool_failure";
  return "unknown";
}

export function getRecoveryStrategy(errorType: RecoveryErrorType): RecoveryStrategy {
  switch (errorType) {
    case "invalid_thinking_signature": return "keep_thinking";
    case "tool_use_without_thinking": return "inject_preserved";
    case "tool_result_missing": return "continue";
    case "thinking_block_order": return "keep_thinking";
    case "thinking_disabled_violation": return "undo_guidance";
    case "session_boundary": return "continue";
    case "tool_failure": return "continue";
    default: return "continue";
  }
}

export function preserveThinkingSignature(thinkingText: string, signature: string): void {
  if (!thinkingText || !signature) return;
  const key = fnv1a32(thinkingText.slice(0, 200)).toString(16);
  signatureCache.set(key, signature);
}

export function getPreservedSignature(thinkingText: string): string | undefined {
  const key = fnv1a32(thinkingText.slice(0, 200)).toString(16);
  return signatureCache.get(key);
}

export function buildRecoveryMessage(ctx: RecoveryContext): string {
  switch (ctx.errorType) {
    case "invalid_thinking_signature":
      return `[auto-recovery] invalid thinking signature detected, preserving and retrying with cached signature for session ${ctx.sessionId ?? "unknown"}`;
    case "tool_use_without_thinking":
      return `[auto-recovery] tool_use without thinking, injecting preserved thinking block`;
    case "tool_result_missing":
      return `[auto-recovery] tool_result missing, injecting continue guidance`;
    case "thinking_block_order":
      return `[auto-recovery] thinking block order violation, keeping thinking and retrying`;
    case "thinking_disabled_violation":
      return `[auto-recovery] thinking disabled violation, undoing guidance`;
    case "session_boundary":
      return `[auto-recovery] session boundary detected, continuing`;
    default:
      return `[auto-recovery] ${ctx.errorType}: ${ctx.message}`;
  }
}

export function transformMessagesForRecovery(messages: any[], ctx: RecoveryContext): any[] {
  const strategy = getRecoveryStrategy(ctx.errorType);
  if (strategy === "inject_preserved" && ctx.lastThinking) {
    const sig = ctx.lastThinking.signature ?? getPreservedSignature(ctx.lastThinking.text);
    if (sig) {
      // inject thinking block before last tool_use
      return messages.map((m, idx) => {
        if (idx === messages.length - 1 && m.role === "assistant") {
          return { ...m, thinking: ctx.lastThinking!.text, thoughtSignature: sig };
        }
        return m;
      });
    }
  }
  if (strategy === "keep_thinking" && ctx.lastThinking) {
    // ensure last assistant message retains thinking
    return messages;
  }
  if (strategy === "continue") {
    // add user message "continue"
    return [...messages, { role: "user", content: [{ text: "continue" }] }];
  }
  if (strategy === "undo_guidance") {
    // remove system guidance about thinking
    return messages.filter(m => !(m.role === "system" && String(m.content).toLowerCase().includes("thinking")));
  }
  return messages;
}

export async function withAutoRecovery<T>(
  fn: (attempt: number, ctx?: RecoveryContext) => Promise<T>,
  opts?: { maxRetries?: number; baseDelay?: number; maxDelay?: number }
): Promise<T> {
  const maxRetries = opts?.maxRetries ?? 3;
  const baseDelay = opts?.baseDelay ?? 250;
  const maxDelay = opts?.maxDelay ?? 10000;
  let lastError: any;
  let recoveryCtx: RecoveryContext | undefined;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn(attempt, recoveryCtx);
    } catch (e: any) {
      lastError = e;
      const errorType = detectErrorType(e);
      if (attempt >= maxRetries) break;
      if (errorType === "unknown" && !String(e?.message ?? "").toLowerCase().includes("thinking") && !String(e?.message ?? "").toLowerCase().includes("tool")) {
        // only retry known recoverable errors
        const status = e?.status ?? e?.response?.status;
        if (status && ![429, 500, 502, 503, 504, 403, 404].includes(Number(status))) break;
      }
      recoveryCtx = {
        errorType,
        message: String(e?.message ?? e),
        lastThinking: e?.lastThinking,
        toolUseId: e?.toolUseId,
        sessionId: e?.sessionId,
      };
      const jitter = (() => { try { return randomInt(0, 81); } catch { return Math.floor(Math.random() * 81); } })();
      const delay = Math.min(baseDelay * Math.pow(2, attempt) + jitter, maxDelay);
      await new Promise(r => setTimeout(r, delay));
    }
  }
  throw lastError;
}

export const Recovery = {
  LRUCache,
  signatureCache,
  detectErrorType,
  getRecoveryStrategy,
  preserveThinkingSignature,
  getPreservedSignature,
  buildRecoveryMessage,
  transformMessagesForRecovery,
  withAutoRecovery,
};

export default Recovery;
