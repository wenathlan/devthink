/**
 * @fileoverview OAuth PKCE para opencode-antigravity-auth-next v2.0.0
 * @module auth/oauth
 *
 * Terceira pessoa observer, library-first, root-first (sem src/).
 * Substitui plugin original que falhou por User-Agent desatualizado.
 *
 * Fluxo 100% direto em cloudcode-pa.googleapis.com, sem base URL localhost v1.
 * Suporte modelos 2026: gemini-3-pro-preview, gemini-3-flash-preview,
 * gemini-3.1-pro-preview, gemini-2.5, claude-opus-4-6-thinking, claude-sonnet-4-6.
 *
 * Apenas node:* builtins + fetch global (Node >=18).
 *   - node:crypto para PKCE S256 e random
 *   - node:http para callback server 127.0.0.1 porta aleatória locked
 *   - node:os para detectar plataforma no open browser
 *   - node:child_process para abrir navegador com fallback manual
 *
 * @license MIT
 */

import * as crypto from "node:crypto";
import * as http from "node:http";
import * as os from "node:os";
import { exec } from "node:child_process";

// ---------------------------------------------------------------------------
// Constantes de identificação Gemini / Cloud Code - v2.0.0 fix
// ---------------------------------------------------------------------------

/**
 * Client ID público oficial do Gemini CLI / Cloud Code.
 * Não é secret sensível - distribuído em binários públicos google.
 * Substitui User-Agent desatualizado do plugin legado.
 */
export const GEMINI_OAUTH_CLIENT_ID =
  "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com";

/**
 * Client Secret público pareado com CLIENT_ID acima (Gemini CLI).
 * Necessário para grant_type=authorization_code no token endpoint.
 */
export const GEMINI_OAUTH_CLIENT_SECRET =
  "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";

/** Endpoints OAuth2 Google - imutáveis */
export const GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
export const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
export const GOOGLE_USERINFO_URL =
  "https://www.googleapis.com/oauth2/v2/userinfo";

/** User-Agent atualizado v2.0.0 - motivo da falha do plugin original */
export const ANTIGRAVITY_USER_AGENT =
  "antigravity-auth-next/2.0.0 (GPN:GeminiCLI) Node.js/22 (+https://github.com/antigravity-auth-next)";

/** Base direta Cloud Code PA - sem localhost v1 proxy */
export const CLOUDCODE_API_BASE = "https://cloudcode-pa.googleapis.com";

/** Origem exigida pelos headers Cloud Code */
export const CLOUDCODE_ORIGIN = "https://cloud.google.com";

/**
 * Escopos mínimos para Cloud Code + UserInfo.
 * Inclui cloud-platform + cloudaicompanion + openid para cobrir Gemini.
 */
export const GOOGLE_OAUTH_SCOPES = [
  "openid",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/cloudcode",
  "https://www.googleapis.com/auth/cloudaicompanion",
].join(" ");

/** Modelos 2026 suportados nesta versão - fonte da verdade */
export const SUPPORTED_MODELS_2026 = [
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "claude-opus-4-6-thinking",
  "claude-sonnet-4-6",
] as const;

export type SupportedModel2026 = (typeof SUPPORTED_MODELS_2026)[number];

// ---------------------------------------------------------------------------
// Tipos
// ---------------------------------------------------------------------------

/**
 * Resposta padrão do Google Token Endpoint (RFC 6749 Sec 5.1).
 */
export interface TokenResponse {
  access_token: string;
  refresh_token?: string;
  id_token?: string;
  expires_in: number;
  token_type: "Bearer";
  scope?: string;
}

/**
 * Resposta de userinfo v2 - contém e-mail verificado.
 */
export interface UserInfo {
  id?: string;
  email: string;
  verified_email?: boolean;
  name?: string;
  given_name?: string;
  family_name?: string;
  picture?: string;
  hd?: string;
}

/**
 * Resultado completo do fluxo OAuth.
 */
export interface OAuthResult {
  tokens: TokenResponse;
  userInfo: UserInfo;
  state: string;
}

/**
 * Callback do servidor local.
 */
export interface OAuthCallbackResult {
  code: string;
  state: string;
  scope?: string;
}

// ---------------------------------------------------------------------------
// PKCE helpers - RFC 7636
// ---------------------------------------------------------------------------

/** Charset unreserved para verifier conforme RFC 7636 Sec 4.1 */
const PKCE_CHARSET =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";

/**
 * Gera verifier aleatório de 128 chars (máximo recomendado RFC 7636).
 * Observer puro: sem side-effects, usa node:crypto.
 *
 * @returns verifier 128 chars
 */
export function generateVerifier(): string {
  const randomBytes = crypto.randomBytes(128);
  let verifier = "";
  for (let i = 0; i < 128; i++) {
    // mapeia byte para charset sem bias crítico (aceitável para verifier)
    verifier += PKCE_CHARSET[randomBytes[i] % PKCE_CHARSET.length];
  }
  return verifier;
}

/**
 * Base64URL encode sem padding - RFC 4648 Sec 5.
 */
function base64UrlEncode(buffer: Buffer | Uint8Array): string {
  return Buffer.from(buffer)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

/**
 * Gera code_challenge S256 = BASE64URL(SHA256(verifier)).
 * Conforme RFC 7636 Sec 4.2 - obrigatório S256 para Google.
 *
 * @param verifier - output de generateVerifier()
 * @returns challenge base64url
 */
export function generateChallenge(verifier: string): string {
  const hash = crypto.createHash("sha256").update(verifier).digest();
  return base64UrlEncode(hash);
}

/**
 * Gera state aleatório CSRF-safe 32 bytes base64url.
 */
export function generateState(): string {
  return base64UrlEncode(crypto.randomBytes(32));
}

// ---------------------------------------------------------------------------
// Browser opener com fallback manual - node:os + node:child_process
// ---------------------------------------------------------------------------

/**
 * Tenta abrir navegador padrão. Nunca falha o fluxo - fallback manual.
 * Observer: registra URL no console para cópia manual.
 *
 * @param url - URL completa de autenticação
 */
export function openBrowser(url: string): void {
  const platform = os.platform();
  let command: string;

  if (platform === "darwin") {
    command = `open "${url.replace(/"/g, '\\"')}"`;
  } else if (platform === "win32") {
    // start precisa de title vazio em Windows
    command = `cmd /c start "" "${url.replace(/"/g, '""')}"`;
  } else {
    // linux / freebsd / etc - xdg-open
    command = `xdg-open "${url.replace(/"/g, '\\"')}"`;
  }

  // Sempre loga instrução manual imediatamente - garantia de acesso
  console.log(
    `\n[antigravity-auth-next] Abrindo navegador para autenticação...\n` +
      `Se não abrir automaticamente, copie e cole no navegador:\n\n${url}\n`
  );

  exec(command, { timeout: 5000 }, (error) => {
    if (error) {
      console.log(
        `[antigravity-auth-next] Falha ao abrir automaticamente (${error.message}). Use o link acima manualmente.`
      );
    }
  });
}

// ---------------------------------------------------------------------------
// Servidor local 127.0.0.1 porta aleatória locked - node:http
// ---------------------------------------------------------------------------

const CALLBACK_HTML_SUCCESS = `<!doctype html>
<html lang="pt"><head><meta charset="utf-8"><title>Antigravity Auth Next - OK</title>
<style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;background:#0a0a0f;color:#e0e0ff}div{text-align:center}</style>
</head><body><div><h1>✓ Autenticado</h1><p>opencode-antigravity-auth-next v2.0.0</p><p>Volte ao terminal. Esta aba pode ser fechada.</p></div></body></html>`;

const CALLBACK_HTML_ERROR = `<!doctype html>
<html lang="pt"><head><meta charset="utf-8"><title>Erro Auth</title>
<style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;background:#1a0a0a;color:#ffb0b0}div{text-align:center}</style>
</head><body><div><h1>✗ Erro na autenticação</h1><p>Verifique o terminal para detalhes.</p></div></body></html>`;

/**
 * Cria servidor local 127.0.0.1 em porta 0 (aleatória locked pelo SO).
 * Terceira pessoa observer: não muta estado global, apenas escuta loopback.
 *
 * Locked significa:
 *   - host fixo 127.0.0.1 (não 0.0.0.0)
 *   - porta 0 (SO aloca porta livre efêmera, sem race)
 *   - timeout default 300s
 *
 * @param options
 * @returns objeto com porta, promise de callback, função close
 */
export function createLocalCallbackServer(options?: {
  timeoutMs?: number;
  pathname?: string;
}): {
  portPromise: Promise<number>;
  callbackPromise: Promise<OAuthCallbackResult>;
  close: () => Promise<void>;
} {
  const timeoutMs = options?.timeoutMs ?? 5 * 60 * 1000;
  const pathname = options?.pathname ?? "/callback";

  let server: http.Server;
  let portResolve!: (p: number) => void;
  let portReject!: (e: Error) => void;
  let callbackResolve!: (r: OAuthCallbackResult) => void;
  let callbackReject!: (e: Error) => void;

  const portPromise = new Promise<number>((res, rej) => {
    portResolve = res;
    portReject = rej;
  });

  const callbackPromise = new Promise<OAuthCallbackResult>((res, rej) => {
    callbackResolve = res;
    callbackReject = rej;
  });

  server = http.createServer((req, res) => {
    try {
      if (!req.url) {
        res.writeHead(400, { "Content-Type": "text/html" });
        res.end(CALLBACK_HTML_ERROR);
        return;
      }

      const url = new URL(req.url, `http://127.0.0.1`);
      // aceita /callback ou / para compatibilidade
      if (url.pathname !== pathname && url.pathname !== "/" && url.pathname !== "/oauth/callback") {
        res.writeHead(404, { "Content-Type": "text/html" });
        res.end(CALLBACK_HTML_ERROR);
        return;
      }

      const error = url.searchParams.get("error");
      if (error) {
        const desc = url.searchParams.get("error_description") ?? error;
        res.writeHead(400, { "Content-Type": "text/html" });
        res.end(CALLBACK_HTML_ERROR.replace("Verifique o terminal", `Erro OAuth: ${desc}`));
        callbackReject(new Error(`OAuth error: ${desc}`));
        return;
      }

      const code = url.searchParams.get("code");
      const state = url.searchParams.get("state");
      const scope = url.searchParams.get("scope") ?? undefined;

      if (!code || !state) {
        res.writeHead(400, { "Content-Type": "text/html" });
        res.end(CALLBACK_HTML_ERROR);
        callbackReject(new Error("Callback sem code ou state"));
        return;
      }

      res.writeHead(200, {
        "Content-Type": "text/html",
        "Cache-Control": "no-store",
      });
      res.end(CALLBACK_HTML_SUCCESS);

      callbackResolve({ code, state, scope });
    } catch (err) {
      res.writeHead(500, { "Content-Type": "text/html" });
      res.end(CALLBACK_HTML_ERROR);
      callbackReject(err instanceof Error ? err : new Error(String(err)));
    }
  });

  // segurança: apenas loopback
  server.on("error", (err) => {
    portReject(err);
    callbackReject(err);
  });

  // porta 0 = aleatória locked pelo kernel
  server.listen(0, "127.0.0.1", () => {
    const addr = server.address() as { port: number } | null;
    if (!addr) {
      portReject(new Error("Falha ao obter porta do servidor local"));
      return;
    }
    portResolve(addr.port);
  });

  // timeout de segurança
  const timeout = setTimeout(() => {
    callbackReject(new Error(`Timeout OAuth após ${timeoutMs / 1000}s - usuário não completou login`));
  }, timeoutMs);

  const close = async (): Promise<void> => {
    clearTimeout(timeout);
    return new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  };

  // unref para não manter processo vivo se esquecido
  server.unref();

  return { portPromise, callbackPromise, close };
}

// ---------------------------------------------------------------------------
// Troca code por tokens - POST oauth2.googleapis.com/token + fetch
// ---------------------------------------------------------------------------

/**
 * Troca authorization code por tokens. Implementação produção com
 * tratamento erro detalhado, usando fetch global e form urlencoded.
 *
 * @param params - código, verifier, redirectUri
 */
export async function exchangeCodeForTokens(params: {
  code: string;
  verifier: string;
  redirectUri: string;
  clientId?: string;
  clientSecret?: string;
}): Promise<TokenResponse> {
  const clientId = params.clientId ?? GEMINI_OAUTH_CLIENT_ID;
  const clientSecret = params.clientSecret ?? GEMINI_OAUTH_CLIENT_SECRET;

  const body = new URLSearchParams({
    code: params.code,
    client_id: clientId,
    client_secret: clientSecret,
    code_verifier: params.verifier,
    grant_type: "authorization_code",
    redirect_uri: params.redirectUri,
  });

  let res: Response;
  try {
    res = await fetch(GOOGLE_TOKEN_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": ANTIGRAVITY_USER_AGENT,
        Accept: "application/json",
      },
      body: body.toString(),
    });
  } catch (err) {
    throw new Error(`Falha rede ao trocar code por tokens: ${(err as Error).message}`, {
      cause: err,
    });
  }

  const text = await res.text();
  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`Resposta token não-JSON (${res.status}): ${text.slice(0, 500)}`);
  }

  if (!res.ok) {
    const detail = json.error_description ?? json.error ?? text;
    throw new Error(`Token exchange falhou ${res.status}: ${detail}`);
  }

  if (!json.access_token) {
    throw new Error(`Token response sem access_token: ${text.slice(0, 500)}`);
  }

  return json as TokenResponse;
}

/**
 * Renova access_token usando refresh_token.
 *
 * @param refreshToken - refresh_token obtido no exchange
 */
export async function refreshAccessToken(
  refreshToken: string,
  options?: { clientId?: string; clientSecret?: string }
): Promise<TokenResponse> {
  if (!refreshToken) {
    throw new Error("refresh_token vazio - impossível renovar");
  }

  const clientId = options?.clientId ?? GEMINI_OAUTH_CLIENT_ID;
  const clientSecret = options?.clientSecret ?? GEMINI_OAUTH_CLIENT_SECRET;

  const body = new URLSearchParams({
    refresh_token: refreshToken,
    client_id: clientId,
    client_secret: clientSecret,
    grant_type: "refresh_token",
  });

  let res: Response;
  try {
    res = await fetch(GOOGLE_TOKEN_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": ANTIGRAVITY_USER_AGENT,
        Accept: "application/json",
      },
      body: body.toString(),
    });
  } catch (err) {
    throw new Error(`Falha rede ao renovar token: ${(err as Error).message}`, {
      cause: err,
    });
  }

  const text = await res.text();
  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`Resposta refresh não-JSON (${res.status}): ${text.slice(0, 500)}`);
  }

  if (!res.ok) {
    const detail = json.error_description ?? json.error ?? text;
    // tratamento específico para refresh expirado - orientar re-login
    if (json.error === "invalid_grant") {
      throw new Error(`Refresh token inválido/expirado - re-autenticação necessária: ${detail}`);
    }
    throw new Error(`Refresh falhou ${res.status}: ${detail}`);
  }

  // Google por padrão NÃO retorna novo refresh_token no refresh, preserva anterior no caller
  // Normalizamos para manter compatibilidade: se caller tinha refresh, será mergeado fora
  return json as TokenResponse;
}

// ---------------------------------------------------------------------------
// UserInfo - consulta email verificado
// ---------------------------------------------------------------------------

/**
 * Consulta e-mail do usuário autenticado via access_token.
 * Usa fetch global, header Bearer, User-Agent atualizado v2.
 *
 * @param accessToken - access_token válido
 */
export async function fetchUserInfo(accessToken: string): Promise<UserInfo> {
  if (!accessToken) {
    throw new Error("access_token vazio para fetchUserInfo");
  }

  let res: Response;
  try {
    res = await fetch(GOOGLE_USERINFO_URL, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "User-Agent": ANTIGRAVITY_USER_AGENT,
        Accept: "application/json",
      },
    });
  } catch (err) {
    throw new Error(`Falha rede ao buscar userinfo: ${(err as Error).message}`, {
      cause: err,
    });
  }

  const text = await res.text();
  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`Resposta userinfo não-JSON (${res.status}): ${text.slice(0, 500)}`);
  }

  if (!res.ok) {
    throw new Error(`Userinfo falhou ${res.status}: ${json.error_description ?? json.error ?? text}`);
  }

  if (!json.email) {
    throw new Error(`Userinfo sem email: ${text.slice(0, 500)}`);
  }

  return json as UserInfo;
}

// ---------------------------------------------------------------------------
// Fluxo completo orquestrado - third-person observer
// ---------------------------------------------------------------------------

export interface StartOAuthFlowOptions {
  /** Path do callback - default /callback */
  callbackPath?: string;
  /** Timeout total em ms - default 5 min */
  timeoutMs?: number;
  /** Escopos - default GOOGLE_OAUTH_SCOPES */
  scopes?: string;
  /** ClientId - default GEMINI_OAUTH_CLIENT_ID */
  clientId?: string;
  /** ClientSecret - default GEMINI_OAUTH_CLIENT_SECRET */
  clientSecret?: string;
  /** Função para abrir navegador - injetável para testes */
  openBrowserFn?: (url: string) => void;
}

/**
 * Orquestra fluxo completo PKCE:
 * 1. generateVerifier 128 chars
 * 2. generateChallenge S256 SHA256 base64url
 * 3. servidor local 127.0.0.1 porta aleatória locked
 * 4. build auth URL com code_challenge, state
 * 5. abertura navegador com fallback manual console.log
 * 6. espera callback com code
 * 7. troca code por tokens POST oauth2.googleapis.com/token
 * 8. consulta userinfo email
 *
 * Observer pattern: funções puras, servidor efêmero, sem estado global.
 *
 * @returns OAuthResult com tokens + userInfo
 */
export async function startOAuthFlow(
  options: StartOAuthFlowOptions = {}
): Promise<OAuthResult> {
  const clientId = options.clientId ?? GEMINI_OAUTH_CLIENT_ID;
  const clientSecret = options.clientSecret ?? GEMINI_OAUTH_CLIENT_SECRET;
  const scopes = options.scopes ?? GOOGLE_OAUTH_SCOPES;
  const callbackPath = options.callbackPath ?? "/callback";
  const opener = options.openBrowserFn ?? openBrowser;

  // 1. PKCE
  const verifier = generateVerifier();
  const challenge = generateChallenge(verifier);
  const state = generateState();

  // 2. servidor local locked 127.0.0.1 porta aleatória
  const { portPromise, callbackPromise, close } = createLocalCallbackServer({
    timeoutMs: options.timeoutMs,
    pathname: callbackPath,
  });

  let port: number;
  try {
    port = await portPromise;
  } catch (err) {
    await close().catch(() => {});
    throw new Error(`Falha ao iniciar callback server 127.0.0.1: ${(err as Error).message}`, {
      cause: err,
    });
  }

  const redirectUri = `http://127.0.0.1:${port}${callbackPath}`;

  // 3. URL de autorização Google
  const authParams = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: scopes,
    code_challenge: challenge,
    code_challenge_method: "S256",
    state,
    access_type: "offline",
    prompt: "consent", // força refresh_token sempre
  });

  const authUrl = `${GOOGLE_AUTH_URL}?${authParams.toString()}`;

  // 4. abre navegador com fallback manual
  try {
    opener(authUrl);
  } catch (err) {
    console.log(`[antigravity-auth-next] openBrowserFn falhou, fallback manual: ${authUrl}`);
  }

  // 5. espera callback
  let callbackResult: OAuthCallbackResult;
  try {
    callbackResult = await callbackPromise;
  } catch (err) {
    await close().catch(() => {});
    throw err;
  }

  // Validação state CSRF
  if (callbackResult.state !== state) {
    await close().catch(() => {});
    throw new Error(`State mismatch - possível CSRF. Esperado ${state} recebeu ${callbackResult.state}`);
  }

  // 6. troca code por tokens
  let tokens: TokenResponse;
  try {
    tokens = await exchangeCodeForTokens({
      code: callbackResult.code,
      verifier,
      redirectUri,
      clientId,
      clientSecret,
    });
  } catch (err) {
    await close().catch(() => {});
    throw err;
  }

  // 7. userinfo e-mail
  let userInfo: UserInfo;
  try {
    userInfo = await fetchUserInfo(tokens.access_token);
  } catch (err) {
    await close().catch(() => {});
    // não falha fluxo completo se userinfo falhar, mas alerta
    // aqui optamos por falhar para garantir identificação
    throw new Error(`Falha ao obter e-mail após troca de tokens: ${(err as Error).message}`, {
      cause: err,
    });
  }

  // 8. fecha servidor
  await close();

  console.log(
    `\n[antigravity-auth-next] ✓ Autenticado como ${userInfo.email} - modelo pronto: ${SUPPORTED_MODELS_2026.join(", ")}\n`
  );

  return { tokens, userInfo, state };
}

/**
 * Helper para renovar mantendo refresh_token anterior quando Google não retorna novo.
 * Padrão library-first.
 */
export async function refreshAndPreserve(
  oldTokens: TokenResponse
): Promise<TokenResponse> {
  if (!oldTokens.refresh_token) {
    throw new Error("Token anterior sem refresh_token - requer novo login");
  }
  const refreshed = await refreshAccessToken(oldTokens.refresh_token);
  return {
    ...refreshed,
    // preserva refresh_token original se endpoint não retornou novo (comportamento Google)
    refresh_token: refreshed.refresh_token ?? oldTokens.refresh_token,
  };
}
