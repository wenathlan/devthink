/**
 * @file version.ts
 * @module opencode-antigravity-auth-next/version
 * @description
 *  Third-person observer: the library watches how Antigravity Manager resolves
 *  its own product version at startup and replicates that chain without running
 *  Antigravity itself. The observer never relies on localhost v1 proxy; it
 *  contacts only public remote registries and falls back to a trusted local
 *  cache file, then to a hard-coded safe version.
 *
 *  Resolution chain replicating Antigravity-Manager (observed on 25/08/2026):
 *   1. Remote API — npm registry, GitHub Releases API, storage.googleapis
 *      with 5s timeout, parsing semver from heterogeneous JSON shapes.
 *   2. Local cache file — ~/.config/opencode/antigravity-version.json
 *      written atomically chmod 600, TTL-aware, survives offline.
 *   3. Fallback — 1.19.2 known to bypass "version no longer supported" ban
 *      while avoiding forced-update prompt.
 *
 *  Runtime: only node:* builtins + global fetch (Node >=18). Zero external deps.
 *  Layout: library-first, root-first — file lives in /mnt/data/auth/version.ts
 *  Endpoint policy: direto cloudcode-pa sem localhost v1 — version module never
 *  touches cloudcode-pa or localhost; only public version registries.
 *
 *  Date governance: 25/08/2026 — Canto do Buriti, PI, BR.
 *  Plugin: opencode-antigravity-auth-next 2.0.0
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";

// ---------------------------------------------------------------------------
// Constants — EN: pinned safe values / PT-BR: valores seguros fixos
// ---------------------------------------------------------------------------

/**
 * Fallback version last known good on 25/08/2026.
 * Observer verified: <1.15.8 banned, 1.11.5 explicitly blocked.
 */
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;

/** Minimum still accepted by cloudcode-pa on 2026-08-25 */
export const ANTIGRAVITY_VERSION_MIN_SUPPORTED = "1.15.8" as const;

/** Explicitly blocked versions observed in AM binary */
export const ANTIGRAVITY_BLOCKED_VERSIONS = [
  "1.11.5",
  "1.12.0",
  "1.12.3",
  "1.13.2",
] as const;

/** Remote URL chain — observer tries in order, fast-fail per URL */
export const ANTIGRAVITY_VERSION_REMOTE_URLS = [
  "https://registry.npmjs.org/antigravity/latest",
  "https://api.github.com/repos/google/antigravity/releases/latest",
  "https://storage.googleapis.com/antigravity-version/version.json",
] as const;

/** Timeout for each remote fetch — 5s per spec */
export const VERSION_FETCH_TIMEOUT_MS = 5_000 as const;

/** Memory cache TTL — version is relatively stable, 6h */
export const VERSION_MEMORY_TTL_MS = 6 * 60 * 60 * 1000 as const;

/** Local file cache TTL — 24h before considered stale but still usable offline */
export const VERSION_FILE_TTL_MS = 24 * 60 * 60 * 1000 as const;

const CACHE_FILE_NAME = "antigravity-version.json" as const;
const CONFIG_DIR_TAIL = path.join(".config", "opencode");
const FILE_MODE = 0o600 as const;
const DIR_MODE = 0o755 as const;

const SEMVER_RE = /^(\d+)\.(\d+)\.(\d+)(?:-[\w.-]+)?(?:\+[\w.-]+)?$/;
const SEMVER_EXTRACT_RE = /(\d+\.\d+\.\d+(?:-[\w.-]+)?(?:\+[\w.-]+)?)/;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface CacheEntry {
  version: string;
  fetchedAt: number; // epoch ms
  source: string; // url or "file" or "memory"
}

export interface VersionCacheFile {
  version: string;
  fetchedAt: number;
  source: string;
  expiresAt: number;
}

export interface FetchOptions {
  /** timeout per request ms — defaults 5000 */
  timeoutMs?: number;
  /** force remote bypassing memory cache */
  force?: boolean;
  /** custom remote urls override for testing */
  remoteUrls?: readonly string[];
  /** custom cache path override */
  cachePath?: string;
  /** headers extra for GitHub rate-limit friendly */
  userAgent?: string;
}

export interface GetVersionOptions extends FetchOptions {
  /** allow returning stale file cache if remote fails — default true */
  allowStale?: boolean;
}

// ---------------------------------------------------------------------------
// In-memory Map — requirement cache Map memória
// ---------------------------------------------------------------------------

/**
 * Memory cache — Map key -> CacheEntry.
 * The observer keeps only latest resolution under key "latest".
 */
export const versionMemoryCache = new Map<string, CacheEntry>();

// ---------------------------------------------------------------------------
// FS helpers — atomically 600, root-first
// ---------------------------------------------------------------------------

function resolveConfigDir(): string {
  // honor OPENCODE_CONFIG_DIR if set (same contract as config.ts)
  const envDir = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (envDir) return envDir;
  const xdg = process.env.XDG_CONFIG_HOME?.trim();
  if (xdg) return path.join(xdg, "opencode");
  return path.join(os.homedir(), CONFIG_DIR_TAIL);
}

function resolveCachePath(customPath?: string): string {
  if (customPath?.trim()) return path.resolve(customPath.trim());
  return path.join(resolveConfigDir(), CACHE_FILE_NAME);
}

// ---------------------------------------------------------------------------
// Semver utils — no external deps
// ---------------------------------------------------------------------------

/**
 * EN: validates strict semver shape.
 * PT-BR: valida shape semver estrito.
 * @param v - input
 */
export function isValidSemver(v: string): boolean {
  if (!v || typeof v !== "string") return false;
  return SEMVER_RE.test(v.trim());
}

/**
 * EN: extracts first semver token from dirty string like "v1.19.2" or "antigravity/1.19.2 darwin/arm64".
 * PT-BR: extrai primeiro token semver de string suja.
 * @param raw - raw input
 * @returns cleaned semver or null
 */
export function cleanSemver(raw: unknown): string | null {
  if (!raw || typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (SEMVER_RE.test(trimmed)) return trimmed;
  const m = trimmed.match(SEMVER_EXTRACT_RE);
  if (m && SEMVER_RE.test(m[1])) return m[1];
  return null;
}

/**
 * EN: compares two semver strings.
 * PT-BR: compara dois semver.
 * @param a - first
 * @param b - second
 * @returns -1 if a < b, 0 if equal, 1 if a > b
 */
export function compareSemver(a: string, b: string): -1 | 0 | 1 {
  const ca = cleanSemver(a);
  const cb = cleanSemver(b);
  // observer treats invalid as lower than any valid, but equal if both invalid
  if (!ca && !cb) return 0;
  if (!ca) return -1;
  if (!cb) return 1;

  const pa = ca.split(/[.-]/);
  const pb = cb.split(/[.-]/);

  // compare major.minor.patch numerically
  for (let i = 0; i < 3; i++) {
    const na = Number.parseInt(pa[i] ?? "0", 10);
    const nb = Number.parseInt(pb[i] ?? "0", 10);
    if (Number.isNaN(na) || Number.isNaN(nb)) continue;
    if (na < nb) return -1;
    if (na > nb) return 1;
  }
  // if numeric equal, shorter (no prerelease) > prerelease? simple: equal for now
  // handle prerelease suffix: e.g. 1.19.2-preview < 1.19.2
  const hasPreA = ca.includes("-");
  const hasPreB = cb.includes("-");
  if (hasPreA && !hasPreB) return -1;
  if (!hasPreA && hasPreB) return 1;
  return 0;
}

/**
 * EN: true if latest > current — should trigger update notification.
 * PT-BR: verdadeiro se latest > current — deve notificar atualização.
 * @param current - installed/current version
 * @param latest - remote latest
 */
export function shouldUpdate(current: string, latest: string): boolean {
  const c = cleanSemver(current);
  const l = cleanSemver(latest);
  if (!c || !l) return false;
  return compareSemver(c, l) === -1;
}

/**
 * EN: check if version is in blocked list.
 * PT-BR: verifica se versão está na lista bloqueada.
 */
export function isBlockedVersion(v: string): boolean {
  const cleaned = cleanSemver(v);
  if (!cleaned) return false;
  return (ANTIGRAVITY_BLOCKED_VERSIONS as readonly string[]).includes(cleaned);
}

/**
 * EN: true if version >= min supported.
 * PT-BR: verdadeiro se versão >= mínimo suportado.
 */
export function isSupportedVersion(v: string): boolean {
  const cleaned = cleanSemver(v);
  if (!cleaned) return false;
  if (isBlockedVersion(cleaned)) return false;
  return compareSemver(cleaned, ANTIGRAVITY_VERSION_MIN_SUPPORTED) >= 0;
}

// ---------------------------------------------------------------------------
// Payload parsing — heterogeneous JSON shapes from npm / GitHub / GCS
// ---------------------------------------------------------------------------

/**
 * EN: observer extracts version from unknown JSON shapes.
 * npm: { version: "1.19.2" }
 * GitHub: { tag_name: "v1.19.2", name: "v1.19.2" }
 * GCS: { version: "1.19.2" } or { latest: "1.19.2", latestVersion: "1.19.2" }
 * PT-BR: extrai versão de formatos heterogêneos.
 */
export function parseVersionFromPayload(payload: unknown): string | null {
  if (!payload || typeof payload !== "object") return null;
  const obj = payload as Record<string, unknown>;

  // direct candidates in priority order
  const candidates: unknown[] = [
    obj["version"],
    obj["latestVersion"],
    obj["latest"],
    obj["tag_name"],
    obj["name"],
    // nested: { data: { version } } some storages
    (obj["data"] as any)?.["version"],
    (obj["data"] as any)?.["latestVersion"],
  ];

  for (const cand of candidates) {
    if (typeof cand === "string") {
      const cleaned = cleanSemver(cand);
      if (cleaned) return cleaned;
    }
  }

  // fallback: stringify and regex first semver ever
  try {
    const asString = JSON.stringify(payload);
    const m = asString.match(SEMVER_EXTRACT_RE);
    if (m) {
      const cleaned = cleanSemver(m[1]);
      if (cleaned) return cleaned;
    }
  } catch {
    // ignore
  }
  return null;
}

// ---------------------------------------------------------------------------
// Fetch with timeout — only node:* + global fetch
// ---------------------------------------------------------------------------

async function fetchWithTimeout(
  url: string,
  timeoutMs: number,
  userAgent: string,
): Promise<Response> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": userAgent,
        // GitHub API needs explicit Accept for versioning but generic is fine
      },
    });
    return res;
  } finally {
    clearTimeout(t);
  }
}

// ---------------------------------------------------------------------------
// Local cache file read/write — atomic chmod 600
// ---------------------------------------------------------------------------

async function readLocalCacheFileAsync(cachePath: string): Promise<VersionCacheFile | null> {
  try {
    await fsp.access(cachePath, fs.constants.F_OK);
  } catch {
    return null;
  }
  try {
    const text = await fsp.readFile(cachePath, "utf8");
    if (!text.trim()) return null;
    const parsed = JSON.parse(text) as VersionCacheFile;
    const cleaned = cleanSemver(parsed?.version);
    if (!cleaned) return null;
    return {
      version: cleaned,
      fetchedAt: typeof parsed.fetchedAt === "number" ? parsed.fetchedAt : Date.now(),
      source: typeof parsed.source === "string" ? parsed.source : "file",
      expiresAt: typeof parsed.expiresAt === "number" ? parsed.expiresAt : Date.now() + VERSION_FILE_TTL_MS,
    };
  } catch {
    return null;
  }
}

function readLocalCacheFileSync(cachePath: string): VersionCacheFile | null {
  try {
    fs.accessSync(cachePath, fs.constants.F_OK);
  } catch {
    return null;
  }
  try {
    const text = fs.readFileSync(cachePath, "utf8");
    if (!text.trim()) return null;
    const parsed = JSON.parse(text) as VersionCacheFile;
    const cleaned = cleanSemver(parsed?.version);
    if (!cleaned) return null;
    return {
      version: cleaned,
      fetchedAt: typeof parsed.fetchedAt === "number" ? parsed.fetchedAt : Date.now(),
      source: typeof parsed.source === "string" ? parsed.source : "file",
      expiresAt: typeof parsed.expiresAt === "number" ? parsed.expiresAt : Date.now() + VERSION_FILE_TTL_MS,
    };
  } catch {
    return null;
  }
}

async function writeLocalCacheFileAtomic(cachePath: string, entry: VersionCacheFile): Promise<void> {
  const dir = path.dirname(cachePath);
  try {
    await fsp.mkdir(dir, { recursive: true, mode: DIR_MODE });
  } catch {
    // best effort
  }
  try {
    await fsp.chmod(dir, DIR_MODE);
  } catch {
    // ignore chmod failure on some FS
  }

  const content = JSON.stringify(entry, null, 2) + "\n";
  const rand = crypto.randomBytes(6).toString("hex");
  const tmp = path.join(dir, `.${path.basename(cachePath)}.${process.pid}.${rand}.tmp`);

  try {
    await fsp.writeFile(tmp, content, { encoding: "utf8", mode: FILE_MODE });
    try {
      await fsp.chmod(tmp, FILE_MODE);
    } catch {}
    await fsp.rename(tmp, cachePath);
    try {
      await fsp.chmod(cachePath, FILE_MODE);
    } catch {}
  } finally {
    try {
      await fsp.unlink(tmp);
    } catch {}
  }
}

function writeLocalCacheFileSync(cachePath: string, entry: VersionCacheFile): void {
  const dir = path.dirname(cachePath);
  try {
    fs.mkdirSync(dir, { recursive: true, mode: DIR_MODE });
  } catch {}
  try {
    fs.chmodSync(dir, DIR_MODE);
  } catch {}

  const content = JSON.stringify(entry, null, 2) + "\n";
  const rand = crypto.randomBytes(6).toString("hex");
  const tmp = path.join(dir, `.${path.basename(cachePath)}.${process.pid}.${rand}.tmp`);

  try {
    fs.writeFileSync(tmp, content, { encoding: "utf8", mode: FILE_MODE });
    try {
      fs.chmodSync(tmp, FILE_MODE);
    } catch {}
    fs.renameSync(tmp, cachePath);
    try {
      fs.chmodSync(cachePath, FILE_MODE);
    } catch {}
  } finally {
    try {
      fs.unlinkSync(tmp);
    } catch {}
  }
}

// ---------------------------------------------------------------------------
// Remote fetch — fetchLatestVersion (required)
// ---------------------------------------------------------------------------

/**
 * EN: observer attempts to fetch latest Antigravity version from remote chain.
 * Each URL has independent 5s timeout via AbortController.
 * Valid semver is cached in memory Map and persisted to local file.
 * PT-BR: tenta buscar versão mais recente na cadeia remota, cada URL com timeout 5s.
 *
 * Chain:
 *  1. https://registry.npmjs.org/antigravity/latest -> { version }
 *  2. https://api.github.com/repos/google/antigravity/releases/latest -> { tag_name: "v1.19.2" }
 *  3. https://storage.googleapis.com/antigravity-version/version.json -> { version | latest }
 *
 * @param opts - optional overrides
 * @returns latest version string or null if all remote fail
 */
export async function fetchLatestVersion(opts: FetchOptions = {}): Promise<string | null> {
  const timeoutMs = opts.timeoutMs ?? VERSION_FETCH_TIMEOUT_MS;
  const remoteUrls = opts.remoteUrls ?? ANTIGRAVITY_VERSION_REMOTE_URLS;
  const cachePath = resolveCachePath(opts.cachePath);
  const userAgent = opts.userAgent ?? `antigravity/${ANTIGRAVITY_VERSION_FALLBACK}`;

  // memory fast path unless forced
  if (!opts.force) {
    const mem = versionMemoryCache.get("latest");
    if (mem && Date.now() - mem.fetchedAt < VERSION_MEMORY_TTL_MS) {
      const cleaned = cleanSemver(mem.version);
      if (cleaned && isSupportedVersion(cleaned)) return cleaned;
    }
  }

  for (const url of remoteUrls) {
    try {
      const res = await fetchWithTimeout(url, timeoutMs, userAgent);
      if (!res.ok) continue;

      let payload: unknown;
      const ct = res.headers.get("content-type") ?? "";
      if (ct.includes("application/json") || ct.includes("text/json")) {
        try {
          payload = await res.json();
        } catch {
          // try text fallback
          const txt = await res.text();
          try {
            payload = JSON.parse(txt);
          } catch {
            payload = { version: txt.trim() };
          }
        }
      } else {
        // some GCS buckets serve text/plain version
        const txt = await res.text();
        const trimmed = txt.trim();
        // try JSON first, then raw version
        try {
          payload = JSON.parse(trimmed);
        } catch {
          payload = { version: trimmed };
        }
      }

      const parsedVersion = parseVersionFromPayload(payload);
      if (!parsedVersion) continue;
      if (!isValidSemver(parsedVersion)) continue;
      if (isBlockedVersion(parsedVersion)) continue;

      // success — cache
      const entry: CacheEntry = {
        version: parsedVersion,
        fetchedAt: Date.now(),
        source: url,
      };
      versionMemoryCache.set("latest", entry);

      const fileEntry: VersionCacheFile = {
        version: parsedVersion,
        fetchedAt: entry.fetchedAt,
        source: url,
        expiresAt: Date.now() + VERSION_FILE_TTL_MS,
      };
      // fire-and-forget file persistence, observer never throws on cache write
      try {
        await writeLocalCacheFileAtomic(cachePath, fileEntry);
      } catch {
        // swallow — memory cache already saved
      }

      return parsedVersion;
    } catch {
      // per-url failure swallowed — try next URL in chain
      continue;
    }
  }

  return null;
}

// ---------------------------------------------------------------------------
// Main public API — getVersion (required) implements full chain 1->2->3
// ---------------------------------------------------------------------------

/**
 * EN: full resolution chain replicating Antigravity Manager:
 *  1. Memory Cache (6h TTL) -> 2. Remote APIs (npm, GitHub, GCS) -> 3. Local file cache -> 4. Fallback 1.19.2
 * The observer never throws — always returns a valid semver.
 * PT-BR: cadeia completa 1 remoto, 2 cache local, 3 fallback 1.19.2 — nunca lança, sempre retorna semver válido.
 *
 * @param opts - optional overrides
 * @returns resolved semver guaranteed
 */
export async function getVersion(opts: GetVersionOptions = {}): Promise<string> {
  const cachePath = resolveCachePath(opts.cachePath);
  const allowStale = opts.allowStale ?? true;

  // 0) memory cache fast path
  if (!opts.force) {
    const mem = versionMemoryCache.get("latest");
    if (mem) {
      const cleaned = cleanSemver(mem.version);
      if (cleaned && Date.now() - mem.fetchedAt < VERSION_MEMORY_TTL_MS && isSupportedVersion(cleaned)) {
        return cleaned;
      }
    }
  }

  // 1) remote chain
  try {
    const remote = await fetchLatestVersion(opts);
    if (remote) {
      const cleaned = cleanSemver(remote);
      if (cleaned && isSupportedVersion(cleaned)) return cleaned;
    }
  } catch {
    // observer swallows, falls through to cache
  }

  // 2) local cache file — allows stale if configured
  try {
    const fileCache = await readLocalCacheFileAsync(cachePath);
    if (fileCache) {
      const isFresh = Date.now() < fileCache.expiresAt;
      if (isFresh || allowStale) {
        const cleaned = cleanSemver(fileCache.version);
        if (cleaned && isSupportedVersion(cleaned)) {
          // promote to memory
          versionMemoryCache.set("latest", {
            version: cleaned,
            fetchedAt: fileCache.fetchedAt,
            source: fileCache.source,
          });
          return cleaned;
        }
      }
    }
  } catch {
    // swallow
  }

  // 3) fallback — guaranteed safe
  const fallback = ANTIGRAVITY_VERSION_FALLBACK;
  versionMemoryCache.set("latest", {
    version: fallback,
    fetchedAt: Date.now(),
    source: "fallback",
  });
  return fallback;
}

/**
 * EN: synchronous variant for startup contexts where async not convenient.
 * Reads memory -> file cache -> fallback, never does remote network.
 * PT-BR: variante síncrona que lê memória, arquivo local e fallback, sem rede.
 *
 * @param opts - cache path override only
 * @returns resolved semver
 */
export function getVersionSync(opts: { cachePath?: string; allowStale?: boolean } = {}): string {
  const cachePath = resolveCachePath(opts.cachePath);
  const allowStale = opts.allowStale ?? true;

  const mem = versionMemoryCache.get("latest");
  if (mem) {
    const cleaned = cleanSemver(mem.version);
    if (cleaned && Date.now() - mem.fetchedAt < VERSION_MEMORY_TTL_MS && isSupportedVersion(cleaned)) {
      return cleaned;
    }
  }

  const fileCache = readLocalCacheFileSync(cachePath);
  if (fileCache) {
    const isFresh = Date.now() < fileCache.expiresAt;
    if (isFresh || allowStale) {
      const cleaned = cleanSemver(fileCache.version);
      if (cleaned && isSupportedVersion(cleaned)) {
        versionMemoryCache.set("latest", {
          version: cleaned,
          fetchedAt: fileCache.fetchedAt,
          source: fileCache.source,
        });
        return cleaned;
      }
    }
  }

  return ANTIGRAVITY_VERSION_FALLBACK;
}

/**
 * EN: clears both memory and file cache — useful for tests or forced refresh.
 * PT-BR: limpa memória e arquivo de cache — útil para testes ou refresh forçado.
 * @param opts - optional cache path
 */
export async function clearVersionCache(opts: { cachePath?: string } = {}): Promise<void> {
  versionMemoryCache.delete("latest");
  const cachePath = resolveCachePath(opts.cachePath);
  try {
    await fsp.unlink(cachePath);
  } catch {
    // ignore missing
  }
}

export function clearVersionCacheSync(opts: { cachePath?: string } = {}): void {
  versionMemoryCache.delete("latest");
  const cachePath = resolveCachePath(opts.cachePath);
  try {
    fs.unlinkSync(cachePath);
  } catch {}
}

// ---------------------------------------------------------------------------
// Helpers for User-Agent integration — keeps UA coherent with resolved version
// ---------------------------------------------------------------------------

/**
 * EN: returns User-Agent string for a given version, e.g. "antigravity/1.19.2 darwin/arm64"
 * Observer mirrors what Antigravity binary sends; platform/arch coherent per host.
 * PT-BR: retorna User-Agent para versão dada.
 * @param version - semver, falls back to 1.19.2 if invalid
 */
export function getAntigravityUserAgent(version?: string): string {
  const ver = cleanSemver(version ?? "") ?? ANTIGRAVITY_VERSION_FALLBACK;
  // lazy import os to avoid top-level side effect, but node:os already imported
  // we reuse same normalization as constants.ts to stay deterministic
  const plat = (() => {
    const p = os.platform();
    if (p === "darwin" || p === "win32" || p === "linux") return p;
    return p;
  })();
  const arch = (() => {
    const a = os.arch();
    if (a === "arm64" || a === "x64" || a === "ia32") return a;
    return a;
  })();
  return `antigravity/${ver} ${plat}/${arch}`;
}

/**
 * EN: async User-Agent that ensures latest version before building string.
 * PT-BR: User-Agent assíncrono que resolve versão mais recente antes.
 * @param cachedVersion - optional pre-resolved version to avoid network
 * @param opts - fetch options
 */
export async function getDynamicUserAgentVersioned(
  cachedVersion?: string,
  opts: FetchOptions = {},
): Promise<string> {
  const ver = cachedVersion && isValidSemver(cachedVersion) ? cachedVersion : await getVersion(opts);
  return getAntigravityUserAgent(ver);
}

// ---------------------------------------------------------------------------
// Barrel exports — library-first
// ---------------------------------------------------------------------------

export const Version = {
  fallback: ANTIGRAVITY_VERSION_FALLBACK,
  minSupported: ANTIGRAVITY_VERSION_MIN_SUPPORTED,
  blocked: ANTIGRAVITY_BLOCKED_VERSIONS,
  remoteUrls: ANTIGRAVITY_VERSION_REMOTE_URLS,
  timeoutMs: VERSION_FETCH_TIMEOUT_MS,
  memoryTtlMs: VERSION_MEMORY_TTL_MS,
  fileTtlMs: VERSION_FILE_TTL_MS,
  memoryCache: versionMemoryCache,
  isValidSemver,
  cleanSemver,
  compareSemver,
  shouldUpdate,
  isBlockedVersion,
  isSupportedVersion,
  parseVersionFromPayload,
  fetchLatestVersion,
  getVersion,
  getVersionSync,
  clearVersionCache,
  clearVersionCacheSync,
  getAntigravityUserAgent,
  getDynamicUserAgentVersioned,
} as const;

export default Version;
