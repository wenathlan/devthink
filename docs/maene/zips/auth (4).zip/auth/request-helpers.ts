/**
 * @file request-helpers.ts
 * @module opencode-antigravity-auth-next/request-helpers
 * @description
 *  Third-person observer helpers for the request pipeline.
 *  The observer watches Antigravity Manager traffic and reproduces its
 *  transformations without running Antigravity itself.
 *
 *  Responsibilities:
 *  - Clean tool schemas (remove unknown "parameters" etc causing Invalid JSON payload)
 *  - Detect gemini-cli-only models (must skip sandbox, issue #233)
 *  - Normalize OpenCode / OpenAI / Anthropic messages → Gemini roles system/user/model
 *  - Filter thinking blocks (thought:true) that break tool_use ordering
 *  - Deterministic FNV-1a session_id / user_prompt_id
 *  - Map thinkingLevel → thinkingBudget (minimal 1024 low 8192 medium 16384 high 32768 max 64000)
 *  - Extract model variants (preview, thinking-low/max, customtools)
 *  - Validate / sanitize tool names (must start letter/underscore, alphanum+_)
 *
 *  Governance:
 *  - Date: 25/08/2026 — Canto do Buriti, PI, BR.
 *  - Runtime: only node:* builtins + global fetch (Node >=18).
 *  - Architecture: library-first, root-first (no src/ nested), no localhost v1 proxy,
 *    direct cloudcode-pa.googleapis.com cascade.
 *  - Observer pattern: pure functions, no global mutation, deterministic when seed given.
 *  - Style: lower_snake for internal? No — camelCase public API, English JSDoc, third-person.
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * Thinking level supported by 2026 models.
 * Observer notes AM sends minimal/low/medium/high, max is for claude max variant.
 */
export type ThinkingLevel = "minimal" | "low" | "medium" | "high" | "max";

/**
 * Gemini part — minimal subset needed for normalization.
 */
export interface GeminiPart {
  text?: string;
  thought?: boolean;
  thinking?: boolean;
  functionCall?: {
    name: string;
    args?: Record<string, unknown>;
  };
  functionResponse?: {
    name: string;
    response: Record<string, unknown>;
  };
  inlineData?: {
    mimeType: string;
    data: string;
  };
  // open extension bag for observer to filter
  type?: string;
  [k: string]: unknown;
}

/**
 * Gemini message — system/user/model.
 */
export interface GeminiMessage {
  role: "system" | "user" | "model";
  parts: GeminiPart[];
  /** raw role before normalization, for debug */
  _rawRole?: string;
}

/**
 * Generic OpenCode / OpenAI / Anthropic incoming message.
 */
export interface IncomingMessage {
  role: string;
  content?: string | unknown[] | Record<string, unknown> | null;
  name?: string;
  tool_calls?: Array<{
    id?: string;
    type?: string;
    function?: { name: string; arguments?: string | Record<string, unknown> };
  }>;
  tool_call_id?: string;
  // anthropic variants
  tool_use_id?: string;
  [k: string]: unknown;
}

/**
 * Cleaned tool definition compatible with Gemini functionDeclarations.
 */
export interface CleanedTool {
  name: string;
  description?: string;
  parameters: {
    type: "object";
    properties: Record<string, unknown>;
    required?: string[];
    description?: string;
  };
}

/**
 * Model variant extraction result.
 */
export interface ModelVariantInfo {
  /** Original id as received */
  original: string;
  /** Normalized lower id */
  normalized: string;
  /** Base id without preview/thinking/customtools/low/max prefixes */
  base: string;
  /** Family detector */
  family: "gemini" | "claude" | "unknown";
  /** True if preview (gemini-3-*-preview) — must use prod endpoint only */
  isPreview: boolean;
  /** True if thinking model */
  isThinking: boolean;
  /** thinking-low / thinking-max variant */
  thinkingVariant: "low" | "max" | null;
  /** customtools suffix */
  isCustomTools: boolean;
  /** Claude flag */
  isClaude: boolean;
  /** Gemini flag */
  isGemini: boolean;
  /** antigravity- wrapper prefix */
  isAntigravityWrapper: boolean;
  /** Suggested thinking budget from variant */
  budgetHint?: number;
  /** Quota group for routing */
  group: "antigravity" | "gemini-cli";
}

// ---------------------------------------------------------------------------
// Constants — bypass & production
// ---------------------------------------------------------------------------

/**
 * Thinking budget map per spec. Observer measured in AM 2026 traffic:
 * minimal 1024 low 8192 medium 16384 high 32768 max 64000.
 */
export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = {
  minimal: 1024,
  low: 8192,
  medium: 16384,
  high: 32768,
  max: 64000,
} as const;

export const THINKING_LEVELS = ["minimal", "low", "medium", "high", "max"] as const;

export const THINKING_BUDGET_MIN = 1024 as const;
export const THINKING_BUDGET_MAX = 64000 as const;
export const THINKING_BUDGET_MAX_GEMINI = 32768 as const;
export const THINKING_BUDGET_MAX_CLAUDE = 64000 as const;

/**
 * FNV-1a 32-bit constants — used for deterministic session_id / user_prompt_id.
 * Same values as in fingerprint.ts and constants.ts for coherence.
 */
export const FNV_OFFSET_BASIS = 2_166_136_261 as const;
export const FNV_PRIME = 16_777_619 as const;

/**
 * Tool name validation: must start with letter or underscore, then alnum + _.
 * Error observed: Invalid function name must start with letter — fix via sanitize.
 */
export const TOOL_NAME_REGEX = /^[a-zA-Z_][a-zA-Z0-9_]*$/;
export const TOOL_NAME_MAX_LENGTH = 64 as const;
export const TOOL_NAME_MIN_LENGTH = 1 as const;
export const MAX_TOOLS_PER_REQUEST = 128 as const;

/**
 * Allowed JSON Schema keys for Gemini functionDeclarations.parameters.
 * Removes unknown names like "$schema", "title", "additionalProperties" deep inside.
 * This fixes "Invalid JSON payload Unknown name 'parameters' at 'tools[0].function_declarations[0].parameters.properties...".
 */
export const ALLOWED_SCHEMA_KEYS = [
  "type",
  "properties",
  "required",
  "description",
  "enum",
  "items",
] as const;

export const ALLOWED_TOOL_TOP_KEYS = ["name", "description", "parameters"] as const;

/**
 * Direct cloudcode-pa endpoints — bypasses localhost v1 proxy completely.
 * Observer enforces prod-first for preview / gemini-3+ models.
 */
export const DIRECT_ENDPOINT = "https://cloudcode-pa.googleapis.com" as const;
export const DAILY_ENDPOINT = "https://daily-cloudcode-pa.googleapis.com" as const;
export const AUTOPUSH_ENDPOINT = "https://autopush-cloudcode-pa.sandbox.googleapis.com" as const;

export const ENDPOINT_CASCADE = [
  DAILY_ENDPOINT,
  AUTOPUSH_ENDPOINT,
  DIRECT_ENDPOINT,
] as const;

/**
 * Headers that must be stripped to avoid 403 IAM (pi-mono #1830).
 * AM never sends these on content requests.
 */
export const HEADERS_TO_STRIP = [
  "x-goog-user-project",
  "X-Goog-QuotaUser",
  "X-Client-Device-Id",
  "X-Goog-Request-Reason",
] as const;

/**
 * Gemini-cli-only models detection — must skip sandbox (issue #233).
 * Observer list generated from constants.ts ANTIGRAVITY_MODELS_2026 where group === gemini-cli.
 */
export const GEMINI_CLI_ONLY_EXACT = [
  "gemini-3-flash-preview",
  "gemini-3-pro-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-3.1-pro",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3.1-pro",
] as const;

/**
 * Bypass marker constants — library-first.
 */
export const BYPASS_CONSTANTS = {
  directEndpoint: DIRECT_ENDPOINT,
  dailyEndpoint: DAILY_ENDPOINT,
  sandboxEndpoint: AUTOPUSH_ENDPOINT,
  endpointCascade: ENDPOINT_CASCADE,
  headersToStrip: HEADERS_TO_STRIP,
  toolNamePattern: TOOL_NAME_REGEX.source,
  maxToolNameLength: TOOL_NAME_MAX_LENGTH,
  maxToolsPerRequest: MAX_TOOLS_PER_REQUEST,
  thinkingBudgetMap: THINKING_BUDGET_MAP,
  fnvOffsetBasis: FNV_OFFSET_BASIS,
  fnvPrime: FNV_PRIME,
} as const;

// ---------------------------------------------------------------------------
// Error handling
// ---------------------------------------------------------------------------

/**
 * Domain error for request-helpers. Observer throws this instead of generic Error
 * to allow caller to distinguish cleaning/normalization failures from transport.
 */
export class RequestHelpersError extends Error {
  public readonly code: string;
  public readonly cause?: unknown;

  constructor(message: string, code = "REQUEST_HELPERS_ERROR", cause?: unknown) {
    super(message);
    this.name = "RequestHelpersError";
    this.code = code;
    if (cause) this.cause = cause;
    // maintain proper prototype chain for instanceof
    Object.setPrototypeOf(this, RequestHelpersError.prototype);
  }
}

// ---------------------------------------------------------------------------
// FNV-1a deterministic hash & IDs
// ---------------------------------------------------------------------------

/**
 * Computes FNV-1a 32-bit hash — deterministic, fast, no external dep.
 * Third-person: same impl as fingerprint.ts for coherence.
 *
 * @param input - string to hash
 * @returns unsigned 32-bit integer
 * @throws {RequestHelpersError} if input not string
 */
export function fnv1a32(input: string): number {
  if (typeof input !== "string") {
    throw new RequestHelpersError(`fnv1a32 expects string, got ${typeof input}`, "INVALID_INPUT");
  }
  let hash = FNV_OFFSET_BASIS;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    // Math.imul handles 32-bit multiplication with overflow semantics
    hash = Math.imul(hash, FNV_PRIME);
  }
  return hash >>> 0;
}

/**
 * Returns hex string padded to 8 chars for given input.
 *
 * @param input - seed string
 * @returns 8-char hex
 */
export function fnv1aHex(input: string): string {
  const h = fnv1a32(input);
  return h.toString(16).padStart(8, "0");
}

/**
 * Returns 16-char hex using two rounds (high/low) for longer IDs.
 * Observer uses this for session_id when longer entropy needed.
 *
 * @param input - seed
 * @returns 16-char hex
 */
export function fnv1aHex16(input: string): string {
  // two independent hashes with different seeds to avoid collision extension
  const low = fnv1a32(input);
  const high = fnv1a32(`__high__:${input}`);
  return `${high.toString(16).padStart(8, "0")}${low.toString(16).padStart(8, "0")}`;
}

/**
 * Generates deterministic ID from seed + prefix.
 *
 * @param seed - arbitrary string seed (prompt, conversation id, etc)
 * @param prefix - prefix like "sess", "up", "session", "user_prompt"
 * @returns deterministic id string
 */
export function generateDeterministicId(seed: string, prefix = "id"): string {
  if (!seed || typeof seed !== "string") {
    // fallback to time-based but still deterministic-ish per call? observer uses default seed
    seed = `default-${Date.now()}`;
  }
  const hex = fnv1aHex16(seed);
  const cleanPrefix = prefix.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 20) || "id";
  return `${cleanPrefix}_${hex}`;
}

/**
 * Generates deterministic session_id — FNV-1a over prompt+context.
 * Matches FingerprintGenerator.generateSessionId behavior.
 *
 * @param seed - typically concatenation of user prompt + conversation context or timestamp when stable
 * @returns session_id like sess_abc123...
 */
export function generateSessionId(seed: string): string {
  if (typeof seed !== "string" || seed.length === 0) {
    throw new RequestHelpersError("generateSessionId requires non-empty string seed", "INVALID_SEED");
  }
  return generateDeterministicId(seed, "sess");
}

/**
 * Generates deterministic user_prompt_id — FNV-1a over user prompt.
 *
 * @param seed - user prompt text or prompt hash source
 * @returns user_prompt_id like up_abc123...
 */
export function generateUserPromptId(seed: string): string {
  if (typeof seed !== "string" || seed.length === 0) {
    throw new RequestHelpersError("generateUserPromptId requires non-empty string seed", "INVALID_SEED");
  }
  return generateDeterministicId(seed, "up");
}

/**
 * Generic helper used by fingerprint.ts compat: fnv1aHash alias.
 */
export const fnv1aHash = fnv1a32;

// ---------------------------------------------------------------------------
// Thinking level → budget
// ---------------------------------------------------------------------------

/**
 * Parses free-form input into ThinkingLevel.
 *
 * @param input - string like "minimal", "low", "MEDIUM", "high", "max", or "8192"
 * @returns level or undefined if not parseable as named level
 */
export function parseThinkingLevel(input: unknown): ThinkingLevel | undefined {
  if (typeof input !== "string") return undefined;
  const l = input.trim().toLowerCase();
  if ((THINKING_LEVELS as readonly string[]).includes(l)) {
    return l as ThinkingLevel;
  }
  // also allow "none" → minimal mapping for compat
  if (l === "none" || l === "off") return "minimal";
  return undefined;
}

/**
 * Maps thinking level string (or numeric budget string) → budget number.
 * Spec: minimal 1024 low 8192 medium 16384 high 32768 max 64000.
 *
 * @param level - ThinkingLevel string or numeric string / number
 * @returns budget in range [1024,64000]
 * @throws {RequestHelpersError} when invalid and no fallback allowed
 */
export function mapThinkingLevelToBudget(level: string | number): number {
  if (typeof level === "number") {
    if (!Number.isFinite(level)) {
      throw new RequestHelpersError(`thinking budget number not finite: ${level}`, "INVALID_THINKING_BUDGET");
    }
    const clamped = Math.max(THINKING_BUDGET_MIN, Math.min(THINKING_BUDGET_MAX, Math.floor(level)));
    return clamped;
  }

  if (typeof level !== "string") {
    throw new RequestHelpersError(`thinking level must be string|number, got ${typeof level}`, "INVALID_THINKING_LEVEL");
  }

  const trimmed = level.trim().toLowerCase();

  // numeric string like "8192" → direct budget
  const asNum = Number(trimmed);
  if (trimmed !== "" && Number.isFinite(asNum) && /^\d+$/.test(trimmed)) {
    return Math.max(THINKING_BUDGET_MIN, Math.min(THINKING_BUDGET_MAX, Math.floor(asNum)));
  }

  const parsed = parseThinkingLevel(trimmed);
  if (parsed && parsed in THINKING_BUDGET_MAP) {
    return THINKING_BUDGET_MAP[parsed];
  }

  // unknown named level → throw in strict mode; but for production robustness return medium
  // observer logs warning and returns medium to avoid breaking request
  // To allow strict validation, caller can check parseThinkingLevel first.
  // Here we implement fallback with error code.
  if (trimmed === "") {
    throw new RequestHelpersError("empty thinking level", "INVALID_THINKING_LEVEL");
  }

  // fallback: return medium (16384) — observer chooses safe default
  // but still throws optional? We return medium.
  return THINKING_BUDGET_MAP.medium;
}

/**
 * Alias required by spec: thinkingLevel→thinkingBudget.
 */
export const thinkingLevelToBudget = mapThinkingLevelToBudget;

/**
 * Returns budget for variant suffix: low→8192 max→64000 etc.
 * Used by extractModelVariant.
 *
 * @param variant - "low" | "max" | null
 * @returns budget hint
 */
export function getThinkingBudgetForVariant(variant: "low" | "max" | null): number {
  if (variant === "low") return THINKING_BUDGET_MAP.low;
  if (variant === "max") return THINKING_BUDGET_MAP.max;
  return THINKING_BUDGET_MAP.medium;
}

// ---------------------------------------------------------------------------
// Model detection — isGeminiCLIOnlyModel + variant extraction
// ---------------------------------------------------------------------------

/**
 * Detects whether model id is gemini-cli-only and must skip sandbox endpoints.
 * Mirrors constant.ts isGeminiCLIOnlyModel but self-contained (no cross-import to keep node:* only).
 *
 * Detection rules observed from RESEARCH.md and issue #233:
 * - any id containing "preview" is cli-only (2026 policy)
 * - gemini-3* and antigravity-gemini-3* are prod-only per 2026 policy
 * - known exact list GEMINI_CLI_ONLY_EXACT
 * - group detection via substring "gemini-3"
 *
 * @param modelId - model id like "gemini-3-flash-preview" or "antigravity-gemini-3-flash"
 * @returns true if model must use direct prod endpoint only
 */
export function isGeminiCLIOnlyModel(modelId: string): boolean {
  if (typeof modelId !== "string" || modelId.trim() === "") {
    return false;
  }
  const lower = modelId.trim().toLowerCase();
  // exact list
  if ((GEMINI_CLI_ONLY_EXACT as readonly string[]).includes(lower)) return true;
  // preview substring — strongest signal
  if (lower.includes("preview")) return true;
  // 2026 policy: gemini-3+ only prod (daily or prod), not sandbox
  if (lower.startsWith("gemini-3") || lower.includes("antigravity-gemini-3")) return true;
  // customtools only exists on preview family
  if (lower.includes("customtools")) return true;
  return false;
}

/**
 * Extracts variant info from model id.
 * Third-person: observer parses traffic to infer routing and budget.
 *
 * @param modelId - raw model id
 * @returns detailed variant info
 * @throws {RequestHelpersError} if empty
 */
export function extractModelVariant(modelId: string): ModelVariantInfo {
  if (typeof modelId !== "string" || modelId.trim() === "") {
    throw new RequestHelpersError("extractModelVariant requires non-empty modelId", "INVALID_MODEL");
  }
  const original = modelId.trim();
  const normalized = original.toLowerCase();

  const isPreview = normalized.includes("preview");
  const isThinking = normalized.includes("thinking");
  const isCustomTools = normalized.includes("customtools");
  const isClaude = normalized.includes("claude");
  const isGemini = normalized.includes("gemini");
  const isAntigravityWrapper = normalized.startsWith("antigravity-");

  let thinkingVariant: "low" | "max" | null = null;
  if (normalized.includes("-low") || normalized.endsWith("low")) {
    // ensure it is thinking-low or standalone low for claude
    if (normalized.includes("thinking-low") || normalized.match(/-low$/)) {
      thinkingVariant = "low";
    }
  }
  if (normalized.includes("-max") || normalized.endsWith("max")) {
    if (normalized.includes("thinking-max") || normalized.match(/-max$/)) {
      thinkingVariant = "max";
    }
  }
  // prioritize max over low if both appear (should not)
  if (normalized.includes("max") && thinkingVariant !== "low") {
    if (isThinking) thinkingVariant = normalized.includes("max") ? "max" : thinkingVariant;
  }

  // family
  let family: ModelVariantInfo["family"] = "unknown";
  if (isClaude) family = "claude";
  else if (isGemini) family = "gemini";

  // base stripping
  let base = normalized;
  base = base.replace(/^antigravity-/, "");
  base = base.replace(/-preview/g, "");
  base = base.replace(/-customtools/g, "");
  base = base.replace(/-thinking-max/g, "");
  base = base.replace(/-thinking-low/g, "");
  base = base.replace(/-thinking/g, "");
  // remove trailing -low/-max that are variant markers (only if claude)
  if (isClaude) {
    base = base.replace(/-low$/g, "");
    base = base.replace(/-max$/g, "");
  }
  // collapse double dashes
  base = base.replace(/--+/g, "-").replace(/^-|-$/g, "");

  const group: ModelVariantInfo["group"] = isGeminiCLIOnlyModel(original) ? "gemini-cli" : "antigravity";

  const budgetHint = isThinking
    ? getThinkingBudgetForVariant(thinkingVariant)
    : isGemini
      ? THINKING_BUDGET_MAP.medium
      : undefined;

  return {
    original,
    normalized,
    base,
    family,
    isPreview,
    isThinking,
    thinkingVariant,
    isCustomTools,
    isClaude,
    isGemini,
    isAntigravityWrapper,
    budgetHint,
    group,
  };
}

/**
 * Alias per checklist naming.
 */
export const parseModelVariant = extractModelVariant;

// ---------------------------------------------------------------------------
// Tool name validation & sanitization
// ---------------------------------------------------------------------------

/**
 * Validates tool name against Gemini requirement:
 * must start with letter or underscore, only alphanum + _ , 1..64 chars.
 *
 * @param name - tool name to validate
 * @returns true if valid
 */
export function validateToolName(name: unknown): boolean {
  if (typeof name !== "string") return false;
  const t = name.trim();
  if (t.length < TOOL_NAME_MIN_LENGTH || t.length > TOOL_NAME_MAX_LENGTH) return false;
  return TOOL_NAME_REGEX.test(t);
}

/**
 * Sanitizes tool name to satisfy Gemini regex.
 * Replaces invalid chars with _, ensures leading letter/underscore,
 * truncates to 64, handles empty.
 *
 * Observer notes fixing "Invalid function name must start with letter"
 * and "must only contain..." errors seen in OpenAI→Gemini bridge.
 *
 * @param raw - raw name (maybe "123-foo.bar" or "my-tool!")
 * @returns sanitized name matching TOOL_NAME_REGEX
 * @throws {RequestHelpersError} if unable to sanitize (should not happen)
 */
export function sanitizeToolName(raw: unknown): string {
  if (typeof raw !== "string") {
    throw new RequestHelpersError(`sanitizeToolName expects string, got ${typeof raw}`, "INVALID_TOOL_NAME");
  }
  let name = raw.trim();

  if (name === "") {
    return "_tool";
  }

  // replace any char not allowed [a-zA-Z0-9_] with _
  name = name.replace(/[^a-zA-Z0-9_]/g, "_");

  // collapse multiple underscores for readability
  name = name.replace(/_+/g, "_");

  // ensure starts with letter or underscore
  if (/^[0-9]/.test(name)) {
    name = `_${name}`;
  }
  if (!/^[a-zA-Z_]/.test(name)) {
    // if still starts with invalid (e.g., after replacement), prefix
    name = `tool_${name}`;
  }

  // truncate to max length, preserve start (more meaningful)
  if (name.length > TOOL_NAME_MAX_LENGTH) {
    name = name.slice(0, TOOL_NAME_MAX_LENGTH);
    // remove trailing underscore after cut
    name = name.replace(/_+$/g, "");
    if (name === "") name = "_tool";
  }

  // final validation — if still invalid, fallback
  if (!TOOL_NAME_REGEX.test(name)) {
    // last resort: hashed fallback deterministic from original raw
    const hash = fnv1aHex(raw);
    const fallback = `tool_${hash}`;
    if (TOOL_NAME_REGEX.test(fallback)) return fallback;
    throw new RequestHelpersError(`Unable to sanitize tool name: ${raw}`, "SANITIZE_FAILED");
  }

  return name;
}

// ---------------------------------------------------------------------------
// JSON Schema cleaning — removes unknown parameters
// ---------------------------------------------------------------------------

/**
 * Type guard for plain object.
 */
function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v) && Object.prototype.toString.call(v) === "[object Object]";
}

/**
 * Recursively cleans a JSON Schema node to only allowed keys.
 * Removes "$schema", "$ref", "title", "additionalProperties", "default", "examples", etc.
 * Keeps structure for properties and items.
 *
 * @param schema - raw schema node
 * @param depth - recursion depth guard
 * @returns cleaned schema or undefined if not salvageable
 */
export function cleanJsonSchema(schema: unknown, depth = 0): Record<string, unknown> | undefined {
  if (depth > 12) {
    throw new RequestHelpersError("JSON schema depth >12 — possible circular", "SCHEMA_TOO_DEEP");
  }
  if (!isPlainObject(schema)) {
    // primitive or array not expected as schema node — return undefined to signal skip
    return undefined;
  }

  const out: Record<string, unknown> = {};

  for (const key of Object.keys(schema)) {
    if (!(ALLOWED_SCHEMA_KEYS as readonly string[]).includes(key)) {
      // skip unknown key — this is the core fix for "Unknown name 'parameters'"
      continue;
    }

    const val = (schema as Record<string, unknown>)[key];

    switch (key) {
      case "type": {
        if (typeof val === "string" && ["object", "string", "number", "integer", "boolean", "array"].includes(val)) {
          out.type = val;
        }
        // allow type array? Gemini tolerates string only — skip if not string
        break;
      }
      case "description": {
        if (typeof val === "string") out.description = val.slice(0, 1024);
        break;
      }
      case "enum": {
        if (Array.isArray(val)) {
          // filter to primitives, cap 100 entries
          const filtered = val.filter((e) => typeof e === "string" || typeof e === "number" || typeof e === "boolean").slice(0, 100);
          if (filtered.length > 0) out.enum = filtered;
        }
        break;
      }
      case "required": {
        if (Array.isArray(val)) {
          const req = val.filter((r) => typeof r === "string").slice(0, 100);
          if (req.length > 0) out.required = req;
        }
        break;
      }
      case "properties": {
        if (isPlainObject(val)) {
          const props: Record<string, unknown> = {};
          for (const propName of Object.keys(val)) {
            // sanitize prop name? keep as is but skip if invalid? Keep original key but value cleaned
            // prop name itself is not tool name, so allow broader? Still ensure string
            const propSchema = (val as Record<string, unknown>)[propName];
            const cleaned = cleanJsonSchema(propSchema, depth + 1);
            if (cleaned) {
              props[propName] = cleaned;
            }
          }
          out.properties = props;
        }
        break;
      }
      case "items": {
        const cleaned = cleanJsonSchema(val, depth + 1);
        if (cleaned) out.items = cleaned;
        break;
      }
      default:
        // should not reach because we filter by allowed keys
        break;
    }
  }

  // ensure at least type exists; default to object for root, string for leaf? observer defaults root to object
  if (!out.type) {
    // if has properties, default to object; else string? we keep undefined to avoid forcing but for parameters root we enforce object later
  }

  return out;
}

/**
 * Cleans a tool schema (OpenAI / Anthropic / Gemini style) removing unknown fields.
 * Handles wrappers like { function: { name, parameters } } and { input_schema }.
 *
 * @param raw - raw tool definition
 * @returns cleaned tool with sanitized name and safe parameters
 * @throws {RequestHelpersError} if unrecoverable
 */
export function cleanToolSchema(raw: unknown): CleanedTool {
  if (!isPlainObject(raw) && !(raw as any)?.function) {
    throw new RequestHelpersError(`cleanToolSchema expects object, got ${typeof raw}`, "INVALID_TOOL_SCHEMA");
  }

  // unwrap OpenAI style { type:"function", function:{...} }
  let src: Record<string, unknown> = raw as Record<string, unknown>;
  if (isPlainObject((src as any).function)) {
    src = (src as any).function as Record<string, unknown>;
  }

  // Anthropic uses input_schema
  const potentialSchemas = [
    (src as any).parameters,
    (src as any).input_schema,
    (src as any).schema,
    (src as any).parameters_json,
  ];

  let parametersRaw: unknown = undefined;
  for (const cand of potentialSchemas) {
    if (cand && isPlainObject(cand)) {
      parametersRaw = cand;
      break;
    }
  }

  // If no parameters at all, create empty object schema
  if (!parametersRaw) {
    parametersRaw = { type: "object", properties: {} };
  }

  const cleanedParams = cleanJsonSchema(parametersRaw, 0) ?? { type: "object", properties: {} };

  // enforce root type object as required by Gemini functionDeclarations
  if ((cleanedParams as any).type !== "object") {
    (cleanedParams as any).type = "object";
  }
  if (!(cleanedParams as any).properties) {
    (cleanedParams as any).properties = {};
  }

  // name extraction & sanitization
  const rawName = (src as any).name;
  if (typeof rawName !== "string" || rawName.trim() === "") {
    throw new RequestHelpersError("tool schema missing name", "INVALID_TOOL_NAME");
  }
  const sanitized = sanitizeToolName(rawName);

  const descriptionRaw = (src as any).description;
  const description = typeof descriptionRaw === "string" ? descriptionRaw.slice(0, 4096) : undefined;

  // final validation: tool count sanity etc not here

  return {
    name: sanitized,
    description,
    parameters: cleanedParams as CleanedTool["parameters"],
  };
}

/**
 * Cleans an array of tool schemas — production helper for request.ts.
 *
 * @param tools - array of raw tools
 * @returns cleaned array, deduplicated by sanitized name (last wins), capped to MAX_TOOLS_PER_REQUEST
 */
export function cleanToolsArray(tools: unknown): CleanedTool[] {
  if (!Array.isArray(tools)) {
    throw new RequestHelpersError("cleanToolsArray expects array", "INVALID_TOOLS");
  }
  const map = new Map<string, CleanedTool>();
  for (const t of tools) {
    try {
      const cleaned = cleanToolSchema(t);
      map.set(cleaned.name, cleaned);
      if (map.size >= MAX_TOOLS_PER_REQUEST) break;
    } catch {
      // skip invalid tool — observer does not fail entire request for one bad tool
      continue;
    }
  }
  return Array.from(map.values());
}

// ---------------------------------------------------------------------------
// Message normalization OpenCode → Gemini
// ---------------------------------------------------------------------------

/**
 * Normalizes role string to Gemini system/user/model.
 *
 * @param rawRole - incoming role e.g. "assistant", "system", "tool", "function"
 * @returns normalized role
 */
export function normalizeRole(rawRole: string): "system" | "user" | "model" {
  if (typeof rawRole !== "string") return "user";
  const l = rawRole.trim().toLowerCase();
  switch (l) {
    case "system":
    case "developer":
    case "system_instruction":
    case "instruction":
    case "sys":
      return "system";
    case "assistant":
    case "model":
    case "ai":
    case "bot":
    case "agent":
    case "assistant_model":
      return "model";
    case "user":
    case "human":
    case "end_user":
      return "user";
    case "tool":
    case "function":
    case "tool_result":
    case "tool_response":
    case "function_response":
    case "function_result":
    case "tool_result_content":
      // Gemini expects functionResponse inside a user role turn
      return "user";
    default:
      // unknown → user for safety (observer fallback)
      return "user";
  }
}

/**
 * Detects if a block/object is a thinking block that must be filtered.
 * Checks multiple signatures: type:"thinking", thought:true, thinking:true, reasoning_content, etc.
 *
 * @param block - any object / part
 * @returns true if thinking block
 */
export function isThinkingBlock(block: unknown): boolean {
  if (!block || typeof block !== "object") return false;
  const b = block as Record<string, unknown>;

  // direct thought flag — Gemini part
  if ((b as any).thought === true) return true;
  if ((b as any).thinking === true) return true;

  // type discriminator used by OpenCode / Anthropic
  const t = (b as any).type;
  if (typeof t === "string") {
    const lt = t.toLowerCase();
    if (lt === "thinking" || lt === "reasoning" || lt === "thought" || lt === "internal_reasoning") return true;
  }

  // Anthropic extended thinking block shape
  if ("thinking" in b && typeof b.thinking === "string" && (b as any).type === "thinking") return true;
  if ("reasoning_content" in b) return true;
  if ("reasoning" in b && typeof b.reasoning === "string") return true;

  // Claude signature block that should not be filtered? Observer keeps signature but filters pure thinking text
  // We treat signature alone not as thinking block unless accompanied by thinking type
  return false;
}

/**
 * Normalizes a single content element (string or block) → Gemini parts.
 *
 * @param content - incoming content
 * @returns array of GeminiParts
 */
export function normalizeContentToParts(content: unknown): GeminiPart[] {
  const parts: GeminiPart[] = [];

  if (content == null) return parts;

  if (typeof content === "string") {
    if (content.trim() !== "") parts.push({ text: content });
    return parts;
  }

  if (Array.isArray(content)) {
    for (const blk of content) {
      // recursive flatten for nested arrays
      if (Array.isArray(blk)) {
        parts.push(...normalizeContentToParts(blk));
        continue;
      }
      if (typeof blk === "string") {
        if (blk.trim() !== "") parts.push({ text: blk });
        continue;
      }
      if (!isPlainObject(blk)) continue;
      const b = blk as Record<string, unknown>;

      // skip thinking early — also handled by filterThinkingBlocks but we also skip here
      if (isThinkingBlock(b)) continue;

      // OpenAI text block
      if (b.type === "text" && typeof b.text === "string") {
        parts.push({ text: b.text as string });
        continue;
      }
      // Anthropic text block may have .text
      if (typeof b.text === "string" && (b.type === undefined || (b as any).type === "text")) {
        // also check for thought attribute which would have been filtered
        if (!(b as any).thought) parts.push({ text: b.text as string });
        continue;
      }
      // image_url block — degraded to placeholder text to keep flow, inlineData would need fetch
      if (b.type === "image_url" || b.type === "image") {
        // observer keeps text marker to preserve context count; real image handling done in request.ts if needed
        parts.push({ text: "[image]" });
        continue;
      }
      // tool use → functionCall
      if (b.type === "tool_use") {
        const nameRaw = (b as any).name ?? (b as any).tool_name ?? "unknown_tool";
        try {
          const name = sanitizeToolName(String(nameRaw));
          const input = (b as any).input ?? (b as any).arguments ?? {};
          parts.push({
            functionCall: {
              name,
              args: isPlainObject(input) ? (input as Record<string, unknown>) : {},
            },
          });
        } catch {
          // skip invalid tool_use
        }
        continue;
      }
      // tool result → functionResponse
      if (b.type === "tool_result" || b.type === "tool_response" || b.type === "function_response") {
        const nameRaw = (b as any).name ?? (b as any).tool_name ?? (b as any).tool_use_id ?? "tool";
        try {
          const name = sanitizeToolName(String(nameRaw));
          // Anthropic tool_result content may be string or array
          let respContent = (b as any).content;
          if (Array.isArray(respContent)) {
            respContent = respContent.map((c: any) => (typeof c === "string" ? c : (c.text ?? JSON.stringify(c)))).join("\n");
          } else if (typeof respContent !== "string") {
            respContent = JSON.stringify(respContent ?? {});
          }
          parts.push({
            functionResponse: {
              name,
              response: { result: String(respContent).slice(0, 20000) },
            },
          });
        } catch {
          // skip
        }
        continue;
      }
      // functionCall already gemini-shaped
      if ((b as any).functionCall) {
        parts.push(b as unknown as GeminiPart);
        continue;
      }
      if ((b as any).functionResponse) {
        parts.push(b as unknown as GeminiPart);
        continue;
      }
      // fallback: if object has text property
      if (typeof b.text === "string") {
        parts.push({ text: b.text });
      }
    }
    return parts;
  }

  // content is object (maybe { text }) or tool_calls container
  if (isPlainObject(content)) {
    const c = content as Record<string, unknown>;
    if (typeof c.text === "string" && c.text.trim() !== "") {
      parts.push({ text: c.text });
    }
    // OpenAI assistant tool_calls at message level
    if (Array.isArray((c as any).tool_calls)) {
      // handled at message level, not here
    }
    return parts;
  }

  return parts;
}

/**
 * Normalizes incoming OpenCode / OpenAI / Anthropic messages → Gemini messages.
 * - Maps role system/user/model (assistant→model, tool→user)
 * - Converts content to parts array
 * - Preserves system instructions as separate role system
 * - Handles tool_calls (OpenAI) → functionCall parts in model role
 * - Handles tool_result via user role with functionResponse parts
 *
 * @param messages - array of incoming messages
 * @returns normalized Gemini messages
 * @throws {RequestHelpersError} if not array
 */
export function normalizeMessages(messages: unknown): GeminiMessage[] {
  if (!Array.isArray(messages)) {
    throw new RequestHelpersError(`normalizeMessages expects array, got ${typeof messages}`, "INVALID_MESSAGES");
  }

  const out: GeminiMessage[] = [];

  for (const raw of messages) {
    if (!isPlainObject(raw)) continue;
    const msg = raw as IncomingMessage;
    const roleRaw = typeof msg.role === "string" ? msg.role : "user";
    const normRole = normalizeRole(roleRaw);

    // gather parts from content
    let parts = normalizeContentToParts(msg.content as unknown);

    // OpenAI style tool_calls array at message level (assistant)
    if (Array.isArray(msg.tool_calls) && msg.tool_calls.length > 0) {
      for (const tc of msg.tool_calls) {
        try {
          const fn = tc.function ?? (tc as any);
          const nameRaw = (fn as any).name ?? tc.id ?? "tool";
          const name = sanitizeToolName(String(nameRaw));
          let args: Record<string, unknown> = {};
          const argsRaw = (fn as any).arguments;
          if (typeof argsRaw === "string") {
            try {
              const parsed = JSON.parse(argsRaw);
              if (isPlainObject(parsed)) args = parsed as Record<string, unknown>;
            } catch {
              // leave empty if not JSON
            }
          } else if (isPlainObject(argsRaw)) {
            args = argsRaw as Record<string, unknown>;
          }
          parts.push({ functionCall: { name, args } });
        } catch {
          continue;
        }
      }
    }

    // If after normalization no parts (empty message), skip unless system
    if (parts.length === 0) {
      // for system messages, allow empty? but we skip to avoid empty API error
      if (normRole === "system") continue;
      // if user sent empty, preserve as empty to not break turn order? observer skips
      continue;
    }

    // filter thinking blocks from parts produced
    parts = parts.filter((p) => !isThinkingBlock(p));

    if (parts.length === 0) continue;

    out.push({
      role: normRole,
      parts,
      _rawRole: roleRaw,
    });
  }

  // Merge consecutive same role (except system which should stay separate?)
  // Gemini prefers alternating user/model, but merging same role preserves content and avoids
  // creating extra turns that break 1:1 with OpenAI.
  const merged: GeminiMessage[] = [];
  for (const cur of out) {
    const last = merged[merged.length - 1];
    if (last && last.role === cur.role && cur.role !== "system") {
      // merge parts
      last.parts.push(...cur.parts);
    } else {
      merged.push(cur);
    }
  }

  return merged;
}

// ---------------------------------------------------------------------------
// Thinking block filter — standalone
// ---------------------------------------------------------------------------

/**
 * Filters thinking blocks from an array of Gemini parts.
 *
 * @param parts - array of parts (any shape)
 * @returns filtered array without thinking blocks
 */
export function filterThinkingBlocksFromParts(parts: unknown): GeminiPart[] {
  if (!Array.isArray(parts)) {
    throw new RequestHelpersError("filterThinkingBlocksFromParts expects array", "INVALID_PARTS");
  }
  const filtered: GeminiPart[] = [];
  for (const p of parts) {
    if (isThinkingBlock(p)) continue;
    // also check if part is wrapped object that contains thinking inside?
    if (isPlainObject(p)) {
      const obj = p as Record<string, unknown>;
      // if object has .thought:true at top level, already caught; also check nested?
      if ((obj as any).thought === true) continue;
    }
    filtered.push(p as GeminiPart);
  }
  return filtered;
}

/**
 * Filters thinking blocks from Gemini messages array.
 * Keeps message structure but removes thinking parts inside each message.
 * Messages that become empty after filtering are dropped (except system).
 *
 * @param messages - normalized Gemini messages
 * @returns filtered messages
 */
export function filterThinkingBlocksFromMessages(messages: unknown): GeminiMessage[] {
  if (!Array.isArray(messages)) {
    throw new RequestHelpersError("filterThinkingBlocksFromMessages expects array", "INVALID_MESSAGES");
  }
  const out: GeminiMessage[] = [];
  for (const raw of messages) {
    if (!isPlainObject(raw)) continue;
    const msg = raw as { role?: string; parts?: unknown[] };
    const role = msg.role;
    const partsRaw = msg.parts;
    if (!Array.isArray(partsRaw)) continue;
    const filteredParts = filterThinkingBlocksFromParts(partsRaw);
    if (filteredParts.length === 0) {
      // drop empty non-system messages
      if (role === "system") continue;
      continue;
    }
    out.push({
      role: (role as GeminiMessage["role"]) ?? "user",
      parts: filteredParts,
      _rawRole: (raw as any)._rawRole,
    });
  }
  return out;
}

/**
 * Generic filter that auto-detects whether input is parts array or messages array.
 * Per spec required name: filterThinkingBlocks
 *
 * @param input - either GeminiPart[] or GeminiMessage[] or OpenCode content blocks array
 * @returns filtered same shape (heuristically)
 */
export function filterThinkingBlocks(input: unknown): unknown[] {
  if (!Array.isArray(input)) {
    throw new RequestHelpersError("filterThinkingBlocks expects array", "INVALID_INPUT");
  }
  if (input.length === 0) return [];

  // heuristic: if first element has .role and .parts → messages
  const first = input[0] as any;
  if (isPlainObject(first) && "role" in first && "parts" in first) {
    return filterThinkingBlocksFromMessages(input);
  }
  // else assume parts / content blocks
  return filterThinkingBlocksFromParts(input);
}

// ---------------------------------------------------------------------------
// Additional production helpers — error / retry
// ---------------------------------------------------------------------------

/**
 * Checks if HTTP status is retryable per cascade spec 403/404/5xx + 429.
 *
 * @param status - http status code
 * @returns true if should retry with fallback endpoint
 */
export function isRetryableStatus(status: number): boolean {
  if (!Number.isFinite(status)) return false;
  return status === 429 || status === 403 || status === 404 || (status >= 500 && status <= 599);
}

/**
 * Strips forbidden headers from record — prevents 403 IAM.
 *
 * @param headers - input headers record
 * @returns new record without stripped keys (case-insensitive)
 */
export function stripForbiddenHeaders(headers: Record<string, string>): Record<string, string> {
  if (!headers || typeof headers !== "object") return {};
  const toStripLower = new Set(HEADERS_TO_STRIP.map((h) => h.toLowerCase()));
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(headers)) {
    if (toStripLower.has(k.toLowerCase())) continue;
    out[k] = v;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Default export — library-first barrel helper
// ---------------------------------------------------------------------------

export const RequestHelpers = {
  // FNV
  fnv1a32,
  fnv1aHex,
  fnv1aHex16,
  fnv1aHash,
  generateDeterministicId,
  generateSessionId,
  generateUserPromptId,

  // thinking
  THINKING_BUDGET_MAP,
  THINKING_LEVELS,
  THINKING_BUDGET_MIN,
  THINKING_BUDGET_MAX,
  parseThinkingLevel,
  mapThinkingLevelToBudget,
  thinkingLevelToBudget,
  getThinkingBudgetForVariant,

  // model detection
  isGeminiCLIOnlyModel,
  extractModelVariant,
  parseModelVariant,

  // tool name
  validateToolName,
  sanitizeToolName,
  TOOL_NAME_REGEX,
  TOOL_NAME_MAX_LENGTH,

  // schema
  ALLOWED_SCHEMA_KEYS,
  cleanJsonSchema,
  cleanToolSchema,
  cleanToolsArray,

  // messages
  normalizeRole,
  normalizeContentToParts,
  normalizeMessages,
  isThinkingBlock,
  filterThinkingBlocks,
  filterThinkingBlocksFromParts,
  filterThinkingBlocksFromMessages,

  // bypass
  BYPASS_CONSTANTS,
  DIRECT_ENDPOINT,
  DAILY_ENDPOINT,
  AUTOPUSH_ENDPOINT,
  ENDPOINT_CASCADE,
  HEADERS_TO_STRIP,
  isRetryableStatus,
  stripForbiddenHeaders,
} as const;

export default RequestHelpers;
