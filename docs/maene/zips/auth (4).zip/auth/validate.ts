/**
 * @file validate.ts
 * @description Validation helpers production-ready, node:* only.
 */

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email ?? "").trim());
}

export function isValidSemver(v: string): boolean {
  return /^\d+\.\d+\.\d+(-[a-z0-9.-]+)?(\+[a-z0-9.-]+)?$/i.test(String(v ?? "").trim());
}

export function isValidProjectId(id: string): boolean {
  return /^[a-z][a-z0-9-]{4,29}[a-z0-9]$/.test(String(id ?? "").trim()) || id === "rising-fact-p41fc";
}

export function validateAccount(a: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  if (!a) errors.push("account is null");
  else {
    if (!a.email || !isValidEmail(a.email)) errors.push("invalid email");
    if (!a.refreshToken || typeof a.refreshToken !== "string" || a.refreshToken.length < 10) errors.push("invalid refreshToken");
  }
  return { valid: errors.length === 0, errors };
}

export function validateModelId(model: string): boolean {
  const lower = String(model ?? "").toLowerCase();
  return lower.includes("gemini") || lower.includes("claude") || lower.includes("antigravity");
}
