/**
 * @file debug.ts
 * @module opencode-antigravity-auth-next/debug
 * @description
 *  Third-person observer view: the library watches Antigravity traffic and
 *  reproduces its fingerprint without running Antigravity itself.
 *  This module observes internal operations and records them safely.
 *
 *  Responsibilities — observed from outside:
 *   - DebugLogger singleton — single shared observer, no global mutation beyond its own buffer/file
 *   - Rotação de logs 10MB — stat before write, rename to timestamped file when limit hit
 *   - Limpeza arquivos >7 dias — readdir + mtime check, unlink old logs
 *   - Buffer TUI circular 1000 linhas — fixed array, head pointer, chronological read
 *   - Controle por variável de ambiente ANTIGRAVITY_DEBUG — parsing robusto (1/true/*, levels, disabled tokens)
 *   - Redação de segredos — refresh_token, access_token, id_token, api_key, client_secret + Bearer + ya29 + AIza
 *
 *  Runtime constraint:
 *   - Only node:* builtins (node:fs, node:path, node:os) + global fetch (not used here)
 *   - No external deps, no node:crypto, no third-party logger
 *   - Production-ready: never throws, chmod 0o700 dir / 0o600 file (best-effort), silent fallback
 *
 *  Log dir: ~/.config/opencode/antigravity-logs/
 *  Active file: antigravity.log
 *  Rotated: antigravity-YYYY-MM-DD-HH-mm-ss-mmm.log
 *
 *  Date governance: 25/08/2026 — Canto do Buriti, PI, BR
 *  Plugin: opencode-antigravity-auth-next 2.0.0 — library-first, root-first (no src/ folder)
 *
 *  @author opencode-antigravity-auth-next
 *  @license MIT
 *  @version 2.0.0
 */

import {
  appendFileSync,
  chmodSync,
  existsSync,
  mkdirSync,
  readdirSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";

// ---------------------------------------------------------------------------
// Constants — frozen, deterministic, aligned with constants.ts governance
// ---------------------------------------------------------------------------

/** 10MB rotation limit — matches DEBUG_LOG_MAX_BYTES in constants.ts */
export const DEBUG_LOG_MAX_BYTES = 10 * 1024 * 1024 as const;

/** Retention 7 days — matches DEBUG_LOG_RETENTION_DAYS */
export const DEBUG_LOG_RETENTION_DAYS = 7 as const;

/** TUI circular buffer size — matches DEBUG_BUFFER_TUI_LINES */
export const DEBUG_BUFFER_TUI_LINES = 1000 as const;

/** Relative log dir from $HOME — ~/.config/opencode/antigravity-logs/ */
export const DEBUG_LOG_DIR_SUBPATH = ".config/opencode/antigravity-logs" as const;

/** Active log filename */
export const DEBUG_LOG_FILE_NAME = "antigravity.log" as const;

/** Retention milliseconds */
const RETENTION_MS = DEBUG_LOG_RETENTION_DAYS * 24 * 60 * 60 * 1000;

/** Cleanup trigger every N writes to avoid readdir on every log */
const CLEANUP_EVERY_WRITES = 50 as const;

// ---------------------------------------------------------------------------
// LogLevel — numeric ordering enables level comparison
// ---------------------------------------------------------------------------

export enum LogLevel {
  DEBUG = 10,
  INFO = 20,
  WARN = 30,
  ERROR = 40,
  SILENT = 100,
}

export type LogLevelName = "DEBUG" | "INFO" | "WARN" | "ERROR";

const LEVEL_NAME_TO_LEVEL: Record<string, LogLevel> = {
  debug: LogLevel.DEBUG,
  info: LogLevel.INFO,
  warn: LogLevel.WARN,
  warning: LogLevel.WARN,
  error: LogLevel.ERROR,
};

const LEVEL_TO_NAME: Record<LogLevel, LogLevelName> = {
  [LogLevel.DEBUG]: "DEBUG",
  [LogLevel.INFO]: "INFO",
  [LogLevel.WARN]: "WARN",
  [LogLevel.ERROR]: "ERROR",
  [LogLevel.SILENT]: "ERROR",
};

// ---------------------------------------------------------------------------
// Secret redaction — observer never leaks credentials
// ---------------------------------------------------------------------------

/**
 * Tokens considered disabled / logger fully off.
 * The observer checks lowercased trimmed env value against this set.
 */
const DISABLED_TOKENS = new Set([
  "0",
  "false",
  "off",
  "disabled",
  "no",
  "none",
  "",
]);

/**
 * Tokens considered full debug enable.
 * Any of these alone means DEBUG level, most verbose.
 */
const DEBUG_ENABLE_TOKENS = new Set([
  "1",
  "true",
  "yes",
  "on",
  "*",
  "all",
  "debug",
  "verbose",
  "trace",
  "silly",
]);

/**
 * Sensitive substrings inside object keys — if key contains any, value is redacted.
 * Requirement: refresh_token, access_token, api_key are mandatory; we also cover
 * id_token, client_secret, password for defense-in-depth.
 */
const SENSITIVE_KEY_SUBSTRINGS = [
  "refresh_token",
  "access_token",
  "id_token",
  "api_key",
  "apikey",
  "api-key",
  "client_secret",
  "client_secret_expires",
  "password",
] as const;

/**
 * Redacts secrets inside free-form text.
 * Third-person observer guarantee: no token leaves log in clear text.
 *
 * @param input - raw log line or message
 * @returns redacted string
 */
export function redactSecretsText(input: string): string {
  if (!input || typeof input !== "string") return input as unknown as string;
  let out = input;

  // 1. JSON / query style key separator — captures key+separator, replaces value
  //    e.g. "refresh_token":"ya29.xxx" , access_token=ya29.xxx , api_key: AIza...
  //    Value must be at least 8 chars to avoid false positives on short strings
  out = out.replace(
    /(["']?(?:refresh_token|access_token|id_token|api_key|api[_-]?key|client_secret|client_id)["']?\s*[:=]\s*["']?)([^"'\s,;}\]&]{8,})/gi,
    (_m, p1: string) => `${p1}[REDACTED]`,
  );

  // 2. Bearer token header
  out = out.replace(/(Bearer\s+)[A-Za-z0-9\-_\.=]{20,}/gi, "$1[REDACTED]");

  // 3. Google OAuth access tokens ya29.*
  out = out.replace(/\bya29\.[A-Za-z0-9\-_]{20,}/g, "[REDACTED_GOOGLE_TOKEN]");

  // 4. Google API keys AIza*
  out = out.replace(/\bAIza[0-9A-Za-z\-_]{30,}/g, "[REDACTED_API_KEY]");

  // 5. Generic secret= / password= / token= assignments with long value (>=12 chars)
  out = out.replace(
    /((?:secret|password|token)\s*[:=]\s*["']?)([^"'\s]{12,})/gi,
    (_m, p1: string) => `${p1}[REDACTED]`,
  );

  return out;
}

/**
 * Checks if object key name is sensitive.
 */
function isSensitiveKey(key: string): boolean {
  const low = key.toLowerCase();
  return SENSITIVE_KEY_SUBSTRINGS.some((s) => low.includes(s));
}

/**
 * Deep redaction that clones and redacts sensitive keys and also redacts string values containing tokens.
 * Handles circular references, Error objects, arrays.
 */
export function redactObjectDeep<T>(value: T, seen = new WeakSet<object>()): T {
  // primitives: string needs text redaction
  if (value === null || value === undefined) return value;
  const t = typeof value;
  if (t === "string") {
    return redactSecretsText(value as unknown as string) as unknown as T;
  }
  if (t !== "object") {
    // number, boolean, bigint, symbol, function -> return as is (functions stringified later)
    return value;
  }

  // Avoid circular
  if (seen.has(value as unknown as object)) {
    return "[Circular]" as unknown as T;
  }

  // Error special handling — third-person observer captures name/message/stack redacted
  if (value instanceof Error) {
    seen.add(value as unknown as object);
    const errObj: Record<string, unknown> = {
      name: (value as Error).name,
      message: redactSecretsText((value as Error).message),
    };
    const stack = (value as Error).stack;
    if (stack) errObj.stack = redactSecretsText(stack);
    // copy enumerable own props with redaction
    for (const k of Object.keys(value as unknown as object)) {
      if (k === "message" || k === "stack" || k === "name") continue;
      try {
        const v = (value as unknown as Record<string, unknown>)[k];
        if (isSensitiveKey(k)) {
          errObj[k] = "[REDACTED]";
        } else {
          errObj[k] = redactObjectDeep(v as unknown, seen);
        }
      } catch {
        errObj[k] = "[Unserializable]";
      }
    }
    return errObj as unknown as T;
  }

  // Array
  if (Array.isArray(value)) {
    seen.add(value as unknown as object);
    const arr = value as unknown as unknown[];
    const out: unknown[] = new Array(arr.length);
    for (let i = 0; i < arr.length; i++) {
      try {
        out[i] = redactObjectDeep(arr[i] as unknown, seen);
      } catch {
        out[i] = "[Unserializable]";
      }
    }
    return out as unknown as T;
  }

  // Plain object / record
  const obj = value as unknown as Record<string, unknown>;
  seen.add(obj as unknown as object);
  const cloned: Record<string, unknown> = {};
  for (const key of Object.keys(obj)) {
    try {
      const v = obj[key];
      if (isSensitiveKey(key)) {
        cloned[key] = "[REDACTED]";
      } else {
        cloned[key] = redactObjectDeep(v as unknown, seen);
      }
    } catch {
      cloned[key] = "[Unserializable]";
    }
  }
  return cloned as unknown as T;
}

/**
 * Safe JSON stringify that never throws, uses redaction layer before.
 */
function safeStringifyMeta(meta: unknown): string {
  if (meta === undefined) return "";
  if (meta === null) return "null";
  try {
    const redacted = redactObjectDeep(meta);
    return JSON.stringify(redacted);
  } catch {
    try {
      return String(meta);
    } catch {
      return "[Unserializable meta]";
    }
  }
}

// ---------------------------------------------------------------------------
// Env control — parsing ANTIGRAVITY_DEBUG
// ---------------------------------------------------------------------------

export interface EnvParseResult {
  /** true = file logging active, false = completely silenced */
  enabled: boolean;
  /** Minimum level that will be emitted */
  level: LogLevel;
  /** Raw env string for debugging */
  raw: string | undefined;
}

/**
 * Parses ANTIGRAVITY_DEBUG env var into enabled flag + level.
 *
 * Rules (observer decision, production-ready):
 * - undefined => enabled true, level WARN (default production shows warn/error, no debug spam)
 * - disabled tokens: 0, false, off, disabled, no, none, "" => enabled false, SILENT
 * - enable tokens: 1, true, yes, on, *, all, debug, verbose, trace, silly => DEBUG
 * - comma/semicolon/space/pipe separated list: picks most verbose (min numeric) level present
 *   e.g. "info,warn" => INFO, "error" => ERROR, "debug,info" => DEBUG
 * - numeric level "10"/"20" etc also accepted (maps to DEBUG/INFO/WARN/ERROR)
 * - unknown non-empty string defaults to DEBUG (user explicitly set env)
 *
 * @param raw - process.env.ANTIGRAVITY_DEBUG value
 */
export function parseAntigravityDebugEnv(raw: string | undefined): EnvParseResult {
  if (raw === undefined) {
    return { enabled: true, level: LogLevel.WARN, raw };
  }
  const trimmed = String(raw).trim();
  const lower = trimmed.toLowerCase();

  if (DISABLED_TOKENS.has(lower)) {
    // explicit empty string counts as disabled when set, but undefined remains default WARN
    // If raw is "" (set to empty), treat as disabled — user blanked it
    return { enabled: false, level: LogLevel.SILENT, raw: trimmed };
  }

  if (DEBUG_ENABLE_TOKENS.has(lower)) {
    return { enabled: true, level: LogLevel.DEBUG, raw: trimmed };
  }

  // Numeric level quick path
  if (/^\d+$/.test(lower)) {
    const n = Number(lower);
    if (n <= 10) return { enabled: true, level: LogLevel.DEBUG, raw: trimmed };
    if (n <= 20) return { enabled: true, level: LogLevel.INFO, raw: trimmed };
    if (n <= 30) return { enabled: true, level: LogLevel.WARN, raw: trimmed };
    if (n <= 40) return { enabled: true, level: LogLevel.ERROR, raw: trimmed };
    return { enabled: true, level: LogLevel.WARN, raw: trimmed };
  }

  // Multi-token list: find most verbose level mentioned
  const tokens = lower
    .split(/[,;\s|]+/g)
    .map((s) => s.trim())
    .filter(Boolean);

  let minLevel: LogLevel | null = null;
  for (const tok of tokens) {
    // direct level names
    if (tok in LEVEL_NAME_TO_LEVEL) {
      const lvl = LEVEL_NAME_TO_LEVEL[tok];
      if (minLevel === null || lvl < minLevel) minLevel = lvl;
      continue;
    }
    // substring contains level name, e.g. "level=debug" or "antigravity:debug"
    for (const [name, lvl] of Object.entries(LEVEL_NAME_TO_LEVEL)) {
      if (tok.includes(name)) {
        if (minLevel === null || lvl < minLevel) minLevel = lvl;
      }
    }
    // wildcard star inside tokens
    if (tok.includes("*")) {
      if (minLevel === null || LogLevel.DEBUG < minLevel) minLevel = LogLevel.DEBUG;
    }
  }

  if (minLevel !== null) {
    return { enabled: true, level: minLevel, raw: trimmed };
  }

  // Non-empty unknown string => treat as DEBUG (user wanted logging)
  if (trimmed.length > 0) {
    return { enabled: true, level: LogLevel.DEBUG, raw: trimmed };
  }

  return { enabled: true, level: LogLevel.WARN, raw: trimmed };
}

// ---------------------------------------------------------------------------
// Home dir resolution — only node:os + path
// ---------------------------------------------------------------------------

function resolveHomeDir(): string {
  try {
    const hd = homedir();
    if (hd && typeof hd === "string" && hd.length > 0) return hd;
  } catch {
    // ignore — fall through
  }
  // Fallback chain using env only if homedir failed — still production-ready
  try {
    // process.env is global, not a node:* import, allowed
    const envHome =
      (typeof process !== "undefined" && (process.env.HOME || process.env.USERPROFILE)) || "";
    if (envHome) return envHome;
  } catch {
    // ignore
  }
  // Last resort: current dir placeholder — logger will try relative path but not crash
  return ".";
}

// ---------------------------------------------------------------------------
// DebugLogger — singleton observer, library-first root-first
// ---------------------------------------------------------------------------

export class DebugLogger {
  private static _instance: DebugLogger | null = null;

  private readonly logDir: string;
  private readonly logFile: string;
  private level: LogLevel;
  private enabled: boolean;
  private rawEnv: string | undefined;

  // TUI circular buffer — third-person observer stores last 1000 lines for UI
  private readonly maxBufferLines: number = DEBUG_BUFFER_TUI_LINES;
  private readonly buffer: string[];
  private bufferHead = 0; // next write position
  private bufferCount = 0;
  private writeCount = 0;

  /**
   * Private constructor — use getInstance().
   * Observer does not throw: all fs operations wrapped in try/catch.
   */
  private constructor() {
    const home = resolveHomeDir();
    this.logDir = join(home, DEBUG_LOG_DIR_SUBPATH);
    this.logFile = join(this.logDir, DEBUG_LOG_FILE_NAME);

    const parsed = parseAntigravityDebugEnv(
      typeof process !== "undefined" ? process.env.ANTIGRAVITY_DEBUG : undefined,
    );
    this.enabled = parsed.enabled;
    this.level = parsed.level;
    this.rawEnv = parsed.raw;

    // Circular buffer pre-allocation — fixed size 1000, production-ready, no growth
    this.buffer = new Array(this.maxBufferLines) as string[];

    // Ensure dir exists best-effort, then clean old files best-effort
    this.ensureLogDir();
    this.cleanupOldLogs();
  }

  /**
   * Returns singleton instance. Double-checked for library-first usage.
   */
  public static getInstance(): DebugLogger {
    if (DebugLogger._instance) return DebugLogger._instance;
    DebugLogger._instance = new DebugLogger();
    return DebugLogger._instance;
  }

  /**
   * For testing only — resets singleton and returns fresh instance reading current env.
   * Production code should use getInstance().
   */
  public static resetInstanceForTests(): DebugLogger {
    DebugLogger._instance = null;
    return DebugLogger.getInstance();
  }

  // -----------------------------------------------------------------------
  // Directory / file helpers — only node:fs builtins
  // -----------------------------------------------------------------------

  private ensureLogDir(): void {
    try {
      if (!existsSync(this.logDir)) {
        mkdirSync(this.logDir, { recursive: true, mode: 0o700 });
      }
      // best-effort chmod 0o700 — ignore on Windows
      try {
        chmodSync(this.logDir, 0o700);
      } catch {
        // ignore chmod errors (Windows / no permission)
      }
    } catch {
      // silent fail — logger must never break host process
    }
  }

  private ensureLogFilePermissions(): void {
    try {
      if (existsSync(this.logFile)) {
        chmodSync(this.logFile, 0o600);
      }
    } catch {
      // ignore
    }
  }

  /**
   * Rotates active log file when >=10MB.
   * Observer renames to antigravity-YYYY-MM-DD-HH-mm-ss-mmm.log
   */
  private rotateIfNeeded(): void {
    try {
      if (!existsSync(this.logFile)) return;
      let size = 0;
      try {
        const st = statSync(this.logFile);
        size = st.size;
      } catch {
        return;
      }
      if (size < DEBUG_LOG_MAX_BYTES) return;

      // Build timestamp safe for filenames: YYYY-MM-DD-HH-mm-ss-mmm
      const now = new Date();
      const iso = now.toISOString(); // e.g. 2026-08-25T14:33:02.123Z
      const ts = iso
        .replace("T", "-")
        .replace(/:/g, "-")
        .replace(/\./g, "-")
        .replace("Z", "");
      const rotatedName = `antigravity-${ts}.log`;
      const rotatedPath = join(this.logDir, rotatedName);
      try {
        renameSync(this.logFile, rotatedPath);
        // Create fresh empty active file with secure mode
        writeFileSync(this.logFile, "", { mode: 0o600 });
        this.ensureLogFilePermissions();
      } catch {
        // If rename fails (file locked), truncate best-effort by removing? Keep original to avoid data loss
        // Do not throw — production-ready
      }
    } catch {
      // swallow — logger never throws
    }
  }

  /**
   * Cleanup logs older than 7 days inside logDir.
   * Matches antigravity*.log pattern.
   */
  public cleanupOldLogs(): void {
    try {
      if (!existsSync(this.logDir)) return;
      let entries: string[];
      try {
        entries = readdirSync(this.logDir);
      } catch {
        return;
      }
      const now = Date.now();
      for (const entry of entries) {
        if (!entry.startsWith("antigravity") || !entry.endsWith(".log")) continue;
        // Skip active file by name — only rotate-clean old rotated or also active if too old? We skip active for safety
        if (entry === DEBUG_LOG_FILE_NAME) continue;
        const full = join(this.logDir, entry);
        try {
          const st = statSync(full);
          const mtime = st.mtimeMs ?? st.mtime?.getTime() ?? 0;
          if (mtime && now - mtime > RETENTION_MS) {
            unlinkSync(full);
          }
        } catch {
          // ignore individual file errors
        }
      }

      // Also clean active log if it itself is older than retention and huge? Keep but we check active size separately
      // For strict 7-day retention of active file content, rotation already handles; active file itself can stay
    } catch {
      // never throw
    }
  }

  // -----------------------------------------------------------------------
  // Buffer TUI circular
  // -----------------------------------------------------------------------

  private pushToBuffer(formattedLine: string): void {
    try {
      this.buffer[this.bufferHead] = formattedLine;
      this.bufferHead = (this.bufferHead + 1) % this.maxBufferLines;
      if (this.bufferCount < this.maxBufferLines) this.bufferCount++;
    } catch {
      // ignore
    }
  }

  /**
   * Returns buffer lines in chronological order oldest->newest, up to 1000 lines.
   * Third-person observer view for TUI rendering.
   */
  public getBuffer(): string[] {
    try {
      if (this.bufferCount === 0) return [];
      if (this.bufferCount < this.maxBufferLines) {
        // Linear from 0 to count-1 (head == count)
        return this.buffer.slice(0, this.bufferCount);
      }
      // Full circular: head is next write position = oldest
      const head = this.bufferHead;
      return [...this.buffer.slice(head), ...this.buffer.slice(0, head)];
    } catch {
      return [];
    }
  }

  /**
   * Returns last n lines (newest n), chronological oldest->newest among those n.
   */
  public getRecent(n = 100): string[] {
    try {
      const all = this.getBuffer();
      if (n >= all.length) return all;
      return all.slice(all.length - n);
    } catch {
      return [];
    }
  }

  /**
   * Clears TUI buffer — does not delete file.
   */
  public clearBuffer(): void {
    try {
      this.bufferHead = 0;
      this.bufferCount = 0;
      // keep array allocation but clear values
      for (let i = 0; i < this.buffer.length; i++) this.buffer[i] = "" as unknown as string;
    } catch {
      // ignore
    }
  }

  // -----------------------------------------------------------------------
  // Core writing — redacted, rotated, file + buffer
  // -----------------------------------------------------------------------

  private writeRaw(level: LogLevel, levelName: LogLevelName, message: string, meta?: unknown): void {
    try {
      if (!this.enabled) return;
      if (level < this.level) return;

      const redactedMsg = redactSecretsText(message ?? "");

      let metaStr = "";
      if (meta !== undefined) {
        const s = safeStringifyMeta(meta);
        if (s) {
          metaStr = s;
          // metaStr already redacted via redactObjectDeep + safeStringify, but also run text redactor as defense
          metaStr = redactSecretsText(metaStr);
        }
      }

      const timestamp = new Date().toISOString();
      const line = `${timestamp} [${levelName}] ${redactedMsg}${metaStr ? " " + metaStr : ""}`;

      // Push to TUI circular buffer first — always available even if file fails
      this.pushToBuffer(line);

      // File path handling — ensure dir exists each time (user may delete dir at runtime)
      this.ensureLogDir();

      // Rotation check before writing
      this.rotateIfNeeded();

      // Append to file best-effort
      try {
        appendFileSync(this.logFile, line + "\n", { encoding: "utf8", mode: 0o600 });
        this.ensureLogFilePermissions();
      } catch {
        // silent — e.g. permission denied, disk full
      }

      this.writeCount++;
      if (this.writeCount % CLEANUP_EVERY_WRITES === 0) {
        this.cleanupOldLogs();
      }
    } catch {
      // Absolute last resort — logger must never propagate exception
    }
  }

  /**
   * Core log method — library-first, typed.
   *
   * @param lvl - LogLevel enum
   * @param message - human readable message
   * @param meta - optional additional context (will be redacted)
   */
  public log(lvl: LogLevel, message: string, meta?: unknown): void {
    const name = LEVEL_TO_NAME[lvl] ?? "INFO";
    // Re-parse env each log? Not for perf, but allow refresh method. We use cached level.
    // Level mapping from enum to name already resolved
    if (lvl === LogLevel.SILENT) return;
    this.writeRaw(lvl, name as LogLevelName, message, meta);
  }

  // -----------------------------------------------------------------------
  // Public level methods — required by spec: debug info warn error
  // -----------------------------------------------------------------------

  /**
   * Debug level — only emitted when ANTIGRAVITY_DEBUG=debug / 1 / * / verbose etc
   * @param message - debug details
   * @param meta - extra context, secrets will be redacted
   */
  public debug(message: string, meta?: unknown): void {
    this.writeRaw(LogLevel.DEBUG, "DEBUG", message, meta);
  }

  /**
   * Info level — emitted when env includes info or more verbose
   */
  public info(message: string, meta?: unknown): void {
    this.writeRaw(LogLevel.INFO, "INFO", message, meta);
  }

  /**
   * Warn level — emitted by default when ANTIGRAVITY_DEBUG not set (WARN + ERROR default)
   */
  public warn(message: string, meta?: unknown): void {
    this.writeRaw(LogLevel.WARN, "WARN", message, meta);
  }

  /**
   * Error level — always emitted unless logger fully disabled via 0/false/off
   */
  public error(message: string, meta?: unknown): void {
    this.writeRaw(LogLevel.ERROR, "ERROR", message, meta);
  }

  // -----------------------------------------------------------------------
  // Env control & introspection — for CLI and plugin core
  // -----------------------------------------------------------------------

  /**
   * Re-reads process.env.ANTIGRAVITY_DEBUG and updates enabled/level.
   * Useful for long-running processes that change env at runtime.
   */
  public refreshFromEnv(): EnvParseResult {
    try {
      const raw = typeof process !== "undefined" ? process.env.ANTIGRAVITY_DEBUG : undefined;
      const parsed = parseAntigravityDebugEnv(raw);
      this.enabled = parsed.enabled;
      this.level = parsed.level;
      this.rawEnv = parsed.raw;
      return parsed;
    } catch {
      return { enabled: this.enabled, level: this.level, raw: this.rawEnv };
    }
  }

  /**
   * Programmatic level setter — overrides env control for current process only.
   * @param level - LogLevel enum or level name string
   */
  public setLevel(level: LogLevel | LogLevelName | string): void {
    try {
      if (typeof level === "number") {
        if (Object.values(LogLevel).includes(level as LogLevel)) {
          this.level = level as LogLevel;
          this.enabled = this.level !== LogLevel.SILENT;
        }
        return;
      }
      const low = String(level).toLowerCase();
      if (low in LEVEL_NAME_TO_LEVEL) {
        this.level = LEVEL_NAME_TO_LEVEL[low];
        this.enabled = true;
        return;
      }
      // parse via env parser for flexibility
      const parsed = parseAntigravityDebugEnv(String(level));
      this.level = parsed.level;
      this.enabled = parsed.enabled;
    } catch {
      // ignore
    }
  }

  /** Returns current log directory path */
  public getLogDir(): string {
    return this.logDir;
  }

  /** Returns active log file path */
  public getLogFilePath(): string {
    return this.logFile;
  }

  /** Returns raw env value */
  public getRawEnv(): string | undefined {
    return this.rawEnv;
  }

  /** Returns current level numeric */
  public getLevel(): LogLevel {
    return this.level;
  }

  /** Returns current level name */
  public getLevelName(): LogLevelName {
    return LEVEL_TO_NAME[this.level] ?? "INFO";
  }

  /** Whether file logging is enabled (false when env 0/false/off) */
  public isEnabled(): boolean {
    return this.enabled;
  }

  /** Returns whether given level would be emitted */
  public isLevelEnabled(lvl: LogLevel): boolean {
    if (!this.enabled) return false;
    return lvl >= this.level;
  }
}

// ---------------------------------------------------------------------------
// Singleton export — library-first convenience
// ---------------------------------------------------------------------------

/**
 * Default singleton observer — import this in library files.
 * Third-person: each module imports same observer, no state duplication.
 */
export const debugLogger = DebugLogger.getInstance();

/**
 * Alias for shorter import: `import { logger } from "./debug.js"`
 */
export const logger = debugLogger;

/**
 * Functional wrappers for quick usage without .getInstance()
 * All wrappers respect env control and redaction.
 */
export function debug(message: string, meta?: unknown): void {
  debugLogger.debug(message, meta);
}
export function info(message: string, meta?: unknown): void {
  debugLogger.info(message, meta);
}
export function warn(message: string, meta?: unknown): void {
  debugLogger.warn(message, meta);
}
export function error(message: string, meta?: unknown): void {
  debugLogger.error(message, meta);
}

/**
 * Helper to redact arbitrary string — exported for other modules (oauth.ts etc)
 * Example: redacting URL with token before logging.
 */
export { redactSecretsText as redactSecrets };

/**
 * Default export for ESM barrel compatibility.
 */
export default debugLogger;
