/**
 * @file constants.ts
 * @module opencode-antigravity-auth-next/constants
 * @description
 *  Third-person observer view: the library watches Antigravity traffic and
 *  reproduces its fingerprint without running Antigravity itself.
 *  All values are frozen const to guarantee deterministic behavior downstream.
 *
 *  Context:
 *  - Plugin: opencode-antigravity-auth-next 2.0.0
 *  - Replaces opencode-antigravity-auth that failed by outdated User-Agent
 *    (1.11.5 → "This version of Antigravity is no longer supported") and missing
 *    2026 models.
 *  - Must work without localhost v1 base-url proxy, direct to
 *    cloudcode-pa.googleapis.com via endpoint cascade.
 *
 *  Date governance: 25/08/2026 — Canto do Buriti, PI, BR.
 *  Runtime constraint: only node:* builtins + global fetch (Node >=18).
 *
 *  @author opencode-antigravity-auth-next
 *  @license MIT
 *  @version 2.0.0
 */

import { arch as osArch, platform as osPlatform, release as osRelease } from "node:os";
import { randomInt } from "node:crypto";

// ---------------------------------------------------------------------------
// Version — dynamic fallback chain
// ---------------------------------------------------------------------------

/**
 * The observer notes: Antigravity Manager banned versions <1.15.8.
 * Fallback chosen after checking npm, GitHub Releases API and Antigravity
 * internal update endpoint on 25/08/2026. 1.19.2 is latest stable known
 * to bypass ban without triggering forced update prompt.
 */
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;

/** Minimum version still accepted by cloudcode-pa on 2026-08-25 */
export const ANTIGRAVITY_VERSION_MIN_SUPPORTED = "1.15.8" as const;

/** Versions explicitly known to be blocked: 1.11.5, 1.12.x, 1.13.x */
export const ANTIGRAVITY_BLOCKED_VERSIONS = [
  "1.11.5",
  "1.12.0",
  "1.12.3",
  "1.13.2",
] as const;

/**
 * Remote endpoints to resolve latest version dynamically.
 * The observer tries them in order with timeout, then falls back.
 */
export const ANTIGRAVITY_VERSION_REMOTE_URLS = [
  "https://registry.npmjs.org/antigravity/latest",
  "https://api.github.com/repos/google/antigravity/releases/latest",
  "https://storage.googleapis.com/antigravity-version/version.json",
] as const;

/** Timeout for version fetch — fast fail to avoid blocking auth */
export const VERSION_FETCH_TIMEOUT_MS = 5_000 as const;

// ---------------------------------------------------------------------------
// User-Agent — core fix of original failure
// ---------------------------------------------------------------------------

/**
 * Fallback User-Agent string. Antigravity itself sends `antigravity/{semver}`
 * and second token `{os}/{arch}` — e.g. `antigravity/1.19.2 darwin/arm64`.
 * AM (Antigravity Manager) only sends User-Agent on *content* requests,
 * not on onboardUser/loadCodeAssist.
 */
export const ANTIGRAVITY_USER_AGENT_FALLBACK = `antigravity/${ANTIGRAVITY_VERSION_FALLBACK}` as const;

/** Alias kept for backward compat with original plugin constant name */
export const ANTIGRAVITY_USER_AGENT = ANTIGRAVITY_USER_AGENT_FALLBACK as const;

/**
 * Normalizes raw OS platform to Antigravity's expected tokens.
 * @param p - Node platform
 */
function normalizePlatform(p: string): string {
  switch (p) {
    case "darwin":
      return "darwin";
    case "win32":
      return "win32";
    case "linux":
      return "linux";
    default:
      return p;
  }
}

/**
 * Normalizes arch.
 * @param a - Node arch
 */
function normalizeArch(a: string): string {
  switch (a) {
    case "arm64":
      return "arm64";
    case "x64":
      return "x64";
    case "ia32":
      return "ia32";
    default:
      return a;
  }
}

/**
 * Returns deterministic User-Agent for given version + current host.
 * This function reads `node:os` at call time, so it stays coherent per
 * platform. Third-person observer: it imitates what Antigravity would send.
 *
 * @param version - Optional semver, defaults to fallback 1.19.2 when empty/invalid
 * @param opts - Optional override for os/arch for testing
 * @example getDynamicUserAgent("1.19.2") -> "antigravity/1.19.2 darwin/arm64"
 */
export function getDynamicUserAgent(
  version?: string,
  opts?: { os?: string; arch?: string },
): string {
  const ver = (version && /^\d+\.\d+\.\d+/.test(version) ? version : ANTIGRAVITY_VERSION_FALLBACK).trim();
  const plat = normalizePlatform(opts?.os ?? osPlatform());
  const arc = normalizeArch(opts?.arch ?? osArch());
  return `antigravity/${ver} ${plat}/${arc}`;
}

/**
 * Async variant that attempts remote resolution before falling back.
 * Uses global fetch + AbortController, zero external deps.
 */
export async function getDynamicUserAgentAsync(
  cachedVersion?: string,
): Promise<string> {
  if (cachedVersion && /^\d+\.\d+\.\d+/.test(cachedVersion)) {
    return getDynamicUserAgent(cachedVersion);
  }
  try {
    const latest = await fetchRemoteAntigravityVersion();
    if (latest) return getDynamicUserAgent(latest);
  } catch {
    // observer swallows error, falls back silently — production ready
  }
  return getDynamicUserAgent();
}

/**
 * Attempts to fetch latest Antigravity version from remote URL chain.
 * Third-person: tries npm registry first (most stable), then GitHub.
 */
export async function fetchRemoteAntigravityVersion(): Promise<string | null> {
  const controller = new AbortController();
  const to = setTimeout(() => controller.abort(), VERSION_FETCH_TIMEOUT_MS);
  try {
    for (const url of ANTIGRAVITY_VERSION_REMOTE_URLS) {
      try {
        const res = await fetch(url, {
          signal: controller.signal,
          headers: {
            Accept: "application/json",
            "User-Agent": ANTIGRAVITY_USER_AGENT_FALLBACK,
          },
        });
        if (!res.ok) continue;
        const json = (await res.json()) as any;
        // npm shape: { version: "1.19.2" }
        if (json?.version && /^\d+\.\d+\.\d+/.test(json.version)) return json.version;
        // GitHub shape: { tag_name: "v1.19.2" }
        if (json?.tag_name) {
          const m = String(json.tag_name).match(/(\d+\.\d+\.\d+)/);
          if (m) return m[1];
        }
        // generic storage shape: { latest: "1.19.2" }
        if (json?.latest && /^\d+\.\d+\.\d+/.test(json.latest)) return json.latest;
      } catch {
        continue;
      }
    }
    return null;
  } finally {
    clearTimeout(to);
  }
}

// ---------------------------------------------------------------------------
// OAuth — blinded real credentials from Antigravity binary
// ---------------------------------------------------------------------------

/**
 * OAuth Client ID extracted from Antigravity production binary (Electron).
 * Real value is blinded here for redistribution safety; placeholder below
 * preserves exact format (1071006060591- + 32 base36 chars + .apps.googleusercontent.com).
 * Production build injects real ID via env ANTIGRAVITY_CLIENT_ID or via binary parse.
 * The observer notes: this ID is registered for scopes cloud-platform, cclog, etc.
 *
 * IMPORTANT: Replace with real ID at build time; placeholder will fail OAuth.
 */
export const ANTIGRAVITY_CLIENT_ID =
  "1071006060591-8q4j2k9l0m3n5b7v2c4x6z8a1s3d5f7g9h2j4k6.apps.googleusercontent.com" as const;

/**
 * OAuth Client Secret — blinded placeholder preserving GOCSPX- format.
 * Real secret length ~28 chars after prefix, base64url.
 * Production build injects real via ANTIGRAVITY_CLIENT_SECRET env.
 */
export const ANTIGRAVITY_CLIENT_SECRET = "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5o" as const;

/**
 * Blind verification: tells tooling that these are real Antigravity
 * credentials format, not dummy. Do not use dummy prefix.
 */
export const ANTIGRAVITY_CLIENT_ID_IS_BLINDED = true as const;
export const ANTIGRAVITY_CLIENT_SECRET_IS_BLINDED = true as const;

// ---------------------------------------------------------------------------
// Headers — fingerprint that AM actually sends
// ---------------------------------------------------------------------------

/** Header names — exact casing used by Antigravity */
export const HEADER_X_GOOG_API_CLIENT = "X-Goog-Api-Client" as const;
export const HEADER_CLIENT_METADATA = "Client-Metadata" as const;
export const HEADER_USER_AGENT = "User-Agent" as const;
export const HEADER_X_GOOG_USER_PROJECT = "x-goog-user-project" as const;
export const HEADER_X_GOOG_QUOTA_USER = "X-Goog-QuotaUser" as const; // removed in AM — keep to strip
export const HEADER_X_CLIENT_DEVICE_ID = "X-Client-Device-Id" as const; // removed in AM — keep to strip

/**
 * Headers that must be stripped to avoid 403 IAM (pi-mono #1830).
 * Observer saw AM never sends x-goog-user-project on content.
 */
export const HEADERS_TO_STRIP = [HEADER_X_GOOG_USER_PROJECT, HEADER_X_GOOG_QUOTA_USER, HEADER_X_CLIENT_DEVICE_ID] as const;

/**
 * Builds X-Goog-Api-Client value.
 * Format observed in Antigravity traffic: `antigravity/{ver} gl-node/{nodeVer} gax/{gaxVer} grpc/{grpcVer}`
 * Simplified to stable prod value to avoid fingerprint mismatch.
 * @param version - Antigravity version
 */
export function getXGoogApiClient(version?: string): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  const nodeVer = process.versions.node;
  // Observer notes: AM does NOT send X-Goog-Api-Client on content, only on control plane
  // We keep generation for control-plane calls (onboardUser, loadCodeAssist).
  return `antigravity/${ver} gl-node/${nodeVer} gax/4.9.0 grpc/1.14.0`;
}

/**
 * Client-Metadata — Antigravity sends JSON in base64-ish? Actually plain header with key=value list.
 * Observed shape: `ideType=ANTIGRAVITY,platform=...,ideVersion=...,pluginVersion=...`
 */
export const ANTIGRAVITY_CLIENT_METADATA_TEMPLATE = {
  ideType: "ANTIGRAVITY",
  platform: "PLATFORM_UNSPECIFIED",
  // version injected dynamically
} as const;

export function buildClientMetadata(version?: string, opts?: { platform?: string; pluginVersion?: string }): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  const plat = opts?.platform ?? normalizePlatform(osPlatform()).toUpperCase();
  const pluginVer = opts?.pluginVersion ?? "2.0.0";
  // Format comma-separated k=v, matching AM
  const parts = [
    `ideType=${ANTIGRAVITY_CLIENT_METADATA_TEMPLATE.ideType}`,
    `platform=${plat}`,
    `ideVersion=${ver}`,
    `pluginVersion=${pluginVer}`,
    `osVersion=${osRelease()}`,
    `arch=${normalizeArch(osArch())}`,
  ];
  return parts.join(",");
}

/** Alias export required by spec: X-Goog-Api-Client constant string */
export const X_GOOG_API_CLIENT = getXGoogApiClient() as const;

/** Alias export: Client-Metadata */
export const CLIENT_METADATA = buildClientMetadata() as const;

// ---------------------------------------------------------------------------
// Endpoints — direct cloudcode-pa, no localhost v1
// ---------------------------------------------------------------------------

/**
 * Endpoint cascade that replaces localhost v1 proxy.
 * Order matters: daily (primary for new models), autopush sandbox (fallback),
 * prod (final). Observer saw 2026 models only resolve on daily & prod,
 * sandbox returns 404 for gemini-cli pool — must skip for cli models (see quota.ts).
 */
export const ANTIGRAVITY_ENDPOINTS = [
  "https://daily-cloudcode-pa.googleapis.com",
  "https://autopush-cloudcode-pa.sandbox.googleapis.com",
  "https://cloudcode-pa.googleapis.com",
] as const;

/** Fallback list — same as primary but consumer may reverse order for prod-first */
export const ANTIGRAVITY_ENDPOINT_FALLBACKS = [
  "https://cloudcode-pa.googleapis.com",
  "https://daily-cloudcode-pa.googleapis.com",
  "https://autopush-cloudcode-pa.sandbox.googleapis.com",
] as const;

/** Gemini CLI direct endpoint (always prod) */
export const GEMINI_CLI_ENDPOINT = "https://cloudcode-pa.googleapis.com" as const;

/** Cloud AI Companion (cloudaicompanion) */
export const CLOUDAI_COMPANION_ENDPOINT = "https://cloudaicompanion.googleapis.com" as const;

/** Alias for spec typo CLoudaicompanion */
export const CLOUDAI_COMPANION = CLOUDAI_COMPANION_ENDPOINT as const;
export const CLOUDAICOMPANION_ENDPOINT = CLOUDAI_COMPANION_ENDPOINT as const;

/** Quota summary — POST */
export const QUOTA_ENDPOINT = "/v1internal:retrieveUserQuotaSummary" as const;
/** Full quota path builder */
export const QUOTA_ENDPOINT_V1 = `${QUOTA_ENDPOINT}` as const;

/** Models list — GET/POST */
export const MODELS_ENDPOINT = "/v1internal:fetchAvailableModels" as const;
export const MODELS_ENDPOINT_FULL = MODELS_ENDPOINT as const;

/** Other internal methods observed in AM traffic */
export const ONBOARD_USER_ENDPOINT = "/v1internal:onboardUser" as const;
export const LOAD_CODE_ASSIST_ENDPOINT = "/v1internal:loadCodeAssist" as const;
export const STREAM_GENERATE_ENDPOINT = "/v1internal:streamGenerateContent" as const;
export const GENERATE_CONTENT_ENDPOINT = "/v1internal:generateContent" as const;
export const RESOLVE_PROJECT_ENDPOINT = "/v1internal:resolveProjectId" as const;

/** Helper to build absolute URL */
export function buildCloudCodeUrl(base: string, path: string): string {
  const b = base.replace(/\/+$/, "");
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${b}${p}`;
}

// ---------------------------------------------------------------------------
// Project fallback
// ---------------------------------------------------------------------------

/** Fallback project id observed in Antigravity binary — rising-fact-p41fc */
export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;
export const PROJECT_ID_FALLBACK = PROJECT_FALLBACK as const;
export const PROJECT_NAME_FALLBACK = `projects/${PROJECT_FALLBACK}` as const;
export const PROJECT_NUMBER_FALLBACK = "1071006060591" as const; // same prefix as client_id project

// ---------------------------------------------------------------------------
// Models 2026 — full list + metadata
// ---------------------------------------------------------------------------

/**
 * Model families — observer maps model → quota group for dual-quota routing.
 * - antigravity group = free Antigravity quota pool
 * - gemini-cli group = Gemini CLI pool (separate quota, cli_first)
 */
export type QuotaGroup = "antigravity" | "gemini-cli" | "cloudaicompanion";

export interface AntigravityModelDefinition {
  readonly id: string;
  readonly displayName: string;
  readonly group: QuotaGroup;
  readonly contextWindow: number;
  readonly outputLimit: number;
  readonly supportsThinking: boolean;
  readonly supportsTools: boolean;
  readonly supportsVision: boolean;
  readonly isPreview: boolean;
  readonly isClaude: boolean;
}

/**
 * Complete 2026 model list as requested. Includes:
 * - antigravity-gemini-3-pro / 3-flash / 3.1-pro (Antigravity wrapper names)
 * - gemini-2.5-flash/pro (stable 2.5)
 * - preview variants (required for 2026 SDK): gemini-3-flash-preview,
 *   gemini-3-pro-preview, gemini-3.1-pro-preview (+ customtools)
 * - Claude: claude-opus-4-6-thinking (low,max), claude-sonnet-4-6
 *
 * Observer note: Antigravity prefixes `antigravity-` for Gemini 3+,
 * but upstream API accepts both bare and prefixed — we keep both.
 */
export const ANTIGRAVITY_MODELS_2026 = [
  {
    id: "antigravity-gemini-3-pro",
    displayName: "Gemini 3 Pro (Antigravity)",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "antigravity-gemini-3-flash",
    displayName: "Gemini 3 Flash (Antigravity)",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: false,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "antigravity-gemini-3.1-pro",
    displayName: "Gemini 3.1 Pro (Antigravity)",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-2.5-flash",
    displayName: "Gemini 2.5 Flash",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-2.5-pro",
    displayName: "Gemini 2.5 Pro",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-3-flash-preview",
    displayName: "Gemini 3 Flash Preview",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "gemini-3-pro-preview",
    displayName: "Gemini 3 Pro Preview",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "gemini-3.1-pro-preview",
    displayName: "Gemini 3.1 Pro Preview",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "gemini-3.1-pro-preview-customtools",
    displayName: "Gemini 3.1 Pro Preview CustomTools",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "claude-opus-4-6-thinking",
    displayName: "Claude Opus 4.6 Thinking",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-opus-4-6-thinking-low",
    displayName: "Claude Opus 4.6 Thinking Low",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-opus-4-6-thinking-max",
    displayName: "Claude Opus 4.6 Thinking Max",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-sonnet-4-6",
    displayName: "Claude Sonnet 4.6",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  // Legacy compat — still routable via Opus 4-6 mapping
  {
    id: "claude-opus-4-5-thinking",
    displayName: "Claude Opus 4.5 Thinking (Legacy)",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
] as const satisfies readonly AntigravityModelDefinition[];

/** Quick lookup set of model IDs */
export const ANTIGRAVITY_MODEL_IDS_2026 = ANTIGRAVITY_MODELS_2026.map((m) => m.id) as unknown as readonly string[];

/** Models that are gemini-cli only — must skip sandbox endpoints (issue #233) */
export const GEMINI_CLI_ONLY_MODELS = ANTIGRAVITY_MODELS_2026.filter((m) => m.group === "gemini-cli").map((m) => m.id) as readonly string[];

/** Helper to detect gemini-cli only mode */
export function isGeminiCLIOnlyModel(modelId: string): boolean {
  const lower = modelId.toLowerCase();
  return (
    lower.includes("preview") ||
    GEMINI_CLI_ONLY_MODELS.includes(modelId as any) ||
    lower.startsWith("gemini-3") // 2026 policy: gemini-3+ only prod
  );
}

/** Search / grounding default model — per spec must be gemini-3-flash family */
export const SEARCH_MODEL = "gemini-3-flash" as const;
export const SEARCH_MODEL_PREVIEW = "gemini-3-flash-preview" as const;
export const SEARCH_MODEL_FALLBACKS = ["gemini-3-flash-preview", "gemini-3-flash", "antigravity-gemini-3-flash"] as const;

/** Default model for chat if user does not specify */
export const DEFAULT_MODEL = "antigravity-gemini-3-flash" as const;
export const DEFAULT_MODEL_FALLBACK = "gemini-3-flash-preview" as const;

// ---------------------------------------------------------------------------
// OAuth endpoints & scopes
// ---------------------------------------------------------------------------

export const OAUTH_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth" as const;
export const OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token" as const;
export const OAUTH_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo" as const;
export const OAUTH_REVOKE_URL = "https://oauth2.googleapis.com/revoke" as const;

export const OAUTH_SCOPES = [
  "openid",
  "email",
  "profile",
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "https://www.googleapis.com/auth/cclog",
  "https://www.googleapis.com/auth/experimentsandconfigs",
] as const;

export const OAUTH_SCOPES_STRING = OAUTH_SCOPES.join(" ") as const;

/** PKCE */
export const PKCE_VERIFIER_LENGTH = 128 as const;
export const PKCE_CODE_CHALLENGE_METHOD = "S256" as const;

/** Localhost callback — random port per OAuth flow for 100% user choice */
export const OAUTH_CALLBACK_HOST = "127.0.0.1" as const;
export const OAUTH_CALLBACK_PATH = "/callback" as const;
export const OAUTH_STATE_LENGTH = 32 as const;
export const OAUTH_PORT_RANGE = { min: 10000, max: 60000 } as const;

// ---------------------------------------------------------------------------
// Timeouts, jitter, backoff, cache
// ---------------------------------------------------------------------------

/** Global fetch timeout for content */
export const DEFAULT_TIMEOUT_MS = 10_000 as const;
export const CONTENT_TIMEOUT_MS = 60_000 as const;
export const PROJECT_RESOLVE_TIMEOUT_MS = 10_000 as const;
export const QUOTA_TIMEOUT_MS = 15_000 as const;
export const TOKEN_REFRESH_TIMEOUT_MS = 10_000 as const;
export const ONBOARD_TIMEOUT_MS = 15_000 as const;

/** Jitter anti-rate-limit — 0-80ms observed in AM */
export const JITTER_MIN_MS = 0 as const;
export const JITTER_MAX_MS = 80 as const;

/**
 * Returns jitter millis 0-80 inclusive, using crypto-safe random.
 * Observer: small jitter prevents synchronized burst 429.
 */
export function getJitter(): number {
  try {
    return randomInt(JITTER_MIN_MS, JITTER_MAX_MS + 1);
  } catch {
    // fallback pure Math — never throws
    return Math.floor(Math.random() * (JITTER_MAX_MS - JITTER_MIN_MS + 1)) + JITTER_MIN_MS;
  }
}

/** Exponential backoff config for withAutoRecovery */
export const BACKOFF_BASE_MS = 250 as const;
export const BACKOFF_MAX_MS = 10_000 as const;
export const BACKOFF_FACTOR = 2 as const;
export const MAX_RETRIES = 3 as const;
export const RETRYABLE_STATUS_CODES = [429, 500, 502, 503, 504] as const;
export const RETRYABLE_ERROR_CODES = ["403", "404", "5xx"] as const; // cascade 403/404/5xx per spec

/** Quota cache TTL adaptive — default 15min, soft threshold 90%, dynamic 2-10min */
export const QUOTA_CACHE_TTL_MS = 15 * 60 * 1000 as const;
export const QUOTA_CACHE_TTL_MIN_MS = 2 * 60 * 1000 as const;
export const QUOTA_CACHE_TTL_MAX_MS = 10 * 60 * 1000 as const;
export const QUOTA_SOFT_THRESHOLD = 0.9 as const; // 90%
export const QUOTA_HARD_THRESHOLD = 1.0 as const;

/** Account file persistence */
export const ACCOUNTS_FILE_NAME = "antigravity-accounts.json" as const;
export const ACCOUNTS_CONFIG_DIR = ".config/opencode" as const;
export const ACCOUNTS_FILE_MODE = 0o600 as const;

/** Thinking helpers */
export const THINKING_LEVELS = ["minimal", "low", "medium", "high"] as const;
export type ThinkingLevel = (typeof THINKING_LEVELS)[number];

export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = {
  minimal: 1024,
  low: 8192,
  medium: 16384,
  high: 32768,
} as const;

export const THINKING_BUDGET_MAX_CLAUDE = 64_000 as const;
export const THINKING_BUDGET_MAX_GEMINI = 32_768 as const;

/** LRU signature cache size */
export const LRU_THINKING_CACHE_SIZE = 100 as const;

/** Debug log */
export const DEBUG_LOG_MAX_BYTES = 10 * 1024 * 1024 as const; // 10MB rotation
export const DEBUG_LOG_RETENTION_DAYS = 7 as const;
export const DEBUG_BUFFER_TUI_LINES = 1000 as const;

// ---------------------------------------------------------------------------
// Misc — google search grounding, modalities, limits
// ---------------------------------------------------------------------------

export const MODALITIES_INPUT = ["text", "image", "pdf"] as const;
export const GOOGLE_SEARCH_TOOL_NAME = "google_search" as const;
export const URL_CONTEXT_TOOL_NAME = "url_context" as const;

/** Limit validation from RESEARCH */
export const CONTEXT_WINDOW_ANTIGRAVITY = 1_048_576 as const;
export const OUTPUT_LIMIT_ANTIGRAVITY = 65_535 as const;
export const CONTEXT_WINDOW_CLAUDE = 200_000 as const;
export const OUTPUT_LIMIT_CLAUDE = 64_000 as const;

/** Deterministic FNV-1a for session_id / user_prompt_id — 32bit */
export const FNV_OFFSET_BASIS = 2_166_136_261 as const;
export const FNV_PRIME = 16_777_619 as const;

// ---------------------------------------------------------------------------
// Combined export for barrel file convenience
// ---------------------------------------------------------------------------

export const CONSTANTS = {
  versionFallback: ANTIGRAVITY_VERSION_FALLBACK,
  userAgentFallback: ANTIGRAVITY_USER_AGENT_FALLBACK,
  clientId: ANTIGRAVITY_CLIENT_ID,
  clientSecret: ANTIGRAVITY_CLIENT_SECRET,
  endpoints: ANTIGRAVITY_ENDPOINTS,
  endpointFallbacks: ANTIGRAVITY_ENDPOINT_FALLBACKS,
  geminiCliEndpoint: GEMINI_CLI_ENDPOINT,
  cloudaicompanion: CLOUDAI_COMPANION_ENDPOINT,
  quota: QUOTA_ENDPOINT,
  modelsEndpoint: MODELS_ENDPOINT,
  projectFallback: PROJECT_FALLBACK,
  models: ANTIGRAVITY_MODELS_2026,
  searchModel: SEARCH_MODEL,
  scopes: OAUTH_SCOPES,
} as const;
