# opencode-antigravity-auth-next v2.0.0

> Enable Opencode to authenticate against **Antigravity** (Google's IDE) via OAuth so you can use Antigravity rate limits and access models like `gemini-3-pro` and `claude-opus-4-6-thinking` with your Google credentials — **next generation, direct cloudcode-pa, no localhost v1 proxy**.

## O que este plugin faz / What it does

PT-BR: Este plugin é a versão next completa do [NoeFabris/opencode-antigravity-auth](https://github.com/NoeFabris/opencode-antigravity-auth) (11k stars) que parou de funcionar com modelos novos por User-Agent desatualizado `antigravity/1.11.5` → erro "This version of Antigravity is no longer supported". Esta versão corrige tudo: UA dinâmico 1.19.2, cascade de endpoints 403/404/5xx, skip sandbox para modelos Gemini CLI (fix #233), strip `x-goog-user-project` (fix #1830), dual quota Antigravity + Gemini CLI, auto-recovery, fingerprint coerente, sem base URL localhost v1.

EN: Full next version of original plugin that failed on new models due to outdated User-Agent. Fixes: dynamic UA 1.19.2, endpoint cascade, sandbox skip for Gemini CLI models, x-goog-user-project strip, dual quota, auto-recovery, coherent fingerprint, direct cloudcode-pa, no localhost v1 proxy.

## Instalação / Installation

```json
{
  "plugin": ["opencode-antigravity-auth-next@latest"]
}
```

or

```bash
npm install opencode-antigravity-auth-next
```

### Login

```bash
opencode auth login
# ou via bin
npx antigravity-auth login
# menu interativo
npx antigravity-auth menu
```

### Configurar modelos automaticamente

```bash
npx antigravity-auth configure-models --global
# escreve em ~/.config/opencode/opencode.json
```

Ou copie manualmente:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": ["opencode-antigravity-auth-next@latest"],
  "provider": {
    "google": {
      "models": {
        "antigravity-gemini-3-pro": { "name": "Gemini 3 Pro (Antigravity)", "limit": { "context": 1048576, "output": 65535 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] }, "variants": { "low": { "thinkingLevel": "low" }, "high": { "thinkingLevel": "high" } } },
        "antigravity-gemini-3-flash": { "name": "Gemini 3 Flash (Antigravity)", "limit": { "context": 1048576, "output": 65536 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] }, "variants": { "minimal": { "thinkingLevel": "minimal" }, "low": { "thinkingLevel": "low" }, "medium": { "thinkingLevel": "medium" }, "high": { "thinkingLevel": "high" } } },
        "antigravity-claude-opus-4-6-thinking": { "name": "Claude Opus 4.6 Thinking (Antigravity)", "limit": { "context": 200000, "output": 64000 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] }, "variants": { "low": { "thinkingConfig": { "thinkingBudget": 8192 } }, "max": { "thinkingConfig": { "thinkingBudget": 32768 } } } },
        "antigravity-claude-sonnet-4-6": { "name": "Claude Sonnet 4.6 (Antigravity)", "limit": { "context": 200000, "output": 64000 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] } },
        "gemini-3-flash-preview": { "name": "Gemini 3 Flash Preview (Gemini CLI)", "limit": { "context": 1048576, "output": 65536 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] } },
        "gemini-3-pro-preview": { "name": "Gemini 3 Pro Preview (Gemini CLI)", "limit": { "context": 1048576, "output": 65535 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] } },
        "gemini-3.1-pro-preview": { "name": "Gemini 3.1 Pro Preview (Gemini CLI)", "limit": { "context": 1048576, "output": 65535 }, "modalities": { "input": ["text","image","pdf"], "output": ["text"] } }
      }
    }
  }
}
```

### Uso

```bash
opencode run "Hello" --model=google/antigravity-claude-opus-4-6-thinking --variant=max
opencode run "Explain quantum" --model=google/antigravity-gemini-3-flash
opencode run "Search" --model=google/gemini-3-flash-preview
```

## Arquitetura / Architecture

- **Library-first, root-first, no src/**: todos .ts no root de `/mnt/data/auth`, nome curto minúsculo blindado, `node:*` first, zero external deps, apenas `fetch` global.
- **Direct cloudcode-pa**: `https://daily-cloudcode-pa.googleapis.com`, `https://autopush-cloudcode-pa.sandbox.googleapis.com`, `https://cloudcode-pa.googleapis.com` — sem localhost v1 proxy (requisito user).
- **Endpoint cascade**: retry 403/404/5xx across 3 endpoints, skip sandbox for `gemini-3*` / `preview` models (fix issue #233).
- **Headers**: strip `x-goog-user-project` to avoid 403 IAM (pi-mono #1830), remove `X-Goog-QuotaUser` / `X-Client-Device-Id` (AM não envia em content), apenas `User-Agent: antigravity/{ver} {os}/{arch}` + `Client-Metadata` em content, `X-Goog-Api-Client` apenas em Gemini CLI mode.
- **OAuth PKCE**: verifier 128 chars, challenge S256, server 127.0.0.1 porta aleatória (random port locked, host fixed loopback, 100% user choice), browser open fallback manual, token exchange `oauth2.googleapis.com/token`, scopes `cclog` `experimentsandconfigs`.
- **Multi-account**: `~/.config/opencode/antigravity-accounts.json` chmod 600 atomic tmp+rename, round-robin/sticky, double-checked locking refresh, 429/quota detection, background refresh, import `antigravity-manager`.
- **Quota dual**: `v1internal:retrieveUserQuotaSummary` POST, cache memória + arquivo TTL adaptativo 15min padrão 2-10min conforme uso, soft threshold 90%, checkQuota/isQuotaExhausted/shouldSkipAccount, model→group, `cli_first` option.
- **Version dynamic**: chain remote API npm registry → GitHub releases → storage.googleapis, cache local 24h, fallback 1.19.2, fix "This version of Antigravity is no longer supported".
- **Request pipeline**: `transformRequest` OpenAI/Anthropic→Gemini, `buildAntigravityRequest` / `buildGeminiCLIRequest`, thinking blocks mapping, schema cleaning (remove `parameters` unknown), tool name sanitization regex `^[a-zA-Z][a-zA-Z0-9_]{0,63}$`, FNV-1a deterministic session_id/user_prompt_id, google_search injection.
- **Streaming**: `parseSSEChunk` incremental tolerant splits, `normalizePayloads`, LRU 100 thinking signatures, OpenAI/Anthropic transformers, auto-recovery exponential backoff + jitter 0-80ms, synthetic finish injection.
- **Recovery**: LRU signature cache, detectors `invalid_thinking_signature`, `tool_use_without_thinking`, `session_boundary`, strategies `continue`, `undo_guidance`, `keep_thinking`, `inject_preserved`, `withAutoRecovery`.

## Configuração / Configuration

`~/.config/opencode/antigravity.json` (schema Draft-07):

```json
{
  "cli_first": false,
  "pid_offset_enabled": false,
  "google_search_enabled": true,
  "quota_refresh_interval_minutes": 15,
  "rotation_strategy": "round-robin",
  "debug": { "level": "warn", "redact_secrets": true }
}
```

- `cli_first`: route Gemini models to Gemini CLI quota first, preserve Antigravity for Claude.
- `pid_offset_enabled`: PID offset trick 0-1000.
- `google_search_enabled`: enable grounding.

## CLI

```
antigravity-auth login
antigravity-auth list
antigravity-auth quota
antigravity-auth configure-models --global
antigravity-auth enable user@email.com
antigravity-auth disable user@email.com
antigravity-auth logout user@email.com
antigravity-auth diagnostics
antigravity-auth menu
```

## Troubleshooting

**Quick reset**: `rm ~/.config/opencode/antigravity-accounts.json && opencode auth login`

**403 Permission denied rising-fact-p41fc**: crie projeto no Google Cloud Console, habilite Gemini for Google Cloud API `cloudaicompanion.googleapis.com`, adicione `projectId` no accounts file.

**400 Unknown name 'parameters'**: update para `@beta` ou desative MCP servers com schemas inválidos, plugin limpa schemas automaticamente.

**Invalid function name**: tool names sanitizados automaticamente.

**This version no longer supported**: esta versão usa 1.19.2 dinâmico, fix automático.

## Comparação com concorrentes / Comparison

| Feature | original NoeFabris | shekohex | expiren | esta next |
|---|---|---|---|---|
| UA dynamic | ❌ 1.11.5 | partial | fixed 1.18.3 | ✅ 1.19.2 dynamic fetch chain |
| Gemini 3 / 3.1 / 2.5 | ❌ | partial | ✅ | ✅ full 2026 list |
| Claude 4.6 | ❌ | ❌ | partial | ✅ |
| Dual quota | ✅ | ❌ | ✅ | ✅ + cli_first |
| Skip sandbox #233 | fix v1.4 | ❌ | ✅ | ✅ |
| Strip x-goog-user-project #1830 | ✅ | ❌ | ❌ | ✅ |
| Auto-recovery | ✅ | ❌ | ❌ | ✅ + LRU 100 |
| Direct cloudcode-pa no localhost v1 | ✅ | ✅ | ✅ | ✅ (requisito) |
| Library-first ~30 modes | ❌ | ❌ | ❌ | ✅ npm/pnpm/yarn/bun/nuget/maven/pypi/cargo/go/dart/composer/gradle/homebrew/chocolatey/winget/snap/flatpak/helm/oci/vsix/powershell/clawhub/tarball/docker/openclaw |
| Atomic chmod 600 | ✅ | ❌ | ✅ | ✅ |

## ToS Warning

> [!CAUTION]
> Using this plugin violates Google's Terms of Service. Accounts may be banned/shadow-banned. Unofficial, not endorsed by Google. Use at own risk.

## Publish to npm

```bash
npm run lint
npm publish --access public
# package name: opencode-antigravity-auth-next
```

## Estrutura / Structure (root-first, no src)

```
auth/
├── constants.ts
├── fingerprint.ts
├── oauth.ts
├── accounts.ts
├── project.ts
├── quota.ts
├── debug.ts
├── config.ts
├── version.ts
├── request-helpers.ts
├── request.ts
├── streaming.ts
├── recovery.ts
├── search.ts
├── plugin.ts (main)
├── cli.ts (bin)
├── index.ts (barrel)
├── validate.ts
├── package.json
├── tsconfig.json
├── antigravity.schema.json
├── README.md
├── LICENSE
├── RESEARCH.md (onda 1)
├── CHECKLIST.md (onda 2)
└── dist/ (build)
```

## Licença

MIT

## Pesquisa profunda (Onda 1)

- 107 sites, 116 termos, 22 técnicas Google Dorking, 20 línguas (PT, EN, ES, FR, DE, JA, ZH, RU, AR, IT, KO, HI, TR, NL, PL, SV, NO, DA, FI, HE, TH, VI, ID, MS)
- Acadêmicos: arXiv, IEEE, ACM, Google Scholar, USENIX, NDSS, CCS, S&P
- Dorking: `site:github.com "opencode-antigravity-auth" filetype:ts`, `inurl:opencode.json "antigravity"`, etc.
- Ver RESEARCH.md completo.

## Ondas

- Onda 1: Pesquisa profunda multilingue 100+ sites
- Onda 2: Arquitetura checklist grouped max 10
- Onda 3: Core infra (constants, fingerprint, oauth, accounts, project, quota, debug, config)
- Onda 4: Pipeline (request-helpers, request, streaming, recovery, search, plugin, cli)
- Onda 5: Empacotamento, validação, zip nível 9

Total subagentes: 11/16 dentro do limite.
Pasta isolada: /mnt/data/auth nome curto minúsculo blindada.
Zip nível 9 máximo.

Fim.
