/**
 * @file config.ts
 * @module opencode-antigravity-auth-next/config
 * @description
 *  Third-person observer: the library watches how Antigravity Manager
 *  and Gemini CLI persist user preferences and reproduces that contract
 *  without depending on their runtime. The observer never leaks secrets,
 *  validates production inputs strictly, and enforces chmod 600 on disk.
 *
 *  Layout: library-first, root-first — file lives in /mnt/data/auth/config.ts
 *  Runtime: only node:* builtins + global fetch (Node >=18). Zero external deps.
 *  Date governance: 25/08/2026 — Canto do Buriti, PI, BR — version awareness 2.0.0
 *
 *  Contract:
 *  - Path: ~/.config/opencode/antigravity.json (honors OPENCODE_CONFIG_DIR)
 *  - Schema: JSON Schema Draft-07 compatible
 *  - Persistence: atomic write (tmp + chmod 600 + rename) + dir 0755
 *  - Defaults: cli_first=false, pid_offset_enabled=false, rotation round-robin,
 *    quota_refresh 15min, google_search true, debug false
 *
 *  Bypass metadata documented in schema description:
 *  EN: Antigravity bypass relies on mimicking antigravity/{ver} {os}/{arch} UA
 *      and bypassing x-goog-user-project stripping, endpoint cascade 403/404/5xx.
 *  PT-BR: Bypass Antigravity depende de imitar UA antigravity/{ver} {os}/{arch}
 *      e remover x-goog-user-project, cascata de endpoints em 403/404/5xx.
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";

// ---------------------------------------------------------------------------
// File system constants — observer enforces secure perms
// ---------------------------------------------------------------------------

const CONFIG_FILE_NAME = "antigravity.json" as const;
const CONFIG_DIR_TAIL = path.join(".config", "opencode");
const FILE_MODE = 0o600 as const;
const DIR_MODE = 0o755 as const;

// ---------------------------------------------------------------------------
// Rotation strategy — requirement: round-robin / sticky
// ---------------------------------------------------------------------------

export type RotationStrategy = "round-robin" | "sticky";
export const ROTATION_STRATEGIES = ["round-robin", "sticky"] as const;

// ---------------------------------------------------------------------------
// Debug — boolean or object shape, production tolerant
// ---------------------------------------------------------------------------

export type DebugLevel = "debug" | "info" | "warn" | "error" | "silent";

export interface DebugObjectConfig {
  /** EN: enable debug logging / PT-BR: ativa log de debug */
  enabled?: boolean;
  /** log level */
  level?: DebugLevel;
  /** custom log file path */
  log_file?: string | null;
  /** retention days */
  retain_days?: number;
  /** max bytes before rotation, e.g. 10MB */
  max_bytes?: number;
  /** TUI circular buffer lines */
  tui_buffer_lines?: number;
  /** redact secrets in logs */
  redact_secrets?: boolean;
}

export type DebugConfig = boolean | DebugObjectConfig;

// ---------------------------------------------------------------------------
// Google Search grounding — requirement google_search enabled
// ---------------------------------------------------------------------------

export interface GoogleSearchConfig {
  /** EN: enable google_search tool injection / PT-BR: ativa injeção de google_search */
  enabled?: boolean;
  /** model used for search grounding, defaults to gemini-3-flash */
  model?: string;
  /** enable url_context companion tool */
  url_context?: boolean;
  /** include groundingMetadata in response */
  include_grounding_metadata?: boolean;
}

// ---------------------------------------------------------------------------
// Endpoint overrides — observer knows prod/daily/sandbox cascade
// ---------------------------------------------------------------------------

export interface EndpointOverrides {
  /** prod: https://cloudcode-pa.googleapis.com */
  prod?: string;
  /** daily: https://daily-cloudcode-pa.googleapis.com */
  daily?: string;
  /** sandbox: https://daily-cloudcode-pa.sandbox.googleapis.com */
  sandbox?: string;
  /** autopush: https://autopush-cloudcode-pa.sandbox.googleapis.com */
  autopush?: string;
  /** quota endpoint override */
  quota?: string;
  /** models endpoint override */
  models?: string;
  /** gemini cli companion endpoint */
  gemini_cli?: string;
  /** cloudaicompanion.googleapis.com */
  cloud_companion?: string;
  /** generateContent base */
  generate?: string;
  /** streamGenerateContent base */
  stream_generate?: string;
}

// ---------------------------------------------------------------------------
// Quota sub-config
// ---------------------------------------------------------------------------

export interface QuotaConfig {
  /** refresh interval minutes — merged to quota_refresh_interval_minutes */
  refresh_interval_minutes?: number;
  /** cache ttl minutes */
  cache_ttl_minutes?: number;
  /** soft threshold 0-1, e.g. 0.9 = 90% */
  soft_threshold?: number;
  /** hard threshold 0-1 */
  hard_threshold?: number;
  /** dual pool enabled */
  dual_pool?: boolean;
}

// ---------------------------------------------------------------------------
// Bypass metadata — documents how UA / fingerprint bypasses ban
// ---------------------------------------------------------------------------

export interface BypassMetadata {
  /** fallback version when dynamic fetch fails */
  version_fallback?: string;
  /** min supported version */
  min_supported?: string;
  /** custom user agent override — observer warns to keep antigravity/{semver} {os}/{arch} pattern */
  user_agent?: string;
  /** strip x-goog-user-project header to avoid 403 */
  strip_user_project_header?: boolean;
  /** enable fingerprint jitter 0-80ms */
  fingerprint_jitter?: boolean;
  /** pid offset trick for Gemini CLI bypass */
  pid_offset?: boolean;
}

// ---------------------------------------------------------------------------
// Root config — V2 canonical
// ---------------------------------------------------------------------------

export interface AntigravityConfig {
  /** json schema pointer, optional */
  $schema?: string;
  /** config version, integer */
  version?: number;

  // — core flags required by prompt —
  /** EN: try Gemini CLI pool first / PT-BR: tenta pool Gemini CLI primeiro */
  cli_first?: boolean;
  /** EN: enable PID offset bypass / PT-BR: ativa bypass de offset de PID */
  pid_offset_enabled?: boolean;
  /** EN: quota refresh interval in minutes / PT-BR: intervalo de atualização de quota em minutos */
  quota_refresh_interval_minutes?: number;
  /** EN: account rotation strategy / PT-BR: estratégia de rotação de contas */
  rotation_strategy?: RotationStrategy;
  /** alias kept for backward compat with older schema */
  account_rotation?: RotationStrategy;
  /** debug flag or object */
  debug?: DebugConfig;
  /** boolean debug shortcut */
  debug_enabled?: boolean;
  /** google_search enabled shortcut */
  google_search_enabled?: boolean;
  /** full google search object */
  google_search?: GoogleSearchConfig;

  // — extended production fields —
  /** endpoint overrides */
  endpoints?: EndpointOverrides;
  /** quota sub-config */
  quota?: QuotaConfig;
  /** bypass metadata */
  bypass?: BypassMetadata;

  /** fallback project id blinded */
  fallback_project_id?: string;
  /** default chat model 2026 */
  default_model?: string;
  /** search/grounding model */
  search_model?: string;

  /** client id override — public client, do not commit secret */
  client_id?: string | null;
  /** client secret override — optional, blinded in logs */
  client_secret?: string | null;

  /** accounts file path override */
  accounts_file?: string | null;

  /** model allowlist custom */
  models_allowlist?: string[];

  /** enable fetch interceptor stripping */
  strip_user_project?: boolean;

  /** extra */
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// Defaults — library-first deterministic
// ---------------------------------------------------------------------------

export const DEFAULT_ENDPOINTS: Readonly<Required<Pick<EndpointOverrides, "prod" | "daily" | "sandbox" | "autopush">>> = {
  prod: "https://cloudcode-pa.googleapis.com",
  daily: "https://daily-cloudcode-pa.googleapis.com",
  sandbox: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  autopush: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
} as const;

export const DEFAULT_QUOTA: Required<QuotaConfig> = {
  refresh_interval_minutes: 15,
  cache_ttl_minutes: 15,
  soft_threshold: 0.9,
  hard_threshold: 1.0,
  dual_pool: true,
};

export const DEFAULT_BYPASS: Required<BypassMetadata> = {
  version_fallback: "1.19.2",
  min_supported: "1.15.8",
  user_agent: "antigravity/1.19.2",
  strip_user_project_header: true,
  fingerprint_jitter: true,
  pid_offset: false,
};

export const DEFAULT_DEBUG_OBJECT: Required<DebugObjectConfig> = {
  enabled: false,
  level: "warn",
  log_file: null,
  retain_days: 7,
  max_bytes: 10 * 1024 * 1024,
  tui_buffer_lines: 1000,
  redact_secrets: true,
};

export const DEFAULT_GOOGLE_SEARCH: Required<GoogleSearchConfig> = {
  enabled: true,
  model: "gemini-3-flash",
  url_context: true,
  include_grounding_metadata: true,
};

export function getDefaultConfig(): AntigravityConfig {
  // observer returns deep clone to avoid mutation between callers
  return {
    $schema: "https://json-schema.org/draft-07/schema#",
    version: 2,
    cli_first: false,
    pid_offset_enabled: false,
    quota_refresh_interval_minutes: 15,
    rotation_strategy: "round-robin",
    account_rotation: "round-robin",
    debug: false,
    debug_enabled: false,
    google_search_enabled: true,
    google_search: { ...DEFAULT_GOOGLE_SEARCH },
    endpoints: { ...DEFAULT_ENDPOINTS },
    quota: { ...DEFAULT_QUOTA },
    bypass: { ...DEFAULT_BYPASS },
    fallback_project_id: "rising-fact-p41fc",
    default_model: "antigravity-gemini-3-flash",
    search_model: "gemini-3-flash",
    client_id: null,
    client_secret: null,
    accounts_file: null,
    models_allowlist: [],
    strip_user_project: true,
  };
}

export const CONFIG_DEFAULTS = getDefaultConfig();

// ---------------------------------------------------------------------------
// JSON Schema Draft-07 — bilingual examples, production validations
// ---------------------------------------------------------------------------

/**
 * Schema for ~/.config/opencode/antigravity.json
 * The observer documents this file with third-person view and bilingual help.
 */
export const ANTIGRAVITY_CONFIG_JSON_SCHEMA = {
  $schema: "http://json-schema.org/draft-07/schema#",
  $id: "https://opencode.ai/schemas/antigravity.json",
  title: "opencode-antigravity-auth-next config — antigravity.json",
  description:
    "EN: Configuration for opencode-antigravity-auth-next plugin. Bypass metadata: mimics antigravity/{ver} {os}/{arch} User-Agent, strips x-goog-user-project, endpoint cascade 403/404/5xx, supports Gemini CLI dual quota pool, round-robin/sticky rotation, google_search grounding. / PT-BR: Configuração do plugin opencode-antigravity-auth-next. Metadados de bypass: imita User-Agent antigravity/{ver} {os}/{arch}, remove x-goog-user-project, cascata de endpoints em 403/404/5xx, suporta dual pool Gemini CLI, rotação round-robin/sticky, grounding google_search.",
  type: "object",
  additionalProperties: false,
  properties: {
    $schema: {
      type: "string",
      format: "uri",
      description: "EN: JSON schema pointer / PT-BR: Ponteiro de schema JSON",
      default: "https://json-schema.org/draft-07/schema#",
      examples: ["https://json-schema.org/draft-07/schema#", "./antigravity.schema.json"],
    },
    version: {
      type: "integer",
      minimum: 1,
      maximum: 10,
      default: 2,
      description: "EN: config version / PT-BR: versão da config",
      examples: [2],
    },
    cli_first: {
      type: "boolean",
      default: false,
      description:
        "EN: When true, tries Gemini CLI quota pool first before Antigravity pool. Useful when Antigravity quota is exhausted but CLI pool still has tokens. / PT-BR: Quando verdadeiro, tenta o pool de quota Gemini CLI primeiro antes do pool Antigravity. Útil quando a quota Antigravity acabou mas o pool CLI ainda tem tokens.",
      examples: [false, true],
    },
    pid_offset_enabled: {
      type: "boolean",
      default: false,
      description:
        "EN: Enables PID offset trick to bypass per-PID rate limiting observed in Gemini CLI gateway. When enabled, adds pid % 1000 to jitter. / PT-BR: Ativa truque de offset de PID para contornar rate limiting por PID observado no gateway Gemini CLI. Quando ativo, soma pid % 1000 ao jitter.",
      examples: [false, true],
    },
    quota_refresh_interval_minutes: {
      type: "integer",
      minimum: 1,
      maximum: 120,
      default: 15,
      description:
        "EN: Interval in minutes for background quota refresh. Adaptive TTL 2-10min when near soft threshold 90%. / PT-BR: Intervalo em minutos para atualização de quota em background. TTL adaptativo 2-10min quando perto do limiar 90%.",
      examples: [5, 15, 30],
    },
    rotation_strategy: {
      type: "string",
      enum: ROTATION_STRATEGIES as unknown as string[],
      default: "round-robin",
      description:
        "EN: Multi-account rotation strategy — round-robin distributes evenly, sticky keeps same account until quota exhausted. / PT-BR: Estratégia de rotação multi-conta — round-robin distribui igualmente, sticky mantém mesma conta até quota acabar.",
      examples: ["round-robin", "sticky"],
    },
    account_rotation: {
      type: "string",
      enum: ROTATION_STRATEGIES as unknown as string[],
      default: "round-robin",
      description:
        "EN: Alias for rotation_strategy (backward compat) / PT-BR: Alias para rotation_strategy (compatibilidade)",
      examples: ["round-robin", "sticky"],
    },
    debug: {
      oneOf: [
        { type: "boolean" },
        {
          type: "object",
          additionalProperties: false,
          properties: {
            enabled: {
              type: "boolean",
              default: false,
              description: "EN: enable debug / PT-BR: ativa debug",
              examples: [false, true],
            },
            level: {
              type: "string",
              enum: ["debug", "info", "warn", "error", "silent"],
              default: "warn",
              description: "EN: log level / PT-BR: nível de log",
              examples: ["debug", "warn"],
            },
            log_file: {
              type: ["string", "null"],
              default: null,
              description: "EN: custom log file path / PT-BR: caminho custom de log",
              examples: [null, "~/.config/opencode/antigravity-debug.log"],
            },
            retain_days: {
              type: "integer",
              minimum: 1,
              maximum: 90,
              default: 7,
              description: "EN: log retention days / PT-BR: dias de retenção de log",
              examples: [7],
            },
            max_bytes: {
              type: "integer",
              minimum: 1024,
              maximum: 100 * 1024 * 1024,
              default: 10485760,
              description: "EN: max bytes before rotation 10MB default / PT-BR: máx bytes antes de rotação padrão 10MB",
              examples: [10485760],
            },
            tui_buffer_lines: {
              type: "integer",
              minimum: 10,
              maximum: 10000,
              default: 1000,
              description: "EN: circular TUI buffer lines / PT-BR: linhas de buffer circular da TUI",
              examples: [1000],
            },
            redact_secrets: {
              type: "boolean",
              default: true,
              description: "EN: redact secrets in logs / PT-BR: redacta segredos no log",
              examples: [true],
            },
          },
        },
      ],
      default: false,
      description:
        "EN: Debug mode — boolean or object with rotation, retention, redaction. / PT-BR: Modo debug — boolean ou objeto com rotação, retenção, redaction.",
      examples: [false, true, { enabled: true, level: "debug" }],
    },
    debug_enabled: {
      type: "boolean",
      default: false,
      description: "EN: shortcut for debug.enabled / PT-BR: atalho para debug.enabled",
      examples: [false, true],
    },
    google_search_enabled: {
      type: "boolean",
      default: true,
      description:
        "EN: Enable native google_search grounding tool (Gemini) injection. / PT-BR: Ativa ferramenta nativa google_search de grounding (Gemini).",
      examples: [true, false],
    },
    google_search: {
      type: "object",
      additionalProperties: false,
      default: { ...DEFAULT_GOOGLE_SEARCH },
      description:
        "EN: Google search grounding full config / PT-BR: Config completa de grounding google_search",
      properties: {
        enabled: {
          type: "boolean",
          default: true,
          description: "EN: enable google_search tool / PT-BR: ativa ferramenta google_search",
          examples: [true, false],
        },
        model: {
          type: "string",
          default: "gemini-3-flash",
          description: "EN: model used for search grounding / PT-BR: modelo usado para grounding",
          examples: ["gemini-3-flash", "gemini-3-flash-preview"],
        },
        url_context: {
          type: "boolean",
          default: true,
          description: "EN: enable url_context companion tool / PT-BR: ativa ferramenta url_context",
          examples: [true, false],
        },
        include_grounding_metadata: {
          type: "boolean",
          default: true,
          description: "EN: include groundingMetadata in response / PT-BR: inclui groundingMetadata na resposta",
          examples: [true],
        },
      },
    },
    endpoints: {
      type: "object",
      additionalProperties: false,
      description:
        "EN: Override Antigravity endpoints. Observer warns: must use https and googleapis.com for bypass. / PT-BR: Sobrescreve endpoints Antigravity. Aviso: deve usar https e googleapis.com para bypass.",
      properties: {
        prod: {
          type: "string",
          format: "uri",
          default: "https://cloudcode-pa.googleapis.com",
          description: "EN: PROD endpoint / PT-BR: endpoint PROD",
          examples: ["https://cloudcode-pa.googleapis.com"],
        },
        daily: {
          type: "string",
          format: "uri",
          default: "https://daily-cloudcode-pa.googleapis.com",
          description: "EN: DAILY endpoint / PT-BR: endpoint DAILY",
          examples: ["https://daily-cloudcode-pa.googleapis.com"],
        },
        sandbox: {
          type: "string",
          format: "uri",
          default: "https://daily-cloudcode-pa.sandbox.googleapis.com",
          description: "EN: SANDBOX endpoint / PT-BR: endpoint SANDBOX",
          examples: ["https://daily-cloudcode-pa.sandbox.googleapis.com"],
        },
        autopush: {
          type: "string",
          format: "uri",
          default: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
          description: "EN: AUTOPUSH optional / PT-BR: AUTOPUSH opcional",
          examples: ["https://autopush-cloudcode-pa.sandbox.googleapis.com"],
        },
        quota: {
          type: "string",
          format: "uri",
          description: "EN: quota endpoint override / PT-BR: override endpoint quota",
          examples: ["https://cloudcode-pa.googleapis.com"],
        },
        models: {
          type: "string",
          format: "uri",
          description: "EN: models endpoint override / PT-BR: override endpoint modelos",
          examples: ["https://cloudcode-pa.googleapis.com"],
        },
        gemini_cli: {
          type: "string",
          format: "uri",
          description: "EN: Gemini CLI companion endpoint / PT-BR: endpoint Gemini CLI",
          examples: ["https://cloudaicompanion.googleapis.com"],
        },
        cloud_companion: {
          type: "string",
          format: "uri",
          description: "EN: cloudaicompanion.googleapis.com / PT-BR: cloudaicompanion.googleapis.com",
          examples: ["https://cloudaicompanion.googleapis.com"],
        },
        generate: {
          type: "string",
          format: "uri",
          description: "EN: generateContent base / PT-BR: base generateContent",
          examples: ["https://cloudcode-pa.googleapis.com"],
        },
        stream_generate: {
          type: "string",
          format: "uri",
          description: "EN: streamGenerateContent base / PT-BR: base streamGenerateContent",
          examples: ["https://cloudcode-pa.googleapis.com"],
        },
      },
    },
    quota: {
      type: "object",
      additionalProperties: false,
      description: "EN: Quota config / PT-BR: Config de quota",
      properties: {
        refresh_interval_minutes: {
          type: "integer",
          minimum: 1,
          maximum: 120,
          default: 15,
          examples: [15],
        },
        cache_ttl_minutes: {
          type: "integer",
          minimum: 1,
          maximum: 60,
          default: 15,
          examples: [15],
        },
        soft_threshold: {
          type: "number",
          minimum: 0.1,
          maximum: 1.0,
          default: 0.9,
          examples: [0.9],
        },
        hard_threshold: {
          type: "number",
          minimum: 0.5,
          maximum: 1.0,
          default: 1.0,
          examples: [1.0],
        },
        dual_pool: {
          type: "boolean",
          default: true,
          description: "EN: enable dual pool Antigravity + Gemini CLI / PT-BR: ativa dual pool Antigravity + Gemini CLI",
          examples: [true],
        },
      },
    },
    bypass: {
      type: "object",
      additionalProperties: false,
      description:
        "EN: Bypass metadata — documents how library imitates Antigravity traffic. UA must match antigravity/{semver} {os}/{arch}. / PT-BR: Metadados bypass — documenta como biblioteca imita tráfego Antigravity. UA deve coincidir antigravity/{semver} {os}/{arch}.",
      properties: {
        version_fallback: {
          type: "string",
          pattern: "^\\d+\\.\\d+\\.\\d+",
          default: "1.19.2",
          examples: ["1.19.2"],
        },
        min_supported: {
          type: "string",
          pattern: "^\\d+\\.\\d+\\.\\d+",
          default: "1.15.8",
          examples: ["1.15.8"],
        },
        user_agent: {
          type: "string",
          default: "antigravity/1.19.2",
          description: "EN: full UA, should contain antigravity/ prefix / PT-BR: UA completo, deve conter prefixo antigravity/",
          examples: ["antigravity/1.19.2 darwin/arm64", "antigravity/1.19.2 linux/x64"],
        },
        strip_user_project_header: {
          type: "boolean",
          default: true,
          description: "EN: strip x-goog-user-project to avoid 403 / PT-BR: remove x-goog-user-project para evitar 403",
          examples: [true],
        },
        fingerprint_jitter: {
          type: "boolean",
          default: true,
          examples: [true],
        },
        pid_offset: {
          type: "boolean",
          default: false,
          examples: [false, true],
        },
      },
    },
    fallback_project_id: {
      type: "string",
      minLength: 3,
      default: "rising-fact-p41fc",
      description: "EN: fallback project id blinded / PT-BR: project id fallback blindado",
      examples: ["rising-fact-p41fc"],
    },
    default_model: {
      type: "string",
      default: "antigravity-gemini-3-flash",
      description: "EN: default chat model 2026 / PT-BR: modelo padrão chat 2026",
      examples: ["antigravity-gemini-3-flash", "gemini-3-pro-preview"],
    },
    search_model: {
      type: "string",
      default: "gemini-3-flash",
      description: "EN: search grounding model / PT-BR: modelo de grounding de pesquisa",
      examples: ["gemini-3-flash", "gemini-3-flash-preview"],
    },
    client_id: {
      type: ["string", "null"],
      default: null,
      description: "EN: OAuth client_id override (public) / PT-BR: override client_id OAuth (público)",
      examples: [null, "1071006060591-...apps.googleusercontent.com"],
    },
    client_secret: {
      type: ["string", "null"],
      default: null,
      description: "EN: OAuth client_secret override — do not commit / PT-BR: override client_secret — não comitar",
      examples: [null],
    },
    accounts_file: {
      type: ["string", "null"],
      default: null,
      format: "uri-reference",
      description: "EN: custom accounts file path / PT-BR: caminho custom arquivo de contas",
      examples: [null, "~/.config/opencode/antigravity-accounts.json"],
    },
    models_allowlist: {
      type: "array",
      items: { type: "string" },
      default: [],
      description: "EN: optional model allowlist / PT-BR: allowlist opcional de modelos",
      examples: [[], ["antigravity-gemini-3-flash", "claude-opus-4-6-thinking"]],
    },
    strip_user_project: {
      type: "boolean",
      default: true,
      description: "EN: legacy alias for bypass.strip_user_project_header / PT-BR: alias legado para bypass.strip_user_project_header",
      examples: [true],
    },
  },
  required: [],
} as const;

// ---------------------------------------------------------------------------
// Path resolution — third-person, no side effects here
// ---------------------------------------------------------------------------

/**
 * The observer resolves config directory honoring OPENCODE_CONFIG_DIR.
 */
export function resolveConfigDir(): string {
  const env = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (env && env.length > 0) return path.resolve(env);
  return path.join(os.homedir(), ".config", "opencode");
}

/**
 * Resolves full antigravity.json path.
 * @param customPath - optional explicit path from caller
 */
export function resolveConfigPath(customPath?: string): string {
  if (customPath && customPath.trim().length > 0) {
    return path.resolve(customPath.trim());
  }
  return path.join(resolveConfigDir(), CONFIG_FILE_NAME);
}

/**
 * Ensures directory exists, idempotent, 0755.
 */
async function ensureDir(dir: string): Promise<void> {
  try {
    await fsp.mkdir(dir, { recursive: true, mode: DIR_MODE });
    // chmod best-effort to 0755 even if existed
    try {
      await fsp.chmod(dir, DIR_MODE);
    } catch {}
  } catch (err: any) {
    // if mkdir fails because exists as file, throw production error
    if (err?.code !== "EEXIST") throw err;
  }
}

// ---------------------------------------------------------------------------
// Atomic write — tmp + chmod 600 + rename
// ---------------------------------------------------------------------------

/**
 * Atomic write helper.
 * The observer writes to a temp sibling file then renames, to avoid partial reads.
 * @param targetPath - final destination
 * @param content - string content to write
 */
async function atomicWriteFileAtomic(targetPath: string, content: string): Promise<void> {
  const dir = path.dirname(targetPath);
  await ensureDir(dir);
  const random = crypto.randomBytes(6).toString("hex");
  const tmp = path.join(dir, `.${path.basename(targetPath)}.${process.pid}.${random}.tmp`);

  try {
    await fsp.writeFile(tmp, content, { encoding: "utf8", mode: FILE_MODE });
    try {
      await fsp.chmod(tmp, FILE_MODE);
    } catch {}
    // fsync dir? best-effort not critical for this config — production tolerant
    await fsp.rename(tmp, targetPath);
    // final chmod on target for existing file overwrite case
    try {
      await fsp.chmod(targetPath, FILE_MODE);
    } catch {}
  } finally {
    // cleanup tmp if rename failed
    try {
      await fsp.unlink(tmp);
    } catch {}
  }
}

// ---------------------------------------------------------------------------
// Helpers — url validation, deep merge, redaction
// ---------------------------------------------------------------------------

function isValidUri(u: string): boolean {
  try {
    const url = new URL(u);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/**
 * Deep merge defaults ← override, observer keeps primitives from override when defined.
 */
function deepMerge<T extends Record<string, any>>(defaults: T, override: Partial<T>): T {
  const out: any = { ...defaults };
  for (const k of Object.keys(override)) {
    const ov = (override as any)[k];
    if (ov === undefined) continue;
    const dv = (defaults as any)[k];
    if (isObject(dv) && isObject(ov) && !Array.isArray(dv) && !Array.isArray(ov)) {
      out[k] = deepMerge(dv as any, ov as any);
    } else {
      out[k] = ov;
    }
  }
  return out as T;
}

function redactedCopy(cfg: AntigravityConfig): AntigravityConfig {
  const c: any = { ...cfg };
  if (c.client_secret) c.client_secret = "***REDACTED***";
  return c;
}

// ---------------------------------------------------------------------------
// Validation — produção-ready, no placeholders
// ---------------------------------------------------------------------------

export interface ValidationError {
  path: string;
  message: string;
  value?: unknown;
}

export class ConfigValidationError extends Error {
  public readonly errors: ValidationError[];
  constructor(message: string, errors: ValidationError[]) {
    super(message);
    this.name = "ConfigValidationError";
    this.errors = errors;
  }
}

/**
 * Validates config strictly for production.
 * The observer collects all errors before throwing, to give full feedback.
 *
 * @param input - raw parsed json
 * @returns sanitized AntigravityConfig
 * @throws ConfigValidationError when invalid
 */
export function validate(input: unknown): AntigravityConfig {
  const result = validateInternal(input);
  if (!result.valid) {
    throw new ConfigValidationError(`config validation failed: ${result.errors.map((e) => `${e.path}: ${e.message}`).join("; ")}`, result.errors);
  }
  return result.config!;
}

export function validateConfig(input: unknown): { valid: boolean; errors: ValidationError[]; config?: AntigravityConfig } {
  return validateInternal(input);
}

function validateInternal(input: unknown): { valid: boolean; errors: ValidationError[]; config?: AntigravityConfig } {
  const errors: ValidationError[] = [];
  const defaults = getDefaultConfig();

  if (!isObject(input)) {
    errors.push({ path: "$", message: "must be object", value: input });
    return { valid: false, errors };
  }

  const raw = input as Record<string, unknown>;
  const out: AntigravityConfig = { ...defaults } as any;

  // helper to push error
  const err = (p: string, msg: string, v?: unknown) => errors.push({ path: p, message: msg, value: v });

  // version
  if (raw.version !== undefined) {
    if (!Number.isInteger(raw.version) || (raw.version as number) < 1 || (raw.version as number) > 10) {
      err("version", "must be integer 1-10", raw.version);
    } else {
      out.version = raw.version as number;
    }
  }

  // cli_first boolean — required by prompt
  if (raw.cli_first !== undefined) {
    if (typeof raw.cli_first !== "boolean") err("cli_first", "must be boolean", raw.cli_first);
    else out.cli_first = raw.cli_first;
  }

  // pid_offset_enabled boolean — required
  if (raw.pid_offset_enabled !== undefined) {
    if (typeof raw.pid_offset_enabled !== "boolean") err("pid_offset_enabled", "must be boolean", raw.pid_offset_enabled);
    else out.pid_offset_enabled = raw.pid_offset_enabled as boolean;
  }

  // quota_refresh_interval_minutes integer 1-120
  if (raw.quota_refresh_interval_minutes !== undefined) {
    if (!Number.isInteger(raw.quota_refresh_interval_minutes) || (raw.quota_refresh_interval_minutes as number) < 1 || (raw.quota_refresh_interval_minutes as number) > 120) {
      err("quota_refresh_interval_minutes", "must be integer 1-120", raw.quota_refresh_interval_minutes);
    } else {
      out.quota_refresh_interval_minutes = raw.quota_refresh_interval_minutes as number;
    }
  }

  // rotation_strategy enum
  const checkRotation = (val: unknown, p: string): RotationStrategy | null => {
    if (val === undefined) return null;
    if (typeof val !== "string" || !(ROTATION_STRATEGIES as readonly string[]).includes(val)) {
      err(p, `must be one of ${ROTATION_STRATEGIES.join(", ")}`, val);
      return null;
    }
    return val as RotationStrategy;
  };
  const rs = checkRotation(raw.rotation_strategy, "rotation_strategy");
  if (rs) {
    out.rotation_strategy = rs;
    out.account_rotation = rs; // keep alias in sync
  }
  const ar = checkRotation(raw.account_rotation, "account_rotation");
  if (ar) {
    out.account_rotation = ar;
    // if rotation_strategy not set, mirror
    if (raw.rotation_strategy === undefined) out.rotation_strategy = ar;
  }

  // debug boolean | object
  if (raw.debug !== undefined) {
    const d = raw.debug;
    if (typeof d === "boolean") {
      out.debug = d;
    } else if (isObject(d)) {
      const obj: DebugObjectConfig = {};
      const dRec = d as Record<string, unknown>;
      if (dRec.enabled !== undefined) {
        if (typeof dRec.enabled !== "boolean") err("debug.enabled", "must be boolean", dRec.enabled);
        else obj.enabled = dRec.enabled;
      }
      if (dRec.level !== undefined) {
        const levels = ["debug", "info", "warn", "error", "silent"];
        if (typeof dRec.level !== "string" || !levels.includes(dRec.level)) err("debug.level", `must be ${levels.join("|")}`, dRec.level);
        else obj.level = dRec.level as DebugLevel;
      }
      if (dRec.log_file !== undefined) {
        if (dRec.log_file !== null && typeof dRec.log_file !== "string") err("debug.log_file", "must be string|null", dRec.log_file);
        else obj.log_file = dRec.log_file as string | null;
      }
      if (dRec.retain_days !== undefined) {
        if (!Number.isInteger(dRec.retain_days) || (dRec.retain_days as number) < 1 || (dRec.retain_days as number) > 90) err("debug.retain_days", "must be integer 1-90", dRec.retain_days);
        else obj.retain_days = dRec.retain_days as number;
      }
      if (dRec.max_bytes !== undefined) {
        if (!Number.isInteger(dRec.max_bytes) || (dRec.max_bytes as number) < 1024 || (dRec.max_bytes as number) > 100 * 1024 * 1024) err("debug.max_bytes", "must be 1024-104857600", dRec.max_bytes);
        else obj.max_bytes = dRec.max_bytes as number;
      }
      if (dRec.tui_buffer_lines !== undefined) {
        if (!Number.isInteger(dRec.tui_buffer_lines) || (dRec.tui_buffer_lines as number) < 10 || (dRec.tui_buffer_lines as number) > 10000)
          err("debug.tui_buffer_lines", "must be 10-10000", dRec.tui_buffer_lines);
        else obj.tui_buffer_lines = dRec.tui_buffer_lines as number;
      }
      if (dRec.redact_secrets !== undefined) {
        if (typeof dRec.redact_secrets !== "boolean") err("debug.redact_secrets", "must be boolean", dRec.redact_secrets);
        else obj.redact_secrets = dRec.redact_secrets;
      }
      // check unknown keys inside debug
      const allowedDebugKeys = ["enabled", "level", "log_file", "retain_days", "max_bytes", "tui_buffer_lines", "redact_secrets"];
      for (const k of Object.keys(dRec)) {
        if (!allowedDebugKeys.includes(k)) err(`debug.${k}`, "unknown property", dRec[k]);
      }
      out.debug = deepMerge(DEFAULT_DEBUG_OBJECT as any, obj as any);
    } else {
      err("debug", "must be boolean or object", d);
    }
  }

  if (raw.debug_enabled !== undefined) {
    if (typeof raw.debug_enabled !== "boolean") err("debug_enabled", "must be boolean", raw.debug_enabled);
    else out.debug_enabled = raw.debug_enabled;
  }

  // google_search_enabled boolean
  if (raw.google_search_enabled !== undefined) {
    if (typeof raw.google_search_enabled !== "boolean") err("google_search_enabled", "must be boolean", raw.google_search_enabled);
    else out.google_search_enabled = raw.google_search_enabled;
  }

  if (raw.google_search !== undefined) {
    if (!isObject(raw.google_search)) {
      err("google_search", "must be object", raw.google_search);
    } else {
      const gsRaw = raw.google_search as Record<string, unknown>;
      const gs: GoogleSearchConfig = {};
      if (gsRaw.enabled !== undefined) {
        if (typeof gsRaw.enabled !== "boolean") err("google_search.enabled", "must be boolean", gsRaw.enabled);
        else gs.enabled = gsRaw.enabled;
      }
      if (gsRaw.model !== undefined) {
        if (typeof gsRaw.model !== "string" || (gsRaw.model as string).length < 2) err("google_search.model", "must be non-empty string", gsRaw.model);
        else gs.model = gsRaw.model;
      }
      if (gsRaw.url_context !== undefined) {
        if (typeof gsRaw.url_context !== "boolean") err("google_search.url_context", "must be boolean", gsRaw.url_context);
        else gs.url_context = gsRaw.url_context;
      }
      if (gsRaw.include_grounding_metadata !== undefined) {
        if (typeof gsRaw.include_grounding_metadata !== "boolean") err("google_search.include_grounding_metadata", "must be boolean", gsRaw.include_grounding_metadata);
        else gs.include_grounding_metadata = gsRaw.include_grounding_metadata;
      }
      for (const k of Object.keys(gsRaw)) {
        if (!["enabled", "model", "url_context", "include_grounding_metadata"].includes(k)) err(`google_search.${k}`, "unknown property", gsRaw[k]);
      }
      out.google_search = deepMerge(DEFAULT_GOOGLE_SEARCH as any, gs as any);
    }
  }

  // sync shortcut booleans with objects
  if (out.google_search_enabled !== undefined && out.google_search) {
    // if shortcut false, enforce object disabled
    if (out.google_search_enabled === false) {
      out.google_search.enabled = false;
    }
    if (out.google_search.enabled === false && out.google_search_enabled === true) {
      // object takes precedence, but mirror to shortcut for consistency
      out.google_search_enabled = false;
    }
  }
  if (out.debug !== undefined) {
    if (typeof out.debug === "boolean") {
      out.debug_enabled = out.debug;
    } else if (isObject(out.debug)) {
      out.debug_enabled = (out.debug as DebugObjectConfig).enabled ?? false;
    }
  }

  // endpoints overrides uri validation
  if (raw.endpoints !== undefined) {
    if (!isObject(raw.endpoints)) {
      err("endpoints", "must be object", raw.endpoints);
    } else {
      const epRaw = raw.endpoints as Record<string, unknown>;
      const ep: EndpointOverrides = {};
      const allowedEp = ["prod", "daily", "sandbox", "autopush", "quota", "models", "gemini_cli", "cloud_companion", "generate", "stream_generate"];
      for (const k of Object.keys(epRaw)) {
        if (!allowedEp.includes(k)) {
          err(`endpoints.${k}`, "unknown endpoint key", epRaw[k]);
          continue;
        }
        const v = epRaw[k];
        if (v === undefined) continue;
        if (typeof v !== "string" || !isValidUri(v)) {
          err(`endpoints.${k}`, "must be valid https uri", v);
        } else {
          (ep as any)[k] = v;
        }
      }
      out.endpoints = deepMerge(DEFAULT_ENDPOINTS as any, ep as any);
    }
  }

  // quota sub-config
  if (raw.quota !== undefined) {
    if (!isObject(raw.quota)) {
      err("quota", "must be object", raw.quota);
    } else {
      const qRaw = raw.quota as Record<string, unknown>;
      const q: QuotaConfig = {};
      if (qRaw.refresh_interval_minutes !== undefined) {
        if (!Number.isInteger(qRaw.refresh_interval_minutes) || (qRaw.refresh_interval_minutes as number) < 1 || (qRaw.refresh_interval_minutes as number) > 120)
          err("quota.refresh_interval_minutes", "must be 1-120", qRaw.refresh_interval_minutes);
        else q.refresh_interval_minutes = qRaw.refresh_interval_minutes as number;
      }
      if (qRaw.cache_ttl_minutes !== undefined) {
        if (!Number.isInteger(qRaw.cache_ttl_minutes) || (qRaw.cache_ttl_minutes as number) < 1 || (qRaw.cache_ttl_minutes as number) > 60)
          err("quota.cache_ttl_minutes", "must be 1-60", qRaw.cache_ttl_minutes);
        else q.cache_ttl_minutes = qRaw.cache_ttl_minutes as number;
      }
      if (qRaw.soft_threshold !== undefined) {
        if (typeof qRaw.soft_threshold !== "number" || (qRaw.soft_threshold as number) < 0.1 || (qRaw.soft_threshold as number) > 1)
          err("quota.soft_threshold", "must be 0.1-1.0", qRaw.soft_threshold);
        else q.soft_threshold = qRaw.soft_threshold as number;
      }
      if (qRaw.hard_threshold !== undefined) {
        if (typeof qRaw.hard_threshold !== "number" || (qRaw.hard_threshold as number) < 0.5 || (qRaw.hard_threshold as number) > 1)
          err("quota.hard_threshold", "must be 0.5-1.0", qRaw.hard_threshold);
        else q.hard_threshold = qRaw.hard_threshold as number;
      }
      if (qRaw.dual_pool !== undefined) {
        if (typeof qRaw.dual_pool !== "boolean") err("quota.dual_pool", "must be boolean", qRaw.dual_pool);
        else q.dual_pool = qRaw.dual_pool;
      }
      for (const k of Object.keys(qRaw)) {
        if (!["refresh_interval_minutes", "cache_ttl_minutes", "soft_threshold", "hard_threshold", "dual_pool"].includes(k))
          err(`quota.${k}`, "unknown property", qRaw[k]);
      }
      out.quota = deepMerge(DEFAULT_QUOTA as any, q as any);
      // sync top-level interval
      if (q.refresh_interval_minutes !== undefined) out.quota_refresh_interval_minutes = q.refresh_interval_minutes;
    }
  }

  // keep top-level interval synced to quota object if defined oppositely
  if (out.quota_refresh_interval_minutes !== undefined) {
    if (!out.quota) out.quota = { ...DEFAULT_QUOTA };
    out.quota.refresh_interval_minutes = out.quota_refresh_interval_minutes;
  }

  // bypass
  if (raw.bypass !== undefined) {
    if (!isObject(raw.bypass)) {
      err("bypass", "must be object", raw.bypass);
    } else {
      const bRaw = raw.bypass as Record<string, unknown>;
      const b: BypassMetadata = {};
      const semverRe = /^\d+\.\d+\.\d+/;
      if (bRaw.version_fallback !== undefined) {
        if (typeof bRaw.version_fallback !== "string" || !semverRe.test(bRaw.version_fallback))
          err("bypass.version_fallback", "must be semver x.y.z", bRaw.version_fallback);
        else b.version_fallback = bRaw.version_fallback;
      }
      if (bRaw.min_supported !== undefined) {
        if (typeof bRaw.min_supported !== "string" || !semverRe.test(bRaw.min_supported))
          err("bypass.min_supported", "must be semver", bRaw.min_supported);
        else b.min_supported = bRaw.min_supported;
      }
      if (bRaw.user_agent !== undefined) {
        if (typeof bRaw.user_agent !== "string" || !bRaw.user_agent.startsWith("antigravity/"))
          err("bypass.user_agent", "must start with antigravity/", bRaw.user_agent);
        else b.user_agent = bRaw.user_agent;
      }
      if (bRaw.strip_user_project_header !== undefined) {
        if (typeof bRaw.strip_user_project_header !== "boolean") err("bypass.strip_user_project_header", "must be boolean", bRaw.strip_user_project_header);
        else b.strip_user_project_header = bRaw.strip_user_project_header;
      }
      if (bRaw.fingerprint_jitter !== undefined) {
        if (typeof bRaw.fingerprint_jitter !== "boolean") err("bypass.fingerprint_jitter", "must be boolean", bRaw.fingerprint_jitter);
        else b.fingerprint_jitter = bRaw.fingerprint_jitter;
      }
      if (bRaw.pid_offset !== undefined) {
        if (typeof bRaw.pid_offset !== "boolean") err("bypass.pid_offset", "must be boolean", bRaw.pid_offset);
        else b.pid_offset = bRaw.pid_offset;
      }
      for (const k of Object.keys(bRaw)) {
        if (!["version_fallback", "min_supported", "user_agent", "strip_user_project_header", "fingerprint_jitter", "pid_offset"].includes(k))
          err(`bypass.${k}`, "unknown property", bRaw[k]);
      }
      out.bypass = deepMerge(DEFAULT_BYPASS as any, b as any);
      // sync pid_offset_enabled
      if (b.pid_offset !== undefined) out.pid_offset_enabled = b.pid_offset;
    }
  }
  if (out.pid_offset_enabled !== undefined) {
    if (!out.bypass) out.bypass = { ...DEFAULT_BYPASS };
    out.bypass.pid_offset = out.pid_offset_enabled;
  }

  // fallback_project_id
  if (raw.fallback_project_id !== undefined) {
    if (typeof raw.fallback_project_id !== "string" || (raw.fallback_project_id as string).length < 3)
      err("fallback_project_id", "must be string length >=3", raw.fallback_project_id);
    else out.fallback_project_id = raw.fallback_project_id;
  }

  // default_model / search_model
  if (raw.default_model !== undefined) {
    if (typeof raw.default_model !== "string" || (raw.default_model as string).length < 3) err("default_model", "must be string", raw.default_model);
    else out.default_model = raw.default_model;
  }
  if (raw.search_model !== undefined) {
    if (typeof raw.search_model !== "string" || (raw.search_model as string).length < 3) err("search_model", "must be string", raw.search_model);
    else out.search_model = raw.search_model;
  }

  // client_id / secret
  if (raw.client_id !== undefined) {
    if (raw.client_id !== null && typeof raw.client_id !== "string") err("client_id", "must be string|null", raw.client_id);
    else out.client_id = raw.client_id as string | null;
  }
  if (raw.client_secret !== undefined) {
    if (raw.client_secret !== null && typeof raw.client_secret !== "string") err("client_secret", "must be string|null", raw.client_secret);
    else out.client_secret = raw.client_secret as string | null;
  }

  if (raw.accounts_file !== undefined) {
    if (raw.accounts_file !== null && typeof raw.accounts_file !== "string") err("accounts_file", "must be string|null", raw.accounts_file);
    else out.accounts_file = raw.accounts_file as string | null;
  }

  if (raw.models_allowlist !== undefined) {
    if (!Array.isArray(raw.models_allowlist) || !(raw.models_allowlist as unknown[]).every((v) => typeof v === "string"))
      err("models_allowlist", "must be string[]", raw.models_allowlist);
    else out.models_allowlist = raw.models_allowlist as string[];
  }

  if (raw.strip_user_project !== undefined) {
    if (typeof raw.strip_user_project !== "boolean") err("strip_user_project", "must be boolean", raw.strip_user_project);
    else out.strip_user_project = raw.strip_user_project;
  }

  // $schema field optional uri
  if (raw.$schema !== undefined) {
    if (typeof raw.$schema !== "string") err("$schema", "must be string uri", raw.$schema);
    else out.$schema = raw.$schema;
  }

  // top-level unknown keys detection — strict production
  const allowedTop = [
    "$schema",
    "version",
    "cli_first",
    "pid_offset_enabled",
    "quota_refresh_interval_minutes",
    "rotation_strategy",
    "account_rotation",
    "debug",
    "debug_enabled",
    "google_search_enabled",
    "google_search",
    "endpoints",
    "quota",
    "bypass",
    "fallback_project_id",
    "default_model",
    "search_model",
    "client_id",
    "client_secret",
    "accounts_file",
    "models_allowlist",
    "strip_user_project",
  ];
  for (const k of Object.keys(raw)) {
    if (!allowedTop.includes(k)) err(k, "unknown property — strict schema", raw[k]);
  }

  const valid = errors.length === 0;
  return { valid, errors, config: valid ? (out as AntigravityConfig) : undefined };
}

// ---------------------------------------------------------------------------
// Defaults export
// ---------------------------------------------------------------------------

/**
 * The observer returns fresh defaults without leaking references.
 */
export function defaults(): AntigravityConfig {
  return getDefaultConfig();
}

// ---------------------------------------------------------------------------
// Load / Save — atomic chmod 600, production ready
// ---------------------------------------------------------------------------

/**
 * Loads config from ~/.config/opencode/antigravity.json
 * If file missing, observer returns defaults silently.
 * If corrupted, throws ConfigValidationError with path context.
 *
 * @param customPath - optional override
 */
export async function loadConfig(customPath?: string): Promise<AntigravityConfig> {
  const fp = resolveConfigPath(customPath);
  try {
    await fsp.access(fp, fs.constants.F_OK);
  } catch {
    // file does not exist — return defaults
    return getDefaultConfig();
  }

  let rawText: string;
  try {
    rawText = await fsp.readFile(fp, "utf8");
  } catch (e: any) {
    throw new Error(`cannot read config ${fp}: ${e?.message ?? String(e)}`);
  }

  if (!rawText.trim()) {
    return getDefaultConfig();
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawText);
  } catch (e: any) {
    throw new ConfigValidationError(`invalid JSON in ${fp}: ${e?.message ?? String(e)}`, [
      { path: "$", message: `json parse error: ${e?.message}` },
    ]);
  }

  // merge defaults ← parsed before validation to allow partial files
  const merged = deepMerge(getDefaultConfig() as any, parsed as any);
  const checked = validateInternal(merged);
  if (!checked.valid) {
    throw new ConfigValidationError(`config validation failed for ${fp}: ${checked.errors.map((er) => `${er.path} ${er.message}`).join(", ")}`, checked.errors);
  }
  return checked.config!;
}

/**
 * Saves config atomically with chmod 600.
 * The observer ensures dir 0755 and file 0600, redacting secrets only in logs, not on disk.
 *
 * @param cfg - partial or full config, will be merged with defaults then validated
 * @param customPath - optional override
 * @returns written file path
 */
export async function saveConfig(cfg: Partial<AntigravityConfig> | AntigravityConfig, customPath?: string): Promise<string> {
  const fp = resolveConfigPath(customPath);
  // merge defaults + incoming, then validate
  const base = getDefaultConfig();
  const toSave = deepMerge(base as any, (cfg ?? {}) as any) as AntigravityConfig;

  const checked = validateInternal(toSave);
  if (!checked.valid) {
    throw new ConfigValidationError(`cannot save invalid config: ${checked.errors.map((er) => `${er.path} ${er.message}`).join(", ")}`, checked.errors);
  }

  const finalCfg = checked.config!;

  // ensure file does not contain undefined, JSON.stringify handles
  const content = JSON.stringify(finalCfg, null, 2) + "\n";

  await atomicWriteFileAtomic(fp, content);

  // for observability, log redacted version if debug enabled
  try {
    if (finalCfg.debug_enabled || (typeof finalCfg.debug === "object" && (finalCfg.debug as DebugObjectConfig).enabled)) {
      const redacted = redactedCopy(finalCfg);
      // observer does not throw on console failure
      if (typeof console !== "undefined" && console.debug) {
        console.debug(`[antigravity-auth] config saved ${fp}`, redacted);
      }
    }
  } catch {}

  return fp;
}

// ---------------------------------------------------------------------------
// Sync variants for CLI entry points that need sync read at startup
// ---------------------------------------------------------------------------

/**
 * Sync load — for CLI bootstrap where async not convenient.
 * Same semantics as loadConfig but sync.
 */
export function loadConfigSync(customPath?: string): AntigravityConfig {
  const fp = resolveConfigPath(customPath);
  try {
    fs.accessSync(fp, fs.constants.F_OK);
  } catch {
    return getDefaultConfig();
  }
  try {
    const txt = fs.readFileSync(fp, "utf8");
    if (!txt.trim()) return getDefaultConfig();
    const parsed = JSON.parse(txt);
    const merged = deepMerge(getDefaultConfig() as any, parsed as any);
    const checked = validateInternal(merged);
    if (!checked.valid) {
      throw new ConfigValidationError(`config validation failed for ${fp}`, checked.errors);
    }
    return checked.config!;
  } catch (e: any) {
    if (e instanceof ConfigValidationError) throw e;
    throw new Error(`cannot read config ${fp}: ${e?.message ?? String(e)}`);
  }
}

/**
 * Sync save atomic — writes tmp, chmod, rename.
 */
export function saveConfigSync(cfg: Partial<AntigravityConfig> | AntigravityConfig, customPath?: string): string {
  const fp = resolveConfigPath(customPath);
  const base = getDefaultConfig();
  const toSave = deepMerge(base as any, (cfg ?? {}) as any) as AntigravityConfig;
  const checked = validateInternal(toSave);
  if (!checked.valid) {
    throw new ConfigValidationError(`cannot save invalid config: ${checked.errors.map((er) => er.path).join(",")}`, checked.errors);
  }
  const finalCfg = checked.config!;
  const content = JSON.stringify(finalCfg, null, 2) + "\n";
  const dir = path.dirname(fp);
  try {
    fs.mkdirSync(dir, { recursive: true, mode: DIR_MODE });
  } catch {}
  try {
    fs.chmodSync(dir, DIR_MODE);
  } catch {}
  const random = crypto.randomBytes(6).toString("hex");
  const tmp = path.join(dir, `.${path.basename(fp)}.${process.pid}.${random}.tmp`);
  try {
    fs.writeFileSync(tmp, content, { encoding: "utf8", mode: FILE_MODE });
    try {
      fs.chmodSync(tmp, FILE_MODE);
    } catch {}
    fs.renameSync(tmp, fp);
    try {
      fs.chmodSync(fp, FILE_MODE);
    } catch {}
  } finally {
    try {
      fs.unlinkSync(tmp);
    } catch {}
  }
  return fp;
}

// ---------------------------------------------------------------------------
// Exports barrel
// ---------------------------------------------------------------------------

export const Config = {
  resolveConfigDir,
  resolveConfigPath,
  getDefaultConfig,
  defaults,
  validate,
  validateConfig,
  loadConfig,
  saveConfig,
  loadConfigSync,
  saveConfigSync,
  schema: ANTIGRAVITY_CONFIG_JSON_SCHEMA,
  defaultsRaw: CONFIG_DEFAULTS,
};

export default Config;

// Compatibility alias for older imports
export const SCHEMA = ANTIGRAVITY_CONFIG_JSON_SCHEMA;
