/**
 * @file plugin.ts
 * @description Main entry, fetch interceptor, credential load, OAuth PKCE, account rotation, quota, auto-recovery, version dynamic, models 2026.
 * observer third-person, library-first root-first, direct cloudcode-pa no localhost v1, node:* only + fetch.
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";
import { randomInt } from "node:crypto";

// internal modules
import { ANTIGRAVITY_VERSION_FALLBACK, getDynamicUserAgent, ANTIGRAVITY_ENDPOINTS, PROJECT_FALLBACK, OAUTH_SCOPES } from "./constants.js";
import { FingerprintGenerator } from "./fingerprint.js";
import { AccountManager, type Account } from "./accounts.js";
import { resolveProjectId } from "./project.js";
import { QuotaManager, mapModelToGroup } from "./quota.js";
import { DebugLogger } from "./debug.js";
import { loadConfig, type AntigravityConfig } from "./config.js";
import { getVersion } from "./version.js";
import { transformRequest, buildAntigravityRequest, buildGeminiCLIRequest, isGeminiCLIOnlyModel, fetchWithCascade } from "./request.js";
import { SSEParser, normalizePayloads, transformToOpenAI, transformToAnthropic, withAutoRecovery as withAutoRecoveryStream, globalThinkingSignatureCache } from "./streaming.js";
import { withAutoRecovery, detectErrorType, getRecoveryStrategy, preserveThinkingSignature } from "./recovery.js";
import { executeSearch } from "./search.js";

const logger = DebugLogger.getInstance();

export type PluginOptions = {
  cli_first?: boolean;
  pid_offset_enabled?: boolean;
  google_search_enabled?: boolean;
  quota_refresh_interval_minutes?: number;
  rotation_strategy?: "round-robin" | "sticky";
  debug?: boolean;
};

export const PLUGIN_ID = "opencode-antigravity-auth-next" as const;
export const PLUGIN_VERSION = "2.0.0" as const;

const MODELS_2026 = [
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3.1-pro",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-sonnet-4-6",
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "claude-opus-4-6-thinking",
  "claude-sonnet-4-6",
] as const;

type FetchInterceptor = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

class AntigravityPlugin {
  private accountManager: AccountManager;
  private quotaManager: QuotaManager;
  private fingerprint: FingerprintGenerator;
  private config: AntigravityConfig;
  private options: PluginOptions;
  private version: string = ANTIGRAVITY_VERSION_FALLBACK;
  private initialized = false;

  constructor(options: PluginOptions = {}) {
    this.options = options;
    this.accountManager = new AccountManager();
    this.quotaManager = new QuotaManager();
    this.fingerprint = new FingerprintGenerator();
    this.config = loadConfig();
  }

  async init(): Promise<void> {
    if (this.initialized) return;
    try {
      this.version = await getVersion().catch(() => ANTIGRAVITY_VERSION_FALLBACK);
    } catch { this.version = ANTIGRAVITY_VERSION_FALLBACK; }
    await this.accountManager.load().catch(() => {});
    this.initialized = true;
    logger.info("plugin initialized", { version: this.version, models: MODELS_2026.length });
  }

  private getUserAgent(): string {
    try {
      return getDynamicUserAgent(this.version);
    } catch {
      return `antigravity/${this.version} linux/x64`;
    }
  }

  private shouldHandleModel(model: string): boolean {
    if (!model) return false;
    const lower = model.toLowerCase();
    return lower.includes("antigravity") || lower.includes("gemini") || lower.includes("claude") || MODELS_2026.some(m => lower.includes(m.toLowerCase()));
  }

  private async getAccountForModel(model: string): Promise<Account | null> {
    const group = mapModelToGroup(model);
    // cli_first option: prefer gemini-cli pool for gemini models
    const preferCliFirst = this.options.cli_first ?? (this.config as any)?.cli_first ?? false;
    let account: Account | null = null;

    // try get next account that not exhausted
    for (let i = 0; i < 10; i++) {
      const candidate = await this.accountManager.getNextAccount(this.options.rotation_strategy ?? "round-robin").catch(() => null);
      if (!candidate) break;
      if (this.quotaManager.shouldSkipAccount(candidate.email, model)) {
        continue;
      }
      account = candidate;
      break;
    }
    if (!account) {
      // fallback any account
      account = await this.accountManager.getNextAccount().catch(() => null);
    }
    return account;
  }

  private async refreshIfNeeded(account: Account): Promise<string> {
    // returns access token
    if (account.accessToken && account.expiry && Date.now() < account.expiry - 5 * 60 * 1000) {
      return account.accessToken;
    }
    // refresh via account manager
    const refreshed = await (this.accountManager as any).refreshAccount?.(account.email).catch(() => null) ?? null;
    if (refreshed?.accessToken) return refreshed.accessToken;
    // try generic refresh using oauth module if available
    try {
      const { refreshAccessToken } = await import("./oauth.js");
      const tokens = await refreshAccessToken(account.refreshToken);
      if (tokens?.access_token) {
        account.accessToken = tokens.access_token;
        account.expiry = Date.now() + (tokens.expires_in ?? 3600) * 1000;
        await this.accountManager.save().catch(() => {});
        return tokens.access_token;
      }
    } catch {}
    if (account.accessToken) return account.accessToken;
    throw new Error(`no access token for ${account.email}`);
  }

  async handleFetch(originalFetch: typeof fetch, input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    await this.init();
    const urlStr = typeof input === "string" ? input : input instanceof URL ? input.toString() : (input as Request).url ?? "";
    const bodyStr = (init?.body as string) ?? "";

    // quick check: only intercept google provider calls
    let model: string | undefined;
    try {
      if (bodyStr) {
        const json = JSON.parse(bodyStr);
        model = json?.model ?? json?.request?.model ?? json?.modelId ?? "";
      }
    } catch {}
    if (!model) {
      // also check url for model param? fallback try header
      if (!urlStr.includes("google") && !urlStr.includes("antigravity") && !urlStr.includes("gemini") && !urlStr.includes("claude")) {
        return originalFetch(input, init);
      }
    }
    const modelToCheck = model ?? urlStr;
    if (!this.shouldHandleModel(modelToCheck)) {
      return originalFetch(input, init);
    }

    // account selection
    const account = await this.getAccountForModel(modelToCheck);
    if (!account) {
      logger.error("no account available", { model: modelToCheck });
      return new Response(JSON.stringify({ error: "no antigravity account configured, run opencode auth login" }), { status: 401, headers: { "Content-Type": "application/json" } });
    }

    let accessToken: string;
    try {
      accessToken = await this.refreshIfNeeded(account);
    } catch (e: any) {
      logger.error("token refresh failed", { email: account.email, error: String(e) });
      return new Response(JSON.stringify({ error: `token refresh failed for ${account.email}: ${e.message}` }), { status: 401 });
    }

    // project id resolution
    let projectId = account.projectId ?? PROJECT_FALLBACK;
    try {
      const resolved = await resolveProjectId(accessToken, account.projectId, async (pid: string) => {
        // metadata saver
        account.projectId = pid;
        await this.accountManager.save().catch(() => {});
      });
      if (resolved) projectId = resolved;
    } catch (e) {
      logger.warn("project resolve failed, using fallback", { error: String(e), fallback: PROJECT_FALLBACK });
    }

    // parse incoming OpenAI/Anthropic request
    let messages: any[] = [];
    let tools: any[] = [];
    let system: string | undefined;
    let thinkingLevel: string | undefined;
    let googleSearchEnabled = this.options.google_search_enabled ?? true;

    try {
      if (bodyStr) {
        const json = JSON.parse(bodyStr);
        // OpenAI shape
        messages = json?.messages ?? json?.request?.contents ?? [];
        tools = json?.tools ?? json?.request?.tools ?? [];
        system = json?.system ?? json?.systemInstruction ?? json?.request?.systemInstruction;
        thinkingLevel = json?.thinkingLevel ?? json?.variant ?? json?.request?.thinkingLevel;
        // check provider model
        if (!model) model = json?.model ?? json?.request?.model;
      }
    } catch {}

    const effectiveModel = model ?? "antigravity-gemini-3-flash";
    const isCliOnly = isGeminiCLIOnlyModel(effectiveModel);
    const endpointBases = isCliOnly ? [ANTIGRAVITY_ENDPOINTS[2], ANTIGRAVITY_ENDPOINTS[0]] : [...ANTIGRAVITY_ENDPOINTS];

    // build request using request.ts
    let buildResult;
    try {
      const transformInput = {
        model: effectiveModel,
        messages,
        tools,
        system,
        thinkingLevel,
        googleSearchEnabled,
        projectId,
        sessionSeed: `${account.email}-${Date.now()}`,
        userPromptSeed: `${effectiveModel}-${Math.random()}`,
      };
      if (isCliOnly || this.options.cli_first) {
        buildResult = buildGeminiCLIRequest({
          model: effectiveModel,
          messages,
          tools,
          system,
          thinkingLevel,
          accessToken,
          projectId,
          endpointOverrides: endpointBases,
          userAgent: this.getUserAgent(),
        });
      } else {
        buildResult = buildAntigravityRequest({
          model: effectiveModel,
          messages,
          tools,
          system,
          thinkingLevel,
          accessToken,
          projectId,
          endpointOverrides: endpointBases,
          userAgent: this.getUserAgent(),
          googleSearchEnabled,
        });
      }
    } catch (e: any) {
      logger.error("transform failed", { error: String(e) });
      return new Response(JSON.stringify({ error: `transform failed: ${e.message}` }), { status: 400 });
    }

    // execute with cascade + auto-recovery
    const exec = async () => {
      const response = await fetchWithCascade(buildResult, { timeoutMs: 60000 });
      if (!response.ok) {
        const txt = await response.text().catch(() => "");
        // detect quota 429
        if (response.status === 429 || txt.toLowerCase().includes("quota") || txt.toLowerCase().includes("rate")) {
          this.quotaManager.refreshQuotaForAccount(account.email, accessToken, projectId, mapModelToGroup(effectiveModel));
          // mark exhausted
          (this.accountManager as any).markQuotaExhausted?.(account.email, 60 * 60 * 1000);
        }
        // if 403/404 retry handled inside fetchWithCascade, else throw
        if (response.status >= 400) {
          throw new Error(`upstream ${response.status}: ${txt.slice(0, 1000)}`);
        }
      }
      // schedule background quota refresh
      this.quotaManager.scheduleBackgroundRefresh(account.email, accessToken, projectId);

      // if streaming request, transform stream
      const contentType = response.headers.get("content-type") ?? "";
      if (contentType.includes("text/event-stream") || (init?.headers as any)?.Accept?.includes?.("text/event-stream") || true) {
        // always treat as SSE for opencode
        const isAnthropic = effectiveModel.toLowerCase().includes("claude");
        const parser = new SSEParser();
        const transformedStream = new ReadableStream({
          async start(controller) {
            const reader = response.body?.getReader();
            if (!reader) { controller.close(); return; }
            const decoder = new TextDecoder();
            try {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                const text = decoder.decode(value, { stream: true });
                const chunks = parser.parseChunk(text);
                for (const sse of chunks) {
                  const normalized = normalizePayloads(sse.data);
                  for (const payload of normalized) {
                    if (payload.thinking?.signature && payload.thinking?.text) {
                      preserveThinkingSignature(payload.thinking.text, payload.thinking.signature);
                    }
                    let outLine: string;
                    if (isAnthropic) {
                      outLine = `data: ${JSON.stringify(transformToAnthropic(payload))}\n\n`;
                    } else {
                      outLine = `data: ${JSON.stringify(transformToOpenAI(payload))}\n\n`;
                    }
                    controller.enqueue(new TextEncoder().encode(outLine));
                  }
                }
              }
              // flush
              const remaining = parser.flush();
              for (const sse of remaining) {
                const normalized = normalizePayloads(sse.data);
                for (const payload of normalized) {
                  const outLine = `data: ${JSON.stringify(isAnthropic ? transformToAnthropic(payload) : transformToOpenAI(payload))}\n\n`;
                  controller.enqueue(new TextEncoder().encode(outLine));
                }
              }
              controller.enqueue(new TextEncoder().encode(`data: [DONE]\n\n`));
              controller.close();
            } catch (e) {
              controller.error(e);
            }
          }
        });
        return new Response(transformedStream, {
          status: response.status,
          headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" },
        });
      }

      // non-streaming: transform JSON
      const json = await response.json().catch(async () => ({ text: await response.text() }));
      return new Response(JSON.stringify(json), { status: response.status, headers: { "Content-Type": "application/json" } });
    };

    try {
      return await withAutoRecovery(async (attempt, ctx) => {
        if (attempt > 0) logger.info("retrying with auto-recovery", { attempt, errorType: ctx?.errorType });
        return await exec();
      }, { maxRetries: 3 });
    } catch (e: any) {
      const errorType = detectErrorType(e);
      logger.error("all retries failed", { errorType, error: String(e) });
      // try fallback to other pool if cli_first enabled
      if (this.options.cli_first && !isCliOnly) {
        // fallback to gemini-cli
        try {
          const fallbackBuild = buildGeminiCLIRequest({
            model: effectiveModel,
            messages,
            tools,
            system,
            thinkingLevel,
            accessToken,
            projectId,
            endpointOverrides: [ANTIGRAVITY_ENDPOINTS[2]],
            userAgent: this.getUserAgent(),
          });
          const resp = await fetchWithCascade(fallbackBuild);
          return resp;
        } catch {}
      }
      return new Response(JSON.stringify({ error: `antigravity request failed after retries: ${e.message}`, errorType }), { status: 500 });
    }
  }

  getPluginDefinition() {
    const self = this;
    return {
      id: PLUGIN_ID,
      version: PLUGIN_VERSION,
      name: "Antigravity Auth Next",
      description: "Enable Opencode to authenticate against Antigravity via OAuth — supports gemini-3, claude-opus-4-6, dual quota, auto-recovery, direct cloudcode-pa (no localhost v1)",
      // opencode plugin hooks
      async onInit() { await self.init(); },
      hooks: {
        "tool.execute.before": async (ctx: any) => { return ctx; },
        "tool.execute.after": async (ctx: any) => { return ctx; },
        "fetch": async (input: RequestInfo | URL, init?: RequestInit, next: typeof fetch) => {
          // intercept fetch if matches google/antigravity
          return self.handleFetch(next, input, init);
        },
      },
      auth: {
        provider: "google",
        async login() {
          const { startOAuthFlow } = await import("./oauth.js");
          const result = await startOAuthFlow();
          if (!result?.refresh_token) throw new Error("OAuth failed no refresh_token");
          const email = result.email ?? `user-${Date.now()}@gmail.com`;
          await self.accountManager.addAccount?.({ email, refreshToken: result.refresh_token, accessToken: result.access_token } as any) ?? await (self.accountManager as any).add?.(email, result.refresh_token);
          await self.accountManager.save();
          return { email };
        },
        async list() { await self.init(); return (self.accountManager as any).list?.() ?? []; },
        async logout(email?: string) { if (email) await (self.accountManager as any).remove?.(email); else await (self.accountManager as any).clear?.(); await self.accountManager.save(); },
      },
      config: {
        schema: {
          cli_first: { type: "boolean", default: false, description: "Route Gemini models to Gemini CLI quota first (preserve Antigravity quota for Claude)" },
          pid_offset_enabled: { type: "boolean", default: false, description: "Enable PID offset trick 0-1000" },
          google_search_enabled: { type: "boolean", default: true },
          quota_refresh_interval_minutes: { type: "number", default: 15 },
          rotation_strategy: { type: "string", enum: ["round-robin", "sticky"], default: "round-robin" },
        },
        defaults: {
          cli_first: false,
          pid_offset_enabled: false,
          google_search_enabled: true,
          quota_refresh_interval_minutes: 15,
          rotation_strategy: "round-robin",
        },
      },
      models: MODELS_2026.map(m => ({
        id: m,
        name: m,
        provider: "google",
        context: m.includes("claude") ? 200000 : 1048576,
        output: m.includes("claude") ? 64000 : 65535,
        modalities: { input: ["text", "image", "pdf"], output: ["text"] },
      })),
    };
  }
}

// singleton export for opencode
let pluginInstance: AntigravityPlugin | null = null;

export function getPlugin(options?: PluginOptions): AntigravityPlugin {
  if (!pluginInstance) pluginInstance = new AntigravityPlugin(options);
  return pluginInstance;
}

export const plugin = getPlugin().getPluginDefinition();

export default plugin;
