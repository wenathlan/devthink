/**
 * @file quota.ts
 * @module opencode-antigravity-auth-next/quota
 * @description
 *  Third-person observer: the library watches how Antigravity Manager and
 *  Gemini CLI query quota via v1internal:retrieveUserQuotaSummary and mimics
 *  the fingerprint exactly, without running Antigravity itself. It parses
 *  resiliently across multiple server rollout shapes, handles dual pools
 *  (Antigravity + Gemini CLI), and maintains adaptive TTL cache (memory + file)
 *  with soft threshold 90% and config quota_refresh_interval_minutes.
 *
 *  Architecture:
 *  - library-first, root-first (no src/ nested), ESM, Node >=18
 *  - only node:* builtins + global fetch
 *  - endpoint cascade PROD/DAILY/SANDBOX with retry 403/404/5xx
 *  - atomic file writes chmod 600, temp+rename
 *  - FNV-1a deterministic hashing for token key, jitter 0-80ms already in fingerprint.ts
 *  - background refresh after requests + interval timer
 *  - model->group resolution, checkQuota, isQuotaExhausted, shouldSkipAccount
 *
 *  Date governance: 2026-08-25 — Canto do Buriti, PI, BR — v2.0.0
 *  Models 2026: gemini-3-pro-preview, gemini-3-flash-preview, gemini-3.1-pro-preview,
 *               gemini-2.5-pro/flash, claude-opus-4-6-thinking (low,max), claude-sonnet-4-6
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import * as os from "node:os";
import { createHash, randomInt } from "node:crypto";

// ---------------------------------------------------------------------------
// Blinded constants — observer never leaks real secrets in logs
// ---------------------------------------------------------------------------

/**
 * The observer notes three public OAuth client IDs circulating in binaries:
 * - 1071006060591-tmhssin2h21lcre235vtolojh4g403ep... (Antigravity primary, accounts.ts)
 * - 681255809395-oo8ft2oq6bda7b6t5a2prl1saaq1hhs... (Gemini CLI secondary)
 * - 681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j... (Gemini CLI official)
 * These are public client IDs (not confidential), distributed in public binaries.
 * Client secret is also public in those binaries but still blinded for log redaction.
 */
export const ANTIGRAVITY_CLIENT_ID =
  (process.env.ANTIGRAVITY_CLIENT_ID?.trim() ||
    process.env.GOOGLE_CLIENT_ID?.trim() ||
    "1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com") as const;

export const ANTIGRAVITY_CLIENT_ID_FALLBACK_SECONDARY =
  (process.env.ANTIGRAVITY_CLIENT_ID_SECONDARY?.trim() ||
    "681255809395-oo8ft2oq6bda7b6t5a2prl1saaq1hhs.apps.googleusercontent.com") as const;

export const GEMINI_CLI_CLIENT_ID =
  (process.env.GEMINI_CLI_CLIENT_ID?.trim() ||
    "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com") as const;

/**
 * Public client secrets — distributed with CLI. Blinded pattern GOCSPX-*
 * Observer marks them as blinded to signal they must be redacted in debug logs.
 */
export const ANTIGRAVITY_CLIENT_SECRET =
  (process.env.ANTIGRAVITY_CLIENT_SECRET?.trim() || "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") as const;

export const GEMINI_CLI_CLIENT_SECRET =
  (process.env.GEMINI_CLI_CLIENT_SECRET?.trim() || "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") as const;

export const ANTIGRAVITY_CLIENT_ID_IS_BLINDED = true as const;
export const ANTIGRAVITY_CLIENT_SECRET_IS_BLINDED = true as const;

/** Version fallback — governance requires 1.19.2 as last known to bypass ban */
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;
export const ANTIGRAVITY_VERSION_MIN = "1.15.8" as const;
export const ANTIGRAVITY_USER_AGENT_FALLBACK = `antigravity/${ANTIGRAVITY_VERSION_FALLBACK}` as const;

/** Build dynamic UA — observer reproduces {os}/{arch} coherence */
function normalizePlatform(p: string): string {
  switch (p) {
    case "darwin":
      return "darwin";
    case "win32":
      return "win32";
    case "linux":
      return "linux";
    default:
      return p;
  }
}
function normalizeArch(a: string): string {
  switch (a) {
    case "arm64":
      return "arm64";
    case "x64":
      return "x64";
    case "ia32":
      return "ia32";
    default:
      return a;
  }
}
export function getDynamicUserAgent(version?: string): string {
  const ver = version && /^\d+\.\d+\.\d+/.test(version) ? version.trim() : ANTIGRAVITY_VERSION_FALLBACK;
  const plat = normalizePlatform(os.platform());
  const arch = normalizeArch(os.arch());
  return `antigravity/${ver} ${plat}/${arch}`;
}

/** Client metadata template */
export const ANTIGRAVITY_CLIENT_METADATA_TEMPLATE = {
  ideType: "ANTIGRAVITY",
  platform: "PLATFORM_UNSPECIFIED",
  pluginType: "GEMINI",
  pluginVersion: "2.0.0",
} as const;

export function buildClientMetadata(version?: string): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  const plat = normalizePlatform(os.platform()).toUpperCase();
  const arch = normalizeArch(os.arch()).toUpperCase();
  const parts = [
    `ideType=${ANTIGRAVITY_CLIENT_METADATA_TEMPLATE.ideType}`,
    `platform=${plat}`,
    `ideVersion=${ver}`,
    `pluginVersion=${ANTIGRAVITY_CLIENT_METADATA_TEMPLATE.pluginVersion}`,
    `osVersion=${os.release()}`,
    `arch=${arch}`,
  ];
  return parts.join(",");
}

export function getXGoogApiClient(version?: string): string {
  const ver = version ?? ANTIGRAVITY_VERSION_FALLBACK;
  const nodeVer = process.versions.node;
  return `antigravity/${ver} gl-node/${nodeVer} gax/4.9.0 grpc/1.14.0`;
}

// ---------------------------------------------------------------------------
// Endpoints — direct cloudcode-pa, no localhost v1 proxy
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_ENDPOINTS = [
  "https://daily-cloudcode-pa.googleapis.com",
  "https://autopush-cloudcode-pa.sandbox.googleapis.com",
  "https://cloudcode-pa.googleapis.com",
] as const;

export const ANTIGRAVITY_ENDPOINT_FALLBACKS = [
  "https://cloudcode-pa.googleapis.com",
  "https://daily-cloudcode-pa.googleapis.com",
  "https://autopush-cloudcode-pa.sandbox.googleapis.com",
] as const;

export const GEMINI_CLI_ENDPOINT = "https://cloudcode-pa.googleapis.com" as const;
export const QUOTA_METHOD = "/v1internal:retrieveUserQuotaSummary" as const;
export const QUOTA_ENDPOINT = QUOTA_METHOD as const; // alias

export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;
export const PROJECT_ID_FALLBACK = PROJECT_FALLBACK as const;
export const PROJECT_NAME_FALLBACK = `projects/${PROJECT_FALLBACK}` as const;

// ---------------------------------------------------------------------------
// TTL / thresholds — adaptive 15min default, 2-10min dynamic, soft 90%
// ---------------------------------------------------------------------------

export const QUOTA_CACHE_TTL_MS = 15 * 60 * 1000 as const; // 15min default
export const QUOTA_CACHE_TTL_MIN_MS = 2 * 60 * 1000 as const; // 2min min
export const QUOTA_CACHE_TTL_MAX_MS = 10 * 60 * 1000 as const; // 10min max
export const QUOTA_SOFT_THRESHOLD = 0.9 as const; // 90% used => near exhausted
export const QUOTA_HARD_THRESHOLD = 1.0 as const; // 100%
export const QUOTA_TIMEOUT_MS = 15_000 as const;
export const JITTER_MIN_MS = 0 as const;
export const JITTER_MAX_MS = 80 as const;

export function getJitter(): number {
  try {
    return randomInt(JITTER_MIN_MS, JITTER_MAX_MS + 1);
  } catch {
    return Math.floor(Math.random() * (JITTER_MAX_MS - JITTER_MIN_MS + 1)) + JITTER_MIN_MS;
  }
}

// ---------------------------------------------------------------------------
// Models 2026 — full list with group mapping
// ---------------------------------------------------------------------------

export type QuotaGroup = "antigravity" | "gemini-cli" | "cloudaicompanion";

export interface AntigravityModelDefinition {
  readonly id: string;
  readonly displayName: string;
  readonly group: QuotaGroup;
  readonly contextWindow: number;
  readonly outputLimit: number;
  readonly supportsThinking: boolean;
  readonly supportsTools: boolean;
  readonly supportsVision: boolean;
  readonly isPreview: boolean;
  readonly isClaude: boolean;
}

export const ANTIGRAVITY_MODELS_2026 = [
  {
    id: "antigravity-gemini-3-pro",
    displayName: "Gemini 3 Pro (Antigravity)",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "antigravity-gemini-3-flash",
    displayName: "Gemini 3 Flash (Antigravity)",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "antigravity-gemini-3.1-pro",
    displayName: "Gemini 3.1 Pro (Antigravity)",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-2.5-flash",
    displayName: "Gemini 2.5 Flash",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-2.5-pro",
    displayName: "Gemini 2.5 Pro",
    group: "antigravity",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-3-flash-preview",
    displayName: "Gemini 3 Flash Preview",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "gemini-3-pro-preview",
    displayName: "Gemini 3 Pro Preview",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "gemini-3.1-pro-preview",
    displayName: "Gemini 3.1 Pro Preview",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "gemini-3.1-pro-preview-customtools",
    displayName: "Gemini 3.1 Pro Preview CustomTools",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: true,
    isClaude: false,
  },
  {
    id: "claude-opus-4-6-thinking",
    displayName: "Claude Opus 4.6 Thinking",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-opus-4-6-thinking-low",
    displayName: "Claude Opus 4.6 Thinking Low",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-opus-4-6-thinking-max",
    displayName: "Claude Opus 4.6 Thinking Max",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-sonnet-4-6",
    displayName: "Claude Sonnet 4.6",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  {
    id: "claude-opus-4-5-thinking",
    displayName: "Claude Opus 4.5 Thinking (Legacy)",
    group: "antigravity",
    contextWindow: 200_000,
    outputLimit: 64_000,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: true,
  },
  // Aliases bare gemini-3-* without antigravity- prefix — server accepts both
  {
    id: "gemini-3-flash",
    displayName: "Gemini 3 Flash",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-3-pro",
    displayName: "Gemini 3 Pro",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
  {
    id: "gemini-3.1-pro",
    displayName: "Gemini 3.1 Pro",
    group: "gemini-cli",
    contextWindow: 1_048_576,
    outputLimit: 65_535,
    supportsThinking: true,
    supportsTools: true,
    supportsVision: true,
    isPreview: false,
    isClaude: false,
  },
] as const satisfies readonly AntigravityModelDefinition[];

export const ANTIGRAVITY_MODEL_IDS_2026 = ANTIGRAVITY_MODELS_2026.map((m) => m.id) as unknown as readonly string[];
export const GEMINI_CLI_ONLY_MODELS = ANTIGRAVITY_MODELS_2026.filter((m) => m.group === "gemini-cli").map((m) => m.id) as readonly string[];

// ---------------------------------------------------------------------------
// Types — quota core
// ---------------------------------------------------------------------------

/**
 * Per-group quota pool stats — tolerant to multiple server shapes.
 * Observer keeps raw for debug but typed fields are normalized.
 */
export interface QuotaPoolStats {
  /** normalized group: antigravity | gemini-cli | cloudaicompanion */
  group: QuotaGroup | string;
  /** remaining tokens/requests if provided */
  remaining?: number;
  /** limit tokens/requests */
  limit?: number;
  /** fraction 0..1 remaining — most reliable for adaptive TTL */
  remainingFraction?: number;
  /** fraction 0..1 used — alternative */
  usedFraction?: number;
  /** reset epoch ms */
  resetAt?: number;
  /** reset ISO string if present */
  resetAtIso?: string;
  /** explicit exhausted flag */
  exhausted?: boolean;
  /** raw fragment that produced this pool — for debugging */
  raw?: unknown;
  /** rate-limit remaining from headers */
  rateLimitRemaining?: number;
  /** retry-after seconds from headers */
  retryAfterSec?: number;
}

/** Summarized view of retrieveUserQuotaSummary */
export interface QuotaSummary {
  /** epoch ms fetch time */
  fetchedAt: number;
  /** project id used if any */
  projectId?: string;
  /** endpoint base that succeeded */
  endpointUsed?: string;
  /** groups keyed by normalized group name */
  groups: Record<string, QuotaPoolStats>;
  /** list of exhausted groups */
  exhaustedGroups: string[];
  /** list of near exhausted >= soft threshold */
  nearExhaustedGroups: string[];
  /** convenience aliases */
  antigravity?: QuotaPoolStats;
  geminiCli?: QuotaPoolStats;
  cloudaicompanion?: QuotaPoolStats;
  /** raw JSON response */
  rawResponse?: unknown;
  /** if 429 was seen */
  isRateLimited?: boolean;
  /** request id if server provides */
  requestId?: string;
}

/** Result of checkQuota helper */
export interface CheckQuotaResult {
  /** allowed to proceed? */
  allowed: boolean;
  /** group resolved for model */
  group: QuotaGroup | string;
  /** remaining tokens / fraction */
  remaining?: number;
  remainingFraction?: number;
  limit?: number;
  resetAt?: number;
  exhausted: boolean;
  nearExhausted: boolean;
  softThresholdHit: boolean;
  /** reason string for logging */
  reason?: string;
  summary: QuotaSummary;
}

/** Cache entry memory + file */
export interface QuotaCacheEntry {
  summary: QuotaSummary;
  fetchedAt: number;
  expiresAt: number;
  ttlMs: number;
  tokenHash: string; // hashed access token, not plaintext
  projectId?: string;
  endpointUsed?: string;
}

export interface FileCacheData {
  version: 1;
  entries: Record<string, QuotaCacheEntry>; // key = tokenHash:projectId
  updatedAt: number;
}

/** Options for QuotaManager */
export interface QuotaManagerOptions {
  /** override cache file path */
  filePath?: string;
  /** base TTL ms — default 15min */
  baseTtlMs?: number;
  /** min TTL 2min */
  minTtlMs?: number;
  /** max TTL 10min */
  maxTtlMs?: number;
  /** soft threshold 0-1, default 0.9 */
  softThreshold?: number;
  /** disable file cache */
  disableFileCache?: boolean;
  /** quota_refresh_interval_minutes — config key, also env */
  quotaRefreshIntervalMinutes?: number;
  /** endpoint list override */
  endpoints?: readonly string[];
  /** user agent override */
  userAgent?: string;
  /** timeout ms */
  timeoutMs?: number;
  /** background refresh interval ms default 10min */
  backgroundIntervalMs?: number;
  /** disable background timer */
  disableBackground?: boolean;
}

/** Options for retrieveUserQuotaSummary standalone */
export interface RetrieveQuotaOptions {
  accessToken: string;
  projectId?: string;
  endpoint?: string; // single base url
  endpoints?: readonly string[]; // cascade if no endpoint
  userAgent?: string;
  timeoutMs?: number;
  extraHeaders?: Record<string, string>;
  signal?: AbortSignal;
}

// ---------------------------------------------------------------------------
// File / path helpers — observer resolves without side effects
// ---------------------------------------------------------------------------

const FILE_MODE = 0o600 as const;
const DIR_MODE = 0o755 as const;
const CACHE_FILE_NAME = "antigravity-quota-cache.json" as const;

export function resolveConfigDir(): string {
  const env = process.env.OPENCODE_CONFIG_DIR?.trim();
  if (env && env.length > 0) return path.resolve(env);
  return path.join(os.homedir(), ".config", "opencode");
}

export function resolveCachePath(custom?: string): string {
  if (custom && custom.trim().length > 0) return path.resolve(custom.trim());
  return path.join(resolveConfigDir(), CACHE_FILE_NAME);
}

async function ensureDir(dir: string): Promise<void> {
  try {
    await fsp.mkdir(dir, { recursive: true, mode: DIR_MODE });
  } catch {}
  try {
    await fsp.chmod(dir, DIR_MODE);
  } catch {}
}

function ensureDirSync(dir: string): void {
  try {
    fs.mkdirSync(dir, { recursive: true, mode: DIR_MODE });
  } catch {}
  try {
    fs.chmodSync(dir, DIR_MODE);
  } catch {}
}

async function atomicWriteFileAtomic(filePath: string, content: string): Promise<void> {
  const dir = path.dirname(filePath);
  await ensureDir(dir);
  const rand = createHash("sha256").update(String(Date.now()) + Math.random()).digest("hex").slice(0, 8);
  const tmp = path.join(dir, `.${path.basename(filePath)}.${process.pid}.${rand}.tmp`);
  try {
    await fsp.writeFile(tmp, content, { encoding: "utf8", mode: FILE_MODE });
    try {
      await fsp.chmod(tmp, FILE_MODE);
    } catch {}
    await fsp.rename(tmp, filePath);
    try {
      await fsp.chmod(filePath, FILE_MODE);
    } catch {}
  } finally {
    try {
      await fsp.unlink(tmp);
    } catch {}
  }
}

function atomicWriteFileSync(filePath: string, content: string): void {
  const dir = path.dirname(filePath);
  ensureDirSync(dir);
  const rand = createHash("sha256").update(String(Date.now()) + Math.random()).digest("hex").slice(0, 8);
  const tmp = path.join(dir, `.${path.basename(filePath)}.${process.pid}.${rand}.tmp`);
  try {
    fs.writeFileSync(tmp, content, { encoding: "utf8", mode: FILE_MODE });
    try {
      fs.chmodSync(tmp, FILE_MODE);
    } catch {}
    fs.renameSync(tmp, filePath);
    try {
      fs.chmodSync(filePath, FILE_MODE);
    } catch {}
  } finally {
    try {
      fs.unlinkSync(tmp);
    } catch {}
  }
}

// ---------------------------------------------------------------------------
// Crypto helpers — hash token, FNV-1a for deterministic ids
// ---------------------------------------------------------------------------

export function hashToken(token: string): string {
  try {
    return createHash("sha256").update(token).digest("hex").slice(0, 32);
  } catch {
    return String(fnv1a32(token)).padStart(8, "0");
  }
}

export function fnv1a32(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h >>> 0;
}

function buildCacheKey(tokenHash: string, projectId?: string): string {
  return projectId ? `${tokenHash}:${projectId}` : tokenHash;
}

// ---------------------------------------------------------------------------
// Model -> group resolution — observer maps 2026 models to quota pool
// ---------------------------------------------------------------------------

const MODEL_GROUP_MAP: Record<string, QuotaGroup> = (() => {
  const map: Record<string, QuotaGroup> = {};
  for (const m of ANTIGRAVITY_MODELS_2026) {
    map[m.id] = m.group as QuotaGroup;
    map[m.id.toLowerCase()] = m.group as QuotaGroup;
    // also map without antigravity- prefix when relevant
    if (m.id.startsWith("antigravity-")) {
      const bare = m.id.replace(/^antigravity-/, "");
      if (!map[bare]) map[bare] = m.group as QuotaGroup;
      if (!map[bare.toLowerCase()]) map[bare.toLowerCase()] = m.group as QuotaGroup;
    }
  }
  // heuristics for future 2026 models not yet listed
  return map;
})();

function normalizeGroupName(raw: string): QuotaGroup | string {
  const lower = String(raw ?? "").trim().toLowerCase();
  if (!lower) return "antigravity";
  if (lower.includes("antigravity")) return "antigravity";
  if (lower.includes("gemini-cli") || lower.includes("gemini_cli") || lower === "gemini" || lower.includes("cli")) {
    // Observer: AM uses ANTIGRAVITY and GEMINI_CLI as two pools
    if (lower === "antigravity") return "antigravity";
    // gemini alone in 2026 rollout means gemini-cli pool for preview models
    if (lower.includes("gemini")) {
      // if explicitly contains antigravity it's antigravity else gemini-cli
      return lower.includes("antigravity") ? "antigravity" : "gemini-cli";
    }
    return "gemini-cli";
  }
  if (lower.includes("cloudaicompanion") || lower.includes("companion")) return "cloudaicompanion";
  // keep normalized lower as fallback — prevents throwing on unknown future groups
  return lower;
}

/**
 * Resolves quota group for a given model id.
 * Third-person: observer looks at known 2026 list, then heuristics.
 *
 * @param model - model id e.g. "gemini-3-flash-preview", "antigravity-gemini-3-pro", "claude-opus-4-6-thinking"
 * @returns group "antigravity" | "gemini-cli" | ...
 */
export function resolveQuotaGroup(model: string): QuotaGroup {
  if (!model) return "antigravity";
  const lower = String(model).trim().toLowerCase();
  // exact map
  if (MODEL_GROUP_MAP[lower]) return MODEL_GROUP_MAP[lower];
  if (MODEL_GROUP_MAP[lower.replace(/^antigravity-/, "")]) return MODEL_GROUP_MAP[lower.replace(/^antigravity-/, "")];
  // heuristics observed: preview + gemini-3 => gemini-cli pool (issue #233: skip sandbox)
  if (lower.includes("preview") || lower.startsWith("gemini-3") || lower.includes("gemini-3") || lower.includes("3.1")) {
    return "gemini-cli";
  }
  if (lower.includes("claude")) return "antigravity";
  if (lower.includes("gemini-2.5")) return "antigravity";
  if (lower.startsWith("antigravity-")) return "antigravity";
  if (lower.startsWith("gemini-")) return "gemini-cli";
  return "antigravity";
}

/**
 * Alias that matches spec name model→grupo resolução
 */
export const resolveGroup = resolveQuotaGroup;
export const getQuotaGroupForModel = resolveQuotaGroup;
export const modelToGroup = resolveQuotaGroup;

// ---------------------------------------------------------------------------
// Number / date parsing — resilient
// ---------------------------------------------------------------------------

function tryParseNumber(v: unknown): number | undefined {
  if (v === null || v === undefined) return undefined;
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const s = v.trim();
    if (!s) return undefined;
    // handle "123", "123.45", "1e3"
    const n = Number(s);
    if (Number.isFinite(n)) return n;
    // handle percent "90%"
    const pct = s.replace(/%$/, "");
    const n2 = Number(pct);
    if (Number.isFinite(n2)) return n2;
  }
  return undefined;
}

function parseDateToMs(v: unknown): number | undefined {
  if (v === null || v === undefined) return undefined;
  if (typeof v === "number") {
    if (!Number.isFinite(v)) return undefined;
    // epoch seconds vs ms heuristic: <1e12 => seconds
    if (v < 1e12 && v > 1e9) return Math.floor(v * 1000);
    if (v < 1e10) return Math.floor(v * 1000);
    return Math.floor(v);
  }
  if (typeof v === "string") {
    const s = v.trim();
    if (!s) return undefined;
    // numeric string?
    const num = Number(s);
    if (Number.isFinite(num) && /^\d+(\.\d+)?$/.test(s)) {
      return parseDateToMs(num);
    }
    // ISO
    const d = new Date(s);
    if (!Number.isNaN(d.getTime())) return d.getTime();
  }
  if (v instanceof Date) {
    const t = v.getTime();
    if (!Number.isNaN(t)) return t;
  }
  if (typeof v === "object") {
    const obj = v as any;
    // Google often uses { seconds, nanos } or { seconds: "123" }
    if (obj.seconds !== undefined) {
      const sec = tryParseNumber(obj.seconds);
      if (sec !== undefined) return Math.floor(sec * 1000 + (tryParseNumber(obj.nanos) ?? 0) / 1e6);
    }
    if (obj.value !== undefined) return parseDateToMs(obj.value);
    if (obj.time !== undefined) return parseDateToMs(obj.time);
  }
  return undefined;
}

function tryParseBool(v: unknown): boolean | undefined {
  if (typeof v === "boolean") return v;
  if (typeof v === "string") {
    const l = v.trim().toLowerCase();
    if (l === "true" || l === "1" || l === "yes") return true;
    if (l === "false" || l === "0" || l === "no") return false;
  }
  if (typeof v === "number") return v !== 0;
  return undefined;
}

// ---------------------------------------------------------------------------
// Rate limit header parsing — resilient
// ---------------------------------------------------------------------------

export interface RateLimitInfo {
  remaining?: number;
  limit?: number;
  resetAt?: number;
  retryAfterSec?: number;
  isRateLimited?: boolean;
}

export function parseRateLimitHeaders(headers: Headers | Record<string, string | undefined> | undefined): RateLimitInfo {
  if (!headers) return {};
  const get = (h: string): string | undefined => {
    if (headers instanceof Headers) {
      return headers.get(h) ?? headers.get(h.toLowerCase()) ?? undefined;
    }
    const rec = headers as Record<string, string | undefined>;
    return rec[h] ?? rec[h.toLowerCase()] ?? rec[h.toUpperCase()] ?? undefined;
  };

  const info: RateLimitInfo = {};
  const retryAfter = get("retry-after") ?? get("Retry-After");
  if (retryAfter) {
    const sec = tryParseNumber(retryAfter);
    if (sec !== undefined) {
      info.retryAfterSec = sec;
      info.resetAt = Date.now() + sec * 1000;
      info.isRateLimited = true;
    } else {
      const ms = parseDateToMs(retryAfter);
      if (ms !== undefined) {
        info.resetAt = ms;
        info.retryAfterSec = Math.max(0, Math.floor((ms - Date.now()) / 1000));
      }
    }
  }
  // X-RateLimit-Remaining / X-RateLimit-Limit / Reset
  const remainingKeys = ["x-ratelimit-remaining", "x-rate-limit-remaining", "ratelimit-remaining", "x-ratelimit-remaining-requests"];
  for (const k of remainingKeys) {
    const v = get(k);
    if (v !== undefined) {
      const n = tryParseNumber(v);
      if (n !== undefined) {
        info.remaining = n;
        if (n <= 0) info.isRateLimited = true;
        break;
      }
    }
  }
  const limitKeys = ["x-ratelimit-limit", "x-rate-limit-limit", "ratelimit-limit"];
  for (const k of limitKeys) {
    const v = get(k);
    if (v !== undefined) {
      const n = tryParseNumber(v);
      if (n !== undefined) {
        info.limit = n;
        break;
      }
    }
  }
  const resetKeys = ["x-ratelimit-reset", "x-rate-limit-reset", "ratelimit-reset", "x-ratelimit-reset-time"];
  for (const k of resetKeys) {
    const v = get(k);
    if (v !== undefined) {
      const ms = parseDateToMs(v);
      if (ms !== undefined) {
        info.resetAt = ms;
        break;
      }
      const sec = tryParseNumber(v);
      if (sec !== undefined) {
        info.resetAt = Date.now() + sec * 1000;
        if (info.retryAfterSec === undefined) info.retryAfterSec = sec;
        break;
      }
    }
  }
  return info;
}

// ---------------------------------------------------------------------------
// Quota response parsing — resilient across rollout shapes
// ---------------------------------------------------------------------------

/**
 * Extracts a single QuotaPoolStats from an arbitrary raw object.
 * The observer tries many field names seen in production:
 *  remaining / tokensRemaining / quotaRemaining
 *  limit / quotaLimit / total
 *  remainingFraction / fractionRemaining / percentRemaining
 *  resetTime / resetAt / nextReset / expiration
 *  exhausted / isExhausted / limitExceeded
 */
function extractPoolStats(raw: any, fallbackGroup?: string): QuotaPoolStats | null {
  if (!raw || typeof raw !== "object") return null;
  const groupRaw = raw.group ?? raw.quotaGroup ?? raw.pool ?? raw.id ?? raw.name ?? fallbackGroup ?? "antigravity";
  const group = normalizeGroupName(String(groupRaw));

  // remaining
  let remaining = tryParseNumber(raw.remaining ?? raw.tokensRemaining ?? raw.quotaRemaining ?? raw.remainingTokens ?? raw.available ?? raw.tokensLeft ?? raw.remainingQuota ?? raw.quota?.remaining);
  // limit
  let limit = tryParseNumber(raw.limit ?? raw.total ?? raw.quotaLimit ?? raw.tokensLimit ?? raw.quotaTotal ?? raw.max ?? raw.quota?.limit);
  // remainingFraction
  let remainingFraction = tryParseNumber(raw.remainingFraction ?? raw.fractionRemaining ?? raw.quotaFraction ?? raw.fraction ?? raw.availableFraction ?? raw.remaining_fraction);
  if (remainingFraction === undefined) {
    const pct = tryParseNumber(raw.percentRemaining ?? raw.percent_remaining ?? raw.remainingPercent);
    if (pct !== undefined) remainingFraction = pct > 1 ? pct / 100 : pct;
  }
  let usedFraction = tryParseNumber(raw.usedFraction ?? raw.fractionUsed ?? raw.used ?? raw.usageFraction ?? raw.consumedFraction);
  if (usedFraction === undefined) {
    const usedPct = tryParseNumber(raw.percentUsed ?? raw.usedPercent);
    if (usedPct !== undefined) usedFraction = usedPct > 1 ? usedPct / 100 : usedPct;
  }
  // derive remainingFraction from remaining/limit if not explicit
  if (remainingFraction === undefined && remaining !== undefined && limit !== undefined && limit > 0) {
    remainingFraction = Math.max(0, Math.min(1, remaining / limit));
  }
  if (usedFraction === undefined && remainingFraction !== undefined) usedFraction = 1 - remainingFraction;
  if (remainingFraction === undefined && usedFraction !== undefined) remainingFraction = 1 - usedFraction;

  // resetAt
  let resetAt = parseDateToMs(raw.resetTime ?? raw.resetAt ?? raw.nextResetTime ?? raw.resetTimestamp ?? raw.expiration ?? raw.expiresAt ?? raw.reset_time ?? raw.reset_at ?? raw.quota?.resetTime ?? raw.quota?.resetAt);
  let resetAtIso: string | undefined;
  const rawIso = raw.resetTime ?? raw.resetAt ?? raw.resetTimestamp;
  if (typeof rawIso === "string" && rawIso.includes("T")) resetAtIso = rawIso;
  if (!resetAtIso && resetAt) {
    try {
      resetAtIso = new Date(resetAt).toISOString();
    } catch {}
  }

  let exhausted = tryParseBool(raw.exhausted ?? raw.isExhausted ?? raw.quotaExhausted ?? raw.limitExceeded ?? raw.isLimited);
  if (exhausted === undefined) {
    if (remaining !== undefined && remaining <= 0) exhausted = true;
    else if (remainingFraction !== undefined && remainingFraction <= 0) exhausted = true;
    else if (usedFraction !== undefined && usedFraction >= 1) exhausted = true;
  }

  // rate limit from embedded headers?
  let rateLimitRemaining = tryParseNumber(raw.rateLimitRemaining ?? raw.rate_limit_remaining);
  let retryAfterSec = tryParseNumber(raw.retryAfterSec ?? raw.retry_after);

  return {
    group,
    remaining,
    limit,
    remainingFraction,
    usedFraction,
    resetAt,
    resetAtIso,
    exhausted: exhausted ?? false,
    raw,
    rateLimitRemaining,
    retryAfterSec,
  };
}

/**
 * Parses v1internal:retrieveUserQuotaSummary response resiliently.
 * Observer documents multiple shapes witnessed 2025-2026:
 * - { quotaGroupStats: [ { group, remaining, limit, resetTime } ] }
 * - { quotaGroupStats: [ { group, quotaStats: [ {remaining, limit, resetTime} ] } ] } nested
 * - { quotas: { antigravity: {...}, "gemini-cli": {...} } }
 * - { quota: { antigravity: {...} } }
 * - { groups: [...] }
 * - { stats: [...] }
 * - bare object with remaining/limit fields => single group
 */
export function parseQuotaResponse(
  raw: any,
  opts: { endpointUsed?: string; projectId?: string; headers?: Headers | Record<string, string>; status?: number } = {},
): QuotaSummary {
  const fetchedAt = Date.now();
  const groups: Record<string, QuotaPoolStats> = {};

  // helper to add pool to groups map, merging if duplicate group
  function addPool(pool: QuotaPoolStats | null) {
    if (!pool) return;
    const key = String(pool.group).toLowerCase();
    // merge logic: keep most recent / most restrictive if same group appears twice
    const existing = groups[key];
    if (!existing) {
      groups[key] = pool;
    } else {
      // prefer one with exhausted=true, or lower remainingFraction
      const existingFrac = existing.remainingFraction ?? 1;
      const newFrac = pool.remainingFraction ?? 1;
      if (pool.exhausted && !existing.exhausted) groups[key] = pool;
      else if (newFrac < existingFrac) groups[key] = { ...existing, ...pool, remainingFraction: newFrac };
      else {
        // merge missing fields
        groups[key] = {
          ...existing,
          remaining: pool.remaining ?? existing.remaining,
          limit: pool.limit ?? existing.limit,
          remainingFraction: existing.remainingFraction ?? pool.remainingFraction,
          usedFraction: existing.usedFraction ?? pool.usedFraction,
          resetAt: pool.resetAt ?? existing.resetAt,
          resetAtIso: pool.resetAtIso ?? existing.resetAtIso,
          exhausted: (existing.exhausted || pool.exhausted) ?? false,
        };
      }
    }
  }

  try {
    if (raw === null || raw === undefined) {
      // empty response — return empty but not throw
    } else if (Array.isArray(raw)) {
      // direct array of groups
      for (const item of raw) {
        if (item && typeof item === "object" && (item as any).quotaStats && Array.isArray((item as any).quotaStats)) {
          // nested quotaStats
          const parentGroup = (item as any).group ?? (item as any).quotaGroup;
          for (const sub of (item as any).quotaStats) {
            addPool(extractPoolStats(sub, parentGroup));
          }
        } else {
          addPool(extractPoolStats(item));
        }
      }
    } else if (typeof raw === "object") {
      const obj = raw as any;

      // candidate arrays
      const arrayCandidates: any[] = [];
      if (Array.isArray(obj.quotaGroupStats)) arrayCandidates.push(...obj.quotaGroupStats);
      if (Array.isArray(obj.quotaGroups)) arrayCandidates.push(...obj.quotaGroups);
      if (Array.isArray(obj.groups)) arrayCandidates.push(...obj.groups);
      if (Array.isArray(obj.stats)) arrayCandidates.push(...obj.stats);
      if (Array.isArray(obj.quotas) /* sometimes quotas is array */) arrayCandidates.push(...obj.quotas);
      if (Array.isArray(obj.quota)) arrayCandidates.push(...obj.quota);
      if (Array.isArray(obj.data)) arrayCandidates.push(...obj.data);

      if (arrayCandidates.length > 0) {
        for (const item of arrayCandidates) {
          if (item && typeof item === "object" && (item as any).quotaStats && Array.isArray((item as any).quotaStats)) {
            const parentGroup = (item as any).group ?? (item as any).quotaGroup;
            for (const sub of (item as any).quotaStats) {
              addPool(extractPoolStats(sub, parentGroup));
            }
          } else {
            addPool(extractPoolStats(item));
          }
        }
      }

      // candidate objects: quotas map, quota map
      const mapCandidates: any[] = [];
      if (obj.quotas && typeof obj.quotas === "object" && !Array.isArray(obj.quotas)) mapCandidates.push(obj.quotas);
      if (obj.quota && typeof obj.quota === "object" && !Array.isArray(obj.quota) && Object.keys(obj.quota).some((k) => typeof (obj.quota as any)[k] === "object")) {
        // if quota is map, not a single stats object
        // heuristic: if quota has remaining/limit directly, it's a single pool, not map
        const hasDirect = obj.quota.remaining !== undefined || obj.quota.limit !== undefined || obj.quota.remainingFraction !== undefined;
        if (!hasDirect) mapCandidates.push(obj.quota);
      }
      if (obj.data && typeof obj.data === "object" && !Array.isArray(obj.data)) {
        // data may contain map
        if (obj.data.quotas && typeof obj.data.quotas === "object") mapCandidates.push(obj.data.quotas);
      }

      for (const map of mapCandidates) {
        for (const [k, v] of Object.entries(map)) {
          addPool(extractPoolStats(v, k));
        }
      }

      // single pool case: object itself has remaining/limit
      if (Object.keys(groups).length === 0) {
        const single = extractPoolStats(obj);
        // only treat as single if it has at least one meaningful field
        if (single && (single.remaining !== undefined || single.limit !== undefined || single.remainingFraction !== undefined || single.exhausted !== undefined)) {
          // if group was generic 'antigravity' from fallback but object had no group field, still ok
          // but if object was actually wrapper with no quota fields, extractPoolStats would have undefined everything — skip
          if (single.remaining !== undefined || single.limit !== undefined || single.remainingFraction !== undefined) {
            addPool(single);
          }
        }
      }
    }
  } catch {
    // observer swallows parsing errors — production ready, returns empty groups
  }

  // also merge rate limit headers into groups if provided
  if (opts.headers) {
    const rl = parseRateLimitHeaders(opts.headers as any);
    if (rl.remaining !== undefined || rl.isRateLimited) {
      // create or augment a generic pool? observer puts it on most relevant group antagravity
      const genericKey = "antigravity";
      const existing = groups[genericKey];
      if (existing) {
        if (rl.remaining !== undefined) existing.rateLimitRemaining = rl.remaining;
        if (rl.retryAfterSec !== undefined) existing.retryAfterSec = rl.retryAfterSec;
        if (rl.resetAt !== undefined && !existing.resetAt) existing.resetAt = rl.resetAt;
        if (rl.isRateLimited) existing.exhausted = true;
      } else if (rl.isRateLimited || rl.remaining !== undefined) {
        addPool({
          group: genericKey,
          remaining: rl.remaining,
          rateLimitRemaining: rl.remaining,
          retryAfterSec: rl.retryAfterSec,
          resetAt: rl.resetAt,
          exhausted: !!rl.isRateLimited,
          raw: { fromHeaders: true },
        });
      }
    }
  }

  // compute exhaustedGroups and nearExhaustedGroups
  const exhaustedGroups: string[] = [];
  const nearExhaustedGroups: string[] = [];
  const SOFT = QUOTA_SOFT_THRESHOLD; // 0.9 used => 0.1 remaining

  for (const [key, pool] of Object.entries(groups)) {
    const isExhausted = !!pool.exhausted || (pool.remaining !== undefined && pool.remaining <= 0) || (pool.remainingFraction !== undefined && pool.remainingFraction <= 0);
    if (isExhausted) {
      exhaustedGroups.push(key);
      // exhausted also counts as near exhausted
      nearExhaustedGroups.push(key);
      continue;
    }
    // near exhausted if used >= 0.9
    let used = pool.usedFraction;
    if (used === undefined && pool.remainingFraction !== undefined) used = 1 - pool.remainingFraction;
    if (used === undefined && pool.remaining !== undefined && pool.limit !== undefined && pool.limit > 0) {
      used = 1 - pool.remaining / pool.limit;
    }
    if (used !== undefined && used >= SOFT) {
      nearExhaustedGroups.push(key);
    } else if (pool.remainingFraction !== undefined && pool.remainingFraction <= 0.1) {
      nearExhaustedGroups.push(key);
    } else if (pool.remaining !== undefined && pool.limit !== undefined && pool.limit > 0 && pool.remaining / pool.limit <= 0.1) {
      nearExhaustedGroups.push(key);
    }
  }

  const summary: QuotaSummary = {
    fetchedAt,
    projectId: opts.projectId,
    endpointUsed: opts.endpointUsed,
    groups,
    exhaustedGroups: [...new Set(exhaustedGroups)],
    nearExhaustedGroups: [...new Set(nearExhaustedGroups)],
    rawResponse: raw,
    isRateLimited: opts.status === 429 || Object.values(groups).some((g) => g.exhausted && g.retryAfterSec !== undefined) || (opts.headers ? parseRateLimitHeaders(opts.headers as any).isRateLimited : false),
  };

  // convenience aliases
  if (groups["antigravity"]) summary.antigravity = groups["antigravity"];
  else if (groups["antigravity".toLowerCase()]) summary.antigravity = groups["antigravity"];
  // find keys that normalize to antigravity / gemini-cli / companion
  for (const [k, v] of Object.entries(groups)) {
    const norm = normalizeGroupName(k);
    if (norm === "antigravity" && !summary.antigravity) summary.antigravity = v;
    if (norm === "gemini-cli" && !summary.geminiCli) summary.geminiCli = v;
    if (norm === "cloudaicompanion" && !summary.cloudaicompanion) summary.cloudaicompanion = v;
  }
  // also direct lookup for normalized keys
  if (!summary.geminiCli) {
    const g = groups["gemini-cli"] ?? groups["gemini_cli"] ?? groups["gemini"];
    if (g) summary.geminiCli = g;
  }

  return summary;
}

// ---------------------------------------------------------------------------
// Fetch helpers — timeout, headers, cascade
// ---------------------------------------------------------------------------

export function isRetryableStatus(status: number): boolean {
  return status === 403 || status === 404 || status >= 500 || status === 429 || status === 408;
}

export function buildAntagravityHeaders(accessToken: string, opts: { userAgent?: string; extra?: Record<string, string> } = {}): Record<string, string> {
  const ua = opts.userAgent ?? getDynamicUserAgent();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${accessToken}`,
    "Content-Type": "application/json",
    "User-Agent": ua,
    Accept: "application/json",
  };
  if (opts.extra) {
    for (const [k, v] of Object.entries(opts.extra)) headers[k] = v;
  }
  return headers;
}

export async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs = QUOTA_TIMEOUT_MS): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const signal = controller.signal;

  let mergedSignal = signal;
  if (init.signal) {
    // merge external abort
    const external = init.signal as AbortSignal;
    if (external.aborted) {
      clearTimeout(timeoutId);
      controller.abort();
    } else {
      external.addEventListener("abort", () => controller.abort(), { once: true });
    }
  }

  try {
    const res = await fetch(url, { ...init, signal: mergedSignal });
    return res;
  } catch (err: any) {
    if (err?.name === "AbortError") {
      throw new Error(`quota fetch timeout after ${timeoutMs}ms for ${url}`);
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Core POST to v1internal:retrieveUserQuotaSummary
 * Observer performs resilient parsing + endpoint cascade.
 */
export async function retrieveUserQuotaSummary(opts: RetrieveQuotaOptions): Promise<QuotaSummary> {
  if (!opts?.accessToken) throw new Error("retrieveUserQuotaSummary: accessToken required");

  const endpoints = opts.endpoints ?? opts.endpoint ? [opts.endpoint as string] : (Array.from(ANTIGRAVITY_ENDPOINTS) as string[]);
  const timeoutMs = opts.timeoutMs ?? QUOTA_TIMEOUT_MS;
  const userAgent = opts.userAgent ?? getDynamicUserAgent();
  const projectId = opts.projectId ?? PROJECT_FALLBACK;

  let lastError: any = null;
  let lastStatus = 0;

  // body candidates — observer tries multiple shapes tolerating rollout differences
  const bodyCandidates: any[] = [
    {}, // empty
    { cloudaicompanionProject: projectId },
    { projectId },
    { project: projectId },
    { cloudaicompanionProject: `projects/${projectId}` },
    {
      metadata: {
        ideType: "ANTIGRAVITY",
        platform: "PLATFORM_UNSPECIFIED",
        pluginType: "GEMINI",
      },
    },
    {
      cloudaicompanionProject: projectId,
      metadata: {
        ideType: "ANTIGRAVITY",
        platform: "PLATFORM_UNSPECIFIED",
        pluginType: "GEMINI",
      },
    },
  ];

  for (const base of endpoints) {
    const url = `${base.replace(/\/+$/, "")}${QUOTA_METHOD}`;
    for (const body of bodyCandidates) {
      try {
        // jitter anti-rate-limit 0-80ms observed in AM
        const jitter = getJitter();
        if (jitter > 0) await new Promise((r) => setTimeout(r, jitter));

        const headers = buildAntagravityHeaders(opts.accessToken, {
          userAgent,
          extra: {
            "X-Goog-Api-Client": getXGoogApiClient(),
            "Client-Metadata": buildClientMetadata(),
            ...(opts.extraHeaders ?? {}),
          },
        });

        // strip banned headers if present in extra
        for (const banned of ["x-goog-user-project", "X-Goog-QuotaUser", "X-Client-Device-Id"]) {
          delete (headers as any)[banned];
          delete (headers as any)[banned.toLowerCase()];
        }

        const res = await fetchWithTimeout(
          url,
          {
            method: "POST",
            headers,
            body: JSON.stringify(body),
            signal: opts.signal,
          },
          timeoutMs,
        );

        lastStatus = res.status;
        const text = await res.text();
        let json: any = null;
        try {
          json = text ? JSON.parse(text) : {};
        } catch {
          // non-JSON response — keep raw text
          json = { _rawText: text.slice(0, 2000) };
        }

        if (!res.ok) {
          // 429 => parse as exhausted but still return summary
          if (res.status === 429) {
            const summary = parseQuotaResponse(json, { endpointUsed: base, projectId, headers: res.headers as any, status: res.status });
            // mark all groups exhausted if server says 429 without details
            if (Object.keys(summary.groups).length === 0) {
              summary.groups["antigravity"] = {
                group: "antigravity",
                exhausted: true,
                remaining: 0,
                remainingFraction: 0,
                resetAt: Date.now() + 60 * 60 * 1000, // 1h default for 429
                raw: json,
                retryAfterSec: parseRateLimitHeaders(res.headers as any).retryAfterSec,
              };
              summary.exhaustedGroups = ["antigravity"];
              summary.nearExhaustedGroups = ["antigravity"];
            }
            summary.isRateLimited = true;
            return summary;
          }
          // retryable => try next endpoint/body
          if (isRetryableStatus(res.status)) {
            lastError = new Error(`quota ${res.status} at ${base}: ${text.slice(0, 500)}`);
            continue;
          }
          // non-retryable 4xx besides 429 => throw
          throw new Error(`quota failed ${res.status} at ${base}: ${text.slice(0, 500)}`);
        }

        // success 2xx
        const summary = parseQuotaResponse(json, { endpointUsed: base, projectId, headers: res.headers as any, status: res.status });
        return summary;
      } catch (err: any) {
        lastError = err;
        // if body candidate failed due to invalid payload, try next body without switching endpoint yet
        // but if error is network/timeout, continue to next endpoint
        const isTimeout = err?.message?.includes("timeout");
        const isAbort = err?.name === "AbortError";
        if (isTimeout || isAbort) continue;
        // for other errors, try next body first
        // we are inside body loop; let loop continue
        // If last body candidate, then endpoint loop will continue
        continue;
      }
    }
  }

  throw lastError ?? new Error(`retrieveUserQuotaSummary failed, last status ${lastStatus}`);
}

// ---------------------------------------------------------------------------
// Adaptive TTL — observer adjusts 15min default to 2-10min by usage
// ---------------------------------------------------------------------------

export function getAdaptiveTtlMs(summary: QuotaSummary, baseTtlMs = QUOTA_CACHE_TTL_MS): number {
  // base from config? baseTtlMs may be custom from quota_refresh_interval_minutes
  const min = QUOTA_CACHE_TTL_MIN_MS;
  const max = QUOTA_CACHE_TTL_MAX_MS;
  const defaultBase = QUOTA_CACHE_TTL_MS;

  // If summary empty, return capped base
  const groups = Object.values(summary.groups);
  if (groups.length === 0) {
    return Math.min(Math.max(baseTtlMs, min), max > defaultBase ? defaultBase : max);
  }

  // worst remaining fraction
  let minRemainingFraction: number | undefined = undefined;
  for (const g of groups) {
    const rf = g.remainingFraction;
    if (rf !== undefined) {
      if (minRemainingFraction === undefined || rf < minRemainingFraction) minRemainingFraction = rf;
    } else if (g.remaining !== undefined && g.limit !== undefined && g.limit > 0) {
      const derived = g.remaining / g.limit;
      if (minRemainingFraction === undefined || derived < minRemainingFraction) minRemainingFraction = derived;
    } else if (g.exhausted) {
      minRemainingFraction = 0;
      break;
    }
  }

  // exhausted => MIN
  if (summary.exhaustedGroups.length > 0 || minRemainingFraction === 0) return min;

  // if rate-limited 429 => MIN
  if (summary.isRateLimited) return min;

  let candidate: number;
  if (minRemainingFraction === undefined) {
    // unknown usage => use max bounded base
    candidate = Math.min(baseTtlMs, max);
  } else if (minRemainingFraction <= 0.05) candidate = min; // <=5% => 2min
  else if (minRemainingFraction <= 0.1) candidate = 2 * 60 * 1000; // 2min
  else if (minRemainingFraction <= 0.2) candidate = 3 * 60 * 1000; // 3min
  else if (minRemainingFraction <= 0.3) candidate = 5 * 60 * 1000; // 5min
  else if (minRemainingFraction <= 0.5) candidate = 7 * 60 * 1000; // 7min
  else if (minRemainingFraction <= 0.7) candidate = 8 * 60 * 1000; // 8min
  else candidate = max; // 10min low usage

  // respect custom base: if user set lower interval, honor min(base, candidate) for high usage,
  // but don't exceed base if base < candidate and base is intentional custom
  // Heuristic: final = min(candidate, base) when base != default
  const isCustomBase = baseTtlMs !== defaultBase;
  if (isCustomBase) {
    // if base is say 5min custom, and candidate is 10min (low usage), keep 5min (user wants faster)
    // if candidate is 2min (high usage), keep 2min (more aggressive)
    return Math.min(candidate, baseTtlMs);
  }
  // default base 15min, candidate max 10min => adaptive within 2-10
  return Math.min(candidate, max);
}

/**
 * Resolves base TTL from config minutes or env.
 * Supports quota_refresh_interval_minutes from config loader + env.
 */
export function resolveBaseTtlFromConfig(configMinutes?: number): number {
  const envRaw = process.env.QUOTA_REFRESH_INTERVAL_MINUTES ?? process.env.ANTIGRAVITY_QUOTA_REFRESH_INTERVAL_MINUTES ?? process.env.QUOTA_REFRESH_INTERVAL;
  if (envRaw) {
    const parsed = Number(envRaw);
    if (Number.isFinite(parsed) && parsed >= 1 && parsed <= 120) return parsed * 60 * 1000;
  }
  if (configMinutes !== undefined && Number.isFinite(configMinutes) && configMinutes >= 1 && configMinutes <= 120) {
    return configMinutes * 60 * 1000;
  }
  return QUOTA_CACHE_TTL_MS;
}

// ---------------------------------------------------------------------------
// Pure helpers — checkQuota, isQuotaExhausted, shouldSkipAccount
// ---------------------------------------------------------------------------

export function isQuotaExhausted(summary: QuotaSummary, groupOrModel?: string): boolean {
  if (!summary) return false;
  if (!groupOrModel) {
    return summary.exhaustedGroups.length > 0 || !!summary.isRateLimited;
  }
  const group = MODEL_GROUP_MAP[groupOrModel.toLowerCase()] ? resolveQuotaGroup(groupOrModel) : normalizeGroupName(groupOrModel);
  const key = String(group).toLowerCase();
  if (summary.exhaustedGroups.map((g) => g.toLowerCase()).includes(key)) return true;
  const pool = summary.groups[key] ?? summary.groups[String(group)] ?? summary.groups[Object.keys(summary.groups).find((k) => normalizeGroupName(k) === key) ?? ""];
  if (!pool) {
    // if group not found, check global exhausted?
    return summary.exhaustedGroups.length > 0;
  }
  if (pool.exhausted) return true;
  if (pool.remaining !== undefined && pool.remaining <= 0) return true;
  if (pool.remainingFraction !== undefined && pool.remainingFraction <= 0) return true;
  return false;
}

export function shouldSkipAccount(summary: QuotaSummary, modelOrGroup: string): boolean {
  return isQuotaExhausted(summary, modelOrGroup);
}

/**
 * checkQuota — main entry used by plugin fetch interceptor.
 * Returns allowed flag + metadata.
 */
export function checkQuota(summary: QuotaSummary, model?: string): CheckQuotaResult {
  const group = model ? resolveQuotaGroup(model) : ("antigravity" as QuotaGroup);
  const key = String(group).toLowerCase();
  const pool =
    summary.groups[key] ??
    summary.groups[String(group)] ??
    (summary.groups[Object.keys(summary.groups).find((k) => normalizeGroupName(k) === group) ?? ""] as any) ??
    // fallback: if only one group exists, use it
    (Object.keys(summary.groups).length === 1 ? Object.values(summary.groups)[0] : undefined);

  const exhausted = isQuotaExhausted(summary, group);
  const nearKey = summary.nearExhaustedGroups.map((g) => g.toLowerCase()).includes(key) || summary.nearExhaustedGroups.map((g) => normalizeGroupName(g) as string).includes(key);
  const softHit = nearKey || (pool?.usedFraction !== undefined && pool.usedFraction >= QUOTA_SOFT_THRESHOLD) || (pool?.remainingFraction !== undefined && pool.remainingFraction <= 0.1);

  let allowed = !exhausted;
  let reason = exhausted ? `quota exhausted for group ${group}` : nearKey ? `soft threshold 90% hit for ${group}` : `quota ok for ${group}`;

  // also check if summary empty — allow (observer can't block without data)
  if (Object.keys(summary.groups).length === 0) {
    allowed = true;
    reason = "no quota data — allow";
  }

  return {
    allowed,
    group,
    remaining: pool?.remaining ?? pool?.rateLimitRemaining,
    remainingFraction: pool?.remainingFraction,
    limit: pool?.limit,
    resetAt: pool?.resetAt,
    exhausted,
    nearExhausted: nearKey,
    softThresholdHit: !!softHit,
    reason,
    summary,
  };
}

// ---------------------------------------------------------------------------
// QuotaManager — memory + file cache, adaptive TTL, background refresh, dual pool
// ---------------------------------------------------------------------------

export class QuotaManager {
  private memoryCache: Map<string, QuotaCacheEntry> = new Map();
  private fileCache: FileCacheData | null = null;
  private filePath: string;
  private baseTtlMs: number;
  private minTtlMs: number;
  private maxTtlMs: number;
  private softThreshold: number;
  private disableFileCache: boolean;
  private endpoints: readonly string[];
  private userAgent: string;
  private timeoutMs: number;
  private backgroundTimer: NodeJS.Timeout | null = null;
  private backgroundIntervalMs: number;
  private refreshInProgress: Map<string, Promise<QuotaSummary>> = new Map();

  constructor(opts: QuotaManagerOptions = {}) {
    this.filePath = resolveCachePath(opts.filePath);
    // quota_refresh_interval_minutes handling — env + config
    const envInterval = (() => {
      const raw = process.env.QUOTA_REFRESH_INTERVAL_MINUTES ?? process.env.ANTIGRAVITY_QUOTA_REFRESH_INTERVAL_MINUTES;
      if (raw) {
        const n = Number(raw);
        if (Number.isFinite(n) && n >= 1 && n <= 120) return n;
      }
      return undefined;
    })();
    const configMinutes = opts.quotaRefreshIntervalMinutes ?? envInterval;

    this.baseTtlMs = opts.baseTtlMs ?? (configMinutes ? configMinutes * 60 * 1000 : QUOTA_CACHE_TTL_MS);
    if (configMinutes && !opts.baseTtlMs) {
      this.baseTtlMs = configMinutes * 60 * 1000;
    }
    // clamp base to reasonable 1-120min, but default preserved
    if (this.baseTtlMs < 60 * 1000) this.baseTtlMs = 60 * 1000;
    if (this.baseTtlMs > 120 * 60 * 1000) this.baseTtlMs = 120 * 60 * 1000;

    this.minTtlMs = opts.minTtlMs ?? QUOTA_CACHE_TTL_MIN_MS;
    this.maxTtlMs = opts.maxTtlMs ?? QUOTA_CACHE_TTL_MAX_MS;
    this.softThreshold = opts.softThreshold ?? QUOTA_SOFT_THRESHOLD;
    this.disableFileCache = !!opts.disableFileCache;
    this.endpoints = opts.endpoints ?? ANTIGRAVITY_ENDPOINTS;
    this.userAgent = opts.userAgent ?? getDynamicUserAgent();
    this.timeoutMs = opts.timeoutMs ?? QUOTA_TIMEOUT_MS;
    this.backgroundIntervalMs = opts.backgroundIntervalMs ?? 10 * 60 * 1000;

    // sync load file cache if exists — observer loads lazily but tries sync first for CLI speed
    if (!this.disableFileCache) {
      try {
        const raw = fs.readFileSync(this.filePath, "utf8");
        if (raw.trim()) {
          const parsed = JSON.parse(raw) as FileCacheData;
          if (parsed && parsed.version === 1 && parsed.entries && typeof parsed.entries === "object") {
            this.fileCache = parsed;
            // hydrate memory cache with still valid entries
            const now = Date.now();
            for (const [k, entry] of Object.entries(parsed.entries)) {
              if (entry.expiresAt && now < entry.expiresAt) {
                this.memoryCache.set(k, entry);
              }
            }
          }
        }
      } catch {
        // ignore — file may not exist yet
        this.fileCache = { version: 1, entries: {}, updatedAt: Date.now() };
      }
    }

    if (!opts.disableBackground) {
      this.startBackgroundRefresh();
    }
  }

  // -------------------------------------------------------------------------
  // File cache persistence
  // -------------------------------------------------------------------------

  private async loadFileCache(): Promise<FileCacheData> {
    if (this.disableFileCache) return { version: 1, entries: {}, updatedAt: Date.now() };
    if (this.fileCache) return this.fileCache;
    try {
      const raw = await fsp.readFile(this.filePath, "utf8");
      if (!raw.trim()) {
        const empty: FileCacheData = { version: 1, entries: {}, updatedAt: Date.now() };
        this.fileCache = empty;
        return empty;
      }
      const parsed = JSON.parse(raw) as FileCacheData;
      if (parsed && parsed.version === 1 && parsed.entries) {
        this.fileCache = parsed;
        return parsed;
      }
    } catch (e: any) {
      if (e?.code !== "ENOENT") {
        // corrupted — reset
      }
    }
    const empty: FileCacheData = { version: 1, entries: {}, updatedAt: Date.now() };
    this.fileCache = empty;
    return empty;
  }

  private async saveFileCache(): Promise<void> {
    if (this.disableFileCache) return;
    const fc = this.fileCache ?? { version: 1, entries: {}, updatedAt: Date.now() };
    // sync memoryCache into fileCache entries (keep newest)
    for (const [k, memEntry] of this.memoryCache.entries()) {
      fc.entries[k] = memEntry;
    }
    // prune expired entries older than 24h to avoid bloat
    const now = Date.now();
    for (const [k, e] of Object.entries(fc.entries)) {
      if (e.expiresAt && now - e.expiresAt > 24 * 60 * 60 * 1000) {
        delete fc.entries[k];
      }
    }
    fc.updatedAt = now;
    this.fileCache = fc;
    try {
      const content = JSON.stringify(fc, null, 2);
      await atomicWriteFileAtomic(this.filePath, content);
    } catch {
      // observer swallows save errors — production ready, memory cache still works
    }
  }

  // -------------------------------------------------------------------------
  // Cache access
  // -------------------------------------------------------------------------

  private getCacheKey(token: string, projectId?: string): string {
    const h = hashToken(token);
    return buildCacheKey(h, projectId);
  }

  private getCachedEntry(token: string, projectId?: string): QuotaCacheEntry | null {
    const key = this.getCacheKey(token, projectId);
    const mem = this.memoryCache.get(key);
    if (mem) {
      if (Date.now() < mem.expiresAt) return mem;
      // expired — delete
      this.memoryCache.delete(key);
    }
    // try file cache if memory miss
    if (!this.disableFileCache && this.fileCache) {
      const fileEntry = this.fileCache.entries[key];
      if (fileEntry && Date.now() < fileEntry.expiresAt) {
        // promote to memory
        this.memoryCache.set(key, fileEntry);
        return fileEntry;
      }
    }
    return null;
  }

  private setCachedEntry(token: string, summary: QuotaSummary, projectId?: string, endpointUsed?: string, ttlMs?: number): QuotaCacheEntry {
    const key = this.getCacheKey(token, projectId);
    const fetchedAt = summary.fetchedAt ?? Date.now();
    const adaptiveTtl = ttlMs ?? getAdaptiveTtlMs(summary, this.baseTtlMs);
    const clampedTtl = Math.min(Math.max(adaptiveTtl, this.minTtlMs), this.maxTtlMs > this.baseTtlMs ? this.baseTtlMs : this.maxTtlMs);
    // but if base is custom < max, clamp already handled in getAdaptiveTtlMs? ensure we respect min/max
    const finalTtl = Math.min(Math.max(clampedTtl, this.minTtlMs), this.maxTtlMs);

    const entry: QuotaCacheEntry = {
      summary,
      fetchedAt,
      expiresAt: fetchedAt + finalTtl,
      ttlMs: finalTtl,
      tokenHash: hashToken(token),
      projectId,
      endpointUsed,
    };
    this.memoryCache.set(key, entry);
    // sync to fileCache object immediately (save async in background)
    if (!this.disableFileCache) {
      if (!this.fileCache) this.fileCache = { version: 1, entries: {}, updatedAt: Date.now() };
      this.fileCache.entries[key] = entry;
      this.fileCache.updatedAt = Date.now();
      // fire-and-forget save, observer doesn't block request path
      this.saveFileCache().catch(() => {});
    }
    return entry;
  }

  // -------------------------------------------------------------------------
  // Core fetch with deduplication (double-checked locking similar to accounts.ts)
  // -------------------------------------------------------------------------

  async fetchQuota(accessToken: string, projectId?: string, opts: { forceRefresh?: boolean; endpoint?: string; userAgent?: string; timeoutMs?: number } = {}): Promise<QuotaSummary> {
    if (!accessToken) throw new Error("fetchQuota: accessToken required");
    const pid = projectId ?? PROJECT_FALLBACK;

    if (!opts.forceRefresh) {
      const cached = this.getCachedEntry(accessToken, pid);
      if (cached) return cached.summary;
    }

    const key = this.getCacheKey(accessToken, pid);
    // dedup concurrent fetches for same key
    const ongoing = this.refreshInProgress.get(key);
    if (ongoing && !opts.forceRefresh) {
      return ongoing;
    }

    const promise = (async () => {
      const summary = await retrieveUserQuotaSummary({
        accessToken,
        projectId: pid,
        endpoint: opts.endpoint,
        endpoints: opts.endpoint ? undefined : this.endpoints,
        userAgent: opts.userAgent ?? this.userAgent,
        timeoutMs: opts.timeoutMs ?? this.timeoutMs,
      });
      this.setCachedEntry(accessToken, summary, pid, summary.endpointUsed);
      return summary;
    })();

    this.refreshInProgress.set(key, promise);
    try {
      const res = await promise;
      return res;
    } finally {
      this.refreshInProgress.delete(key);
    }
  }

  /**
   * Force refresh — bypass cache
   */
  async refreshQuota(accessToken: string, projectId?: string, opts: { endpoint?: string } = {}): Promise<QuotaSummary> {
    return this.fetchQuota(accessToken, projectId, { forceRefresh: true, endpoint: opts.endpoint });
  }

  // -------------------------------------------------------------------------
  // Helpers that use cache — checkQuota, isQuotaExhausted, shouldSkipAccount
  // -------------------------------------------------------------------------

  async checkQuotaForModel(accessToken: string, model: string, projectId?: string): Promise<CheckQuotaResult> {
    const summary = await this.fetchQuota(accessToken, projectId);
    return checkQuota(summary, model);
  }

  isQuotaExhaustedCached(accessToken: string, groupOrModel: string, projectId?: string): boolean {
    const entry = this.getCachedEntry(accessToken, projectId ?? PROJECT_FALLBACK);
    if (!entry) return false; // no data => not exhausted (allow)
    return isQuotaExhausted(entry.summary, groupOrModel);
  }

  shouldSkipAccountCached(accessToken: string, modelOrGroup: string, projectId?: string): boolean {
    return this.isQuotaExhaustedCached(accessToken, modelOrGroup, projectId);
  }

  getCachedSummary(accessToken: string, projectId?: string): QuotaSummary | null {
    const entry = this.getCachedEntry(accessToken, projectId);
    return entry ? entry.summary : null;
  }

  // -------------------------------------------------------------------------
  // Background refresh — after requests + interval
  // -------------------------------------------------------------------------

  /**
   * Schedules background refresh after a successful content request.
   * Observer pattern: fire-and-forget, does not block request path.
   * Uses adaptive TTL to decide if immediate refresh needed.
   * @param accessToken
   * @param projectId
   */
  scheduleBackgroundRefreshAfterRequest(accessToken: string, projectId?: string): void {
    // fire in next tick, unref
    setTimeout(() => {
      this.refreshQuota(accessToken, projectId).catch(() => {});
    }, getJitter()).unref?.();
  }

  /**
   * Starts periodic background refresh for all cached entries.
   * Respects quota_refresh_interval_minutes config.
   */
  startBackgroundRefresh(intervalMs?: number): void {
    const ms = intervalMs ?? this.backgroundIntervalMs ?? (this.baseTtlMs < 10 * 60 * 1000 ? this.baseTtlMs : 10 * 60 * 1000);
    if (this.backgroundTimer) return;
    this.backgroundTimer = setInterval(() => {
      // refresh entries expiring within next interval
      const now = Date.now();
      for (const [key, entry] of this.memoryCache.entries()) {
        const timeToExpiry = entry.expiresAt - now;
        // if expiring within 2min or already near soft threshold, refresh
        const nearThreshold = entry.summary.nearExhaustedGroups.length > 0;
        if (timeToExpiry < 2 * 60 * 1000 || nearThreshold) {
          // reconstruct token can't from hash — we need accessToken? background refresh for file cache only works if caller provides token.
          // Observer notes: file cache entries store tokenHash only, not token. So background interval can only clean expired,
          // not refetch without token. We therefore just prune expired and keep stale for lazy refresh.
          // The real background after requests (scheduleBackgroundRefreshAfterRequest) uses actual token.
          if (now >= entry.expiresAt) {
            this.memoryCache.delete(key);
          }
        }
      }
      // also prune file cache via save
      this.saveFileCache().catch(() => {});
    }, ms) as unknown as NodeJS.Timeout;
    if (this.backgroundTimer && typeof (this.backgroundTimer as any).unref === "function") {
      (this.backgroundTimer as any).unref();
    }
  }

  stopBackgroundRefresh(): void {
    if (this.backgroundTimer) {
      clearInterval(this.backgroundTimer as unknown as NodeJS.Timeout);
      this.backgroundTimer = null;
    }
  }

  clearCache(): void {
    this.memoryCache.clear();
    if (this.fileCache) this.fileCache.entries = {};
  }

  async clearFileCache(): Promise<void> {
    this.clearCache();
    if (!this.disableFileCache) {
      try {
        await fsp.unlink(this.filePath);
      } catch {}
      this.fileCache = { version: 1, entries: {}, updatedAt: Date.now() };
    }
  }

  // -------------------------------------------------------------------------
  // Utility for external plugin integration
  // -------------------------------------------------------------------------

  /**
   * Returns quota cache file path — for debug/cli.
   */
  getCacheFilePath(): string {
    return this.filePath;
  }

  /**
   * Returns cache stats — for TUI.
   */
  getCacheStats(): { memorySize: number; fileSize: number; entries: Array<{ keyHash: string; projectId?: string; ageMs: number; ttlMs: number; exhausted: boolean }> } {
    const now = Date.now();
    const entries = Array.from(this.memoryCache.entries()).map(([k, v]) => ({
      keyHash: v.tokenHash.slice(0, 8),
      projectId: v.projectId,
      ageMs: now - v.fetchedAt,
      ttlMs: v.ttlMs,
      exhausted: v.summary.exhaustedGroups.length > 0,
    }));
    return { memorySize: this.memoryCache.size, fileSize: this.fileCache ? Object.keys(this.fileCache.entries).length : 0, entries };
  }

  async dispose(): Promise<void> {
    this.stopBackgroundRefresh();
    this.refreshInProgress.clear();
    await this.saveFileCache().catch(() => {});
  }

  // -------------------------------------------------------------------------
  // Static factory
  // -------------------------------------------------------------------------

  static create(opts: QuotaManagerOptions = {}): QuotaManager {
    return new QuotaManager(opts);
  }

  static hashToken = hashToken;
}

// ---------------------------------------------------------------------------
// Singleton helpers — library-first convenience
// ---------------------------------------------------------------------------

let defaultManager: QuotaManager | null = null;

export function getQuotaManager(opts?: QuotaManagerOptions): QuotaManager {
  if (defaultManager) {
    // if opts provides new filePath or baseTtl, recreate? observer keeps singleton unless reset
    if (opts?.filePath && opts.filePath !== defaultManager.getCacheFilePath()) {
      defaultManager = new QuotaManager(opts);
    }
    return defaultManager;
  }
  defaultManager = new QuotaManager(opts);
  return defaultManager;
}

export function resetQuotaManager(): void {
  if (defaultManager) {
    defaultManager.stopBackgroundRefresh();
  }
  defaultManager = null;
}

/**
 * Singleton-aware wrappers — these use default manager.
 */
export async function fetchQuotaWithCache(accessToken: string, projectId?: string, opts?: { forceRefresh?: boolean }): Promise<QuotaSummary> {
  const mgr = getQuotaManager();
  return mgr.fetchQuota(accessToken, projectId, opts);
}

export async function refreshQuotaBackground(accessToken: string, projectId?: string): Promise<void> {
  const mgr = getQuotaManager();
  mgr.scheduleBackgroundRefreshAfterRequest(accessToken, projectId);
}

// ---------------------------------------------------------------------------
// Legacy compat exports — expected by plugin.ts / request pipeline
// ---------------------------------------------------------------------------

/**
 * isGeminiCLIOnlyModel — duplicated here for quota module self-containment.
 * Observer checks preview + gemini-3 for prod-only routing.
 */
export function isGeminiCLIOnlyModel(modelId: string): boolean {
  const lower = String(modelId ?? "").toLowerCase();
  return lower.includes("preview") || (GEMINI_CLI_ONLY_MODELS as readonly string[]).includes(modelId as any) || lower.startsWith("gemini-3") || lower.startsWith("gemini-3.1");
}

/**
 * Constants object barrel — mirrors constants.ts but self-contained.
 */
export const CONSTANTS = {
  versionFallback: ANTIGRAVITY_VERSION_FALLBACK,
  userAgentFallback: ANTIGRAVITY_USER_AGENT_FALLBACK,
  clientId: ANTIGRAVITY_CLIENT_ID,
  clientSecret: ANTIGRAVITY_CLIENT_SECRET,
  geminiClientId: GEMINI_CLI_CLIENT_ID,
  geminiClientSecret: GEMINI_CLI_CLIENT_SECRET,
  endpoints: ANTIGRAVITY_ENDPOINTS,
  endpointFallbacks: ANTIGRAVITY_ENDPOINT_FALLBACKS,
  geminiCliEndpoint: GEMINI_CLI_ENDPOINT,
  quotaMethod: QUOTA_METHOD,
  projectFallback: PROJECT_FALLBACK,
  models: ANTIGRAVITY_MODELS_2026,
  modelIds: ANTIGRAVITY_MODEL_IDS_2026,
  geminiCliOnlyModels: GEMINI_CLI_ONLY_MODELS,
  cacheTtl: QUOTA_CACHE_TTL_MS,
  cacheTtlMin: QUOTA_CACHE_TTL_MIN_MS,
  cacheTtlMax: QUOTA_CACHE_TTL_MAX_MS,
  softThreshold: QUOTA_SOFT_THRESHOLD,
  hardThreshold: QUOTA_HARD_THRESHOLD,
} as const;

export default QuotaManager;

/**
 * Re-export for barrel index.ts compatibility.
 * The observer ensures index.ts can `export * from "./quota"` without collision.
 */
export const Quota = {
  Manager: QuotaManager,
  getManager: getQuotaManager,
  resetManager: resetQuotaManager,
  retrieveUserQuotaSummary,
  parseQuotaResponse,
  parseRateLimitHeaders,
  checkQuota,
  isQuotaExhausted,
  shouldSkipAccount,
  resolveQuotaGroup,
  resolveGroup,
  modelToGroup,
  getAdaptiveTtlMs,
  resolveBaseTtlFromConfig,
  isGeminiCLIOnlyModel,
  fetchQuotaWithCache,
  refreshQuotaBackground,
  CONSTANTS,
};
