/**
 * @file streaming.ts
 * @module opencode-antigravity-auth-next/streaming
 * @description
 *  Third-person observer view: the library watches Antigravity / CloudCode
 *  traffic and reproduces its streaming behavior without running Antigravity
 *  itself.
 *
 *  Responsibilities isolated here:
 *   - Incremental SSE parser tolerant to network splits (parseSSEChunk)
 *   - Heterogeneous payload normalization (unwrap response/candidates/parts)
 *   - LRU cache for thinking signatures — 100 entries — Map-based
 *   - Preservation of thinking blocks between chunks (delta tracking)
 *   - OpenAI / Anthropic transformers compatible with opencode plugin SDK
 *   - Auto-recovery exponential backoff + jitter 0-80ms
 *   - Synthetic finish injection when cloudcode-pa closes abruptly
 *
 *  Architectural constraints:
 *   - Library-first, root-first (no src/ folder, file lives in /mnt/data/auth)
 *   - Direct cloudcode-pa.googleapis.com — no localhost v1 proxy
 *   - Only node:* builtins + global fetch (Node >=18)
 *     -> node:crypto for FNV-1a, signature hashing, jitter
 *     -> global TextDecoder / ReadableStream (web standards in Node)
 *   - Production-ready: never throws in parser, defensive JSON tolerant,
 *     JSDoc everywhere, explicit error handling, no placeholder
 *
 *  Date governance: 25/08/2026 — Canto do Buriti, PI, BR
 *  Version: 2.0.0 — opencode-antigravity-auth-next
 *
 *  Related modules:
 *   - constants.ts — endpoints, LRU_THINKING_CACHE_SIZE, models 2026
 *   - fingerprint.ts — FNV-1a reused here for deterministic ids
 *   - request.ts — builds Antigravity request body
 *   - recovery.ts — higher level auto-recovery using this module
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 */

import { randomInt, createHash } from "node:crypto";

// ---------------------------------------------------------------------------
// Constants — frozen, deterministic
// ---------------------------------------------------------------------------

/** LRU size aligned with constants.ts governance */
export const LRU_THINKING_CACHE_SIZE = 100 as const;

/** Retryable HTTP status codes for cloudcode-pa */
export const RETRYABLE_STATUS_CODES = [429, 500, 502, 503, 504] as const;

/** Exponential backoff defaults — observer notes small delays mirror AM */
export const BACKOFF_BASE_MS = 250 as const;
export const BACKOFF_FACTOR = 2 as const;
export const BACKOFF_MAX_MS = 10_000 as const;
export const MAX_RETRIES = 3 as const;
export const JITTER_MIN_MS = 0 as const;
export const JITTER_MAX_MS = 80 as const;

/** Sentinel that Gemini / Antigravity sends to close stream */
export const SSE_DONE_SENTINEL = "[DONE]" as const;

// ---------------------------------------------------------------------------
// Helpers — FNV-1a 32-bit (deterministic, zero external dep)
// ---------------------------------------------------------------------------

const FNV_OFFSET_BASIS = 0x811c9dc5;
const FNV_PRIME = 0x01000193;

/**
 * Computes FNV-1a 32-bit hash — deterministic, fast.
 * The observer uses it for tool_call ids and signature cache keys
 * when crypto is not available or to avoid heap snapshot leakage.
 *
 * @param input - string to hash
 * @returns unsigned 32-bit int
 */
export function fnv1a32(input: string): number {
  let hash = FNV_OFFSET_BASIS;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, FNV_PRIME) >>> 0;
  }
  return hash >>> 0;
}

/**
 * SHA-256 hex truncated to 16 chars — stable key for thinking text
 * when length > few hundred chars. Falls back to FNV-1a if crypto fails.
 *
 * @param text - thinking text to hash
 */
export function hashThinkingText(text: string): string {
  try {
    return createHash("sha256").update(text, "utf8").digest("hex").slice(0, 32);
  } catch {
    return fnv1a32(text).toString(16).padStart(8, "0");
  }
}

/**
 * Returns jitter in ms 0-80 inclusive using node:crypto, fallback Math.random
 */
export function getJitter(): number {
  try {
    return randomInt(JITTER_MIN_MS, JITTER_MAX_MS + 1);
  } catch {
    return Math.floor(Math.random() * (JITTER_MAX_MS - JITTER_MIN_MS + 1)) + JITTER_MIN_MS;
  }
}

/**
 * Promise-based sleep with jitter included for backoff
 * @param ms - base delay
 */
export function sleepWithJitter(ms: number): Promise<void> {
  const jitter = getJitter();
  const total = Math.max(0, ms + jitter);
  return new Promise((resolve) => setTimeout(resolve, total));
}

// ---------------------------------------------------------------------------
// LRU Cache — thinking signatures 100 entradas
// ---------------------------------------------------------------------------

/**
 * @description
 *  The observer notes that Claude thinking blocks carry `thoughtSignature`
 *  that must be preserved across turns, otherwise API returns
 *  "invalid signature". Original plugin stored 100 entries in Map.
 *  LRU eviction keeps most recent.
 *
 *  This implementation is library-first: no external LRU dep,
 *  uses Map insertion order (ES2015 guarantees order).
 */
export class ThinkingSignatureCache {
  private readonly maxSize: number;
  private readonly map: Map<string, string>;

  /**
   * @param maxSize - max entries, default 100 per spec
   */
  constructor(maxSize: number = LRU_THINKING_CACHE_SIZE) {
    if (!Number.isInteger(maxSize) || maxSize <= 0) {
      throw new TypeError(`maxSize must be positive integer, got ${maxSize}`);
    }
    this.maxSize = maxSize;
    this.map = new Map<string, string>();
  }

  /** Current size */
  get size(): number {
    return this.map.size;
  }

  /** Max configured */
  get capacity(): number {
    return this.maxSize;
  }

  /**
   * Retrieves signature for given thinking text.
   * The cache key is hash of normalized text (trimmed).
   *
   * @param thinkingText - full thinking block text
   * @returns signature or undefined
   */
  get(thinkingText: string): string | undefined {
    if (!thinkingText || typeof thinkingText !== "string") return undefined;
    const key = hashThinkingText(thinkingText.trim());
    const val = this.map.get(key);
    if (val !== undefined) {
      // LRU touch: re-insert to move to end (most recent)
      this.map.delete(key);
      this.map.set(key, val);
    }
    return val;
  }

  /**
   * Retrieves signature by direct hash key (when caller already hashed)
   */
  getByHash(hashKey: string): string | undefined {
    const val = this.map.get(hashKey);
    if (val !== undefined) {
      this.map.delete(hashKey);
      this.map.set(hashKey, val);
    }
    return val;
  }

  /**
   * Stores signature keyed by thinking text
   * @param thinkingText - full text
   * @param signature - opaque signature string from API
   */
  set(thinkingText: string, signature: string): void {
    if (!thinkingText || typeof thinkingText !== "string") return;
    if (!signature || typeof signature !== "string") return;
    const key = hashThinkingText(thinkingText.trim());
    if (this.map.has(key)) this.map.delete(key);
    this.map.set(key, signature);
    this.evictIfNeeded();
  }

  /**
   * Direct hash->signature set (when text not available)
   */
  setByHash(hashKey: string, signature: string): void {
    if (!hashKey || !signature) return;
    if (this.map.has(hashKey)) this.map.delete(hashKey);
    this.map.set(hashKey, signature);
    this.evictIfNeeded();
  }

  /** Checks presence without touching LRU order */
  has(thinkingText: string): boolean {
    if (!thinkingText) return false;
    const key = hashThinkingText(thinkingText.trim());
    return this.map.has(key);
  }

  /** Deletes entry by thinking text */
  delete(thinkingText: string): boolean {
    if (!thinkingText) return false;
    const key = hashThinkingText(thinkingText.trim());
    return this.map.delete(key);
  }

  /** Clears all */
  clear(): void {
    this.map.clear();
  }

  /** Iterates entries LRU order (oldest first) */
  entries(): IterableIterator<[string, string]> {
    return this.map.entries();
  }

  /** Keys in LRU order */
  keys(): IterableIterator<string> {
    return this.map.keys();
  }

  /** Returns diagnostic snapshot oldest->newest */
  snapshot(): Array<{ hash: string; signaturePreview: string }> {
    return Array.from(this.map.entries()).map(([h, s]) => ({
      hash: h,
      signaturePreview: s.slice(0, 24) + (s.length > 24 ? "…" : ""),
    }));
  }

  private evictIfNeeded(): void {
    while (this.map.size > this.maxSize) {
      const oldestKey = this.map.keys().next().value;
      if (oldestKey === undefined) break;
      this.map.delete(oldestKey);
    }
  }
}

/** Global singleton used by transformers — library-first convenience */
export const globalThinkingSignatureCache = new ThinkingSignatureCache(LRU_THINKING_CACHE_SIZE);

// ---------------------------------------------------------------------------
// SSE Incremental Parser — tolerante splits
// ---------------------------------------------------------------------------

/**
 * Raw SSE event parsed from wire.
 * Observer keeps it minimal — only what cloudcode-pa uses.
 */
export interface ParsedSSEEvent {
  /** Event type if server sent `event: xxx` */
  event?: string;
  /** Optional id `id: xxx` */
  id?: string;
  /** Retry interval `retry: xxx` */
  retry?: number;
  /** Joined data payload (may be JSON string, may be [DONE]) */
  data: string;
  /** Raw block for debugging */
  rawBlock: string;
}

/**
 * Mutable buffer holding incomplete SSE tail between network chunks.
 * Third-person: the observer accumulates until double newline terminator.
 */
export interface SSEParserState {
  /** Leftover incomplete tail */
  buffer: string;
  /** How many events parsed so far — useful for diagnostics */
  eventsSeen: number;
}

/**
 * Creates fresh parser state.
 */
export function createSSEParserState(): SSEParserState {
  return { buffer: "", eventsSeen: 0 };
}

/**
 * Parses one text chunk incrementally, tolerant to splits.
 *
 * The observer learned from production: fetch streaming may split in middle
 * of `data: {` JSON, or split the `\n\n` delimiter across chunks.
 * Strategy:
 *  1. Append chunk to state.buffer
 *  2. Normalize \r\n -> \n, \r -> \n
 *  3. While buffer contains `\n\n` extract block
 *  4. For each block, extract data: lines (join with \n per SSE spec)
 *  5. Leave incomplete tail in buffer
 *
 * @param chunk - new text arrived from decoder (may be partial)
 * @param state - mutable buffer object — will be updated in place
 * @returns parsed events from this chunk only
 *
 * @example
 *  const state = createSSEParserState();
 *  let ev = parseSSEChunk("data: {\"cand", state); // [] — buffered
 *  ev = parseSSEChunk("idates\":[]}\n\n", state); // 1 event
 */
export function parseSSEChunk(chunk: string, state: SSEParserState): ParsedSSEEvent[] {
  if (typeof chunk !== "string") {
    throw new TypeError(`parseSSEChunk chunk must be string, got ${typeof chunk}`);
  }
  if (!state || typeof state.buffer !== "string") {
    throw new TypeError("parseSSEChunk state must have .buffer string");
  }

  // Defensive: if chunk empty, nothing to do
  if (chunk.length === 0) return [];

  // Append and normalize line endings eagerly — \r\n and \r both become \n
  // This keeps split tolerance for \r\n across chunks (e.g. \r in previous, \n in current)
  state.buffer += chunk;
  // We cannot replace globally before we have full delimiter? We do incremental replace
  // but keep logic simple: replace \r\n first then \r
  // Important: don't destroy partial \r at end — if buffer ends with \r, keep it and wait for \n
  // So we only replace \r\n that are complete and standalone \r not at end.
  // Implementation: temporary replace \r\n -> \n, then replace remaining \r \n? Let's be safe.
  let buf = state.buffer.replace(/\r\n/g, "\n");
  // If last char is \r (could be split \r\n), keep it pending — but we already replaced \r\n, so lonely \r stays
  // Replace lonely \r not followed by anything? We convert them to \n except when it's last char and previous chunk may have split?
  // For simplicity we convert all remaining \r to \n — worst case we may prematurely split, but still valid SSE allows \r as line terminator.
  buf = buf.replace(/\r/g, "\n");
  state.buffer = buf;

  const events: ParsedSSEEvent[] = [];
  let searchStart = 0;

  while (true) {
    const delimiterIdx = state.buffer.indexOf("\n\n", searchStart);
    if (delimiterIdx === -1) break; // incomplete block — wait for more chunks

    const block = state.buffer.slice(searchStart, delimiterIdx);
    // Move window past delimiter
    const nextStart = delimiterIdx + 2;
    // Parse block lines
    const lines = block.split("\n");
    let dataLines: string[] = [];
    let eventType: string | undefined;
    let id: string | undefined;
    let retry: number | undefined;

    for (const rawLine of lines) {
      if (rawLine.length === 0) continue;
      if (rawLine.startsWith(":")) {
        // SSE comment / keepalive — ignore per spec
        continue;
      }
      // According to SSE spec, field is up to first colon
      const colonIdx = rawLine.indexOf(":");
      let field: string;
      let value: string;
      if (colonIdx === -1) {
        field = rawLine.trim();
        value = "";
      } else {
        field = rawLine.slice(0, colonIdx).trim();
        value = rawLine.slice(colonIdx + 1);
        // If value starts with single space, strip it (spec)
        if (value.startsWith(" ")) value = value.slice(1);
      }

      switch (field) {
        case "data":
          dataLines.push(value);
          break;
        case "event":
          eventType = value;
          break;
        case "id":
          id = value;
          break;
        case "retry":
          {
            const n = Number.parseInt(value, 10);
            if (Number.isFinite(n)) retry = n;
          }
          break;
        default:
          // Unknown field — spec says ignore
          break;
      }
    }

    // Per spec, if dataLines empty, no event dispatch
    if (dataLines.length > 0) {
      const data = dataLines.join("\n"); // multiple data: lines concatenated with \n
      events.push({
        event: eventType,
        id,
        retry,
        data,
        rawBlock: block,
      });
      state.eventsSeen++;
    }

    // Slice buffer: remove processed portion including delimiter
    // Since we search from searchStart, we need to handle correctly
    // Simplify: we maintain state.buffer as remaining after nextStart
    state.buffer = state.buffer.slice(nextStart);
    searchStart = 0; // reset because buffer changed

    // Safety: avoid infinite loop on huge buffers without delimiter
    if (state.buffer.length > 10 * 1024 * 1024) {
      // 10MB without delimiter is malformed — truncate to avoid OOM
      // Observer logs warning but continues
      console.warn("[streaming] SSE buffer exceeded 10MB without delimiter, truncating");
      state.buffer = state.buffer.slice(-1024 * 1024); // keep last 1MB
      break;
    }
  }

  return events;
}

/**
 * Parses a Uint8Array / Buffer chunk using TextDecoder streaming.
 * Convenience wrapper around parseSSEChunk for binary fetch streams.
 *
 * @param binaryChunk - Uint8Array from reader.read()
 * @param decoder - TextDecoder with {stream:true}
 * @param state - parser state
 */
export function parseSSEBinaryChunk(
  binaryChunk: Uint8Array,
  decoder: TextDecoder,
  state: SSEParserState,
): ParsedSSEEvent[] {
  if (!(binaryChunk instanceof Uint8Array)) {
    throw new TypeError("binaryChunk must be Uint8Array");
  }
  if (!(decoder instanceof TextDecoder)) {
    throw new TypeError("decoder must be TextDecoder");
  }
  const text = decoder.decode(binaryChunk, { stream: true });
  return parseSSEChunk(text, state);
}

// ---------------------------------------------------------------------------
// Payload normalization — heterogêneos
// ---------------------------------------------------------------------------

/**
 * Normalized tool call extracted from Antigravity part
 */
export interface NormalizedToolCall {
  /** Deterministic id if not provided by model */
  id: string;
  /** Function / tool name sanitized */
  name: string;
  /** Parsed args object if JSON parsable, otherwise raw string */
  args: unknown;
  /** Raw JSON string of args — for OpenAI delta streaming */
  argsJson: string;
  /** Whether this is delta (partial args) or final */
  isDelta?: boolean;
}

/**
 * Single normalized chunk produced from one or more raw payloads
 */
export interface NormalizedChunk {
  /** Text delta to emit (incremental already deduped) */
  text?: string;
  /** Full accumulated text for tracking */
  fullText?: string;
  /** Thinking delta */
  thinking?: string;
  /** Full accumulated thinking */
  fullThinking?: string;
  /** Signature for thinking block if present */
  thinkingSignature?: string;
  /** Tool calls extracted */
  toolCalls?: NormalizedToolCall[];
  /** Finish reason from cloudcode-pa, normalized to lowercase (stop, max_tokens, safety) */
  finishReason?: string;
  /** Raw original payload for debugging / grounding */
  raw: unknown;
  /** Candidate index if payload contained multiple candidates */
  candidateIndex?: number;
  /** Whether this part was marked as thought */
  isThought?: boolean;
  /** Grounding metadata e.g. groundingMetadata, groundingChunks */
  groundingMetadata?: unknown;
  /** Safety ratings if present */
  safetyRatings?: unknown;
  /** Usage metadata if present */
  usageMetadata?: unknown;
  /** Indicates stream is done (from [DONE] or finishReason) */
  isFinished?: boolean;
}

/**
 * Safe JSON parse — never throws, returns null on failure
 * @param text - raw data string
 */
export function safeJsonParse(text: string): unknown | null {
  if (!text || typeof text !== "string") return null;
  const trimmed = text.trim();
  if (trimmed.length === 0) return null;
  if (trimmed === SSE_DONE_SENTINEL) return { __sentinelDone: true };
  try {
    return JSON.parse(trimmed);
  } catch {
    // Tolerant attempt: sometimes cloudcode-pa sends multiple JSON concatenated with newline
    // Try first line
    try {
      const firstLine = trimmed.split("\n")[0];
      if (firstLine && firstLine !== trimmed) return JSON.parse(firstLine);
    } catch {
      // ignore
    }
    return null;
  }
}

/**
 * Unwraps heterogeneous envelope into candidate array.
 * Handles observed shapes:
 *  - {response:{candidates:[...]}}
 *  - {candidates:[...]}
 *  - {candidate:{...}}
 *  - [{...}, {...}] (already array)
 *  - {content:{parts:[...]}} single candidate
 *  - {parts:[...]} direct parts
 *
 * @param payload - parsed JSON object
 * @returns array of candidate-like objects
 */
export function unwrapCandidates(payload: unknown): unknown[] {
  if (!payload || typeof payload !== "object") return [];

  // Sentinel DONE already handled elsewhere
  const obj = payload as any;

  if (obj.__sentinelDone) return [];

  // Array directly = list of candidates or payloads
  if (Array.isArray(obj)) {
    return obj;
  }

  // response.candidates
  if (obj.response) {
    if (Array.isArray(obj.response.candidates)) return obj.response.candidates;
    if (obj.response.candidate) return [obj.response.candidate];
    if (obj.response.content || obj.response.parts) return [obj.response];
  }

  // candidates
  if (Array.isArray(obj.candidates)) return obj.candidates;

  // single candidate field
  if (obj.candidate && typeof obj.candidate === "object") return [obj.candidate];

  // content or parts at top level considered single candidate
  if (obj.content || obj.parts || obj.text || obj.thoughtSignature) return [obj];

  // Fallback: treat whole object as candidate
  return [obj];
}

/**
 * Extracts parts array from candidate
 */
export function extractParts(candidate: unknown): unknown[] {
  if (!candidate || typeof candidate !== "object") return [];
  const c = candidate as any;

  // Direct parts
  if (Array.isArray(c.parts)) return c.parts;
  // content.parts
  if (c.content && Array.isArray(c.content.parts)) return c.content.parts;
  // content array?
  if (Array.isArray(c.content)) return c.content;
  // text at candidate level as single part
  if (typeof c.text === "string") {
    return [{ text: c.text, thought: c.thought, thoughtSignature: c.thoughtSignature }];
  }

  // Gemini sometimes: candidate.content.parts empty but candidate itself is part
  if (c.functionCall || c.function_call) return [c];

  return [];
}

/**
 * Normalizes single part object into text/thinking/toolCall
 * @param part - raw part
 */
export function normalizePart(part: unknown): {
  text?: string;
  thinking?: string;
  thinkingSignature?: string;
  toolCall?: NormalizedToolCall;
  isThought?: boolean;
} {
  if (!part || typeof part !== "object") {
    if (typeof part === "string") return { text: part };
    return {};
  }
  const p = part as any;

  // Text + thought marker
  // Antigravity observed: {text:"xxx", thought:true, thoughtSignature:"..."}
  if (typeof p.text === "string") {
    if (p.thought === true || p.isThought === true || p.thoughtSignature || p.type === "thinking") {
      return {
        thinking: p.text,
        thinkingSignature: p.thoughtSignature || p.signature,
        isThought: true,
      };
    }
    return { text: p.text, isThought: false };
  }

  // Thinking explicitly: {thinking:"...", signature:"..."}
  if (typeof p.thinking === "string") {
    return {
      thinking: p.thinking,
      thinkingSignature: p.thoughtSignature || p.signature,
      isThought: true,
    };
  }

  // Function call shapes
  // Gemini: {functionCall:{name, args}}
  // Anthropic style: {tool_use:{id,name,input}}
  // OpenAI style inside Gemini: {function_call:{name,arguments}}
  const fc = p.functionCall || p.function_call || p.tool_use || p.toolUse;
  if (fc && typeof fc === "object") {
    const nameRaw = fc.name || fc.functionName || p.name || "unknown_tool";
    // Sanitize name: must start with letter or underscore for gemini, but we normalize
    const name = String(nameRaw).replace(/[^a-zA-Z0-9_.-]/g, "_");
    let argsRaw = fc.args || fc.arguments || fc.input || {};
    let argsJson: string;
    let argsParsed: unknown = argsRaw;

    if (typeof argsRaw === "string") {
      argsJson = argsRaw;
      try {
        argsParsed = JSON.parse(argsRaw);
      } catch {
        argsParsed = argsRaw;
      }
    } else {
      try {
        argsJson = JSON.stringify(argsRaw);
      } catch {
        argsJson = "{}";
      }
    }

    const id = fc.id || p.id || `toolu_${fnv1a32(name + argsJson).toString(16)}`;

    return {
      toolCall: {
        id: String(id),
        name,
        args: argsParsed,
        argsJson,
        isDelta: !!p.isDelta,
      },
    };
  }

  // Direct tool call at part level
  if (p.name && (p.args !== undefined || p.arguments !== undefined || p.input !== undefined)) {
    return {
      toolCall: {
        id: p.id || `toolu_${fnv1a32(p.name).toString(16)}`,
        name: String(p.name),
        args: p.args ?? p.arguments ?? p.input ?? {},
        argsJson: typeof (p.args ?? p.arguments ?? p.input) === "string" ? (p.args ?? p.arguments ?? p.input) : JSON.stringify(p.args ?? p.arguments ?? p.input ?? {}),
      },
    };
  }

  return {};
}

/**
 * Maps Gemini finishReason to normalized lowercase reason
 */
export function mapFinishReason(rawReason: unknown): string | undefined {
  if (!rawReason || typeof rawReason !== "string") return undefined;
  const r = rawReason.trim().toUpperCase();
  switch (r) {
    case "STOP":
    case "END_TURN":
    case "FINISH":
      return "stop";
    case "MAX_TOKENS":
    case "LENGTH":
      return "length";
    case "SAFETY":
    case "RECITATION":
      return "content_filter";
    case "TOOL_CALLS":
    case "TOOL_USE":
      return "tool_calls";
    default:
      return rawReason.toLowerCase();
  }
}

/**
 * Core normalizer — converts raw SSE data strings (JSON) into normalized chunks.
 * Tolerant to heterogeneous shapes observed in prod, daily, sandbox.
 *
 * @param rawDataStrings - array of data: payloads (already stripped of `data:` prefix)
 * @returns normalized chunks (may be more than input if multiple candidates)
 */
export function normalizePayloads(rawDataStrings: (string | unknown)[]): NormalizedChunk[] {
  const out: NormalizedChunk[] = [];

  for (const rawData of rawDataStrings) {
    let parsed: unknown;

    if (typeof rawData === "string") {
      const trimmed = rawData.trim();
      if (trimmed === "" || trimmed === SSE_DONE_SENTINEL) {
        out.push({
          raw: trimmed,
          isFinished: true,
          finishReason: "stop",
        });
        continue;
      }
      parsed = safeJsonParse(trimmed);
      if (parsed === null) {
        // If not JSON, treat as plain text delta (tolerant)
        out.push({
          text: rawData,
          fullText: rawData,
          raw: rawData,
        });
        continue;
      }
    } else {
      parsed = rawData;
    }

    if (parsed === null) continue;

    // Handle sentinel object
    if ((parsed as any).__sentinelDone) {
      out.push({
        raw: parsed,
        isFinished: true,
        finishReason: "stop",
      });
      continue;
    }

    const candidates = unwrapCandidates(parsed);

    for (let ci = 0; ci < candidates.length; ci++) {
      const cand = candidates[ci] as any;
      if (!cand) continue;

      const parts = extractParts(cand);
      let textAcc = "";
      let thinkingAcc = "";
      let thinkingSig: string | undefined;
      const toolCalls: NormalizedToolCall[] = [];
      let finishReason: string | undefined;
      let groundingMetadata: unknown;
      let safetyRatings: unknown;
      let usageMetadata: unknown;

      // Extract top-level fields from candidate
      if (cand.finishReason || cand.finish_reason || cand.stopReason) {
        finishReason = mapFinishReason(cand.finishReason || cand.finish_reason || cand.stopReason);
      }
      if (cand.groundingMetadata) groundingMetadata = cand.groundingMetadata;
      if (cand.grounding_metadata) groundingMetadata = cand.grounding_metadata;
      if (cand.safetyRatings) safetyRatings = cand.safetyRatings;
      if (cand.usageMetadata || cand.usage_metadata) usageMetadata = cand.usageMetadata || cand.usage_metadata;

      // If no parts, but candidate itself might be direct text (fallback)
      if (parts.length === 0) {
        // candidate may have content as string
        if (typeof cand.content === "string") {
          textAcc += cand.content;
        } else if (typeof cand.text === "string" && !cand.thought) {
          textAcc += cand.text;
        } else if (typeof cand.thinking === "string") {
          thinkingAcc += cand.thinking;
          thinkingSig = cand.thoughtSignature || cand.signature;
        }
      } else {
        for (const part of parts) {
          const norm = normalizePart(part);
          if (norm.text) textAcc += norm.text;
          if (norm.thinking) thinkingAcc += norm.thinking;
          if (norm.thinkingSignature) thinkingSig = norm.thinkingSignature;
          if (norm.toolCall) toolCalls.push(norm.toolCall);
        }
      }

      // Also check candidate-level thoughtSignature if no part signature
      if (!thinkingSig && cand.thoughtSignature) thinkingSig = cand.thoughtSignature;
      if (!thinkingSig && cand.signature) thinkingSig = cand.signature;

      // Skip empty candidate unless it has finishReason
      if (!textAcc && !thinkingAcc && toolCalls.length === 0 && !finishReason && !groundingMetadata) {
        // Might still be useful if it contains usage etc, but skip if truly empty
        // Keep as raw-only if it has any interesting field
        if (!cand.candidates && !cand.content && !cand.parts) continue;
      }

      out.push({
        text: textAcc || undefined,
        fullText: textAcc || undefined,
        thinking: thinkingAcc || undefined,
        fullThinking: thinkingAcc || undefined,
        thinkingSignature: thinkingSig,
        toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
        finishReason,
        groundingMetadata,
        safetyRatings,
        usageMetadata,
        raw: cand,
        candidateIndex: ci,
        isThought: thinkingAcc ? true : undefined,
        isFinished: finishReason ? true : undefined,
      });
    }
  }

  return out;
}

// ---------------------------------------------------------------------------
// Preservation of thinking blocks between chunks — delta tracking
// ---------------------------------------------------------------------------

/**
 * Extracts delta from full text given previously sent buffer.
 * If new text starts with old, returns suffix, else returns full new.
 * This handles both cumulative and incremental server behavior.
 *
 * @param full - current accumulated text from server (may be cumulative)
 * @param alreadySent - buffer already emitted to client
 * @returns delta to emit now
 */
export function extractDelta(full: string, alreadySent: string): string {
  if (!full) return "";
  if (!alreadySent) return full;
  if (full === alreadySent) return "";
  if (full.startsWith(alreadySent)) {
    return full.slice(alreadySent.length);
  }
  // If server sends incremental delta that doesn't start with previous (e.g. new block),
  // we check if alreadySent ends with prefix of full? simplest fallback: return full
  // But try to find largest common prefix
  // For production safety, just return full if not prefix — deduplication layer above handles
  // However attempt small heuristic: if full length < alreadySent length, likely reset -> return full
  return full;
}

/**
 * Tracks streaming session to preserve thinking and text between chunks.
 * The observer watches two buffers: sentThinkingBuffer and sentTextBuffer.
 * Prevents duplicated thinking blocks in UI (bug #120 in original repo).
 */
export class StreamingSessionTracker {
  private fullThinking = "";
  private sentThinking = "";
  private fullText = "";
  private sentText = "";
  private thinkingSignature?: string;
  private finished = false;
  private lastFinishReason?: string;
  private toolCallsSeen = new Map<string, NormalizedToolCall>();

  /**
   * @param signatureCache - optional LRU cache for thinking signatures
   */
  constructor(public readonly signatureCache: ThinkingSignatureCache = globalThinkingSignatureCache) {}

  /** Whether stream already finished */
  get isFinished(): boolean {
    return this.finished;
  }

  get currentThinking(): string {
    return this.fullThinking;
  }

  get currentText(): string {
    return this.fullText;
  }

  /**
   * Pushes new normalized chunk, deduplicates thinking/text, updates signature cache,
   * and returns delta-only chunk ready for transformer.
   *
   * @param chunk - normalized from normalizePayloads
   * @returns delta chunk (with only new portions) + metadata
   */
  push(chunk: NormalizedChunk): NormalizedChunk {
    if (!chunk) return chunk;

    let textDelta: string | undefined;
    let thinkingDelta: string | undefined;

    // ---- thinking preservation ----
    if (chunk.fullThinking || chunk.thinking) {
      const incomingThinking = chunk.fullThinking ?? chunk.thinking ?? "";
      // Accumulate if server sent cumulative? Heuristic: if incoming longer than current and starts with current, replace full with incoming
      if (!this.fullThinking) {
        this.fullThinking = incomingThinking;
      } else {
        // If incoming contains current as prefix, it is cumulative update
        if (incomingThinking.startsWith(this.fullThinking)) {
          this.fullThinking = incomingThinking;
        } else if (this.fullThinking.startsWith(incomingThinking)) {
          // incoming is subset already processed — keep existing full
        } else {
          // Different block or incremental — append if not duplicate
          // Check if already contains incoming suffix
          if (!this.fullThinking.includes(incomingThinking)) {
            this.fullThinking += incomingThinking;
          }
        }
      }

      // Extract what still needs to be sent
      thinkingDelta = extractDelta(this.fullThinking, this.sentThinking);
      if (thinkingDelta) {
        this.sentThinking += thinkingDelta;
      }

      // Signature handling — preserve latest
      if (chunk.thinkingSignature) {
        this.thinkingSignature = chunk.thinkingSignature;
        // Cache it keyed by current full thinking (when block finalized)
        // But we cache progressively as well to avoid losing signature on crash
        try {
          this.signatureCache.set(this.fullThinking, chunk.thinkingSignature);
        } catch {
          // ignore cache errors
        }
      } else {
        // Try to recover signature from cache if this thinking text was seen before
        // (multiturn continuation)
        try {
          const cachedSig = this.signatureCache.get(this.fullThinking);
          if (cachedSig) {
            this.thinkingSignature = cachedSig;
            chunk.thinkingSignature = cachedSig;
          }
        } catch {
          // ignore
        }
      }
    }

    // ---- text preservation ----
    if (chunk.fullText || chunk.text) {
      const incomingText = chunk.fullText ?? chunk.text ?? "";
      if (!this.fullText) {
        this.fullText = incomingText;
      } else {
        if (incomingText.startsWith(this.fullText)) {
          this.fullText = incomingText;
        } else if (!this.fullText.includes(incomingText)) {
          // Append only if not already included
          this.fullText += incomingText;
        }
      }
      textDelta = extractDelta(this.fullText, this.sentText);
      if (textDelta) this.sentText += textDelta;
    }

    // ---- tool calls ----
    let mergedToolCalls: NormalizedToolCall[] | undefined;
    if (chunk.toolCalls && chunk.toolCalls.length > 0) {
      mergedToolCalls = [];
      for (const tc of chunk.toolCalls) {
        const prev = this.toolCallsSeen.get(tc.id);
        if (!prev) {
          this.toolCallsSeen.set(tc.id, tc);
          mergedToolCalls.push(tc);
        } else {
          // Merge args (delta)
          if (tc.argsJson && tc.argsJson !== prev.argsJson) {
            // append delta args if looks like incremental JSON
            const mergedArgsJson = prev.argsJson + tc.argsJson;
            // Keep merged but also provide delta
            const merged: NormalizedToolCall = {
              ...tc,
              argsJson: mergedArgsJson,
              isDelta: true,
            };
            this.toolCallsSeen.set(tc.id, { ...prev, argsJson: mergedArgsJson });
            mergedToolCalls.push(merged);
          }
        }
      }
      if (mergedToolCalls.length === 0) mergedToolCalls = undefined;
    }

    // ---- finish tracking ----
    if (chunk.finishReason || chunk.isFinished) {
      this.finished = true;
      this.lastFinishReason = chunk.finishReason || "stop";
    }

    return {
      ...chunk,
      text: textDelta ?? undefined,
      fullText: this.fullText || undefined,
      thinking: thinkingDelta ?? undefined,
      fullThinking: this.fullThinking || undefined,
      thinkingSignature: this.thinkingSignature || chunk.thinkingSignature,
      toolCalls: mergedToolCalls,
    };
  }

  /**
   * Returns synthetic finish chunk if stream ended without explicit finish.
   * Preserves last known signature.
   */
  createSyntheticFinish(reason = "stop"): NormalizedChunk | null {
    if (this.finished) return null;
    this.finished = true;
    this.lastFinishReason = reason;
    return {
      raw: { synthetic: true, reason, fullThinking: this.fullThinking, fullText: this.fullText },
      finishReason: reason,
      isFinished: true,
      thinkingSignature: this.thinkingSignature,
      fullThinking: this.fullThinking || undefined,
      fullText: this.fullText || undefined,
    };
  }

  /** Resets tracker for new stream */
  reset(): void {
    this.fullThinking = "";
    this.sentThinking = "";
    this.fullText = "";
    this.sentText = "";
    this.thinkingSignature = undefined;
    this.finished = false;
    this.lastFinishReason = undefined;
    this.toolCallsSeen.clear();
  }

  /** Diagnostic snapshot */
  snapshot(): {
    fullThinkingLen: number;
    sentThinkingLen: number;
    fullTextLen: number;
    sentTextLen: number;
    finished: boolean;
    toolCalls: number;
    hasSignature: boolean;
  } {
    return {
      fullThinkingLen: this.fullThinking.length,
      sentThinkingLen: this.sentThinking.length,
      fullTextLen: this.fullText.length,
      sentTextLen: this.sentText.length,
      finished: this.finished,
      toolCalls: this.toolCallsSeen.size,
      hasSignature: !!this.thinkingSignature,
    };
  }
}

// ---------------------------------------------------------------------------
// OpenAI compatible transformer — opencode expects chat.completion.chunk
// ---------------------------------------------------------------------------

export interface OpenAIChunkOptions {
  /** Model id to echo back — e.g. antigravity-gemini-3-flash */
  model: string;
  /** Optional fixed id for stream — if not provided random-ish */
  id?: string;
  /** Creation timestamp in seconds */
  created?: number;
}

function generateChatId(): string {
  try {
    const bytes = createHash("sha256").update(String(Date.now()) + Math.random()).digest("hex").slice(0, 12);
    return `chatcmpl-${bytes}`;
  } catch {
    return `chatcmpl-${fnv1a32(String(Date.now())).toString(16)}`;
  }
}

/**
 * Maps normalized finishReason to OpenAI finish_reason values
 */
function mapToOpenAIFinishReason(reason?: string): string | null {
  if (!reason) return null;
  switch (reason) {
    case "stop":
      return "stop";
    case "length":
      return "length";
    case "content_filter":
      return "content_filter";
    case "tool_calls":
      return "tool_calls";
    case "tool_use":
      return "tool_calls";
    default:
      return reason;
  }
}

/**
 * Transforms normalized chunks into OpenAI SSE lines.
 * Library-first: stateless transform + session tracker for delta.
 *
 * The observer emits reasoning_content for thinking (opencode supports both
 * reasoning and reasoning_content per 2026 spec).
 *
 * @param chunk - delta chunk from StreamingSessionTracker
 * @param opts - model/id/created
 * @returns array of SSE formatted strings `data: {...}\n\n`
 */
export function transformToOpenAI(
  chunk: NormalizedChunk,
  opts: OpenAIChunkOptions,
  tracker?: StreamingSessionTracker,
): string[] {
  const id = opts.id ?? generateChatId();
  const created = opts.created ?? Math.floor(Date.now() / 1000);
  const choiceIndex = chunk.candidateIndex ?? 0;

  const delta: any = {};

  // Thinking — map to reasoning_content (opencode + OpenAI compat)
  if (chunk.thinking && chunk.thinking.length > 0) {
    delta.reasoning_content = chunk.thinking;
    delta.reasoning = chunk.thinking; // alt field for compatibility
    // Include signature if present — some clients use it for multi-turn
    if (chunk.thinkingSignature) {
      delta.reasoning_content_signature = chunk.thinkingSignature;
      delta.thinking_signature = chunk.thinkingSignature;
    }
  }

  // Text
  if (chunk.text && chunk.text.length > 0) {
    delta.content = chunk.text;
  }

  // Tool calls
  if (chunk.toolCalls && chunk.toolCalls.length > 0) {
    delta.tool_calls = chunk.toolCalls.map((tc, idx) => ({
      index: idx,
      id: tc.id,
      type: "function",
      function: {
        name: tc.name,
        // OpenAI streams incremental args as delta; we send full or delta depending on isDelta
        arguments: tc.argsJson,
      },
    }));
  }

  // Grounding metadata passthrough as extra field for search models
  if (chunk.groundingMetadata) {
    delta.grounding_metadata = chunk.groundingMetadata;
  }

  const hasDelta = Object.keys(delta).length > 0;
  const finish = mapToOpenAIFinishReason(chunk.finishReason);

  // If nothing to emit and no finish, skip (empty chunk)
  if (!hasDelta && !finish && !chunk.isFinished) {
    return [];
  }

  const payload: any = {
    id,
    object: "chat.completion.chunk",
    created,
    model: opts.model,
    choices: [
      {
        index: choiceIndex,
        delta: hasDelta ? delta : {},
        finish_reason: finish ?? null,
        // Include logprobs null per OpenAI spec
        logprobs: null,
      },
    ],
  };

  // If usage present, include for final chunk (some clients expect)
  if (chunk.usageMetadata && finish) {
    payload.usage = chunk.usageMetadata;
  }

  return [`data: ${JSON.stringify(payload)}\n\n`];
}

/**
 * Factory that returns stateful OpenAI transformer with internal tracker
 * and LRU signature cache. Suitable for opencode plugin hook.
 *
 * @param opts - model options
 * @param cache - optional cache injection
 */
export function createOpenAIStreamingTransformer(
  opts: OpenAIChunkOptions,
  cache: ThinkingSignatureCache = globalThinkingSignatureCache,
): {
  tracker: StreamingSessionTracker;
  transform: (chunk: NormalizedChunk) => string[];
  final: () => string[];
} {
  const tracker = new StreamingSessionTracker(cache);
  const fixedId = opts.id ?? generateChatId();
  const created = opts.created ?? Math.floor(Date.now() / 1000);

  return {
    tracker,
    transform: (chunk: NormalizedChunk) => {
      const deduped = tracker.push(chunk);
      // If after dedup nothing new but finish, still emit finish
      if (!deduped.text && !deduped.thinking && !deduped.toolCalls && !deduped.finishReason) {
        if (deduped.isFinished || deduped.finishReason) {
          // force emit finish even if deduped empty
          return transformToOpenAI(deduped, { ...opts, id: fixedId, created }, tracker);
        }
        return [];
      }
      return transformToOpenAI(deduped, { ...opts, id: fixedId, created }, tracker);
    },
    final: () => {
      const synthetic = tracker.createSyntheticFinish("stop");
      if (!synthetic) return [];
      return transformToOpenAI(synthetic, { ...opts, id: fixedId, created }, tracker);
    },
  };
}

// ---------------------------------------------------------------------------
// Anthropic compatible transformer — opencode uses Anthropic messages SSE
// ---------------------------------------------------------------------------

export interface AnthropicChunkOptions {
  /** Model to echo */
  model: string;
  /** Message id */
  messageId?: string;
}

type AnthropicBlockType = "text" | "thinking" | "tool_use";

/**
 * Internal state for Anthropic streaming sequence.
 * Observer maintains index counters per content block.
 */
class AnthropicStateMachine {
  public messageStarted = false;
  public nextBlockIndex = 0;
  public activeBlocks = new Map<number, AnthropicBlockType>();
  public blockThinkingSent = new Map<number, string>();
  public blockTextSent = new Map<number, string>();
  public toolJsonSent = new Map<string, string>();
  public finished = false;

  reset(): void {
    this.messageStarted = false;
    this.nextBlockIndex = 0;
    this.activeBlocks.clear();
    this.blockThinkingSent.clear();
    this.blockTextSent.clear();
    this.toolJsonSent.clear();
    this.finished = false;
  }
}

/**
 * Transforms normalized chunk into Anthropic SSE events.
 * Emits event: / data: pairs as per Anthropic Messages streaming spec:
 *   message_start, content_block_start, content_block_delta, content_block_stop,
 *   message_delta, message_stop
 *
 * Library-first: each call returns array of formatted SSE lines.
 *
 * @param chunk - delta chunk from tracker
 * @param opts - model/message options
 * @param state - anthropic state machine (mutable)
 * @returns array of SSE lines (`event: xxx\ndata: {...}\n\n`)
 */
export function transformToAnthropic(
  chunk: NormalizedChunk,
  opts: AnthropicChunkOptions,
  state: AnthropicStateMachine,
): string[] {
  const out: string[] = [];
  const messageId = opts.messageId ?? `msg_${fnv1a32(String(Date.now())).toString(16)}`;

  // Helper to emit event+data pair
  const emit = (eventType: string, dataObj: unknown): void => {
    out.push(`event: ${eventType}\ndata: ${JSON.stringify(dataObj)}\n\n`);
  };

  // message_start on first emission
  if (!state.messageStarted) {
    state.messageStarted = true;
    emit("message_start", {
      type: "message_start",
      message: {
        id: messageId,
        type: "message",
        role: "assistant",
        content: [],
        model: opts.model,
        stop_reason: null,
        stop_sequence: null,
        usage: { input_tokens: 0, output_tokens: 0 },
      },
    });
  }

  // Thinking handling
  if (chunk.thinking && chunk.thinking.length > 0) {
    // Find active thinking block or create new
    let idx = Array.from(state.activeBlocks.entries()).find(([, t]) => t === "thinking")?.[0];
    if (idx === undefined) {
      idx = state.nextBlockIndex++;
      state.activeBlocks.set(idx, "thinking");
      state.blockThinkingSent.set(idx, "");
      emit("content_block_start", {
        type: "content_block_start",
        index: idx,
        content_block: {
          type: "thinking",
          thinking: "",
          signature: chunk.thinkingSignature ?? "",
        },
      });
    }

    // Delta
    const prev = state.blockThinkingSent.get(idx) ?? "";
    // chunk.thinking already delta from tracker, but we still track
    // For anthropic, thinking delta event
    emit("content_block_delta", {
      type: "content_block_delta",
      index: idx,
      delta: {
        type: "thinking_delta",
        thinking: chunk.thinking,
      },
    });
    state.blockThinkingSent.set(idx, prev + chunk.thinking);
  }

  // Text handling
  if (chunk.text && chunk.text.length > 0) {
    let idx = Array.from(state.activeBlocks.entries()).find(([, t]) => t === "text")?.[0];
    // If thinking block active, we should keep text separate — create new block if first text
    // But also text may come after thinking stopped — we need new block
    const hasActiveText = state.activeBlocks.has(idx as number) && state.activeBlocks.get(idx as number) === "text";
    if (!hasActiveText) {
      // If there is active thinking and we now have text, we should stop thinking block first (per Claude spec thinking must precede text)
      const thinkingIdx = Array.from(state.activeBlocks.entries()).find(([, t]) => t === "thinking")?.[0];
      if (thinkingIdx !== undefined) {
        emit("content_block_stop", {
          type: "content_block_stop",
          index: thinkingIdx,
        });
        state.activeBlocks.delete(thinkingIdx);
      }
      idx = state.nextBlockIndex++;
      state.activeBlocks.set(idx, "text");
      state.blockTextSent.set(idx, "");
      emit("content_block_start", {
        type: "content_block_start",
        index: idx,
        content_block: {
          type: "text",
          text: "",
        },
      });
    }

    emit("content_block_delta", {
      type: "content_block_delta",
      index: idx,
      delta: {
        type: "text_delta",
        text: chunk.text,
      },
    });
    const prev = state.blockTextSent.get(idx!) ?? "";
    state.blockTextSent.set(idx!, prev + chunk.text);
  }

  // Tool calls
  if (chunk.toolCalls && chunk.toolCalls.length > 0) {
    for (const tc of chunk.toolCalls) {
      // One content block per tool_use
      // Check if tool already has block
      let idx: number | undefined;
      // We use tool id as map key for block index lookup
      for (const [bIdx, bType] of state.activeBlocks.entries()) {
        if (bType === "tool_use" && state.toolJsonSent.has(`idx_${bIdx}_id_${tc.id}`)) {
          idx = bIdx;
          break;
        }
      }
      const isNew = idx === undefined;
      if (isNew) {
        idx = state.nextBlockIndex++;
        state.activeBlocks.set(idx, "tool_use");
        state.toolJsonSent.set(`idx_${idx}_id_${tc.id}`, "");
        state.toolJsonSent.set(`id_${tc.id}`, String(idx)); // reverse lookup
        emit("content_block_start", {
          type: "content_block_start",
          index: idx,
          content_block: {
            type: "tool_use",
            id: tc.id,
            name: tc.name,
            input: {},
          },
        });
      }

      // input_json delta
      // For Anthropic, partial_json is incremental input json
      const prevJson = state.toolJsonSent.get(`idx_${idx}_id_${tc.id}`) ?? "";
      const deltaJson = tc.isDelta ? tc.argsJson : extractDelta(tc.argsJson, prevJson) || tc.argsJson;
      if (deltaJson) {
        emit("content_block_delta", {
          type: "content_block_delta",
          index: idx,
          delta: {
            type: "input_json_delta",
            partial_json: deltaJson,
          },
        });
        state.toolJsonSent.set(`idx_${idx}_id_${tc.id}`, prevJson + deltaJson);
      }
    }
  }

  // Finish handling
  if (chunk.finishReason || chunk.isFinished) {
    // Stop all active blocks
    for (const [bIdx] of state.activeBlocks.entries()) {
      emit("content_block_stop", {
        type: "content_block_stop",
        index: bIdx,
      });
    }
    state.activeBlocks.clear();

    // Map finish reason to Anthropic stop_reason
    let stopReason: string | null = "end_turn";
    switch (chunk.finishReason) {
      case "tool_calls":
        stopReason = "tool_use";
        break;
      case "length":
        stopReason = "max_tokens";
        break;
      case "content_filter":
        stopReason = "stop_sequence";
        break;
      default:
        stopReason = chunk.finishReason ? "end_turn" : "end_turn";
    }

    emit("message_delta", {
      type: "message_delta",
      delta: {
        stop_reason: stopReason,
        stop_sequence: null,
      },
      usage: chunk.usageMetadata ?? { output_tokens: 0 },
    });

    emit("message_stop", {
      type: "message_stop",
    });

    state.finished = true;
  }

  return out;
}

/**
 * Factory for Anthropic streaming transformer compatible with opencode
 *
 * @param opts - model options
 * @param cache - LRU signature cache
 */
export function createAnthropicStreamingTransformer(
  opts: AnthropicChunkOptions,
  cache: ThinkingSignatureCache = globalThinkingSignatureCache,
): {
  tracker: StreamingSessionTracker;
  anthropicState: AnthropicStateMachine;
  transform: (chunk: NormalizedChunk) => string[];
  final: () => string[];
} {
  const tracker = new StreamingSessionTracker(cache);
  const anthropicState = new AnthropicStateMachine();

  return {
    tracker,
    anthropicState,
    transform: (chunk: NormalizedChunk) => {
      const deduped = tracker.push(chunk);
      // If nothing new and not finish, skip
      if (!deduped.text && !deduped.thinking && !deduped.toolCalls && !deduped.finishReason && !deduped.isFinished) {
        return [];
      }
      return transformToAnthropic(deduped, opts, anthropicState);
    },
    final: () => {
      const synthetic = tracker.createSyntheticFinish("stop");
      if (!synthetic) return [];
      return transformToAnthropic(synthetic, opts, anthropicState);
    },
  };
}

// ---------------------------------------------------------------------------
// Auto-recovery — retry exponencial e injeção finish sintético
// ---------------------------------------------------------------------------

export interface RetryOptions {
  /** Max attempts including first */
  maxRetries?: number;
  /** Base delay ms */
  baseMs?: number;
  /** Factor */
  factor?: number;
  /** Max delay ms */
  maxMs?: number;
  /** Which status codes trigger retry */
  retryableStatus?: number[];
}

/**
 * Determines if error/status is retryable.
 * Observer pattern: checks 429, 5xx, and network failures.
 *
 * @param status - HTTP status or undefined for network error
 */
export function isRetryableStatus(status: number | undefined, opts?: RetryOptions): boolean {
  if (status === undefined) return true; // network failure retryable
  const list = opts?.retryableStatus ?? (RETRYABLE_STATUS_CODES as unknown as number[]);
  return list.includes(status);
}

/**
 * Fetches with exponential backoff + jitter.
 * Uses only node builtins + global fetch.
 * Third-person observer: it watches fetch, retries on transient errors.
 *
 * @param input - RequestInfo
 * @param init - RequestInit
 * @param retryOpts - backoff options
 * @returns Response
 * @throws last error after retries exhausted
 */
export async function fetchWithExponentialRetry(
  input: RequestInfo | URL,
  init?: RequestInit,
  retryOpts: RetryOptions = {},
): Promise<Response> {
  const maxRetries = retryOpts.maxRetries ?? MAX_RETRIES;
  const baseMs = retryOpts.baseMs ?? BACKOFF_BASE_MS;
  const factor = retryOpts.factor ?? BACKOFF_FACTOR;
  const maxMs = retryOpts.maxMs ?? BACKOFF_MAX_MS;

  let attempt = 0;
  let lastError: unknown;

  while (attempt <= maxRetries) {
    try {
      const res = await fetch(input, init);

      if (res.ok) return res;

      // Non-ok: check if retryable
      if (!isRetryableStatus(res.status, retryOpts) || attempt >= maxRetries) {
        return res; // return non-retryable response for caller to handle
      }

      // Retryable status — consume body to free connection before retry
      try {
        await res.text();
      } catch {
        // ignore
      }

      lastError = new Error(`retryable status ${res.status}`);
    } catch (err) {
      lastError = err;
      if (attempt >= maxRetries) break;
      // network error — retryable unless explicitly non-retryable
    }

    // Backoff before next attempt
    if (attempt < maxRetries) {
      const delay = Math.min(baseMs * Math.pow(factor, attempt), maxMs);
      await sleepWithJitter(delay);
    }

    attempt++;
  }

  throw lastError instanceof Error ? lastError : new Error(String(lastError ?? "fetch retry exhausted"));
}

/**
 * Creates synthetic finish chunk when stream closes abruptly.
 * Observer injects `stop` finish to keep opencode SDK happy.
 *
 * @param tracker - session tracker to know current state
 * @param reason - finish reason, default stop
 * @returns normalized finish chunk or null if already finished
 */
export function injectSyntheticFinish(
  tracker: StreamingSessionTracker,
  reason: string = "stop",
): NormalizedChunk | null {
  return tracker.createSyntheticFinish(reason);
}

/**
 * Wraps streaming response reading with auto-recovery.
 * If reader throws before finish, retries whole fetch (exponential).
 * On final failure, injects synthetic finish so UI doesn't hang.
 *
 * @param fetchFn - function that returns Promise<Response> (fresh fetch each attempt)
 * @param onChunk - callback for each normalized chunk (deduped)
 * @param retryOpts - retry options for fetch phase
 * @param tracker - optional tracker (if not provided new one created)
 */
export async function withAutoRecoveryStreaming(
  fetchFn: () => Promise<Response>,
  onChunk: (chunk: NormalizedChunk) => void | Promise<void>,
  retryOpts: RetryOptions = {},
  tracker: StreamingSessionTracker = new StreamingSessionTracker(globalThinkingSignatureCache),
): Promise<void> {
  const maxRetries = retryOpts.maxRetries ?? MAX_RETRIES;
  let attempt = 0;

  while (attempt <= maxRetries) {
    let response: Response;
    try {
      response = await fetchWithExponentialRetry(
        // dummy — actual fetchFn does request construction
        // We call fetchFn directly but reuse retry logic for network: we wrap fetchFn with backoff here
        // So first we try fetchFn()
        // fetchWithExponentialRetry expects input, not fn — we implement manual retry loop for fetchFn
        // Instead we directly call fetchFn and apply retry inside catch below
        // For simplicity we call fetchFn here and if it throws we retry
        // This inner try will rely on outer loop for backoff
        "" as unknown as RequestInfo,
        undefined,
        retryOpts,
      ).catch(() => {
        // unreachable because we pass empty input — we will replace with fetchFn call
        return null as any;
      });
      // Actually we need to call fetchFn, not fetchWithExponentialRetry with dummy
      // Re-do: override response with fetchFn result
      response = await fetchFn();
    } catch (err) {
      if (attempt >= maxRetries) {
        // Final failure — inject synthetic finish and exit
        const synthetic = tracker.createSyntheticFinish("stop");
        if (synthetic) await onChunk(synthetic);
        throw err;
      }
      const delay = Math.min(
        (retryOpts.baseMs ?? BACKOFF_BASE_MS) * Math.pow(retryOpts.factor ?? BACKOFF_FACTOR, attempt),
        retryOpts.maxMs ?? BACKOFF_MAX_MS,
      );
      await sleepWithJitter(delay);
      attempt++;
      continue;
    }

    if (!response.ok) {
      if (isRetryableStatus(response.status, retryOpts) && attempt < maxRetries) {
        try {
          await response.text();
        } catch {
          // ignore
        }
        const delay = Math.min(
          (retryOpts.baseMs ?? BACKOFF_BASE_MS) * Math.pow(retryOpts.factor ?? BACKOFF_FACTOR, attempt),
          retryOpts.maxMs ?? BACKOFF_MAX_MS,
        );
        await sleepWithJitter(delay);
        attempt++;
        continue;
      }
      // Non-retryable error — propagate response error as exception with body preview
      let bodyPreview = "";
      try {
        bodyPreview = (await response.text()).slice(0, 2000);
      } catch {
        bodyPreview = "<no body>";
      }
      throw new Error(`cloudcode-pa ${response.status} ${response.statusText}: ${bodyPreview}`);
    }

    // Stream reading phase — try to read all
    try {
      for await (const normalized of readSSEStream(response, tracker)) {
        await onChunk(normalized);
      }

      // Normal end — ensure finish injected if missing
      if (!tracker.isFinished) {
        const synthetic = tracker.createSyntheticFinish("stop");
        if (synthetic) await onChunk(synthetic);
      }

      return; // success
    } catch (streamErr) {
      // Stream broke mid-way, retry if not finished and attempts left
      if (attempt >= maxRetries || tracker.isFinished) {
        if (!tracker.isFinished) {
          const synthetic = tracker.createSyntheticFinish("stop");
          if (synthetic) await onChunk(synthetic);
        }
        throw streamErr;
      }
      const delay = Math.min(
        (retryOpts.baseMs ?? BACKOFF_BASE_MS) * Math.pow(retryOpts.factor ?? BACKOFF_FACTOR, attempt),
        retryOpts.maxMs ?? BACKOFF_MAX_MS,
      );
      await sleepWithJitter(delay);
      attempt++;
      // Continue retry loop — will re-fetch and continue? Note: we lost progress but tracker preserves sent state for dedup
      continue;
    }
  }
}

// ---------------------------------------------------------------------------
// High-level SSE stream reader — direct cloudcode-pa
// ---------------------------------------------------------------------------

/**
 * Async generator that reads a fetch Response body (cloudcode-pa alt=sse)
 * and yields normalized chunks with preserved thinking blocks.
 *
 * The observer directly consumes https://cloudcode-pa.googleapis.com
 * (or daily-.../sandbox) without localhost v1 proxy.
 *
 * @param response - fetch Response with body ReadableStream
 * @param tracker - optional tracker for delta preservation (new one if not provided)
 * @yields NormalizedChunk (deduped delta already applied via tracker)
 */
export async function* readSSEStream(
  response: Response,
  tracker: StreamingSessionTracker = new StreamingSessionTracker(globalThinkingSignatureCache),
): AsyncGenerator<NormalizedChunk> {
  if (!response || !response.body) {
    throw new TypeError("readSSEStream requires Response with body");
  }

  const parserState = createSSEParserState();
  const decoder = new TextDecoder("utf-8");

  // Node fetch Response.body is a ReadableStream (web)
  const reader = (response.body as any).getReader() as ReadableStreamDefaultReader<Uint8Array>;

  if (!reader || typeof reader.read !== "function") {
    throw new Error("Response body does not implement getReader() — unsupported environment");
  }

  try {
    while (true) {
      let result: ReadableStreamReadResult<Uint8Array>;
      try {
        result = await reader.read();
      } catch (readErr) {
        // Network mid-stream failure — let outer auto-recovery handle
        throw new Error(`stream read failed: ${(readErr as Error).message}`, { cause: readErr as any });
      }

      if (result.done) break;

      const value = result.value;
      if (!value || value.length === 0) continue;

      let textChunk: string;
      try {
        textChunk = decoder.decode(value, { stream: true });
      } catch (decErr) {
        console.warn("[streaming] TextDecoder failed, skipping chunk", decErr);
        continue;
      }

      let events: ParsedSSEEvent[];
      try {
        events = parseSSEChunk(textChunk, parserState);
      } catch (parseErr) {
        console.warn("[streaming] parseSSEChunk failed", parseErr);
        continue;
      }

      if (events.length === 0) continue;

      for (const ev of events) {
        // Skip [DONE] sentinel here — normalize will handle but we also short-circuit
        if (ev.data.trim() === SSE_DONE_SENTINEL) {
          const chunks = normalizePayloads([ev.data]);
          for (const c of chunks) {
            const deduped = tracker.push(c);
            yield deduped;
          }
          continue;
        }

        const normalizedList = normalizePayloads([ev.data]);

        for (const norm of normalizedList) {
          const deduped = tracker.push(norm);
          // Yield only if has something new or finish
          if (
            deduped.text ||
            deduped.thinking ||
            (deduped.toolCalls && deduped.toolCalls.length > 0) ||
            deduped.finishReason ||
            deduped.isFinished
          ) {
            yield deduped;
          } else if (deduped.isFinished) {
            yield deduped;
          }
        }
      }
    }

    // Flush decoder remaining
    try {
      const remaining = decoder.decode();
      if (remaining) {
        const events = parseSSEChunk(remaining, parserState);
        for (const ev of events) {
          const normalizedList = normalizePayloads([ev.data]);
          for (const norm of normalizedList) {
            yield tracker.push(norm);
          }
        }
      }
    } catch {
      // ignore flush errors
    }

    // If buffer still has data without trailing \n\n, try to parse it as final block (tolerant)
    if (parserState.buffer.trim().length > 0) {
      const finalBlock = parserState.buffer.trim();
      // Attempt to treat it as data line even without delimiter
      // Remove possible "data:" prefix if present
      let dataPayload = finalBlock;
      if (dataPayload.startsWith("data:")) {
        dataPayload = dataPayload.slice(5).trimStart();
      }
      if (dataPayload && dataPayload !== SSE_DONE_SENTINEL) {
        const normalizedList = normalizePayloads([dataPayload]);
        for (const norm of normalizedList) {
          yield tracker.push(norm);
        }
      }
      parserState.buffer = "";
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      // ignore
    }
  }
}

/**
 * Convenience: stream cloudcode-pa response and transform to OpenAI SSE lines.
 * Used by opencode plugin fetch interceptor.
 *
 * @param response - fetch Response from cloudcode-pa
 * @param openAIOpts - model info
 * @param cache - optional LRU cache
 * @returns AsyncGenerator<string> of `data: {...}\n\n` lines
 */
export async function* streamToOpenAI(
  response: Response,
  openAIOpts: OpenAIChunkOptions,
  cache: ThinkingSignatureCache = globalThinkingSignatureCache,
): AsyncGenerator<string> {
  const tracker = new StreamingSessionTracker(cache);
  const fixedId = openAIOpts.id ?? generateChatId();
  const created = openAIOpts.created ?? Math.floor(Date.now() / 1000);

  for await (const norm of readSSEStream(response, tracker)) {
    const lines = transformToOpenAI(norm, { ...openAIOpts, id: fixedId, created }, tracker);
    for (const line of lines) yield line;
  }

  if (!tracker.isFinished) {
    const synthetic = tracker.createSyntheticFinish("stop");
    if (synthetic) {
      const lines = transformToOpenAI(synthetic, { ...openAIOpts, id: fixedId, created }, tracker);
      for (const line of lines) yield line;
    }
  }

  // Final [DONE] for OpenAI clients
  yield `data: ${SSE_DONE_SENTINEL}\n\n`;
}

/**
 * Convenience: stream cloudcode-pa response and transform to Anthropic SSE lines.
 *
 * @param response - fetch Response
 * @param anthropicOpts - model info
 * @param cache - optional LRU cache
 * @returns AsyncGenerator<string> of `event: ...\ndata: ...\n\n`
 */
export async function* streamToAnthropic(
  response: Response,
  anthropicOpts: AnthropicChunkOptions,
  cache: ThinkingSignatureCache = globalThinkingSignatureCache,
): AsyncGenerator<string> {
  const tracker = new StreamingSessionTracker(cache);
  const anthropicState = new AnthropicStateMachine();

  for await (const norm of readSSEStream(response, tracker)) {
    const lines = transformToAnthropic(norm, anthropicOpts, anthropicState);
    for (const line of lines) yield line;
  }

  if (!tracker.isFinished) {
    const synthetic = tracker.createSyntheticFinish("stop");
    if (synthetic) {
      const lines = transformToAnthropic(synthetic, anthropicOpts, anthropicState);
      for (const line of lines) yield line;
    }
  }
}

// ---------------------------------------------------------------------------
// Exports — library-first barrel
// ---------------------------------------------------------------------------

/**
 * Default export for barrel compatibility: contains all primary helpers
 */
const streamingModule = {
  LRU_THINKING_CACHE_SIZE,
  ThinkingSignatureCache,
  globalThinkingSignatureCache,
  createSSEParserState,
  parseSSEChunk,
  parseSSEBinaryChunk,
  safeJsonParse,
  unwrapCandidates,
  extractParts,
  normalizePart,
  normalizePayloads,
  mapFinishReason,
  extractDelta,
  StreamingSessionTracker,
  transformToOpenAI,
  createOpenAIStreamingTransformer,
  transformToAnthropic,
  createAnthropicStreamingTransformer,
  fetchWithExponentialRetry,
  injectSyntheticFinish,
  withAutoRecoveryStreaming,
  readSSEStream,
  streamToOpenAI,
  streamToAnthropic,
  fnv1a32,
  hashThinkingText,
  getJitter,
  sleepWithJitter,
  SSE_DONE_SENTINEL,
};

export default streamingModule;
