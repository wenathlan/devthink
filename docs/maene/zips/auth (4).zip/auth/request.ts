/**
 * @file request.ts
 * @module opencode-antigravity-auth-next/request
 * @description
 *  Third-person observer view: the library watches how OpenCode transforms
 *  user messages (OpenAI and Anthropic shapes) into Gemini/Claude payloads
 *  and how Antigravity Manager forwards them to cloudcode-pa.googleapis.com
 *  without using localhost v1 proxy.
 *
 *  Responsibilities:
 *  - transformRequest: OpenCode → Gemini normalized request (contents, system, tools, genConfig)
 *  - buildAntigravityRequest / buildGeminiCLIRequest: wraps normalized request into
 *    cloudcode-pa envelope with deterministic session_id / user_prompt_id (FNV-1a),
 *    endpoint cascade, fingerprint headers, and x-goog-user-project stripping
 *  - isGeminiCLIOnlyModel: prod-only detection for 2026 models (gemini-3, preview)
 *  - thinking blocks mapping, JSON Schema cleaning, tool name validation/sanitization,
 *    google_search injection when enabled
 *
 *  Architecture governance:
 *  - Date: 25/08/2026 — Canto do Buriti, Piauí, Brasil
 *  - Library-first, root-first: file lives at /mnt/data/auth/request.ts (no src/ nesting)
 *  - Only node:* builtins + global fetch (Node >=18) — zero external deps
 *  - Direct cloudcode-pa usage: https://cloudcode-pa.googleapis.com,
 *    https://daily-cloudcode-pa.googleapis.com,
 *    https://daily-cloudcode-pa.sandbox.googleapis.com
 *  - No localhost v1 base-url proxy (requisito explícito)
 *  - Supports 2026 models: gemini-3-pro-preview, gemini-3-flash-preview,
 *    gemini-3.1-pro-preview, gemini-2.5-pro/flash, claude-opus-4-6-thinking,
 *    claude-sonnet-4-6, antigravity-* variants
 *  - Deterministic IDs via FNV-1a (32-bit) — reproducible per conversation
 *  - Strip x-goog-user-project header to avoid 403 IAM (issue pi-mono #1830)
 *  - Skip sandbox for gemini-cli models to avoid 404/403 cascade (#233)
 *
 * @author opencode-antigravity-auth-next
 * @license MIT
 * @version 2.0.0
 */

import * as os from "node:os";
import { randomInt } from "node:crypto";

// ---------------------------------------------------------------------------
// Constants — endpoint cascade, models 2026, budgets, headers
// ---------------------------------------------------------------------------

/**
 * Official cloudcode-pa endpoints — prod is authoritative in 2026,
 * daily and sandbox are rollout / canary fallbacks.
 * Third-person: observer copies order from Antigravity Manager binary.
 */
export const ENDPOINTS = {
  PROD: "https://cloudcode-pa.googleapis.com",
  DAILY: "https://daily-cloudcode-pa.googleapis.com",
  SANDBOX: "https://daily-cloudcode-pa.sandbox.googleapis.com",
  AUTOPUSH: "https://autopush-cloudcode-pa.sandbox.googleapis.com",
} as const;

/** Default cascade order for Antigravity pool */
export const ENDPOINT_ORDER_ANTIGRAVITY: readonly string[] = [
  ENDPOINTS.PROD,
  ENDPOINTS.DAILY,
  ENDPOINTS.SANDBOX,
] as const;

/** Cascade for Gemini CLI pool — sandbox is explicitly skipped for preview/gemini-3 */
export const ENDPOINT_ORDER_GEMINI_CLI: readonly string[] = [
  ENDPOINTS.PROD,
  ENDPOINTS.DAILY,
] as const;

/** Stream endpoint suffix used by Antigravity */
export const STREAM_METHOD = "/v1internal:streamGenerateContent?alt=sse" as const;
export const GENERATE_METHOD = "/v1internal:generateContent" as const;

/** Antigravity version fallback — governance requires 1.19.2 (bypass ban <1.15.8) */
export const ANTIGRAVITY_VERSION_FALLBACK = "1.19.2" as const;

/** Fallback project id */
export const PROJECT_FALLBACK = "rising-fact-p41fc" as const;

/** Models 2026 — full list supported by fetchAvailableModels on 2026-08-25 */
export const MODELS_2026 = [
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3.1-pro-preview-customtools",
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-2.5-pro",
  "gemini-2.5-flash",
  "gemini-2.5",
  "claude-opus-4-6-thinking",
  "claude-opus-4-6-thinking-low",
  "claude-opus-4-6-thinking-max",
  "claude-sonnet-4-6",
  "claude-sonnet-4-6-thinking",
  "claude-opus-4-5-thinking",
  "antigravity-gemini-3-pro",
  "antigravity-gemini-3-flash",
  "antigravity-gemini-3.1-pro",
  "antigravity-gemini-3-pro-preview",
  "antigravity-gemini-3-flash-preview",
  "antigravity-claude-opus-4-6-thinking",
  "antigravity-claude-sonnet-4-6",
] as const;

/** Models that must route only via PROD (+ DAILY) — skip sandbox to avoid 403/404 cascade */
export const GEMINI_CLI_ONLY_MODELS = [
  "gemini-3-pro-preview",
  "gemini-3-flash-preview",
  "gemini-3.1-pro-preview",
  "gemini-3-pro",
  "gemini-3-flash",
  "gemini-3.1-pro",
  "antigravity-gemini-3-pro-preview",
  "antigravity-gemini-3-flash-preview",
] as const;

export const SEARCH_MODEL = "gemini-3-flash" as const;
export const SEARCH_MODEL_PREVIEW = "gemini-3-flash-preview" as const;

/** Thinking levels observed in Claude + Gemini 3 */
export const THINKING_LEVELS = ["minimal", "low", "medium", "high", "max"] as const;
export type ThinkingLevel = (typeof THINKING_LEVELS)[number];

/** Mapping thinkingLevel → thinkingBudget */
export const THINKING_BUDGET_MAP: Record<ThinkingLevel, number> = {
  minimal: 1024,
  low: 8192,
  medium: 16384,
  high: 32768,
  max: 64000,
} as const;

/** FNV-1a constants — 32-bit */
export const FNV_OFFSET_BASIS = 2166136261;
export const FNV_PRIME = 16777619;

/** Forbidden headers stripped case-insensitively — observer notes AM never sends them on content */
export const FORBIDDEN_HEADERS = [
  "x-goog-user-project",
  "x-goog-quotatuser",
  "x-goog-quota-user",
  "x-client-device-id",
  "x-goog-request-reason",
] as const;

/** Tool name regex validation — must start with letter, alphanumeric + underscore */
export const TOOL_NAME_REGEX = /^[a-zA-Z][a-zA-Z0-9_]{0,63}$/;

/** Allowed JSON Schema keys for Gemini function declarations */
export const ALLOWED_SCHEMA_KEYS = new Set([
  "type",
  "properties",
  "required",
  "description",
  "enum",
  "items",
  "anyOf",
  "oneOf",
  "format",
  "minimum",
  "maximum",
  "minLength",
  "maxLength",
  "pattern",
  "title",
  "nullable",
]);

// ---------------------------------------------------------------------------
// Types — OpenCode shapes, Gemini shapes, build options
// ---------------------------------------------------------------------------

/**
 * OpenCode message from plugin SDK — may be OpenAI or Anthropic shape.
 */
export interface OpenCodeMessage {
  role: "system" | "user" | "assistant" | "tool" | "model" | string;
  content?: string | any[] | null;
  tool_calls?: Array<{ id: string; type?: string; function: { name: string; arguments: string | object } }>;
  tool_call_id?: string;
  name?: string;
  // Anthropic extras
  thinking?: string;
  signature?: string;
  [k: string]: any;
}

/**
 * OpenCode function tool — accepts OpenAI, Anthropic, or Gemini pre-shaped.
 */
export type OpenCodeTool =
  | { type: "function"; function: { name: string; description?: string; parameters?: any } }
  | { name: string; description?: string; input_schema?: any; inputSchema?: any; parameters?: any; [k: string]: any }
  | { functionDeclarations: Array<{ name: string; description?: string; parameters?: any }> };

export interface TransformRequestInput {
  /** Model id, e.g. gemini-3-flash-preview or claude-opus-4-6-thinking-low */
  model: string;
  /** Message history in OpenCode format */
  messages: OpenCodeMessage[];
  /** Optional tools — OpenAI / Anthropic / Gemini shapes tolerated */
  tools?: OpenCodeTool[] | any[];
  /** Optional system instruction as string or array of texts */
  system?: string | string[] | null;
  /** Optional thinking level minimal|low|medium|high|max — maps to budget */
  thinkingLevel?: ThinkingLevel | string;
  /** Optional explicit thinking budget — overrides level map */
  thinkingBudget?: number;
  /** Whether to inject google_search grounding tool */
  googleSearchEnabled?: boolean;
  /** Optional generationConfig passthrough (temperature, maxTokens, etc) */
  generationConfig?: Record<string, any>;
  /** Optional seed for deterministic session_id — defaults to hash of messages+model */
  sessionSeed?: string;
  /** Optional seed for user_prompt_id — defaults to last user message */
  userPromptSeed?: string;
  /** Optional projectId — not used in transformRequest but kept for symmetry */
  projectId?: string;
}

export interface GeminiPart {
  text?: string;
  thought?: boolean;
  thoughtSignature?: string;
  inlineData?: { mimeType: string; data: string };
  functionCall?: { name: string; args: Record<string, any> };
  functionResponse?: { name: string; response: Record<string, any> };
  [k: string]: any;
}

export interface GeminiContent {
  role: "user" | "model" | "system";
  parts: GeminiPart[];
}

export interface GeminiTool {
  functionDeclarations?: Array<{ name: string; description?: string; parameters?: any }>;
}

export interface TransformedRequest {
  /** Normalized model id stripped of antigravity- prefix for routing but original preserved */
  model: string;
  /** Original model string exactly as user provided */
  originalModel: string;
  /** Gemini contents array ready for cloudcode-pa */
  contents: GeminiContent[];
  /** System instruction aggregated */
  systemInstruction?: { role: "system"; parts: [{ text: string }] } | null;
  /** Tools normalized to Gemini functionDeclarations */
  tools?: GeminiTool[] | null;
  /** Generation config with thinking budget mapped if provided */
  generationConfig?: Record<string, any> | null;
  /** Deterministic session_id via FNV-1a */
  sessionId: string;
  /** Deterministic user_prompt_id via FNV-1a */
  userPromptId: string;
  /** Thinking budget resolved */
  thinkingBudget?: number;
  /** Thinking level resolved */
  thinkingLevel?: ThinkingLevel;
  /** Whether model is gemini-cli only (prod-only) */
  isGeminiCLIOnly: boolean;
  /** Whether google_search was injected */
  googleSearchInjected: boolean;
}

export interface BuildOptions extends TransformRequestInput {
  /** Cloud project id — required for cloudcode-pa envelope */
  projectId: string;
  /** OAuth bearer token */
  accessToken: string;
  /** Optional user-agent override, defaults to dynamic antigravity/{ver} {os}/{arch} */
  userAgent?: string;
  /** Optional version override */
  antigravityVersion?: string;
  /** Optional endpoint overrides — if provided, replaces cascade */
  endpointOverrides?: string[];
  /** Which method suffix: stream vs generate — default stream */
  methodSuffix?: typeof STREAM_METHOD | typeof GENERATE_METHOD;
}

export interface BuildResult {
  /** Primary URL to POST (first in cascade) */
  url: string;
  /** All candidate URLs ordered for cascade retry */
  endpoints: string[];
  /** Base endpoints without method suffix */
  baseEndpoints: string[];
  /** Headers ready for fetch — includes Authorization, UA, Client-Metadata */
  headers: Record<string, string>;
  /** Full JSON body to POST — { project, request: {...}, sessionId, userPromptId } */
  body: Record<string, any>;
  /** Deterministic session id */
  sessionId: string;
  /** Deterministic user_prompt id */
  userPromptId: string;
  /** Whether model requires prod-only routing */
  isGeminiCLIOnly: boolean;
  /** HTTP method */
  method: "POST";
  /** Raw normalized inner request (the `request` field inside body) */
  innerRequest: TransformedRequest;
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/**
 * Thrown when transformRequest cannot normalize input.
 */
export class RequestTransformationError extends Error {
  public readonly code: string;
  constructor(message: string, code = "REQUEST_TRANSFORM_ERROR") {
    super(message);
    this.name = "RequestTransformationError";
    this.code = code;
  }
}

// ---------------------------------------------------------------------------
// FNV-1a — deterministic hashing for session_id / user_prompt_id
// ---------------------------------------------------------------------------

/**
 * Computes FNV-1a 32-bit hash.
 * Third-person: observer notes this hash is fast, no crypto deps, deterministic.
 *
 * @param input - string to hash
 * @returns unsigned 32-bit integer
 */
export function fnv1a32(input: string): number {
  if (typeof input !== "string") {
    throw new TypeError("fnv1a32 input must be string");
  }
  let hash = FNV_OFFSET_BASIS;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    // Math.imul ensures 32-bit overflow semantics
    hash = Math.imul(hash, FNV_PRIME);
  }
  return hash >>> 0;
}

/**
 * Generates hex string padded to 8 chars from FNV-1a.
 *
 * @param input - seed
 * @returns 8-char hex
 */
export function fnv1a32Hex(input: string): string {
  const h = fnv1a32(input);
  return h.toString(16).padStart(8, "0");
}

/**
 * Generates deterministic id by hashing twice with different salts and concatenating.
 * Observer produces ids like sess-a1b2c3d4-e5f6g7... that remain stable for same seed.
 *
 * @param seed - base seed string
 * @param prefix - prefix like "sess" or "prompt"
 * @returns deterministic id string
 */
export function generateDeterministicId(seed: string, prefix: string): string {
  if (!seed) seed = String(Date.now());
  const h1 = fnv1a32Hex(seed);
  const h2 = fnv1a32Hex(seed + "|salt2|" + prefix);
  const h3 = fnv1a32Hex(seed.split("").reverse().join("") + "|" + prefix);
  // Format: prefix-h1h2-h3 (16 + 8 = 24 hex chars, enough entropy, deterministic)
  return `${prefix}-${h1}${h2}-${h3}`;
}

/**
 * Generates deterministic session_id.
 *
 * @param seed - usually model + full conversation JSON
 * @returns session id
 */
export function generateSessionId(seed: string): string {
  return generateDeterministicId(seed, "sess");
}

/**
 * Generates deterministic user_prompt_id from last user message.
 *
 * @param seed - last user prompt text or hash of conversation tail
 * @returns user_prompt id
 */
export function generateUserPromptId(seed: string): string {
  return generateDeterministicId(seed, "up");
}

// ---------------------------------------------------------------------------
// Model helpers — 2026 support, variant extraction, cli-only detection
// ---------------------------------------------------------------------------

/**
 * Normalizes model id — trims, lowercases for detection, preserves original case for request.
 * Also strips antigravity- prefix for internal detection but keeps original model field elsewhere.
 *
 * @param modelId - raw model string
 * @returns object with base, original, normalized
 */
export function parseModelId(modelId: string): { original: string; normalized: string; base: string; variantSuffixes: string[] } {
  if (!modelId || typeof modelId !== "string") {
    throw new RequestTransformationError("model id must be non-empty string", "INVALID_MODEL");
  }
  const original = modelId.trim();
  if (!original) throw new RequestTransformationError("model id empty after trim", "INVALID_MODEL");
  const lower = original.toLowerCase();
  // Extract antigravity- prefix if present
  const withoutAntigravity = lower.startsWith("antigravity-") ? lower.slice("antigravity-".length) : lower;
  // Variant suffixes like -customtools, -thinking-low, -thinking-max
  const variantSuffixes: string[] = [];
  let base = withoutAntigravity;

  // Known suffixes to peel
  const peelSuffixes = ["-customtools", "-search", "-grounding", "-thinking-max", "-thinking-low", "-thinking-medium", "-thinking-high", "-thinking-minimal", "-thinking"];
  // Peel iteratively from end
  let peeled = true;
  while (peeled) {
    peeled = false;
    for (const sfx of peelSuffixes) {
      if (base.endsWith(sfx)) {
        variantSuffixes.unshift(sfx.replace(/^-/, ""));
        base = base.slice(0, -sfx.length);
        peeled = true;
        break;
      }
    }
  }

  return { original, normalized: withoutAntigravity, base, variantSuffixes };
}

/**
 * Extracts thinking level from model id or explicit parameter.
 *
 * Supports:
 * - claude-opus-4-6-thinking-low → low
 * - claude-opus-4-6-thinking-max → max
 * - gemini-3-pro-high → high (if present)
 * - explicit thinkingLevel param overrides model suffix
 *
 * @param modelId - model string
 * @param explicitLevel - optional explicit level
 * @returns level or undefined plus budget resolved
 */
export function extractThinkingLevel(
  modelId: string,
  explicitLevel?: string,
): { level?: ThinkingLevel; budget?: number } {
  const exp = (explicitLevel ?? "").toLowerCase().trim();
  if (exp && (THINKING_LEVELS as readonly string[]).includes(exp)) {
    const lvl = exp as ThinkingLevel;
    return { level: lvl, budget: THINKING_BUDGET_MAP[lvl] };
  }

  const lower = (modelId ?? "").toLowerCase();
  for (const lvl of THINKING_LEVELS) {
    if (lower.includes(`-${lvl}`)) {
      return { level: lvl as ThinkingLevel, budget: THINKING_BUDGET_MAP[lvl as ThinkingLevel] };
    }
  }

  // generic thinking suffix without level → default medium for Claude, low for Gemini minimal?
  if (lower.includes("thinking")) {
    // heuristic: claude thinking defaults to medium, gemini to low
    const isClaude = lower.includes("claude");
    const defaultLvl: ThinkingLevel = isClaude ? "medium" : "low";
    return { level: defaultLvl, budget: THINKING_BUDGET_MAP[defaultLvl] };
  }

  return {};
}

/**
 * Determines whether model must use prod-only endpoint (skip sandbox).
 * Rule from RESEARCH:
 * - any model containing preview → cli only
 * - any gemini-3 or gemini-3.1 → cli only (2026 policy)
 * - explicit list GEMINI_CLI_ONLY_MODELS
 * Third-person observer: emulates behavior that fixed #233
 *
 * @param modelId - model id to test
 * @returns true if must skip sandbox
 */
export function isGeminiCLIOnlyModel(modelId: string): boolean {
  if (!modelId || typeof modelId !== "string") return false;
  const lower = modelId.trim().toLowerCase();
  if (!lower) return false;

  // explicit list match
  if ((GEMINI_CLI_ONLY_MODELS as readonly string[]).includes(lower as any)) return true;
  if ((GEMINI_CLI_ONLY_MODELS as readonly string[]).some((m) => lower.includes(m))) return true;

  // policy: preview → prod only
  if (lower.includes("preview")) return true;

  // policy: gemini-3+ only prod — covers gemini-3-pro-preview, gemini-3-flash, gemini-3.1-pro-preview, antigravity-gemini-3-*
  if (lower.includes("gemini-3") || lower.startsWith("antigravity-gemini-3")) return true;

  // also antigravity-gemini-3 aliases
  if (lower.includes("gemini-3.") || lower.includes("antigravity-gemini-3.")) return true;

  return false;
}

/**
 * Returns endpoint cascade bases for given model.
 * - If gemini-cli only → PROD + DAILY (skip sandbox)
 * - Else → PROD + DAILY + SANDBOX
 * Observer follows governance: skip sandbox for preview/gemini-3 to avoid 403/404 cascade.
 *
 * @param modelId - model
 * @param overrides - optional custom bases to use instead
 * @returns ordered base endpoints
 */
export function getEndpointsForModel(modelId: string, overrides?: string[]): string[] {
  if (overrides && overrides.length > 0) {
    return overrides.map((e) => e.replace(/\/+$/, "")).filter(Boolean);
  }
  if (isGeminiCLIOnlyModel(modelId)) {
    return [...ENDPOINT_ORDER_GEMINI_CLI];
  }
  return [...ENDPOINT_ORDER_ANTIGRAVITY];
}

// ---------------------------------------------------------------------------
// Headers — fingerprint, User-Agent dynamic, strip forbidden
// ---------------------------------------------------------------------------

/**
 * Normalizes OS/platform token to Antigravity style.
 *
 * @param p - node platform
 */
function normalizePlatform(p: string): string {
  switch (p) {
    case "darwin":
      return "darwin";
    case "win32":
      return "win32";
    case "linux":
      return "linux";
    default:
      return p;
  }
}

/**
 * Normalizes arch token.
 *
 * @param a - node arch
 */
function normalizeArch(a: string): string {
  switch (a) {
    case "arm64":
      return "arm64";
    case "x64":
      return "x64";
    case "ia32":
      return "ia32";
    default:
      return a;
  }
}

/**
 * Builds dynamic User-Agent antigravity/{version} {os}/{arch}.
 * Third-person observer copies AM behavior to bypass ban on 1.11.5.
 *
 * @param version - optional semver
 */
export function buildDynamicUserAgent(version?: string): string {
  const ver = version && /^\d+\.\d+\.\d+/.test(version) ? version.trim() : ANTIGRAVITY_VERSION_FALLBACK;
  try {
    const plat = normalizePlatform(os.platform());
    const arch = normalizeArch(os.arch());
    return `antigravity/${ver} ${plat}/${arch}`;
  } catch {
    return `antigravity/${ver}`;
  }
}

/**
 * Builds Client-Metadata header.
 *
 * @param version - optional version
 */
export function buildClientMetadata(version?: string): string {
  const ver = version && /^\d+\.\d+\.\d+/.test(version) ? version.trim() : ANTIGRAVITY_VERSION_FALLBACK;
  try {
    const plat = normalizePlatform(os.platform()).toUpperCase();
    const arch = normalizeArch(os.arch()).toUpperCase();
    return [
      `ideType=ANTIGRAVITY`,
      `platform=${plat}`,
      `ideVersion=${ver}`,
      `pluginVersion=2.0.0`,
      `arch=${arch}`,
      `osVersion=${os.release()}`,
    ].join(",");
  } catch {
    return `ideType=ANTIGRAVITY,platform=PLATFORM_UNSPECIFIED,ideVersion=${ver},pluginVersion=2.0.0`;
  }
}

/**
 * Builds X-Goog-Api-Client header — only for gemini-cli mode.
 *
 * @param version - optional
 */
export function buildApiClient(version?: string): string {
  const ver = version && /^\d+\.\d+\.\d+/.test(version) ? version.trim() : ANTIGRAVITY_VERSION_FALLBACK;
  try {
    const nodeVer = process.versions.node ?? "20.0.0";
    return `antigravity/${ver} gl-node/${nodeVer} gax/4.9.0 grpc/1.14.0`;
  } catch {
    return `antigravity/${ver}`;
  }
}

/**
 * Generates fingerprint headers for given style.
 * Observer knows:
 * - AM only sends User-Agent on content requests (not on onboard/load)
 * - Never sends X-Goog-QuotaUser nor X-Client-Device-Id
 * - Gemini CLI includes X-Goog-Api-Client
 *
 * @param style - 'antigravity' or 'gemini-cli'
 * @param version - optional antigravity version
 * @returns headers record
 */
export function getFingerprintHeaders(
  style: "antigravity" | "gemini-cli" = "antigravity",
  version?: string,
): Record<string, string> {
  const ua = buildDynamicUserAgent(version);
  const cm = buildClientMetadata(version);
  const headers: Record<string, string> = {
    "User-Agent": ua,
    "Client-Metadata": cm,
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  if (style === "gemini-cli") {
    headers["X-Goog-Api-Client"] = buildApiClient(version);
  }
  return headers;
}

/**
 * Strips forbidden headers case-insensitively.
 * Primary requirement: strip x-goog-user-project to avoid 403 permission denied.
 * Also strips quota headers intentionally removed from AM traffic.
 *
 * @param headers - incoming headers record
 * @returns cleaned headers record
 */
export function stripForbiddenHeaders(headers: Record<string, string>): Record<string, string> {
  if (!headers || typeof headers !== "object") return {};
  const forbiddenSet = new Set(FORBIDDEN_HEADERS.map((h) => h.toLowerCase()));
  const cleaned: Record<string, string> = {};
  for (const [k, v] of Object.entries(headers)) {
    if (!k) continue;
    const lower = k.toLowerCase();
    if (forbiddenSet.has(lower)) continue;
    // Also strip any header that case-insensitively equals x-goog-user-project with spaces
    if (lower.trim() === "x-goog-user-project") continue;
    cleaned[k] = v;
  }
  return cleaned;
}

/**
 * Alias required by checklist naming: strip x-goog-user-project header explicit.
 *
 * @param headers - headers map
 * @returns cleaned map
 */
export function stripXGoogUserProjectHeader(headers: Record<string, string>): Record<string, string> {
  return stripForbiddenHeaders(headers);
}

// ---------------------------------------------------------------------------
// Tool name sanitization & validation
// ---------------------------------------------------------------------------

/**
 * Sanitizes a tool name to match Gemini's constraints:
 * - Must start with letter
 * - Only [a-zA-Z0-9_], 1-64 chars
 * - Replaces invalid chars with _
 * - Prepends "tool_" if starts with digit or empty
 *
 * @param name - raw name
 * @returns sanitized name
 */
export function sanitizeToolName(name: string): string {
  if (typeof name !== "string") {
    // deterministic fallback
    const fallback = `tool_${fnv1a32Hex(String(name ?? ""))}`;
    return fallback.slice(0, 64);
  }
  let trimmed = name.trim();
  if (!trimmed) {
    return `tool_${fnv1a32Hex(name).slice(0, 8)}`;
  }
  // Replace non-alphanumeric underscore with _
  let sanitized = trimmed.replace(/[^a-zA-Z0-9_]/g, "_");
  // Collapse multiple _
  sanitized = sanitized.replace(/__+/g, "_");
  // Remove leading _ if followed by digit? Ensure starts with letter
  if (!/^[a-zA-Z]/.test(sanitized)) {
    // If starts with digit, prepend tool_
    sanitized = `tool_${sanitized.replace(/^[^a-zA-Z]+/, "")}`;
  }
  // Trim to 64
  sanitized = sanitized.slice(0, 64);
  // Ensure still valid, if not, fallback
  if (!sanitized) sanitized = `tool_${fnv1a32Hex(name).slice(0, 8)}`;
  // Final validation — if still invalid (e.g., only _), prefix
  if (!TOOL_NAME_REGEX.test(sanitized)) {
    // Force valid: remove trailing _ and ensure length
    sanitized = `tool_${sanitized.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 59)}`;
    sanitized = sanitized.slice(0, 64);
    if (!/^[a-zA-Z]/.test(sanitized)) sanitized = `a${sanitized.slice(0, 63)}`;
  }
  return sanitized;
}

/**
 * Ensures tool names unique after sanitization.
 * If duplicate, appends _1, _2 ...
 *
 * @param names - sanitized names
 * @returns unique names preserving order
 */
export function ensureUniqueToolNames(names: string[]): string[] {
  const seen = new Map<string, number>();
  const result: string[] = [];
  for (let raw of names) {
    let candidate = raw;
    let count = seen.get(raw) ?? 0;
    if (count > 0 || result.includes(candidate)) {
      // Find free suffix
      let idx = 1;
      while (result.includes(`${raw}_${idx}`)) idx++;
      candidate = `${raw}_${idx}`.slice(0, 64);
    }
    seen.set(raw, (seen.get(raw) ?? 0) + 1);
    result.push(candidate);
  }
  return result;
}

/**
 * Validates and sanitizes tool list — handles OpenAI, Anthropic, Gemini shapes.
 * Also cleans JSON schemas via cleanJsonSchema.
 *
 * @param rawTools - raw tools from OpenCode
 * @returns object with declarations and name mapping
 */
export function validateAndSanitizeTools(rawTools?: any[]): {
  declarations: Array<{ name: string; description?: string; parameters?: any; originalName: string }>;
  uniqueNames: string[];
} {
  if (!rawTools || !Array.isArray(rawTools) || rawTools.length === 0) {
    return { declarations: [], uniqueNames: [] };
  }

  const decls: Array<{ name: string; description?: string; parameters?: any; originalName: string }> = [];

  for (const entry of rawTools) {
    if (!entry) continue;

    // Gemini pre-shaped: { functionDeclarations: [...] }
    if (entry.functionDeclarations && Array.isArray(entry.functionDeclarations)) {
      for (const fd of entry.functionDeclarations) {
        if (!fd || !fd.name) continue;
        const sanitized = sanitizeToolName(String(fd.name));
        decls.push({
          name: sanitized,
          description: fd.description ? String(fd.description).slice(0, 1024) : undefined,
          parameters: fd.parameters ? cleanJsonSchema(fd.parameters) : { type: "OBJECT", properties: {} },
          originalName: String(fd.name),
        });
      }
      continue;
    }

    // OpenAI shape: { type: "function", function: { name, description, parameters } }
    if (entry.type === "function" && entry.function) {
      const fn = entry.function;
      if (!fn.name) continue;
      const sanitized = sanitizeToolName(String(fn.name));
      decls.push({
        name: sanitized,
        description: fn.description ? String(fn.description).slice(0, 1024) : undefined,
        parameters: fn.parameters ? cleanJsonSchema(fn.parameters) : { type: "OBJECT", properties: {} },
        originalName: String(fn.name),
      });
      continue;
    }

    // Anthropic shape: { name, description, input_schema }
    if (entry.name) {
      const schemaRaw = entry.input_schema ?? entry.inputSchema ?? entry.parameters ?? entry.schema;
      const sanitized = sanitizeToolName(String(entry.name));
      decls.push({
        name: sanitized,
        description: entry.description ? String(entry.description).slice(0, 1024) : undefined,
        parameters: schemaRaw ? cleanJsonSchema(schemaRaw) : { type: "OBJECT", properties: {} },
        originalName: String(entry.name),
      });
      continue;
    }

    // Fallback: attempt to interpret as bare function declaration
    if (typeof entry === "object" && "name" in entry) {
      const sanitized = sanitizeToolName(String((entry as any).name));
      decls.push({
        name: sanitized,
        description: (entry as any).description ? String((entry as any).description).slice(0, 1024) : undefined,
        parameters: (entry as any).parameters ? cleanJsonSchema((entry as any).parameters) : { type: "OBJECT", properties: {} },
        originalName: String((entry as any).name),
      });
    }
  }

  // Ensure uniqueness
  const names = decls.map((d) => d.name);
  const unique = ensureUniqueToolNames(names);
  // Apply unique back to decls
  for (let i = 0; i < decls.length; i++) {
    decls[i].name = unique[i];
  }

  return { declarations: decls, uniqueNames: unique };
}

// ---------------------------------------------------------------------------
// JSON Schema cleaning — fixes Invalid JSON payload Unknown name 'parameters'
// ---------------------------------------------------------------------------

/**
 * Cleans a JSON Schema for Gemini compatibility.
 * - Removes $schema, $id, $ref, $defs, additionalProperties, examples, default etc.
 * - Upper-cases type values (OBJECT, STRING, ...)
 * - Recursively cleans properties, items, anyOf, oneOf
 * - Ensures type defaults to OBJECT when properties present
 *
 * @param input - raw schema
 * @param seen - WeakSet to avoid cycles
 * @returns cleaned schema
 */
export function cleanJsonSchema(input: any, seen = new WeakSet()): any {
  if (input === null || input === undefined) {
    return { type: "OBJECT", properties: {} };
  }

  if (typeof input === "boolean") {
    // JSON Schema boolean — convert to empty object schema truthy handling
    return input ? { type: "OBJECT", properties: {} } : { type: "OBJECT", properties: {}, description: "disallowed" };
  }

  if (Array.isArray(input)) {
    // Array of schemas (e.g., anyOf) — clean each
    return input.map((item) => cleanJsonSchema(item, seen));
  }

  if (typeof input !== "object") {
    // Primitive — return as-is for non-object contexts, but for schema root fallback
    return { type: "STRING", description: String(input).slice(0, 500) };
  }

  // Avoid circular refs
  if (seen.has(input)) {
    return { type: "OBJECT", properties: {} };
  }
  seen.add(input);

  const out: Record<string, any> = {};

  // Determine type first, normalize to uppercase string if string
  let rawType = (input as any).type;
  if (Array.isArray(rawType) && rawType.length > 0) {
    // If array type like ["string","null"] — pick first non-null
    rawType = rawType.find((t: any) => t !== "null") ?? rawType[0];
  }
  if (typeof rawType === "string" && rawType) {
    out.type = rawType.toUpperCase();
    // Map some common aliases
    if (out.type === "OBJECT" || out.type === "OBJECTS") out.type = "OBJECT";
    else if (out.type === "ARRAY") out.type = "ARRAY";
    else if (out.type === "STRING") out.type = "STRING";
    else if (out.type === "NUMBER") out.type = "NUMBER";
    else if (out.type === "INTEGER") out.type = "INTEGER";
    else if (out.type === "BOOLEAN") out.type = "BOOLEAN";
    else if (out.type === "NULL") out.type = "STRING"; // Gemini dislikes null type, map to string nullable
    else {
      // Unknown type — try uppercase anyway else default OBJECT
      const up = rawType.toUpperCase();
      if (["OBJECT", "ARRAY", "STRING", "NUMBER", "INTEGER", "BOOLEAN"].includes(up)) {
        out.type = up;
      } else {
        // fallback if type is lowercase object with nested
        out.type = "OBJECT";
      }
    }
  }

  // If properties present and no type, imply OBJECT
  if (!out.type && (input as any).properties) {
    out.type = "OBJECT";
  }

  // Clean allowed keys
  for (const key of Object.keys(input)) {
    if (key.startsWith("$")) continue; // $schema, $id, $ref, $defs
    if (key === "additionalProperties") continue; // Gemini disallows
    if (key === "definitions") continue;
    if (key === "$defs") continue;
    if (key === "examples") continue;
    if (key === "example") continue;
    if (key === "const") continue;
    if (key === "default" && out.type !== undefined) continue; // skip default to avoid unknown name errors
    if (!ALLOWED_SCHEMA_KEYS.has(key)) {
      // Keep description, etc., only allowed
      if (key === "description" || key === "enum" || key === "required" || key === "properties" || key === "items" || key === "anyOf" || key === "oneOf" || key === "format" || key === "minimum" || key === "maximum" || key === "minLength" || key === "maxLength" || key === "pattern" || key === "title") {
        // allowed handled below
      } else if (key === "type") {
        continue; // already processed
      } else {
        continue;
      }
    }

    const val = (input as any)[key];

    switch (key) {
      case "description":
        if (typeof val === "string") out.description = val.slice(0, 2000);
        break;
      case "enum":
        if (Array.isArray(val)) out.enum = val.slice(0, 100);
        break;
      case "required":
        if (Array.isArray(val)) out.required = val.filter((v: any) => typeof v === "string").slice(0, 100);
        break;
      case "properties":
        if (val && typeof val === "object" && !Array.isArray(val)) {
          const cleanedProps: Record<string, any> = {};
          for (const [propK, propV] of Object.entries(val)) {
            const sanitizedPropKey = propK.trim().slice(0, 100);
            if (!sanitizedPropKey) continue;
            cleanedProps[sanitizedPropKey] = cleanJsonSchema(propV, seen);
          }
          out.properties = cleanedProps;
        }
        break;
      case "items":
        out.items = cleanJsonSchema(val, seen);
        break;
      case "anyOf":
      case "oneOf":
        if (Array.isArray(val)) {
          out[key] = val.map((v: any) => cleanJsonSchema(v, seen)).slice(0, 20);
        }
        break;
      case "format":
        if (typeof val === "string") out.format = val.slice(0, 100);
        break;
      case "title":
        if (typeof val === "string") out.title = val.slice(0, 200);
        break;
      default:
        // numeric constraints
        if (["minimum", "maximum", "minLength", "maxLength"].includes(key) && typeof val === "number") {
          out[key] = val;
        } else if (key === "pattern" && typeof val === "string") {
          out.pattern = val.slice(0, 500);
        }
        break;
    }
  }

  // Ensure OBJECT has at least empty properties
  if (out.type === "OBJECT" && !out.properties) {
    out.properties = {};
  }

  // Ensure ARRAY has items
  if (out.type === "ARRAY" && !out.items) {
    out.items = { type: "STRING" };
  }

  // Final fallback if empty
  if (Object.keys(out).length === 0) {
    return { type: "OBJECT", properties: {} };
  }

  return out;
}

// ---------------------------------------------------------------------------
// Thinking blocks mapping
// ---------------------------------------------------------------------------

/**
 * Maps a thinking block to Gemini thought part.
 * For Gemini 3 and Claude via Antigravity, thought parts must have thought: true.
 * Optionally includes thoughtSignature for multi-turn preservation.
 *
 * @param text - thinking text
 * @param signature - optional signature for LRU cache in streaming.ts
 * @returns GeminiPart
 */
export function mapThinkingBlock(text: string, signature?: string): GeminiPart {
  if (!text || typeof text !== "string") text = String(text ?? "");
  const part: GeminiPart = {
    text,
    thought: true,
  };
  if (signature && typeof signature === "string" && signature.length > 0) {
    part.thoughtSignature = signature.slice(0, 10000);
  }
  return part;
}

/**
 * Sorts parts so that thought parts come first, then text, then function calls.
 * Required because Gemini/Claude require thinking block order validation.
 *
 * @param parts - parts array
 * @returns sorted parts
 */
export function sortThoughtFirst(parts: GeminiPart[]): GeminiPart[] {
  if (!Array.isArray(parts)) return [];
  const thoughts = parts.filter((p) => p.thought === true);
  const others = parts.filter((p) => p.thought !== true);
  // Preserve relative order within groups, thoughts first
  return [...thoughts, ...others];
}

/**
 * Filters and normalizes thinking content — removes empty thinking and ensures
 * signature preservation.
 *
 * @param parts - incoming parts
 * @returns filtered parts
 */
export function filterAndMapThinkingParts(parts: any[]): GeminiPart[] {
  const out: GeminiPart[] = [];
  for (const p of parts) {
    if (!p) continue;
    // Already Gemini thought
    if (p.thought === true && p.text) {
      out.push(mapThinkingBlock(String(p.text), p.thoughtSignature));
      continue;
    }
    // Anthropic thinking type
    if (p.type === "thinking" || p.type === "reasoning") {
      const txt = p.thinking ?? p.text ?? p.reasoning ?? "";
      const sig = p.signature ?? p.thoughtSignature;
      if (txt) out.push(mapThinkingBlock(String(txt), sig ? String(sig) : undefined));
      continue;
    }
    // Direct string thinking marker
    if (typeof p === "object" && "thinking" in p && typeof p.thinking === "string") {
      out.push(mapThinkingBlock(p.thinking, p.signature));
      continue;
    }
    // Keep other parts as-is for later mapping (text, etc)
    out.push(p);
  }
  return sortThoughtFirst(out);
}

// ---------------------------------------------------------------------------
// Google Search tool injection
// ---------------------------------------------------------------------------

/**
 * Definition for google_search built-in grounding tool wrapped as function declaration
 * for compatibility with OpenCode → Gemini flow.
 * Observer notes: original plugin shekohex uses wrapper to call separate search API.
 */
export const GOOGLE_SEARCH_FUNCTION_DECLARATION = {
  name: "google_search",
  description:
    "Search the web for real-time information, factual grounding, current events, documentation, and recent knowledge. Use when user asks for latest information, news, or requires browsing to answer.",
  parameters: {
    type: "OBJECT",
    properties: {
      query: {
        type: "STRING",
        description: "Search query string, 3-10 words focused keywords",
      },
    },
    required: ["query"],
  },
} as const;

export const URL_CONTEXT_FUNCTION_DECLARATION = {
  name: "url_context",
  description: "Fetch and provide context from a URL for grounding.",
  parameters: {
    type: "OBJECT",
    properties: {
      url: {
        type: "STRING",
        description: "HTTP(S) URL to fetch",
      },
    },
    required: ["url"],
  },
} as const;

/**
 * Injects google_search tool into declarations if enabled and not already present.
 *
 * @param declarations - existing declarations array
 * @param enabled - whether injection enabled
 * @param includeUrlContext - whether to also inject url_context
 * @returns new declarations array with injection
 */
export function injectGoogleSearchTool(
  declarations: Array<{ name: string; description?: string; parameters?: any; originalName?: string }>,
  enabled?: boolean,
  includeUrlContext = false,
): Array<{ name: string; description?: string; parameters?: any; originalName?: string }> {
  if (!enabled) return declarations;
  const existingNames = new Set(declarations.map((d) => d.name.toLowerCase()));
  const result = [...declarations];

  if (!existingNames.has("google_search")) {
    result.push({
      name: "google_search",
      description: GOOGLE_SEARCH_FUNCTION_DECLARATION.description,
      parameters: GOOGLE_SEARCH_FUNCTION_DECLARATION.parameters,
      originalName: "google_search",
    });
  }

  if (includeUrlContext && !existingNames.has("url_context")) {
    result.push({
      name: "url_context",
      description: URL_CONTEXT_FUNCTION_DECLARATION.description,
      parameters: URL_CONTEXT_FUNCTION_DECLARATION.parameters,
      originalName: "url_context",
    });
  }

  return result;
}

// ---------------------------------------------------------------------------
// Content helpers — inlineData, data URI, function args parsing
// ---------------------------------------------------------------------------

/**
 * Parses OpenAI tool arguments which may be stringified JSON.
 *
 * @param args - args string or object
 * @returns parsed object
 */
export function parseFunctionArgs(args: string | object | any): Record<string, any> {
  if (!args) return {};
  if (typeof args === "object" && !Array.isArray(args)) return args as Record<string, any>;
  if (typeof args === "string") {
    const trimmed = args.trim();
    if (!trimmed) return {};
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed && typeof parsed === "object") return parsed;
      return { value: parsed };
    } catch {
      // If not JSON, treat as single string value if schema expects string, else wrap
      return { query: trimmed, input: trimmed };
    }
  }
  return { value: args };
}

/**
 * Extracts mime type and base64 data from data URI.
 *
 * @param dataUri - e.g. data:image/png;base64,iVBOR...
 * @returns { mimeType, data } or null if not data URI
 */
export function parseDataUri(dataUri: string): { mimeType: string; data: string } | null {
  if (!dataUri || typeof dataUri !== "string") return null;
  const match = dataUri.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  const mimeType = match[1];
  const data = match[2];
  return { mimeType, data };
}

/**
 * Attempts to extract last user prompt text for deterministic user_prompt_id.
 *
 * @param messages - messages array
 * @returns last user text or fallback
 */
export function extractLastUserPrompt(messages: OpenCodeMessage[]): string {
  if (!Array.isArray(messages) || messages.length === 0) return "empty-prompt";
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (!m) continue;
    if (String(m.role).toLowerCase() !== "user") continue;
    const c = m.content;
    if (typeof c === "string" && c.trim()) return c.trim().slice(0, 2000);
    if (Array.isArray(c)) {
      for (const part of c) {
        if (!part) continue;
        if (part.type === "text" && part.text && String(part.text).trim()) {
          return String(part.text).trim().slice(0, 2000);
        }
        if (typeof part === "object" && "text" in part && typeof (part as any).text === "string") {
          const t = String((part as any).text).trim();
          if (t) return t.slice(0, 2000);
        }
      }
    }
  }
  // Fallback: stringify whole
  try {
    return JSON.stringify(messages).slice(0, 2000);
  } catch {
    return "fallback-prompt";
  }
}

// ---------------------------------------------------------------------------
// Core: transformRequest — OpenCode → Gemini normalized
// ---------------------------------------------------------------------------

/**
 * Transforms OpenCode request (OpenAI/Anthropic mixed) into Gemini/Antigravity
 * normalized request ready for cloudcode-pa envelope.
 *
 * Steps performed by third-person observer:
 * - Validates model, messages
 * - Parses model variant to extract thinkingLevel/budget
 * - Aggregates system instructions
 * - Normalizes contents: user ↔ model, maps thinking blocks first,
 *   handles tool_use/tool_result pairing, handles OpenAI tool_calls
 * - Cleans tool schemas, sanitizes tool names, ensures uniqueness
 * - Injects google_search tool when enabled
 * - Generates deterministic session_id and user_prompt_id via FNV-1a
 * - Builds generationConfig with thinking budget if applicable
 * - Supports 2026 models aliasing
 *
 * @param input - transform input
 * @returns transformed request
 * @throws RequestTransformationError on invalid input
 */
export function transformRequest(input: TransformRequestInput): TransformedRequest {
  // ---- validation ----
  if (!input || typeof input !== "object") {
    throw new RequestTransformationError("input must be object", "INVALID_INPUT");
  }
  if (!input.model || typeof input.model !== "string" || !input.model.trim()) {
    throw new RequestTransformationError("model is required and must be non-empty string", "INVALID_MODEL");
  }
  if (!Array.isArray(input.messages)) {
    throw new RequestTransformationError("messages must be array", "INVALID_MESSAGES");
  }

  const originalModel = input.model.trim();
  const modelParse = parseModelId(originalModel);
  const modelForGemini = modelParse.normalized; // without antigravity- prefix, for endpoint decision
  const isCliOnly = isGeminiCLIOnlyModel(originalModel);

  // ---- thinking level extraction ----
  const explicitLevel = typeof input.thinkingLevel === "string" ? input.thinkingLevel : undefined;
  const explicitBudget = typeof input.thinkingBudget === "number" && Number.isFinite(input.thinkingBudget) ? input.thinkingBudget : undefined;
  const fromModel = extractThinkingLevel(originalModel, explicitLevel);

  let thinkingLevel: ThinkingLevel | undefined = (explicitLevel as ThinkingLevel) ?? fromModel.level;
  let thinkingBudget: number | undefined = explicitBudget ?? fromModel.budget;

  // If explicit level provided but no budget, map level → budget
  if (thinkingLevel && !thinkingBudget) {
    const mapped = THINKING_BUDGET_MAP[thinkingLevel as ThinkingLevel];
    if (mapped) thinkingBudget = mapped;
  }

  // If model is claude thinking variant but no level extracted, default
  if (!thinkingLevel && modelParse.variantSuffixes.includes("thinking")) {
    thinkingLevel = "medium";
    thinkingBudget = thinkingBudget ?? THINKING_BUDGET_MAP["medium"];
  }

  // ---- system instruction aggregation ----
  let systemTexts: string[] = [];

  if (input.system) {
    if (typeof input.system === "string" && input.system.trim()) {
      systemTexts.push(input.system.trim());
    } else if (Array.isArray(input.system)) {
      for (const s of input.system) {
        if (typeof s === "string" && s.trim()) systemTexts.push(s.trim());
      }
    }
  }

  // Collect system role messages
  for (const m of input.messages) {
    if (!m) continue;
    if (String(m.role).toLowerCase() === "system") {
      const c = m.content;
      if (typeof c === "string" && c.trim()) systemTexts.push(c.trim());
      else if (Array.isArray(c)) {
        for (const part of c) {
          if (part?.type === "text" && typeof part.text === "string" && part.text.trim()) {
            systemTexts.push(part.text.trim());
          } else if (typeof part === "string" && part.trim()) {
            systemTexts.push(part.trim());
          }
        }
      }
    }
  }

  const systemInstruction = systemTexts.length > 0
    ? {
        role: "system" as const,
        parts: [{ text: systemTexts.join("\n\n") }],
      }
    : null;

  // ---- tool id → name map for OpenAI tool_calls grouping ----
  const toolIdToName = new Map<string, string>();

  // Pre-scan assistant messages to populate map
  for (const m of input.messages) {
    if (!m) continue;
    const role = String(m.role).toLowerCase();
    if (role !== "assistant" && role !== "model") continue;
    if (Array.isArray(m.tool_calls)) {
      for (const tc of m.tool_calls) {
        if (tc?.id && tc.function?.name) {
          toolIdToName.set(tc.id, tc.function.name);
        }
      }
    }
    // Anthropic content-level tool_use
    if (Array.isArray(m.content)) {
      for (const p of m.content) {
        if (p?.type === "tool_use" && p.id && p.name) {
          toolIdToName.set(p.id, p.name);
        }
      }
    }
  }

  // ---- contents normalization ----
  const contents: GeminiContent[] = [];

  let idx = 0;
  while (idx < input.messages.length) {
    const msg = input.messages[idx];
    if (!msg) {
      idx++;
      continue;
    }
    const roleRaw = String(msg.role ?? "").toLowerCase();
    if (roleRaw === "system") {
      idx++;
      continue; // already aggregated
    }

    // USER path
    if (roleRaw === "user") {
      const parts: GeminiPart[] = [];
      const content = msg.content;

      if (typeof content === "string") {
        if (content.trim()) parts.push({ text: content });
      } else if (Array.isArray(content)) {
        for (const p of content) {
          if (!p) continue;
          // text
          if (p.type === "text" && typeof p.text === "string") {
            if (p.text.trim()) parts.push({ text: p.text });
          } else if (p.type === "thinking" || p.type === "reasoning") {
            const txt = (p as any).thinking ?? (p as any).text ?? "";
            const sig = (p as any).signature ?? (p as any).thoughtSignature;
            if (txt) parts.push(mapThinkingBlock(String(txt), sig ? String(sig) : undefined));
          } else if (p.type === "image_url" && p.image_url?.url) {
            const url = String(p.image_url.url);
            const parsed = parseDataUri(url);
            if (parsed) {
              parts.push({ inlineData: { mimeType: parsed.mimeType, data: parsed.data } });
            } else {
              // For remote URL, keep as text reference — Antigravity expects inlineData only,
              // so we include placeholder text; downstream may fetch via url_context tool
              parts.push({ text: `[Image: ${url}]` });
            }
          } else if (p.type === "image" && p.source) {
            const src = p.source;
            if (src.type === "base64" && src.data) {
              parts.push({
                inlineData: {
                  mimeType: src.media_type ?? "image/png",
                  data: String(src.data),
                },
              });
            }
          } else if (p.type === "tool_result" || p.type === "tool_use_result" || (p.tool_use_id || p.tool_result)) {
            // Anthropic tool_result inside user message
            const toolUseId = p.tool_use_id ?? p.tool_useId ?? p.id ?? "";
            const prevName = toolIdToName.get(String(toolUseId)) ?? p.name ?? "tool_result";
            const sanitizedName = sanitizeToolName(String(prevName));
            let responseObj: Record<string, any>;
            const rawContent = p.content ?? p.result ?? "";
            if (typeof rawContent === "string") {
              try {
                const parsed = JSON.parse(rawContent);
                responseObj = typeof parsed === "object" && parsed !== null ? parsed : { result: String(parsed) };
              } catch {
                responseObj = { result: String(rawContent) };
              }
            } else if (typeof rawContent === "object" && rawContent !== null) {
              responseObj = rawContent as Record<string, any>;
            } else {
              responseObj = { result: String(rawContent ?? "") };
            }
            parts.push({ functionResponse: { name: sanitizedName, response: responseObj } });
          } else if (typeof p === "object" && "text" in p && typeof (p as any).text === "string") {
            if (String((p as any).text).trim()) parts.push({ text: String((p as any).text) });
          }
        }
      } else if (content && typeof content === "object") {
        // Single part object
        if ("text" in (content as any) && typeof (content as any).text === "string") {
          const t = String((content as any).text).trim();
          if (t) parts.push({ text: t });
        }
      }

      if (parts.length > 0) {
        contents.push({ role: "user", parts: sortThoughtFirst(parts) });
      }
      idx++;
      continue;
    }

    // ASSISTANT / MODEL path
    if (roleRaw === "assistant" || roleRaw === "model") {
      const parts: GeminiPart[] = [];
      const content = msg.content;

      if (typeof content === "string") {
        if (content.trim()) parts.push({ text: content });
      } else if (Array.isArray(content)) {
        for (const p of content) {
          if (!p) continue;
          if (p.type === "text" && typeof p.text === "string") {
            if (p.text.trim()) parts.push({ text: p.text });
          } else if (p.type === "thinking" || p.type === "reasoning") {
            const txt = (p as any).thinking ?? (p as any).text ?? (p as any).reasoning ?? "";
            const sig = (p as any).signature ?? (p as any).thoughtSignature;
            if (txt) parts.push(mapThinkingBlock(String(txt), sig ? String(sig) : undefined));
          } else if (p.type === "tool_use") {
            const rawName = String(p.name ?? "");
            const sanitized = sanitizeToolName(rawName);
            const args = parseFunctionArgs(p.input ?? p.input_schema ?? {});
            parts.push({ functionCall: { name: sanitized, args } });
            if (p.id && rawName) toolIdToName.set(String(p.id), rawName);
          } else if (p.type === "image" || p.type === "image_url") {
            // Assistant rarely sends images, but handle
            if (p.type === "image_url" && p.image_url?.url) {
              const parsed = parseDataUri(String(p.image_url.url));
              if (parsed) parts.push({ inlineData: { mimeType: parsed.mimeType, data: parsed.data } });
            }
          } else if (typeof p === "object" && "text" in p && typeof (p as any).text === "string") {
            if (String((p as any).text).trim()) parts.push({ text: String((p as any).text) });
          }
        }
      }

      // OpenAI tool_calls array
      if (Array.isArray(msg.tool_calls)) {
        for (const tc of msg.tool_calls) {
          if (!tc) continue;
          const rawName = tc.function?.name ?? "";
          if (!rawName) continue;
          const sanitized = sanitizeToolName(String(rawName));
          const args = parseFunctionArgs(tc.function?.arguments ?? {});
          parts.push({ functionCall: { name: sanitized, args } });
          if (tc.id) toolIdToName.set(tc.id, rawName);
        }
      }

      // Handle anthropic content that may be tool_result inside assistant? Shouldn't, but skip

      if (parts.length > 0) {
        contents.push({ role: "model", parts: sortThoughtFirst(parts) });
      } else {
        // If assistant message empty but has tool_calls previously handled, still push if parts exist
        if (parts.length === 0 && msg.content === null) {
          // no op — avoid empty content which Gemini rejects
        }
      }

      idx++;
      continue;
    }

    // TOOL role — OpenAI explicit tool result messages grouping
    if (roleRaw === "tool") {
      const aggregated: GeminiPart[] = [];
      while (idx < input.messages.length) {
        const cur = input.messages[idx];
        if (!cur) {
          idx++;
          continue;
        }
        if (String(cur.role).toLowerCase() !== "tool") break;
        const toolCallId = String(cur.tool_call_id ?? cur.tool_use_id ?? cur.id ?? "");
        const nameFromMap = toolIdToName.get(toolCallId);
        const rawName = cur.name ?? nameFromMap ?? toolCallId ?? "tool_result";
        const sanitized = sanitizeToolName(String(rawName));
        const rawContent = cur.content;
        let responseObj: Record<string, any>;
        if (typeof rawContent === "string") {
          try {
            const parsed = JSON.parse(rawContent);
            responseObj = typeof parsed === "object" && parsed !== null ? parsed : { result: String(parsed) };
          } catch {
            responseObj = { result: rawContent };
          }
        } else if (rawContent && typeof rawContent === "object") {
          responseObj = rawContent as Record<string, any>;
        } else {
          responseObj = { result: String(rawContent ?? "") };
        }
        aggregated.push({ functionResponse: { name: sanitized, response: responseObj } });
        idx++;
      }
      if (aggregated.length > 0) {
        contents.push({ role: "user", parts: aggregated });
      }
      continue;
    }

    // Unknown role — treat as user text
    {
      const c = msg.content;
      let txt = "";
      if (typeof c === "string") txt = c;
      else {
        try {
          txt = JSON.stringify(c);
        } catch {
          txt = String(c ?? "");
        }
      }
      if (txt.trim()) {
        contents.push({ role: "user", parts: [{ text: txt.trim() }] });
      }
      idx++;
      continue;
    }
  }

  if (contents.length === 0) {
    throw new RequestTransformationError("no valid contents produced from messages", "EMPTY_CONTENTS");
  }

  // Ensure first content is user (Gemini requires user first) — if first is model, insert placeholder user
  if (contents[0].role !== "user") {
    // Prepend empty user? Better prepend user instruction referencing system? For safety, insert user with system texts if available
    const fallbackText = systemInstruction?.parts?.[0]?.text?.slice(0, 500) ?? "Hello";
    contents.unshift({ role: "user", parts: [{ text: fallbackText }] });
  }

  // ---- tools handling — clean schemas, sanitize names, inject google_search ----
  let existingDeclsInput = input.tools ?? [];
  const sanitizedResult = validateAndSanitizeTools(existingDeclsInput as any[]);
  let declarations = sanitizedResult.declarations;

  const googleSearchEnabled = Boolean(input.googleSearchEnabled);
  const beforeInjectCount = declarations.length;
  declarations = injectGoogleSearchTool(declarations, googleSearchEnabled, false);
  const googleSearchInjected = declarations.length > beforeInjectCount;

  let tools: GeminiTool[] | null = null;
  if (declarations.length > 0) {
    tools = [
      {
        functionDeclarations: declarations.map((d) => ({
          name: d.name,
          description: d.description,
          parameters: d.parameters,
        })),
      },
    ];
  }

  // ---- generation config ----
  let generationConfig: Record<string, any> | null = null;
  const baseGen = input.generationConfig && typeof input.generationConfig === "object" ? { ...input.generationConfig } : {};

  // Merge thinking budget
  if (thinkingBudget !== undefined) {
    baseGen.thinkingConfig = baseGen.thinkingConfig ?? {};
    if (typeof baseGen.thinkingConfig === "object") {
      (baseGen.thinkingConfig as any).thinkingBudget = thinkingBudget;
      (baseGen.thinkingConfig as any).includeThoughts = true;
    }
    // Also legacy field some routers check
    (baseGen as any).thinkingBudget = thinkingBudget;
  }

  if (Object.keys(baseGen).length > 0) {
    generationConfig = baseGen;
  } else if (thinkingBudget !== undefined) {
    generationConfig = {
      thinkingConfig: {
        thinkingBudget,
        includeThoughts: true,
      },
    };
  }

  // ---- deterministic session_id / user_prompt_id via FNV-1a ----
  // Seed for session: model + full messages JSON (stable)
  let sessionSeed: string;
  if (input.sessionSeed && typeof input.sessionSeed === "string" && input.sessionSeed.trim()) {
    sessionSeed = input.sessionSeed.trim();
  } else {
    try {
      // Deterministic hash of model + messages — slice to avoid huge string but FNV handles large
      const raw = `${originalModel}|${JSON.stringify(input.messages).slice(0, 20000)}`;
      sessionSeed = raw;
    } catch {
      sessionSeed = `${originalModel}|fallback-session-${Date.now()}`;
    }
  }

  let userPromptSeed: string;
  if (input.userPromptSeed && typeof input.userPromptSeed === "string" && input.userPromptSeed.trim()) {
    userPromptSeed = input.userPromptSeed.trim();
  } else {
    userPromptSeed = extractLastUserPrompt(input.messages);
  }

  const sessionId = generateSessionId(sessionSeed);
  const userPromptId = generateUserPromptId(userPromptSeed);

  // ---- final normalized object ----
  const transformed: TransformedRequest = {
    model: modelForGemini, // normalized base without antigravity- prefix — cloudcode-pa accepts both
    originalModel,
    contents,
    systemInstruction,
    tools,
    generationConfig,
    sessionId,
    userPromptId,
    thinkingBudget,
    thinkingLevel,
    isGeminiCLIOnly: isCliOnly,
    googleSearchInjected,
  };

  return transformed;
}

// ---------------------------------------------------------------------------
// Build envelope for cloudcode-pa — endpoint cascade, headers, body
// ---------------------------------------------------------------------------

/**
 * Builds common headers for Antigravity request.
 *
 * @param opts - options containing token, version
 * @param style - header style
 * @returns headers ready for fetch
 */
function buildCommonHeaders(
  opts: { accessToken: string; userAgent?: string; version?: string },
  style: "antigravity" | "gemini-cli",
): Record<string, string> {
  if (!opts.accessToken || typeof opts.accessToken !== "string" || !opts.accessToken.trim()) {
    throw new RequestTransformationError("accessToken required for build request", "MISSING_TOKEN");
  }
  const fingerprint = getFingerprintHeaders(style, opts.version);
  const headers: Record<string, string> = {
    ...fingerprint,
    Authorization: `Bearer ${opts.accessToken.trim()}`,
  };
  // Override User-Agent if custom provided
  if (opts.userAgent && typeof opts.userAgent === "string" && opts.userAgent.trim()) {
    headers["User-Agent"] = opts.userAgent.trim();
  }
  return stripForbiddenHeaders(headers);
}

/**
 * Constructs the full JSON body for cloudcode-pa.
 * Shape observed from Antigravity Manager binary analysis:
 * {
 *   project: "projects/{id}" or raw id,
 *   request: { model, contents, systemInstruction, tools, generationConfig },
 *   sessionId, userPromptId
 * }
 * Plus deterministic ids.
 *
 * @param projectId - cloud project id
 * @param inner - transformed inner request
 * @returns body object
 */
function buildCloudCodeBody(projectId: string, inner: TransformedRequest): Record<string, any> {
  if (!projectId || typeof projectId !== "string" || !projectId.trim()) {
    throw new RequestTransformationError("projectId required for cloudcode body", "MISSING_PROJECT");
  }
  const pid = projectId.trim();

  // The API tolerates both bare id and projects/{id} — we send bare but allow projects/ prefix passthrough
  const projectField = pid.startsWith("projects/") ? pid : pid;

  const requestField: Record<string, any> = {
    model: inner.originalModel, // send original to preserve routing (antigravity- prefix useful for Claude)
    contents: inner.contents,
  };

  if (inner.systemInstruction) {
    requestField.systemInstruction = inner.systemInstruction;
  }
  if (inner.tools) {
    requestField.tools = inner.tools;
  }
  if (inner.generationConfig) {
    requestField.generationConfig = inner.generationConfig;
  }

  const body: Record<string, any> = {
    project: projectField,
    request: requestField,
    sessionId: inner.sessionId,
    userPromptId: inner.userPromptId,
  };

  return body;
}

/**
 * Builds Antigravity request for direct cloudcode-pa call.
 * Uses endpoint cascade: PROD → DAILY → SANDBOX.
 * Skips sandbox automatically when model is gemini-cli only (preview/gemini-3) per #233.
 * Strips x-goog-user-project header to avoid 403.
 *
 * Third-person observer: mimics Antigravity Manager direct fetch, no localhost v1 proxy.
 *
 * @param options - build options with projectId, accessToken, messages, model etc.
 * @returns BuildResult with url, endpoints, headers, body, deterministic ids
 */
export function buildAntigravityRequest(options: BuildOptions): BuildResult {
  if (!options || typeof options !== "object") {
    throw new RequestTransformationError("build options required", "INVALID_OPTIONS");
  }

  const projectId = String(options.projectId ?? "").trim() || PROJECT_FALLBACK;
  const token = String(options.accessToken ?? "").trim();
  if (!token) throw new RequestTransformationError("accessToken required", "MISSING_TOKEN");

  const model = String(options.model ?? "").trim();
  if (!model) throw new RequestTransformationError("model required", "INVALID_MODEL");

  // Transform inner request first
  const inner = transformRequest({
    model: options.model,
    messages: options.messages,
    tools: options.tools,
    system: options.system,
    thinkingLevel: options.thinkingLevel,
    thinkingBudget: options.thinkingBudget,
    googleSearchEnabled: options.googleSearchEnabled,
    generationConfig: options.generationConfig,
    sessionSeed: options.sessionSeed,
    userPromptSeed: options.userPromptSeed,
    projectId,
  });

  const bases = getEndpointsForModel(model, options.endpointOverrides);
  const fullEndpoints = bases.map((b) => `${b.replace(/\/+$/, "")}${options.methodSuffix ?? STREAM_METHOD}`);

  const version = options.antigravityVersion ?? ANTIGRAVITY_VERSION_FALLBACK;
  const headers = buildCommonHeaders({ accessToken: token, userAgent: options.userAgent, version }, "antigravity");

  const body = buildCloudCodeBody(projectId, inner);

  return {
    url: fullEndpoints[0],
    endpoints: fullEndpoints,
    baseEndpoints: bases,
    headers,
    body,
    sessionId: inner.sessionId,
    userPromptId: inner.userPromptId,
    isGeminiCLIOnly: inner.isGeminiCLIOnly,
    method: "POST",
    innerRequest: inner,
  };
}

/**
 * Builds Gemini CLI request — prod-only, includes X-Goog-Api-Client.
 * Observer enforces skip sandbox for gemini-cli models (gemini-3, preview) to avoid 404/403 cascade.
 * Same body shape as Antigravity but different fingerprint headers and endpoint list.
 *
 * @param options - build options
 * @returns BuildResult with cli-style headers
 */
export function buildGeminiCLIRequest(options: BuildOptions): BuildResult {
  if (!options || typeof options !== "object") {
    throw new RequestTransformationError("build options required for Gemini CLI", "INVALID_OPTIONS");
  }

  const projectId = String(options.projectId ?? "").trim() || PROJECT_FALLBACK;
  const token = String(options.accessToken ?? "").trim();
  if (!token) throw new RequestTransformationError("accessToken required", "MISSING_TOKEN");

  const model = String(options.model ?? "").trim();
  if (!model) throw new RequestTransformationError("model required for Gemini CLI", "INVALID_MODEL");

  const inner = transformRequest({
    model: options.model,
    messages: options.messages,
    tools: options.tools,
    system: options.system,
    thinkingLevel: options.thinkingLevel,
    thinkingBudget: options.thinkingBudget,
    googleSearchEnabled: options.googleSearchEnabled,
    generationConfig: options.generationConfig,
    sessionSeed: options.sessionSeed,
    userPromptSeed: options.userPromptSeed,
    projectId,
  });

  // For CLI, force prod (+ daily) only, explicitly stripping sandbox even if overrides contain it
  const rawBases = getEndpointsForModel(model, options.endpointOverrides);
  const filteredBases = rawBases.filter((b) => !b.toLowerCase().includes("sandbox"));
  // Ensure at least PROD present
  const bases = filteredBases.length > 0 ? filteredBases : [ENDPOINTS.PROD];

  const fullEndpoints = bases.map((b) => `${b.replace(/\/+$/, "")}${options.methodSuffix ?? STREAM_METHOD}`);

  const version = options.antigravityVersion ?? ANTIGRAVITY_VERSION_FALLBACK;
  const headers = buildCommonHeaders({ accessToken: token, userAgent: options.userAgent, version }, "gemini-cli");

  const body = buildCloudCodeBody(projectId, inner);

  return {
    url: fullEndpoints[0],
    endpoints: fullEndpoints,
    baseEndpoints: bases,
    headers,
    body,
    sessionId: inner.sessionId,
    userPromptId: inner.userPromptId,
    isGeminiCLIOnly: true, // gemini-cli path always considered cli-only for routing
    method: "POST",
    innerRequest: inner,
  };
}

// ---------------------------------------------------------------------------
// Convenience: fetch with cascade (optional helper for plugin.ts integration)
// ---------------------------------------------------------------------------

/**
 * Attempts fetch across endpoint cascade with retry on 403/404/5xx.
 * Observer implements fallback rising-fact-p41fc style but does not hardcode fallback here —
 * caller (plugin.ts) should decide fallback.
 *
 * Stripping x-goog-user-project is done before each attempt.
 * Only uses node:* builtins + global fetch.
 *
 * @param buildResult - result from buildAntigravityRequest or buildGeminiCLIRequest
 * @param fetchOptions - optional extra fetch options (signal etc)
 * @returns Response from first successful endpoint
 * @throws last error if all endpoints fail
 */
export async function fetchWithCascade(
  buildResult: BuildResult,
  fetchOptions?: { signal?: AbortSignal; timeoutMs?: number },
): Promise<Response> {
  if (!buildResult || !Array.isArray(buildResult.endpoints) || buildResult.endpoints.length === 0) {
    throw new RequestTransformationError("buildResult with endpoints required", "INVALID_BUILD_RESULT");
  }

  let lastError: Error | null = null;

  for (const endpointUrl of buildResult.endpoints) {
    const controller = new AbortController();
    const timeoutMs = fetchOptions?.timeoutMs ?? 15000;
    const to = setTimeout(() => controller.abort(), timeoutMs);

    // Merge signals if provided
    const signal = fetchOptions?.signal
      ? (() => {
          // Create combined abort: if external signal aborts, abort internal
          const combined = new AbortController();
          const onExternalAbort = () => combined.abort();
          fetchOptions.signal!.addEventListener("abort", onExternalAbort, { once: true });
          // Also propagate internal timeout abort
          controller.signal.addEventListener("abort", () => combined.abort());
          return combined.signal;
        })()
      : controller.signal;

    try {
      // Apply jitter 0-80ms anti-rate-limit (AM behavior)
      try {
        const jitter = randomInt(0, 81);
        if (jitter > 0) await new Promise((r) => setTimeout(r, jitter));
      } catch {
        // Math fallback never throws
        const jitter = Math.floor(Math.random() * 81);
        if (jitter > 0) await new Promise((r) => setTimeout(r, jitter));
      }

      const headers = stripForbiddenHeaders(buildResult.headers);

      const res = await fetch(endpointUrl, {
        method: buildResult.method,
        headers,
        body: JSON.stringify(buildResult.body),
        signal,
      });

      // Retryable status: 403/404/5xx indicates need to try next endpoint (cascade)
      if (res.status === 403 || res.status === 404 || res.status >= 500) {
        lastError = new Error(`cascade retryable status ${res.status} at ${endpointUrl}`);
        // Continue to next endpoint
        continue;
      }

      clearTimeout(to);
      return res;
    } catch (e: any) {
      clearTimeout(to);
      // If abort or network error, store and try next
      lastError = e instanceof Error ? e : new Error(String(e));
      // If signal aborted externally, stop cascade immediately
      if (fetchOptions?.signal?.aborted) throw lastError;
      continue;
    } finally {
      clearTimeout(to);
    }
  }

  throw lastError ?? new Error("all endpoints failed in cascade");
}

// ---------------------------------------------------------------------------
// Barrel exports — library-first
// ---------------------------------------------------------------------------

export const RequestPipeline = {
  transformRequest,
  buildAntigravityRequest,
  buildGeminiCLIRequest,
  isGeminiCLIOnlyModel,
  getEndpointsForModel,
  fnv1a32,
  fnv1a32Hex,
  generateDeterministicId,
  generateSessionId,
  generateUserPromptId,
  sanitizeToolName,
  ensureUniqueToolNames,
  validateAndSanitizeTools,
  cleanJsonSchema,
  mapThinkingBlock,
  sortThoughtFirst,
  filterAndMapThinkingParts,
  injectGoogleSearchTool,
  stripForbiddenHeaders,
  stripXGoogUserProjectHeader,
  getFingerprintHeaders,
  buildDynamicUserAgent,
  fetchWithCascade,
  parseModelId,
  extractThinkingLevel,
};

export default RequestPipeline;
